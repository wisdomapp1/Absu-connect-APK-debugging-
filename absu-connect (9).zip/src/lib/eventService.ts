import { supabase } from './supabase.ts';
import type { CampusEvent, CreateEventInput, EventResponse, EventParticipant } from '../types/events.ts';
import { safeStorage } from '../utils/safeStorage.ts';
import { uploadEventFlyerToStorage } from './storageService.ts';

function purgeLegacyLocalEventCache() {
  try {
    safeStorage.removeItem('absu_local_events');
    safeStorage.removeItem('absu_local_event_responses');
  } catch {
    // ignore
  }
}

async function getAuthHeaders(includeJson = true): Promise<Record<string, string>> {
  const headers: Record<string, string> = {};
  if (includeJson) headers['Content-Type'] = 'application/json';
  try {
    const { data } = await supabase.auth.getSession();
    if (data?.session?.access_token) {
      headers['Authorization'] = `Bearer ${data.session.access_token}`;
    }
  } catch {
    // ignore
  }
  return headers;
}

export async function fetchCampusEvents(params?: {
  category?: string;
  search?: string;
  tab?: 'all' | 'today' | 'saved' | 'my';
  userId?: string;
}): Promise<CampusEvent[]> {
  purgeLegacyLocalEventCache();
  try {
    const qs = new URLSearchParams();
    if (params?.userId) qs.set('userId', params.userId);
    if (params?.category) qs.set('category', params.category);
    if (params?.search) qs.set('search', params.search);
    if (params?.tab) qs.set('tab', params.tab);

    const headers = await getAuthHeaders(false);
    const res = await fetch(`/api/events?${qs.toString()}`, { headers });
    if (res.ok) {
      const json = await res.json();
      if (json.success && Array.isArray(json.events)) {
        return json.events;
      }
    }
  } catch {
    // fallback below
  }

  try {
    const { data, error } = await supabase
      .from('campus_events')
      .select('*')
      .neq('status', 'draft')
      .order('start_time', { ascending: true })
      .limit(100);
    if (error || !data) return [];

    return data.map((row: any) => ({
      id: row.id,
      title: row.title,
      description: row.description || '',
      category: row.category || 'Academic',
      organizerId: row.organizer_id,
      organizerName: row.organizer_name || 'ABSU Organizer',
      venue: row.venue || 'ABSU Uturu',
      campus: row.campus || 'Uturu (Main Campus)',
      startTime: row.start_time,
      endTime: row.end_time || undefined,
      posterUrl: row.poster_url || undefined,
      status: row.status || 'published',
      visibility: row.visibility === 'campus_only' ? 'campus_only' : 'public',
      registrationLink: row.registration_link || undefined,
      interestedCount: Number(row.interested_count || 0),
      goingCount: Number(row.going_count || 0),
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      isOrganizer: Boolean(params?.userId && row.organizer_id === params.userId),
    }));
  } catch {
    return [];
  }
}

export async function fetchEventById(eventId: string, userId?: string): Promise<CampusEvent | null> {
  purgeLegacyLocalEventCache();
  if (!eventId) return null;
  try {
    const qs = userId ? `?userId=${encodeURIComponent(userId)}` : '';
    const headers = await getAuthHeaders(false);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}${qs}`, { headers });
    if (res.ok) {
      const json = await res.json();
      if (json.success && json.event) return json.event;
    }
  } catch {
    // ignore
  }
  return null;
}

export async function createCampusEvent(
  input: CreateEventInput,
  organizerId: string,
  posterFile?: File
): Promise<{ success: boolean; event?: CampusEvent; error?: string }> {
  try {
    let posterUrl = input.posterUrl;
    if (posterFile) {
      const upRes = await uploadEventFlyerToStorage(organizerId, posterFile);
      if (!upRes.success || !upRes.url) {
        return { success: false, error: upRes.error || 'Failed to upload event flyer.' };
      }
      posterUrl = upRes.url;
    }

    const headers = await getAuthHeaders(true);
    const res = await fetch('/api/events', {
      method: 'POST',
      headers,
      body: JSON.stringify({ ...input, posterUrl, organizerId }),
    });
    const json = await res.json();
    if (res.ok && json.success && json.event) {
      return { success: true, event: json.event };
    }
    return { success: false, error: json.error || 'Failed to publish campus event.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to create event.' };
  }
}

export async function respondToEvent(
  eventId: string,
  userId: string,
  response: EventResponse | null
): Promise<{ success: boolean; interestedCount: number; goingCount: number; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}/respond`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId, response }),
    });
    const json = await res.json();
    if (res.ok && json.success) {
      return {
        success: true,
        interestedCount: Number(json.interestedCount || 0),
        goingCount: Number(json.goingCount || 0),
      };
    }
    return { success: false, interestedCount: 0, goingCount: 0, error: json.error };
  } catch (err: unknown) {
    return {
      success: false,
      interestedCount: 0,
      goingCount: 0,
      error: err instanceof Error ? err.message : 'Failed to RSVP.',
    };
  }
}

export async function toggleSaveEvent(
  eventId: string,
  userId: string,
  isSaved: boolean
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}/save`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId, isSaved }),
    });
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to save event.' };
  }
}

export async function cancelCampusEvent(
  eventId: string,
  organizerId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}/cancel`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ organizerId }),
    });
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to cancel event.' };
  }
}

export async function editCampusEvent(
  eventId: string,
  input: Partial<CreateEventInput>,
  organizerId: string
): Promise<{ success: boolean; event?: CampusEvent; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ ...input, organizerId }),
    });
    const json = await res.json();
    if (res.ok && json.success && json.event) {
      return { success: true, event: json.event };
    }
    return { success: false, error: json.error || 'Failed to update event.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to update event.' };
  }
}

export async function fetchEventParticipants(eventId: string): Promise<EventParticipant[]> {
  try {
    const headers = await getAuthHeaders(false);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}/participants`, { headers });
    if (res.ok) {
      const json = await res.json();
      if (json.success && Array.isArray(json.participants)) {
        return json.participants;
      }
    }
  } catch {
    // ignore
  }
  return [];
}

export async function fetchOrganizerDashboard(organizerId: string): Promise<{
  totalEvents: number;
  totalInterested: number;
  totalGoing: number;
  events: CampusEvent[];
}> {
  try {
    const headers = await getAuthHeaders(false);
    const res = await fetch(
      `/api/events/organizer/dashboard?organizerId=${encodeURIComponent(organizerId)}`,
      { headers }
    );
    if (res.ok) {
      const json = await res.json();
      if (json.success) {
        return {
          totalEvents: Number(json.totalEvents || 0),
          totalInterested: Number(json.totalInterested || 0),
          totalGoing: Number(json.totalGoing || 0),
          events: json.events || [],
        };
      }
    }
  } catch {
    // ignore
  }
  return { totalEvents: 0, totalInterested: 0, totalGoing: 0, events: [] };
}

export async function deleteCampusEvent(
  eventId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/events/${encodeURIComponent(eventId)}`, {
      method: 'DELETE',
      headers,
      body: JSON.stringify({ userId }),
    });
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to archive event.' };
  }
}

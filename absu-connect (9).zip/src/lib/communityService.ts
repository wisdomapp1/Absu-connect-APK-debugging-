import { supabase } from './supabase.ts';
import type {
  Community,
  CommunityMember,
  CreateCommunityInput,
  UpdateCommunityInput,
  CommunityRole,
  CommunityCategory,
} from '../types/communities.ts';
import type { Post, AttachedMediaItem } from '../types/index.ts';
import { safeStorage } from '../utils/safeStorage.ts';
import { fetchCommunityPostsFromSupabase, createRealPost, PostMediaAttachment } from './postService.ts';
import { uploadPostMediaToSupabaseStorage, deletePostMediaFilesFromStorage } from './storageService.ts';

function purgeLegacyLocalCommunityCache() {
  try {
    safeStorage.removeItem('absu_local_communities');
  } catch {
    // ignore
  }
}

async function getAuthHeaders(includeJson = true): Promise<Record<string, string>> {
  const headers: Record<string, string> = {};
  if (includeJson) headers['Content-Type'] = 'application/json';
  try {
    const { data } = await supabase.auth.getSession();
    if (data?.session?.access_token) {
      headers['Authorization'] = `Bearer ${data.session.access_token}`;
    }
  } catch {
    // ignore
  }
  return headers;
}

export function mapSupabaseRowToCommunity(row: any, _currentUserId?: string, membership?: any): Community {
  const rulesList = Array.isArray(row?.rules_list)
    ? row.rules_list
    : typeof row?.rules === 'string' && row.rules.trim()
    ? row.rules.split('\n').map((s: string) => s.trim()).filter(Boolean)
    : [];

  return {
    id: row?.id || '',
    name: row?.name || 'ABSU Community',
    slug: row?.slug || 'community',
    description: row?.description || '',
    category: (row?.category || 'General') as CommunityCategory,
    imageUrl: row?.image_url || '',
    coverUrl: row?.cover_image_url || '',
    location: row?.location || 'Uturu Main Campus',
    privacy: row?.privacy === 'private' ? 'private' : 'public',
    creatorId: row?.creator_id || '',
    rules: row?.rules || rulesList.join('\n'),
    rulesList,
    membersCount: Number(row?.members_count || 0),
    status: row?.status || 'active',
    isVerified: Boolean(row?.is_verified),
    createdAt: row?.created_at || new Date().toISOString(),
    updatedAt: row?.updated_at || new Date().toISOString(),
    isMember: membership ? membership.status === 'active' || membership.status === 'approved' : Boolean(row?.isMember),
    userRole: membership?.role || row?.userRole,
    membershipStatus: membership?.status || row?.membershipStatus,
  };
}

export async function fetchCommunities(params?: {
  category?: string;
  search?: string;
  tab?: 'discover' | 'my' | 'managed';
  userId?: string;
}): Promise<Community[]> {
  purgeLegacyLocalCommunityCache();
  try {
    const qs = new URLSearchParams();
    if (params?.userId) qs.set('userId', params.userId);
    if (params?.category) qs.set('category', params.category);
    if (params?.search) qs.set('search', params.search);
    if (params?.tab) qs.set('tab', params.tab);

    const headers = await getAuthHeaders(false);
    const res = await fetch(`/api/communities?${qs.toString()}`, { headers });
    if (res.ok) {
      const json = await res.json();
      if (json.success && Array.isArray(json.communities)) {
        return json.communities;
      }
    }
  } catch {
    // Fallback to direct Supabase query
  }

  try {
    const { data, error } = await supabase
      .from('communities')
      .select('*')
      .neq('status', 'archived')
      .order('members_count', { ascending: false })
      .limit(100);

    if (error || !data) return [];

    const membershipsMap = new Map<string, any>();
    if (params?.userId) {
      const { data: mems } = await supabase
        .from('community_members')
        .select('community_id, role, status')
        .eq('user_id', params.userId);
      for (const m of mems || []) membershipsMap.set(m.community_id, m);
    }

    let list = data.map((row: any) => mapSupabaseRowToCommunity(row, params?.userId, membershipsMap.get(row.id)));
    if (params?.category && params.category !== 'All') {
      list = list.filter((c) => c.category === params.category);
    }
    if (params?.search) {
      const q = params.search.trim().toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.category.toLowerCase().includes(q)
      );
    }
    if (params?.tab === 'my' && params?.userId) {
      list = list.filter((c) => c.isMember || c.creatorId === params.userId);
    } else if (params?.tab === 'managed' && params?.userId) {
      list = list.filter((c) => c.creatorId === params.userId || c.userRole === 'owner' || c.userRole === 'admin');
    }
    return list;
  } catch {
    return [];
  }
}

export async function fetchCommunityById(
  communityId: string,
  currentUserId?: string
): Promise<Community | null> {
  purgeLegacyLocalCommunityCache();
  if (!communityId) return null;
  try {
    const qs = currentUserId ? `?userId=${encodeURIComponent(currentUserId)}` : '';
    const headers = await getAuthHeaders(false);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}${qs}`, { headers });
    if (res.ok) {
      const json = await res.json();
      if (json.success && json.community) {
        return json.community;
      }
    }
  } catch {
    // Fallback below
  }

  try {
    const { data, error } = await supabase.from('communities').select('*').eq('id', communityId).maybeSingle();
    if (error || !data) return null;
    let membership: any = null;
    if (currentUserId) {
      const { data: mem } = await supabase
        .from('community_members')
        .select('role, status')
        .eq('community_id', communityId)
        .eq('user_id', currentUserId)
        .maybeSingle();
      membership = mem;
    }
    return mapSupabaseRowToCommunity(data, currentUserId, membership);
  } catch {
    return null;
  }
}

export async function createCommunity(
  input: CreateCommunityInput,
  creatorId: string
): Promise<{ success: boolean; community?: Community; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch('/api/communities', {
      method: 'POST',
      headers,
      body: JSON.stringify({ ...input, creatorId }),
    });
    const json = await res.json();
    if (res.ok && json.success && json.community) {
      return { success: true, community: json.community };
    }
    return { success: false, error: json.error || 'Failed to create community.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to create community.' };
  }
}

export async function updateCommunity(
  communityId: string,
  updates: UpdateCommunityInput,
  currentUserId: string
): Promise<{ success: boolean; community?: Community; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ ...updates, currentUserId }),
    });
    const json = await res.json();
    if (res.ok && json.success && json.community) {
      return { success: true, community: json.community };
    }
    return { success: false, error: json.error || 'Failed to update community.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to update community.' };
  }
}

export async function deleteCommunity(
  communityId: string,
  currentUserId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}`, {
      method: 'DELETE',
      headers,
      body: JSON.stringify({ currentUserId }),
    });
    const json = await res.json();
    return res.ok && json.success
      ? { success: true }
      : { success: false, error: json.error || 'Failed to archive community.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to archive community.' };
  }
}

export async function joinCommunity(
  communityId: string,
  userId: string
): Promise<{ success: boolean; status?: 'active' | 'pending'; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}/join`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId }),
    });
    const json = await res.json();
    if (res.ok && json.success) {
      return { success: true, status: json.status || 'active' };
    }
    return { success: false, error: json.error || 'Failed to join community.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to join community.' };
  }
}

export async function leaveCommunity(
  communityId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}/leave`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId }),
    });
    const json = await res.json();
    return res.ok && json.success
      ? { success: true }
      : { success: false, error: json.error || 'Failed to leave community.' };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to leave community.' };
  }
}

export async function fetchCommunityMembers(communityId: string): Promise<CommunityMember[]> {
  try {
    const headers = await getAuthHeaders(false);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}/members`, { headers });
    if (res.ok) {
      const json = await res.json();
      if (json.success && Array.isArray(json.members)) {
        return json.members;
      }
    }
  } catch {
    // ignore
  }
  return [];
}

export async function updateMemberRole(
  communityId: string,
  targetUserId: string,
  newRole: CommunityRole,
  currentUserId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}/manage-request`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ targetUserId, action: 'role', role: newRole, currentUserId }),
    });
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to update role.' };
  }
}

export async function removeMember(
  communityId: string,
  targetUserId: string,
  currentUserId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}/manage-request`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ targetUserId, action: 'remove', currentUserId }),
    });
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to remove member.' };
  }
}

export async function manageMembershipRequest(
  communityId: string,
  targetUserId: string,
  action: 'approve' | 'reject',
  currentUserId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(`/api/communities/${encodeURIComponent(communityId)}/manage-request`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ targetUserId, action, currentUserId }),
    });
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to manage request.' };
  }
}

export async function fetchCommunityPosts(communityId: string, currentUserId?: string): Promise<Post[]> {
  return fetchCommunityPostsFromSupabase(communityId, currentUserId);
}

export async function createCommunityPost(
  communityId: string,
  authorId: string,
  content: string,
  attachments: AttachedMediaItem[] = []
): Promise<{ success: boolean; post?: Post; error?: string }> {
  const uploadedPaths: string[] = [];
  const mediaList: PostMediaAttachment[] = [];

  try {
    for (let i = 0; i < attachments.length; i++) {
      const item = attachments[i];
      if (!item.file) continue;
      const uploadRes = await uploadPostMediaToSupabaseStorage(authorId, item.file);
      if (!uploadRes.success || !uploadRes.media) {
        if (uploadedPaths.length > 0) await deletePostMediaFilesFromStorage(uploadedPaths);
        return { success: false, error: uploadRes.error || 'Failed to upload post media.' };
      }
      uploadedPaths.push(uploadRes.media.asset_id);
      mediaList.push({
        secure_url: uploadRes.media.secure_url,
        asset_id: uploadRes.media.asset_id,
        format: uploadRes.media.format,
        bytes: uploadRes.media.bytes,
        width: uploadRes.media.width,
        height: uploadRes.media.height,
        kind: uploadRes.media.kind,
        provider: 'supabase',
        position: i,
      });
    }

    return await createRealPost({
      authorId,
      body: content,
      visibility: 'public',
      media: mediaList,
      communityId,
    });
  } catch (err: unknown) {
    if (uploadedPaths.length > 0) await deletePostMediaFilesFromStorage(uploadedPaths);
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to publish community post.',
    };
  }
}

export async function deleteCommunityPost(
  _communityId: string,
  postId: string,
  currentUserId: string
): Promise<{ success: boolean; error?: string }> {
  const { deleteRealPost } = await import('./postService.ts');
  return deleteRealPost(postId, currentUserId);
}

export async function togglePinCommunityPost(
  communityId: string,
  postId: string,
  isPinned: boolean
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    const res = await fetch(
      `/api/communities/${encodeURIComponent(communityId)}/posts/${encodeURIComponent(postId)}/pin`,
      {
        method: 'POST',
        headers,
        body: JSON.stringify({ isPinned: !isPinned }),
      }
    );
    const json = await res.json();
    return res.ok && json.success ? { success: true } : { success: false, error: json.error };
  } catch (err: unknown) {
    return { success: false, error: err instanceof Error ? err.message : 'Failed to toggle pin.' };
  }
}

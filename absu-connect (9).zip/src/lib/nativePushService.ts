/**
 * ABSU Connect — Native Android Push Notification Service
 * Integrates Capacitor Push Notifications, Firebase Cloud Messaging (FCM),
 * Android 14 POST_NOTIFICATIONS permission management, notification channels,
 * and Supabase Edge Function ("send-android-push") delivery.
 */

import { supabase, supabaseAnonKey } from './supabase.ts';
import { safeStorage } from '../utils/safeStorage.ts';
import { playNotificationChime } from './pushService.ts';

export const ANDROID_CHANNEL_ID = 'absu_notifications';
export const EDGE_FUNCTION_URL = 'https://aqzolewmhpmrcvkrvchn.supabase.co/functions/v1/send-android-push';

export interface PushDiagnosticInfo {
  isNativeApp: boolean;
  platform: 'android' | 'ios' | 'web';
  permissionStatus: string;
  hasRegisteredToken: boolean;
  maskedTokenFingerprint: string | null;
  channelId: string;
  channelCreated: boolean;
  registeredTokensCount: number;
  lastSyncAt: string | null;
}

/**
 * Detect whether the app is executing inside the native Capacitor Android container.
 */
export function isNativeAndroidApp(): boolean {
  if (typeof window === 'undefined') return false;
  const cap = (window as any).Capacitor;
  if (!cap) return false;
  try {
    const isNative = typeof cap.isNativePlatform === 'function' ? cap.isNativePlatform() : false;
    const platform = typeof cap.getPlatform === 'function' ? cap.getPlatform() : '';
    return isNative || platform === 'android';
  } catch {
    return false;
  }
}

/**
 * Safely access the Capacitor PushNotifications plugin if available.
 */
function getCapacitorPushPlugin(): any | null {
  if (typeof window === 'undefined') return null;
  const cap = (window as any).Capacitor;
  return cap?.Plugins?.PushNotifications || null;
}

/**
 * Create or ensure the high-importance Android notification channel exists.
 * Android 8.0+ requires notification channels; importance 5 (High) enables
 * pop-up heads-up banners, vibration, sound, and lock-screen visibility.
 */
export async function setupAndroidNotificationChannel(): Promise<boolean> {
  const plugin = getCapacitorPushPlugin();
  if (!plugin || typeof plugin.createChannel !== 'function') {
    return false;
  }

  try {
    await plugin.createChannel({
      id: ANDROID_CHANNEL_ID,
      name: 'ABSU Connect Notifications',
      description: 'Campus direct messages, friend requests, alerts and updates',
      importance: 5, // High: Heads-up pop-up alert
      visibility: 1, // Public: Visible on lockscreen
      sound: 'notification.wav',
      vibration: true,
      lights: true,
      lightColor: '#7c3aed', // ABSU purple brand color
    });
    console.log('[Native Push] Android notification channel configured:', ANDROID_CHANNEL_ID);
    return true;
  } catch (err) {
    console.warn('[Native Push] createChannel notice:', err);
    return false;
  }
}

/**
 * Check and request runtime notification permissions for Android 13+ (API 33+ POST_NOTIFICATIONS).
 */
export async function requestAndroidNotificationPermission(): Promise<{
  granted: boolean;
  status: string;
}> {
  const plugin = getCapacitorPushPlugin();
  if (!plugin) {
    // If running in browser, check web Notification permission
    if (typeof Notification !== 'undefined') {
      const perm = await Notification.requestPermission();
      return { granted: perm === 'granted', status: perm };
    }
    return { granted: false, status: 'unsupported' };
  }

  try {
    let perm = await plugin.checkPermissions();
    if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') {
      perm = await plugin.requestPermissions();
    }

    const granted = perm.receive === 'granted';
    console.log('[Native Push] Android notification permission result:', perm.receive);
    return { granted, status: perm.receive };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown permission error';
    console.warn('[Native Push] Permission request error:', msg);
    return { granted: false, status: 'error' };
  }
}

/**
 * Register the native Android device with Firebase Cloud Messaging (FCM)
 * and persist the device token to Supabase `device_push_tokens`.
 */
export async function initNativePush(userId: string): Promise<boolean> {
  if (!userId) return false;
  const plugin = getCapacitorPushPlugin();
  if (!plugin) {
    // Not running inside native Android app
    return false;
  }

  try {
    // 1. Create High-Importance Notification Channel
    await setupAndroidNotificationChannel();

    // 2. Request Android 13+ runtime permission
    const { granted } = await requestAndroidNotificationPermission();
    if (!granted) {
      console.warn('[Native Push] Notification permission not granted by user.');
      return false;
    }

    // 3. Register listeners
    // A. Registration Token received from Firebase
    plugin.addListener('registration', async (tokenData: { value: string }) => {
      const fcmToken = tokenData.value;
      if (!fcmToken) return;

      console.log('[Native Push] FCM token acquired. Length:', fcmToken.length);

      // Save token in safeStorage for diagnostic tracking
      safeStorage.setItem(`absu_fcm_token_${userId}`, fcmToken);
      safeStorage.setItem(`absu_fcm_registered_at_${userId}`, new Date().toISOString());

      // Upsert into Supabase device_push_tokens table
      try {
        const { error: upsertErr } = await supabase
          .from('device_push_tokens')
          .upsert(
            {
              user_id: userId,
              token: fcmToken,
              platform: 'android',
              updated_at: new Date().toISOString(),
            },
            { onConflict: 'user_id,token' }
          );

        if (upsertErr) {
          console.warn('[Native Push] device_push_tokens upsert note:', upsertErr.message);
        } else {
          console.log('[Native Push] FCM token successfully registered in database.');
        }
      } catch (dbErr) {
        console.warn('[Native Push] DB token sync note:', dbErr);
      }
    });

    // B. Registration Error listener
    plugin.addListener('registrationError', (error: any) => {
      console.error('[Native Push] FCM registration error:', error);
    });

    // C. Foreground notification received
    plugin.addListener('pushNotificationReceived', (notification: any) => {
      console.log('[Native Push] Foreground notification received:', notification.title);
      playNotificationChime();
    });

    // D. Notification tapped by user
    plugin.addListener('pushNotificationActionPerformed', (action: any) => {
      console.log('[Native Push] Notification action performed:', action.notification?.title);
      const data = action.notification?.data || {};
      const targetUrl = data.url || (data.type === 'message' ? '/?view=messages' : '/?view=alerts');
      if (typeof window !== 'undefined' && targetUrl) {
        window.location.href = targetUrl;
      }
    });

    // 4. Trigger actual native registration
    await plugin.register();
    return true;
  } catch (err) {
    console.warn('[Native Push] Error initializing native push:', err);
    return false;
  }
}

/**
 * Remove device token on user sign-out to prevent cross-account notification leakage.
 */
export async function unregisterNativePush(userId: string): Promise<void> {
  if (!userId) return;
  try {
    const fcmToken = safeStorage.getItem(`absu_fcm_token_${userId}`);
    if (fcmToken) {
      await supabase
        .from('device_push_tokens')
        .delete()
        .eq('user_id', userId)
        .eq('token', fcmToken);
    }
    safeStorage.removeItem(`absu_fcm_token_${userId}`);
    safeStorage.removeItem(`absu_fcm_registered_at_${userId}`);
  } catch (err) {
    console.debug('[Native Push] Token cleanup notice:', err);
  }
}

/**
 * Dispatch an Android FCM Push notification via the deployed Supabase Edge Function
 * ("send-android-push"). The Edge Function authenticates the actor, verifies the
 * corresponding record in the `notifications` table, queries `device_push_tokens`,
 * and delivers the push through Google Firebase Cloud Messaging v1.
 */
export async function dispatchAndroidPush(params: {
  recipientId: string;
  type: string;
  entityId: string;
}): Promise<{ success: boolean; sent?: number; error?: string }> {
  if (!params.recipientId || !params.type || !params.entityId) {
    return { success: false, error: 'Missing required parameters (recipientId, type, entityId)' };
  }

  try {
    // 1. Get current authenticated user session
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData?.session?.access_token;
    if (!token) {
      return { success: false, error: 'No active session access token' };
    }

    // 2. Call the deployed Supabase Edge Function
    const res = await fetch(EDGE_FUNCTION_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        recipient_id: params.recipientId,
        type: params.type,
        entity_id: params.entityId,
      }),
    });

    const data = await res.json().catch(() => null);

    if (res.ok && data?.ok) {
      return { success: true, sent: data.sent ?? 0 };
    }

    // Handled gracefully if no tokens registered for recipient
    return {
      success: false,
      sent: 0,
      error: data?.error || `Edge function responded with status ${res.status}`,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown Edge Function invoke error';
    return { success: false, error: msg };
  }
}

/**
 * Safely mask an FCM device token for logging and diagnostic displays.
 * Example: "cEzIe5...yJoU (163 chars)"
 */
export function maskTokenFingerprint(token?: string | null): string | null {
  if (!token || token.length < 12) return null;
  return `${token.slice(0, 6)}...${token.slice(-4)} (${token.length} chars)`;
}

/**
 * Retrieve comprehensive push diagnostic status for the currently authenticated student.
 */
export async function getPushDiagnosticInfo(userId: string): Promise<PushDiagnosticInfo> {
  const isNative = isNativeAndroidApp();
  const plugin = getCapacitorPushPlugin();
  let permStatus = 'unsupported';

  if (plugin && typeof plugin.checkPermissions === 'function') {
    try {
      const p = await plugin.checkPermissions();
      permStatus = p.receive || 'unknown';
    } catch {
      permStatus = 'error';
    }
  } else if (typeof Notification !== 'undefined') {
    permStatus = Notification.permission;
  }

  // Retrieve token records from Supabase
  let tokenCount = 0;
  let latestToken: string | null = null;
  let lastSyncAt: string | null = null;

  try {
    const { data: tokenRows } = await supabase
      .from('device_push_tokens')
      .select('token, updated_at, created_at')
      .eq('user_id', userId)
      .eq('platform', 'android')
      .order('updated_at', { ascending: false });

    if (tokenRows && tokenRows.length > 0) {
      tokenCount = tokenRows.length;
      latestToken = tokenRows[0].token;
      lastSyncAt = tokenRows[0].updated_at || tokenRows[0].created_at;
    }
  } catch (err) {
    console.debug('[Push Diagnostics] DB token query note:', err);
  }

  // Fallback to local safeStorage if DB row not synced yet
  if (!latestToken && userId) {
    latestToken = safeStorage.getItem(`absu_fcm_token_${userId}`);
    lastSyncAt = safeStorage.getItem(`absu_fcm_registered_at_${userId}`);
  }

  return {
    isNativeApp: isNative,
    platform: isNative ? 'android' : 'web',
    permissionStatus: permStatus,
    hasRegisteredToken: Boolean(latestToken),
    maskedTokenFingerprint: maskTokenFingerprint(latestToken),
    channelId: ANDROID_CHANNEL_ID,
    channelCreated: isNative,
    registeredTokensCount: tokenCount,
    lastSyncAt,
  };
}

/**
 * Perform a live diagnostic end-to-end FCM push test to the user's own device.
 */
export async function sendDiagnosticFcmTest(userId: string): Promise<{
  success: boolean;
  message: string;
  sent?: number;
  fcmResult?: any;
}> {
  if (!userId) {
    return { success: false, message: 'User ID is required for push diagnostics.' };
  }

  try {
    const testEntityId = '00000000-0000-4000-8000-' + Math.random().toString(16).slice(2, 14).padEnd(12, '0');
    const nowIso = new Date().toISOString();

    // 1. Create test notification via server endpoint with admin service role (bypasses RLS safely)
    const createRes = await fetch('/api/notifications/create-test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId,
        entityId: testEntityId,
      }),
    });
    const createData = await createRes.json().catch(() => null);

    if (!createRes.ok || !createData?.success) {
      return {
        success: false,
        message: `Failed to create test notification: ${createData?.error || 'Server error'}`,
      };
    }

    // 2. Invoke the deployed Supabase Edge Function to deliver real FCM message
    const fcmRes = await dispatchAndroidPush({
      recipientId: userId,
      type: 'announcement',
      entityId: testEntityId,
    });

    return {
      success: fcmRes.success,
      sent: fcmRes.sent,
      message: fcmRes.success
        ? `✅ Pop-up notification sent to Firebase! Delivered to ${fcmRes.sent ?? 1} registered device(s).`
        : `Edge function response: ${fcmRes.error || 'No registered Android devices found.'}`,
      fcmResult: fcmRes,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error executing FCM test';
    return { success: false, message: msg };
  }
}

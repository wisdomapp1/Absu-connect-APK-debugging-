import { supabase } from './supabase.ts';
import type { NotificationItem, NotificationType } from '../types/index.ts';
import { mapProfileRowToUser, SupabaseProfileRow } from './profileService.ts';
import { formatTimeAgo } from './postService.ts';
import { MR_ANONYMOUS_PAGE_ID } from './pageService.ts';
import { dispatchAndroidPush } from './nativePushService.ts';

/**
 * Returns privacy-safe action text for the notification.
 * Strictly never includes message bodies, excerpts, or private attachment details.
 */
export function getPrivacySafeNotificationText(type: NotificationType): string {
  switch (type) {
    case 'message':
      return 'sent you a message.';
    case 'friend_request':
      return 'sent you a friend request.';
    case 'friend_accept':
      return 'accepted your friend request.';
    case 'comment':
      return 'commented on your post.';
    case 'like':
      return 'liked your post.';
    case 'mention':
      return 'mentioned you in a post.';
    case 'campus_notice':
      return 'published a campus announcement.';
    case 'game_invitation':
      return 'invited you to play a game.';
    case 'welcome_discovery':
      return 'Explore Discover in Friend Navigator to meet classmates across ABSU.';
    case 'discovery_suggestion':
      return 'New classmates matching your department are on ABSU Connect.';
    case 'discovery_reminder':
      return 'Tap here to discover ABSU peers and start building your campus network.';
    case 'community_post':
      return 'shared a new post in your community.';
    case 'event_reminder':
      return 'upcoming campus event reminder.';
    default:
      return 'interacted with you on ABSU Connect.';
  }
}

export const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export function isValidUuid(id?: string | null): boolean {
  if (!id) return false;
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id.trim());
}

async function getAuthHeaders(includeJson = true): Promise<Record<string, string>> {
  const headers: Record<string, string> = {};
  if (includeJson) headers['Content-Type'] = 'application/json';
  try {
    const { data } = await supabase.auth.getSession();
    const token = data?.session?.access_token;
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  } catch {
    // ignore
  }
  return headers;
}

/**
 * Maps frontend TypeScript NotificationType to PostgreSQL notification_type enum in Supabase.
 */
export function mapAppTypeToDbEnum(type: NotificationType): string {
  switch (type) {
    case 'like':
      return 'reaction';
    case 'friend_accept':
      return 'friend_accepted';
    case 'campus_notice':
      return 'announcement';
    case 'game_invitation':
      return 'game_invite';
    case 'welcome_discovery':
    case 'discovery_suggestion':
    case 'discovery_reminder':
      return 'system';
    default:
      return type;
  }
}

/**
 * Maps database notification_type enum + entity_type string to frontend TypeScript NotificationType.
 */
export function mapDbEnumToAppType(rawType: string, entityType?: string | null): NotificationType {
  const cleanEntity = (entityType || '').toLowerCase().trim();
  if (cleanEntity === 'discovery_welcome') return 'welcome_discovery';
  if (cleanEntity === 'discovery_suggestion') return 'discovery_suggestion';
  if (cleanEntity === 'discovery_reminder') return 'discovery_reminder';

  const clean = (rawType || '').toLowerCase().trim();
  if (clean === 'welcome_discovery') return 'welcome_discovery';
  if (clean === 'discovery_suggestion') return 'discovery_suggestion';
  if (clean === 'discovery_reminder') return 'discovery_reminder';
  if (clean === 'community_post') return 'community_post';
  if (clean === 'event_reminder') return 'event_reminder';
  if (clean === 'event_update') return 'event_update';
  if (clean === 'community_invite') return 'community_invite';
  if (clean === 'community_approved') return 'community_approved';
  if (clean === 'community_rejected') return 'community_rejected';
  if (clean.includes('message') || clean.includes('chat') || clean.includes('dm')) {
    return 'message';
  }
  if (clean === 'friend_accepted' || (clean.includes('friend') && clean.includes('accept'))) {
    return 'friend_accept';
  }
  if (clean.includes('friend') || clean.includes('request')) {
    return 'friend_request';
  }
  if (clean === 'reaction' || clean.includes('like')) {
    return 'like';
  }
  if (clean.includes('comment')) {
    return 'comment';
  }
  if (clean.includes('mention')) {
    return 'mention';
  }
  if (clean === 'announcement' || clean.includes('campus') || clean.includes('notice')) {
    return 'campus_notice';
  }
  if (clean === 'game_invite' || clean.includes('game')) {
    return 'game_invitation';
  }
  return 'campus_notice';
}

/**
 * Fetch notifications for current user with strict privacy protection.
 * - Uses server endpoint (with service-role bypass) first to avoid client RLS hurdles.
 * - Deduplicates active unread message alerts at conversation level (WhatsApp-like behavior).
 * - Partitions into Active Recent (< 7 days) and Archived (>= 7 days).
 */
export async function fetchUserNotifications(
  currentUserId: string,
  filter: 'all' | 'recent' | 'archived' = 'all'
): Promise<NotificationItem[]> {
  if (!currentUserId) return [];

  try {
    let rawRows: any[] = [];

    // 1. Try server endpoint first (guaranteed admin access without RLS restrictions)
    try {
      const headers = await getAuthHeaders(false);
      const serverRes = await fetch(`/api/notifications/user/${encodeURIComponent(currentUserId)}`, {
        headers,
      });
      if (serverRes.ok) {
        const json = await serverRes.json();
        if (json.success && Array.isArray(json.notifications)) {
          rawRows = json.notifications;
        }
      }
    } catch {
      // Server fetch failed, fallback to client Supabase query below
    }

    // 2. Fallback to direct Supabase query if server fetch didn't return data
    if (rawRows.length === 0) {
      try {
        const { data: supaRows, error: supaErr } = await supabase
          .from('notifications')
          .select('*')
          .eq('recipient_id', currentUserId)
          .order('created_at', { ascending: false })
          .limit(100);

        if (!supaErr && supaRows) {
          rawRows = supaRows;
        }
      } catch (err) {
        console.warn('[Notifications] Supabase direct query note:', err);
      }
    }

    const now = Date.now();
    const rawList: NotificationItem[] = [];

    for (const row of rawRows) {
      const notifType: NotificationType = mapDbEnumToAppType(row.type || '', row.entity_type);
      const isDiscoverySystem =
        notifType === 'welcome_discovery' ||
        notifType === 'discovery_suggestion' ||
        notifType === 'discovery_reminder';

      const actorUser =
        isDiscoverySystem
          ? {
              id: 'system',
              name: 'ABSU Connect Discovery',
              avatar: `https://api.dicebear.com/7.x/initials/svg?seed=AC&backgroundColor=7c3aed&textColor=ffffff`,
            }
          : row.actor
          ? mapProfileRowToUser(row.actor as SupabaseProfileRow)
          : {
              id: row.actor_id || 'system',
              name: row.actor_id === currentUserId ? 'ABSU Connect' : 'ABSU Student',
              avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(row.actor_id || 'ABSU')}&backgroundColor=6d45d9&textColor=ffffff`,
              handle: '@student',
              department: 'Notice Board',
              faculty: 'Abia State University',
              level: 'Campus',
              campus: 'Uturu',
              bio: '',
              interests: [],
              relationshipState: 'none' as const,
            };

      const maxLen = isDiscoverySystem ? 280 : 120;
      const safeAction =
        row.body && row.body.length <= maxLen
          ? row.body
          : getPrivacySafeNotificationText(notifType);
      const createdTime = row.created_at ? new Date(row.created_at).getTime() : now;
      const isArchived = (now - createdTime) >= SEVEN_DAYS_MS;

      // Filter handling
      if (filter === 'recent' && isArchived) continue;
      if (filter === 'archived' && !isArchived) continue;

      let convId: string | undefined = undefined;
      if (notifType === 'message' && row.entity_type === 'conversation' && row.entity_id) {
        convId = row.entity_id;
      }

      rawList.push({
        id: row.id,
        type: notifType,
        title: row.title || undefined,
        entityType: row.entity_type || undefined,
        actor: {
          id: actorUser.id,
          name: actorUser.name,
          avatar: actorUser.avatar,
        },
        content: safeAction,
        timestamp: formatTimeAgo(row.created_at),
        createdAt: row.created_at,
        isRead: Boolean(row.read_at),
        isArchived,
        targetPostId: row.entity_type === 'post' ? row.entity_id : undefined,
        conversationId: convId,
      });
    }

    // WhatsApp-Like Conversation-Level Deduplication for Active Message Alerts
    const activeUnreadMessageConvs = new Set<string>();
    const deduplicatedResult: NotificationItem[] = [];

    for (const item of rawList) {
      if (item.type === 'message' && !item.isRead && !item.isArchived) {
        const dedupeKey = item.conversationId || `sender_${item.actor.id}`;
        if (activeUnreadMessageConvs.has(dedupeKey)) {
          continue;
        }
        activeUnreadMessageConvs.add(dedupeKey);
        deduplicatedResult.push(item);
      } else {
        deduplicatedResult.push(item);
      }
    }

    return deduplicatedResult;
  } catch (err) {
    console.warn('Unexpected error in fetchUserNotifications:', err);
    return [];
  }
}

/**
 * Create a privacy-safe notification record.
 * Uses the server endpoint (service-role admin) to reliably bypass client RLS issues,
 * and automatically triggers Web Push notifications.
 */
export async function createRealNotification(params: {
  recipientId: string;
  actorId: string;
  type: NotificationType;
  entityType?: 'post' | 'conversation' | 'friend_request' | 'friend_accepted' | 'game' | 'user';
  entityId?: string;
  senderName?: string;
  url?: string;
}): Promise<boolean> {
  if (
    !params.recipientId ||
    !params.actorId ||
    params.recipientId === params.actorId ||
    !isValidUuid(params.recipientId) ||
    params.recipientId === MR_ANONYMOUS_PAGE_ID
  ) {
    return true; // Skip gracefully without foreign key errors
  }

  try {
    const safeBody = getPrivacySafeNotificationText(params.type);
    const validEntity = isValidUuid(params.entityId) ? params.entityId : null;

    const dbType = mapAppTypeToDbEnum(params.type);
    let creationSuccess = false;

    // 1. Dispatch through server-authoritative endpoint (bypasses RLS & triggers Web Push)
    const headers = await getAuthHeaders(true);
    const serverRes = await fetch('/api/notifications/create', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        recipientId: params.recipientId,
        actorId: params.actorId,
        type: params.type,
        title: 'ABSU Connect Alert',
        body: safeBody,
        entityType: params.entityType,
        entityId: validEntity,
        senderName: params.senderName,
        url: params.url,
      }),
    });

    if (serverRes.ok) {
      creationSuccess = true;
    } else {
      // 2. Client-side fallback if server was temporarily unavailable
      const { error } = await supabase.from('notifications').insert({
        recipient_id: params.recipientId,
        actor_id: isValidUuid(params.actorId) ? params.actorId : null,
        type: dbType,
        title: 'ABSU Connect Alert',
        body: safeBody,
        entity_type: params.entityType,
        entity_id: validEntity,
        created_at: new Date().toISOString(),
        read_at: null,
      });
      creationSuccess = !error;
    }

    // 3. Trigger native Android FCM push via Supabase Edge Function ("send-android-push")
    if (creationSuccess && validEntity) {
      dispatchAndroidPush({
        recipientId: params.recipientId,
        type: dbType,
        entityId: validEntity,
      }).catch((fcmErr) => {
        console.debug('[Native Push] FCM dispatch note:', fcmErr);
      });
    }

    return creationSuccess;
  } catch (err) {
    console.debug('createRealNotification note:', err);
    return false;
  }
}

/**
 * Conversation-level Message Notification: Ensures that an incoming message from a sender
 * maintains exactly ONE active unread conversation notification for that recipient.
 */
export async function createOrUpdateConversationNotification(params: {
  recipientId: string;
  senderId: string;
  conversationId: string;
  messageId?: string;
  senderName?: string;
}): Promise<boolean> {
  if (params.recipientId === params.senderId) return false;

  try {
    const safeConvId = isValidUuid(params.conversationId) ? params.conversationId : null;
    const safeMsgId = isValidUuid(params.messageId) ? params.messageId : null;

    // Call server endpoint with admin privileges
    const res = await fetch('/api/notifications/create-or-update-message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        recipientId: params.recipientId,
        senderId: params.senderId,
        conversationId: safeConvId,
        messageId: safeMsgId,
        senderName: params.senderName,
      }),
    });

    // Also trigger native Android FCM push via Supabase Edge Function ("send-android-push")
    // Pass the actual message ID so the Edge Function validates the exact notification record
    const entityToDispatch = safeMsgId || safeConvId;
    if (entityToDispatch) {
      dispatchAndroidPush({
        recipientId: params.recipientId,
        type: 'message',
        entityId: entityToDispatch,
      }).catch((fcmErr) => {
        console.debug('[Native Push] Message FCM dispatch note:', fcmErr);
      });
    }

    return res.ok;
  } catch (err) {
    console.warn('createOrUpdateConversationNotification error:', err);
    return false;
  }
}

/**
 * Mark all message notifications for a specific conversation as read when recipient opens it.
 */
export async function markConversationNotificationsAsRead(
  currentUserId: string,
  conversationId: string,
  participantId?: string
): Promise<{ success: boolean; error?: string }> {
  if (!currentUserId || !conversationId) return { success: false };

  try {
    const nowIso = new Date().toISOString();

    let safeParticipantId = participantId;
    if (!safeParticipantId) {
      const { data: otherMember } = await supabase
        .from('conversation_members')
        .select('user_id')
        .eq('conversation_id', conversationId)
        .neq('user_id', currentUserId)
        .maybeSingle();
      if (otherMember?.user_id) safeParticipantId = otherMember.user_id;
    }

    // 1. Direct Supabase update
    let query = supabase
      .from('notifications')
      .update({ read_at: nowIso })
      .eq('recipient_id', currentUserId)
      .eq('type', 'message')
      .is('read_at', null);

    if (safeParticipantId) {
      query = query.or(`entity_id.eq.${conversationId},actor_id.eq.${safeParticipantId}`);
    } else {
      query = query.eq('entity_id', conversationId);
    }
    await query;

    // 2. Server-side resolution
    fetch('/api/notifications/resolve-conversation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUserId,
        conversationId,
        participantId: safeParticipantId,
      }),
    }).catch(() => {});

    return { success: true };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error resolving conversation notifications';
    return { success: false, error: msg };
  }
}

/**
 * Trigger the idempotent Smart Welcome & Student Discovery notification after onboarding.
 */
export async function triggerWelcomeDiscoveryNotification(userId: string): Promise<void> {
  if (!userId || !isValidUuid(userId)) return;
  try {
    const headers = await getAuthHeaders(true);
    await fetch('/api/notifications/welcome-discovery', {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId }),
    });
  } catch (err) {
    console.debug('[Notifications] Welcome discovery trigger note:', err);
  }
}

/**
 * Check if a user registered >24h ago with no social engagement yet and trigger at most ONE reminder.
 */
export async function checkDiscoveryInactivityReminder(userId: string): Promise<void> {
  if (!userId || !isValidUuid(userId)) return;
  try {
    const headers = await getAuthHeaders(true);
    await fetch('/api/notifications/check-discovery-reminder', {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId }),
    });
  } catch (err) {
    console.debug('[Notifications] Discovery inactivity reminder note:', err);
  }
}

/**
 * Mark an individual notification as read
 */
export async function markRealNotificationAsRead(
  notificationId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    fetch('/api/notifications/mark-read', {
      method: 'POST',
      headers,
      body: JSON.stringify({ notificationId }),
    }).catch(() => {});

    await supabase
      .from('notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('id', notificationId);

    return { success: true };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error updating notification';
    return { success: false, error: msg };
  }
}

/**
 * Mark all notifications as read for current user
 */
export async function markAllRealNotificationsAsRead(
  currentUserId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers = await getAuthHeaders(true);
    fetch('/api/notifications/mark-all-read', {
      method: 'POST',
      headers,
      body: JSON.stringify({ userId: currentUserId }),
    }).catch(() => {});

    await supabase
      .from('notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('recipient_id', currentUserId)
      .is('read_at', null);

    return { success: true };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error updating notifications';
    return { success: false, error: msg };
  }
}

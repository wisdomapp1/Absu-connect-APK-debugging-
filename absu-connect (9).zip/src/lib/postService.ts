import { supabase } from './supabase.ts';
import type { User, Post, Comment, PostCategory, PostAudience, PostMediaItem } from '../types/index.ts';
import { mapProfileRowToUser, SupabaseProfileRow } from './profileService.ts';
import {
  batchResolvePostMediaSignedUrls,
  deletePostMediaFilesFromStorage,
  extractPostMediaStoragePath,
} from './storageService.ts';

export interface SupabasePostRow {
  id: string;
  author_id: string;
  page_id?: string | null;
  page?: {
    id: string;
    slug: string;
    name: string;
    description?: string;
    avatar_url?: string;
  } | null;
  body: string;
  visibility: string;
  created_at: string;
  updated_at: string;
  author?: SupabaseProfileRow;
  post_media?: Array<{
    id: string;
    secure_url?: string;
    asset_id?: string;
    format?: string;
    bytes?: number;
    width?: number;
    height?: number;
    kind?: 'image' | 'video';
    provider?: string;
    position?: number;
  }>;
  post_reactions?: Array<{
    post_id: string;
    user_id: string;
    reaction: string;
  }>;
  comments?: Array<{
    id: string;
  }>;
  is_pinned?: boolean;
  community_id?: string;
  community?: {
    id: string;
    name: string;
    slug: string;
    image_url?: string;
  };
}

export function formatTimeAgo(isoString: string): string {
  try {
    const diff = Math.max(0, Date.now() - new Date(isoString).getTime());
    const seconds = Math.floor(diff / 1000);
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    return new Date(isoString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
    });
  } catch {
    return 'Recently';
  }
}

/**
 * Maps Supabase post row + author profile + reactions to frontend Post model
 */
export function mapSupabasePostToFrontend(
  row: SupabasePostRow,
  currentUserId?: string,
  savedPostIds?: Set<string>
): Post {
  let author: User;
  const isPagePost = Boolean(row.page_id);

  if (row.page_id) {
    const pageName = row.page?.name || 'Mr Anonymous';
    const pageSlug = row.page?.slug || 'mr-anonymous';
    const pageAvatar =
      row.page?.avatar_url ||
      'https://aqzolewmhpmrcvkrvchn.supabase.co/storage/v1/object/public/profile-avatars/b4f38505-fce6-44be-8727-8ebf04eb2ceb/1793258674588_ysurzh_avatar.jpg';

    author = {
      id: row.page?.id || row.page_id,
      name: pageName,
      avatar: pageAvatar,
      handle: `@${pageSlug}`,
      department: 'Official Campus Page',
      faculty: 'Abia State University',
      level: 'Community',
      campus: 'ABSU Campus',
      bio: row.page?.description || 'Moderated ABSU anonymous confessions, experiences & campus gist.',
      interests: ['#Anonymous', '#Confessions', '#Gist'],
      relationshipState: 'none' as const,
    };
  } else if (row.author) {
    author = mapProfileRowToUser(row.author, null, row.author.id === currentUserId ? 'self' : 'none');
  } else {
    author = {
      id: row.author_id,
      name: 'ABSU Student',
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${row.author_id}&backgroundColor=6d45d9&textColor=ffffff`,
      handle: '@student',
      department: 'Student',
      faculty: 'Abia State University',
      level: 'Undergraduate',
      campus: 'Uturu (Main Campus)',
      bio: '',
      interests: [],
      relationshipState: 'none' as const,
    };
  }

  // Map all attached media items
  const rawMedia = row.post_media || [];
  const mediaItems: PostMediaItem[] = rawMedia
    .map((m, idx) => ({
      id: m.id,
      secure_url: m.secure_url || '',
      asset_id: m.asset_id,
      format: m.format,
      bytes: m.bytes,
      width: m.width,
      height: m.height,
      kind: (m.kind === 'video' ||
        (m.format || '').toLowerCase() === 'mp4' ||
        (m.secure_url || '').includes('/video/') ||
        (m.secure_url || '').match(/\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i)
        ? 'video'
        : 'image') as 'image' | 'video',
      provider: m.provider || 'supabase',
      position: m.position ?? idx,
    }))
    .sort((a, b) => (a.position ?? 0) - (b.position ?? 0));

  const primaryMedia = mediaItems[0];
  const mediaUrl = primaryMedia ? primaryMedia.secure_url : undefined;
  const mediaType = primaryMedia ? primaryMedia.kind : undefined;

  const reactions = row.post_reactions || [];
  const isLikedByMe = Boolean(
    currentUserId && reactions.some((r) => r.user_id === currentUserId)
  );

  // Audience mapping
  let audience: PostAudience = 'Public';
  if (row.visibility === 'friends') audience = 'Friends Only';
  else if (row.visibility === 'campus') audience = 'Campus Only';

  // Required Category Hashtag extraction: #Event, #CampusUpdates, #GeneralPost
  let categoryHashtag: '#Event' | '#CampusUpdates' | '#GeneralPost' | undefined = undefined;
  const rawBody = row.body || '';
  if (/(?:^|\s)#Event\b/i.test(rawBody)) {
    categoryHashtag = '#Event';
  } else if (/(?:^|\s)#CampusUpdates\b/i.test(rawBody)) {
    categoryHashtag = '#CampusUpdates';
  } else if (/(?:^|\s)#GeneralPost\b/i.test(rawBody)) {
    categoryHashtag = '#GeneralPost';
  }

  // Category inference from hashtag or content or fallback
  let category: PostCategory = 'General';
  if (categoryHashtag === '#Event') {
    category = 'Event';
  } else if (categoryHashtag === '#CampusUpdates') {
    category = 'Campus Update';
  } else if (categoryHashtag === '#GeneralPost') {
    category = 'General';
  } else {
    const lowerBody = rawBody.toLowerCase();
    if (lowerBody.includes('#academic') || lowerBody.includes('exam') || lowerBody.includes('class') || lowerBody.includes('lecture')) {
      category = 'Academic';
    } else if (lowerBody.includes('#campus') || lowerBody.includes('hostel') || lowerBody.includes('faculty')) {
      category = 'Campus Update';
    } else if (lowerBody.includes('#hostel') || lowerBody.includes('lodge')) {
      category = 'Hostel Life';
    }
  }

  // Community detection from direct row relationship or fallback tag #community_<id>
  let communityId: string | undefined = row.community_id || undefined;
  let communityName: string | undefined = row.community?.name || undefined;
  let communitySlug: string | undefined = row.community?.slug || undefined;
  let communityImageUrl: string | undefined = row.community?.image_url || undefined;
  let displayContent = rawBody;

  const commMatch = rawBody.match(/#community_([a-zA-Z0-9_-]+)/i);
  if (commMatch) {
    if (!communityId) communityId = commMatch[1];
    displayContent = rawBody.replace(/#community_[a-zA-Z0-9_-]+/gi, '').trim();
    if (!communityName) {
      const rawSlug = communityId.replace(/^comm_\d+_/, '').replace(/-/g, ' ');
      if (rawSlug) {
        communityName = rawSlug.charAt(0).toUpperCase() + rawSlug.slice(1);
      }
    }
  }

  return {
    id: row.id,
    author,
    content: displayContent || '',
    mediaUrl,
    mediaType,
    mediaItems,
    category,
    categoryHashtag,
    audience,
    createdAt: formatTimeAgo(row.created_at),
    likesCount: reactions.length,
    isLiked: isLikedByMe,
    isSaved: Boolean(savedPostIds?.has(row.id)),
    commentsCount: Array.isArray(row.comments) ? row.comments.length : 0,
    comments: [],
    isPinned: Boolean(row.is_pinned),
    pageId: row.page_id || undefined,
    isPagePost,
    communityId,
    communityName,
    communitySlug,
    communityImageUrl,
  };
}

/**
 * Resolve fresh signed URLs on post_media rows from persistent storage paths (`post-media`).
 * Preserves public bucket URLs (`profile-avatars`), legacy Cloudinary URLs, and presets untouched.
 */
export async function resolvePostMediaUrlsOnRows(postRows: SupabasePostRow[]): Promise<void> {
  const allMediaRows = postRows.flatMap((r) => r.post_media || []);
  if (allMediaRows.length === 0) return;

  const signedMap = await batchResolvePostMediaSignedUrls(allMediaRows);
  for (const row of postRows) {
    if (!row.post_media) continue;
    for (const m of row.post_media) {
      const storagePath = extractPostMediaStoragePath(m.asset_id, m.secure_url, m.provider);
      if (storagePath) {
        m.asset_id = storagePath;
        if (signedMap.has(storagePath)) {
          m.secure_url = signedMap.get(storagePath);
        } else if (
          !m.secure_url?.startsWith('http://') &&
          !m.secure_url?.startsWith('https://') &&
          !m.secure_url?.startsWith('data:') &&
          !m.secure_url?.startsWith('/')
        ) {
          // Avoid leaving a bare storage path in <img src>; trigger error + retry card instead
          m.secure_url = '';
        }
      } else if (m.secure_url && signedMap.has(m.secure_url)) {
        m.secure_url = signedMap.get(m.secure_url);
      }
    }
  }
}

export async function fetchSavedPostIds(userId?: string): Promise<Set<string>> {
  const savedSet = new Set<string>();
  if (!userId) return savedSet;
  try {
    const { data, error } = await supabase
      .from('saved_posts')
      .select('post_id')
      .eq('user_id', userId);
    if (!error && data) {
      for (const row of data as Array<{ post_id: string }>) {
        if (row.post_id) savedSet.add(row.post_id);
      }
    }
  } catch {
    // Graceful fallback if table hasn't been migrated yet
  }
  return savedSet;
}

export async function toggleSavePostInDb(
  postId: string,
  userId: string,
  currentlySaved: boolean
): Promise<{ success: boolean; isSaved: boolean; error?: string }> {
  if (!postId || !userId) return { success: false, isSaved: currentlySaved, error: 'Invalid post or user.' };
  try {
    if (currentlySaved) {
      const { error } = await supabase
        .from('saved_posts')
        .delete()
        .eq('post_id', postId)
        .eq('user_id', userId);
      if (error) return { success: false, isSaved: currentlySaved, error: error.message };
      return { success: true, isSaved: false };
    } else {
      const { error } = await supabase
        .from('saved_posts')
        .upsert(
          { post_id: postId, user_id: userId, created_at: new Date().toISOString() },
          { onConflict: 'user_id,post_id', ignoreDuplicates: true }
        );
      if (error) return { success: false, isSaved: currentlySaved, error: error.message };
      return { success: true, isSaved: true };
    }
  } catch (err: unknown) {
    return {
      success: false,
      isSaved: currentlySaved,
      error: err instanceof Error ? err.message : 'Failed to update saved status',
    };
  }
}

export async function fetchSavedPosts(userId: string): Promise<Post[]> {
  if (!userId) return [];
  try {
    const { data: savedRows, error: savedErr } = await supabase
      .from('saved_posts')
      .select('post_id, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (savedErr || !savedRows || savedRows.length === 0) {
      return [];
    }

    const postIds = savedRows.map((r: any) => r.post_id).filter(Boolean);
    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        author:profiles!posts_author_id_fkey(*),
        page:pages(*),
        community:communities(*),
        post_media(*),
        post_reactions(*),
        comments(id)
      `)
      .in('id', postIds);

    if (error || !data) return [];

    const postRows = data as unknown as SupabasePostRow[];
    await resolvePostMediaUrlsOnRows(postRows);

    const savedSet = new Set<string>(postIds);
    const byId = new Map<string, Post>();
    for (const row of postRows) {
      if (row.visibility !== 'hidden') {
        byId.set(row.id, mapSupabasePostToFrontend(row, userId, savedSet));
      }
    }

    return postIds.map((id) => byId.get(id)).filter((p): p is Post => Boolean(p));
  } catch (err) {
    console.warn('Error fetching saved posts:', err);
    return [];
  }
}

export async function fetchCommunityPostsFromSupabase(
  communityId: string,
  currentUserId?: string
): Promise<Post[]> {
  if (!communityId) return [];
  try {
    const [postsRes, savedSet] = await Promise.all([
      supabase
        .from('posts')
        .select(`
          *,
          author:profiles!posts_author_id_fkey(*),
          page:pages(*),
          community:communities(*),
          post_media(*),
          post_reactions(*),
          comments(id)
        `)
        .eq('community_id', communityId)
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(50),
      fetchSavedPostIds(currentUserId),
    ]);

    if (postsRes.error || !postsRes.data) return [];
    const postRows = postsRes.data as unknown as SupabasePostRow[];
    await resolvePostMediaUrlsOnRows(postRows);

    return postRows
      .filter((r) => r.visibility !== 'hidden')
      .map((row) => mapSupabasePostToFrontend(row, currentUserId, savedSet));
  } catch (err) {
    console.warn('Error fetching community posts:', err);
    return [];
  }
}

/**
 * Fetch feed posts from Supabase posts table with author and reactions.
 * Batch resolves signed URLs for private 'post-media' bucket items.
 */
export async function fetchFeedPosts(currentUserId?: string): Promise<Post[]> {
  try {
    const [postsRes, savedSet] = await Promise.all([
      supabase
        .from('posts')
        .select(`
          *,
          author:profiles!posts_author_id_fkey(*),
          page:pages(*),
          community:communities(*),
          post_media(*),
          post_reactions(*),
          comments(id)
        `)
        .order('created_at', { ascending: false })
        .limit(50),
      fetchSavedPostIds(currentUserId),
    ]);

    if (postsRes.error) {
      console.warn('Supabase fetchFeedPosts error:', postsRes.error.message);
      return [];
    }

    const postRows = (postsRes.data || []) as unknown as SupabasePostRow[];
    await resolvePostMediaUrlsOnRows(postRows);

    // Query active moderated posts from server store for real-time admin content control
    let moderatedSet = new Set<string>();
    try {
      const modRes = await fetch('/api/content/moderated-posts');
      if (modRes.ok) {
        const modData = await modRes.json();
        if (modData.success && modData.moderated) {
          for (const [pId, info] of Object.entries(modData.moderated as Record<string, { action: string }>)) {
            if (info.action === 'hide' || info.action === 'delete') {
              moderatedSet.add(pId);
            }
          }
        }
      }
    } catch {
      // Non-blocking if offline
    }

    const visibleRows = postRows.filter(
      (r) => r.visibility !== 'hidden' && !moderatedSet.has(r.id)
    );

    return visibleRows.map((row) =>
      mapSupabasePostToFrontend(row, currentUserId, savedSet)
    );
  } catch (err) {
    console.warn('Unexpected error in fetchFeedPosts:', err);
    return [];
  }
}

/**
 * Fetch posts published by a specific user (for ProfileView cross-user & self views).
 */
export async function fetchUserPosts(targetUserId: string, currentUserId?: string): Promise<Post[]> {
  if (!targetUserId) return [];
  try {
    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        author:profiles!posts_author_id_fkey(*),
        page:pages(*),
        community:communities(*),
        post_media(*),
        post_reactions(*),
        comments(id)
      `)
      .eq('author_id', targetUserId)
      .is('page_id', null)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      console.warn('Supabase fetchUserPosts error:', error.message);
      return [];
    }

    const postRows = (data || []) as unknown as SupabasePostRow[];
    await resolvePostMediaUrlsOnRows(postRows);

    const visibleRows = postRows.filter((r) => r.visibility !== 'hidden');
    return visibleRows.map((row) => mapSupabasePostToFrontend(row, currentUserId));
  } catch (err) {
    console.warn('Unexpected error in fetchUserPosts:', err);
    return [];
  }
}

export interface PostMediaAttachment {
  secure_url: string;
  asset_id?: string;
  format?: string;
  bytes?: number;
  width?: number;
  height?: number;
  kind?: 'image' | 'video';
  provider?: string;
  position?: number;
}

/**
 * Create a real post in Supabase with optional multiple media items.
 * Uses Supabase Storage 'post-media' bucket.
 * Cleans up orphaned files and posts on any failure.
 */
export async function createRealPost(params: {
  authorId: string;
  body: string;
  visibility?: 'public' | 'friends' | 'campus';
  media?: PostMediaAttachment | PostMediaAttachment[];
  communityId?: string;
  categoryHashtag?: '#Event' | '#CampusUpdates' | '#GeneralPost';
}): Promise<{ success: boolean; post?: Post; error?: string }> {
  const mediaList: PostMediaAttachment[] = Array.isArray(params.media)
    ? params.media
    : params.media
    ? [params.media]
    : [];

  try {
    const postPayload: Record<string, any> = {
      author_id: params.authorId,
      body: params.body.trim(),
      visibility: params.visibility || 'public',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    if (params.communityId) {
      postPayload.community_id = params.communityId;
    }

    console.log('[Supabase Post Insert] Creating post row...', {
      author_id: params.authorId,
      community_id: params.communityId,
      visibility: postPayload.visibility,
      mediaCount: mediaList.length,
    });

    const { data: postData, error: postError } = await supabase
      .from('posts')
      .insert(postPayload)
      .select(`
        *,
        author:profiles!posts_author_id_fkey(*),
        community:communities(*)
      `)
      .single();

    if (postError || !postData) {
      console.error('[Supabase Post Error] Failed to insert post:', postError?.message);
      // Clean up uploaded media in storage if post insertion fails
      const storagePaths = mediaList
        .map((m) => m.asset_id)
        .filter(Boolean) as string[];
      if (storagePaths.length > 0) {
        await deletePostMediaFilesFromStorage(storagePaths);
      }
      return { success: false, error: postError?.message || 'Failed to create post.' };
    }

    // Insert all post_media items if any attached — persist storage path, never temporary signed URLs
    if (mediaList.length > 0) {
      const mediaPayloads = mediaList.map((m, idx) => {
        const mediaKind: 'image' | 'video' =
          m.kind ||
          (m.format === 'mp4' ||
          m.secure_url.includes('/video/') ||
          m.secure_url.match(/\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i)
            ? 'video'
            : 'image');

        const persistentStoragePath = extractPostMediaStoragePath(
          m.asset_id,
          m.secure_url,
          m.provider
        );

        return {
          post_id: postData.id,
          uploader_id: params.authorId,
          kind: mediaKind,
          provider: m.provider || 'supabase',
          // Store persistent storage path for private post-media bucket; preserve public URLs only for public buckets/presets
          secure_url: persistentStoragePath || m.secure_url,
          asset_id: persistentStoragePath || m.asset_id || m.secure_url || `media_${postData.id}_${idx}`,
          format: m.format || null,
          bytes: m.bytes || null,
          width: m.width || null,
          height: m.height || null,
          position: m.position ?? idx,
          created_at: new Date().toISOString(),
        };
      });

      console.log(`[Supabase Media Insert] Attaching ${mediaPayloads.length} post_media rows...`);

      const { error: mediaError } = await supabase
        .from('post_media')
        .insert(mediaPayloads);

      if (mediaError) {
        console.error('[Supabase Media Insert Failed]', {
          message: mediaError.message,
          code: mediaError.code,
          details: mediaError.details,
        });

        // Clean up orphaned post so we don't leave broken content
        await supabase.from('posts').delete().eq('id', postData.id);

        // Clean up uploaded files in post-media storage bucket
        const storagePaths = mediaList
          .map((m) => m.asset_id)
          .filter(Boolean) as string[];
        if (storagePaths.length > 0) {
          await deletePostMediaFilesFromStorage(storagePaths);
        }

        const isMissingFileNameTrigger =
          mediaError.code === '42703' ||
          mediaError.message?.toLowerCase().includes('file_name');

        return {
          success: false,
          error: isMissingFileNameTrigger
            ? 'Database trigger mismatch on post_media (missing file_name). Run the MVP 1 SQL migration in Supabase SQL Editor to resolve.'
            : `Media metadata failed to save (${mediaError.message}). Please try again.`,
        };
      }
    }

    const frontendPost = mapSupabasePostToFrontend(
      {
        ...postData,
        post_media: mediaList,
        post_reactions: [],
        comments: [],
      } as unknown as SupabasePostRow,
      params.authorId
    );

    console.log('[Supabase Post Published] Post successfully created with ID:', postData.id);
    return { success: true, post: frontendPost };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Failed to publish post';
    console.error('[Supabase Post Error] Unexpected exception:', msg);

    // Clean up uploaded files on unexpected exception
    const storagePaths = mediaList
      .map((m) => m.asset_id)
      .filter(Boolean) as string[];
    if (storagePaths.length > 0) {
      await deletePostMediaFilesFromStorage(storagePaths);
    }

    return { success: false, error: msg };
  }
}

/**
 * Delete a post from Supabase and remove associated storage media
 */
export async function deleteRealPost(
  postId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // 1. Fetch attached media to clean up storage objects
    const { data: mediaRows } = await supabase
      .from('post_media')
      .select('asset_id, provider')
      .eq('post_id', postId);

    if (mediaRows && mediaRows.length > 0) {
      const pathsToDelete = mediaRows
        .filter((m) => m.asset_id && m.provider === 'supabase')
        .map((m) => m.asset_id as string);
      if (pathsToDelete.length > 0) {
        await deletePostMediaFilesFromStorage(pathsToDelete);
      }
    }

    // 2. Delete post row (cascades or deletes post_media/reactions)
    const { error } = await supabase
      .from('posts')
      .delete()
      .match({ id: postId, author_id: userId });

    if (error) {
      console.warn('Supabase deletePost error:', error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Failed to delete post';
    return { success: false, error: msg };
  }
}

/**
 * Toggle post reaction in Supabase post_reactions table
 */
export async function toggleRealPostReaction(
  postId: string,
  userId: string,
  reaction = 'heart'
): Promise<{ success: boolean; isLiked: boolean; error?: string }> {
  try {
    // Check if reaction exists
    const { data: existing, error: checkErr } = await supabase
      .from('post_reactions')
      .select('*')
      .eq('post_id', postId)
      .eq('user_id', userId)
      .maybeSingle();

    if (checkErr) {
      console.warn('Check reaction error:', checkErr.message);
    }

    if (existing) {
      // Remove reaction
      const { error: delErr } = await supabase
        .from('post_reactions')
        .delete()
        .eq('post_id', postId)
        .eq('user_id', userId);

      if (delErr) {
        return { success: false, isLiked: true, error: delErr.message };
      }
      return { success: true, isLiked: false };
    } else {
      // Insert reaction
      const { error: insErr } = await supabase
        .from('post_reactions')
        .insert({
          post_id: postId,
          user_id: userId,
          reaction,
          created_at: new Date().toISOString(),
        });

      if (insErr) {
        return { success: false, isLiked: false, error: insErr.message };
      }
      return { success: true, isLiked: true };
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Reaction update failed';
    return { success: false, isLiked: false, error: msg };
  }
}

/**
 * Recursively count total comments (top-level + nested replies)
 */
export function countThreadedComments(comments: Comment[]): number {
  return comments.reduce(
    (sum, c) => sum + 1 + (c.replies ? countThreadedComments(c.replies) : 0),
    0
  );
}

/**
 * Fetch threaded comments for a post along with independent `comment_reactions` counts/state
 */
export async function fetchPostComments(
  postId: string,
  currentUserId?: string
): Promise<Comment[]> {
  try {
    const { data, error } = await supabase
      .from('comments')
      .select(`
        *,
        author:profiles!comments_author_id_fkey(*)
      `)
      .eq('post_id', postId)
      .order('created_at', { ascending: true });

    if (error) {
      console.warn('Supabase fetchPostComments error:', error.message);
      return [];
    }

    const rows = data || [];
    if (rows.length === 0) return [];

    const commentIds = rows.map((r: any) => r.id);
    const likesCountMap = new Map<string, number>();
    const likedByMeSet = new Set<string>();

    try {
      const { data: reactionsData, error: reactionsErr } = await supabase
        .from('comment_reactions')
        .select('comment_id, user_id')
        .in('comment_id', commentIds);

      if (!reactionsErr && reactionsData) {
        for (const r of reactionsData as Array<{ comment_id: string; user_id: string }>) {
          likesCountMap.set(r.comment_id, (likesCountMap.get(r.comment_id) || 0) + 1);
          if (currentUserId && r.user_id === currentUserId) {
            likedByMeSet.add(r.comment_id);
          }
        }
      }
    } catch {
      // Safe fallback if comment_reactions table is not yet migrated
    }

    const flatComments: Comment[] = rows.map((row: any) => {
      const author = row.author
        ? mapProfileRowToUser(row.author, null, row.author.id === currentUserId ? 'self' : 'none')
        : {
            id: row.author_id,
            name: 'ABSU Student',
            avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${row.author_id}&backgroundColor=6d45d9&textColor=ffffff`,
            handle: '@student',
            department: 'Student',
            faculty: 'Abia State University',
            level: 'Undergraduate',
            campus: 'Uturu (Main Campus)',
            bio: '',
            interests: [],
            relationshipState: 'none' as const,
          };

      const isEdited = Boolean(
        row.updated_at &&
          row.created_at &&
          new Date(row.updated_at).getTime() - new Date(row.created_at).getTime() > 2000
      );

      return {
        id: row.id,
        postId: row.post_id,
        parentId: row.parent_comment_id || null,
        author: {
          id: author.id,
          name: author.name,
          avatar: author.avatar,
          department: author.department,
          level: author.level,
        },
        content: row.body || '',
        createdAt: formatTimeAgo(row.created_at),
        updatedAt: row.updated_at,
        isEdited,
        likesCount: likesCountMap.get(row.id) || 0,
        isLiked: likedByMeSet.has(row.id),
        replies: [],
      };
    });

    // Assemble parent -> replies hierarchy cleanly (supports deep replies collapsed onto top-level root or direct parent)
    const commentById = new Map<string, Comment>();
    for (const c of flatComments) {
      commentById.set(c.id, c);
    }

    const roots: Comment[] = [];
    for (const c of flatComments) {
      if (c.parentId && commentById.has(c.parentId)) {
        const parent = commentById.get(c.parentId)!;
        parent.replies = parent.replies || [];
        parent.replies.push(c);
      } else {
        roots.push(c);
      }
    }

    return roots;
  } catch (err) {
    console.warn('Error fetching comments:', err);
    return [];
  }
}

/**
 * Add a top-level comment or threaded reply to a post in Supabase comments table
 */
export async function createRealComment(params: {
  postId: string;
  authorId: string;
  body: string;
  parentId?: string | null;
}): Promise<{ success: boolean; comment?: Comment; error?: string }> {
  try {
    const nowIso = new Date().toISOString();
    const payload: Record<string, any> = {
      post_id: params.postId,
      author_id: params.authorId,
      body: params.body.trim(),
      created_at: nowIso,
      updated_at: nowIso,
    };

    if (params.parentId) {
      payload.parent_comment_id = params.parentId;
    }

    const { data, error } = await supabase
      .from('comments')
      .insert(payload)
      .select(`
        *,
        author:profiles!comments_author_id_fkey(*)
      `)
      .single();

    if (error || !data) {
      return { success: false, error: error?.message || 'Failed to post comment.' };
    }

    const author = data.author
      ? mapProfileRowToUser(data.author, null, 'self')
      : {
          id: params.authorId,
          name: 'You',
          avatar: '',
          handle: '@you',
          department: 'Student',
          faculty: 'Abia State University',
          level: 'Undergraduate',
          campus: 'Uturu (Main Campus)',
          bio: '',
          interests: [],
          relationshipState: 'self' as const,
        };

    const comment: Comment = {
      id: data.id,
      postId: data.post_id,
      parentId: data.parent_comment_id || null,
      author: {
        id: author.id,
        name: author.name,
        avatar: author.avatar,
        department: author.department,
        level: author.level,
      },
      content: data.body,
      createdAt: 'Just now',
      updatedAt: data.updated_at,
      isEdited: false,
      likesCount: 0,
      isLiked: false,
      replies: [],
    };

    return { success: true, comment };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Comment creation failed';
    return { success: false, error: msg };
  }
}

/**
 * Edit an existing comment/reply owned by the current user
 */
export async function updateRealComment(
  commentId: string,
  authorId: string,
  body: string
): Promise<{ success: boolean; error?: string }> {
  const trimmed = body.trim();
  if (!trimmed) return { success: false, error: 'Comment cannot be empty.' };

  try {
    const { error } = await supabase
      .from('comments')
      .update({
        body: trimmed,
        updated_at: new Date().toISOString(),
      })
      .eq('id', commentId)
      .eq('author_id', authorId);

    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to update comment.',
    };
  }
}

/**
 * Delete a comment/reply owned by the current user
 */
export async function deleteRealComment(
  commentId: string,
  authorId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('comments')
      .delete()
      .eq('id', commentId)
      .eq('author_id', authorId);

    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete comment.',
    };
  }
}

/**
 * Toggle independent like on a comment or reply via `comment_reactions` (isolated from `post_reactions`)
 */
export async function toggleRealCommentReaction(
  commentId: string,
  userId: string,
  reaction = 'heart'
): Promise<{ success: boolean; isLiked: boolean; error?: string }> {
  try {
    const { data: existing, error: checkErr } = await supabase
      .from('comment_reactions')
      .select('comment_id')
      .eq('comment_id', commentId)
      .eq('user_id', userId)
      .maybeSingle();

    if (checkErr && !checkErr.message.includes('0 rows')) {
      console.warn('[Comments] comment_reactions check notice:', checkErr.message);
    }

    if (existing) {
      const { error: delErr } = await supabase
        .from('comment_reactions')
        .delete()
        .eq('comment_id', commentId)
        .eq('user_id', userId);

      if (delErr) {
        return { success: false, isLiked: true, error: delErr.message };
      }
      return { success: true, isLiked: false };
    } else {
      const { error: insErr } = await supabase.from('comment_reactions').insert({
        comment_id: commentId,
        user_id: userId,
        reaction,
        created_at: new Date().toISOString(),
      });

      if (insErr) {
        return { success: false, isLiked: false, error: insErr.message };
      }
      return { success: true, isLiked: true };
    }
  } catch (err: unknown) {
    return {
      success: false,
      isLiked: false,
      error: err instanceof Error ? err.message : 'Comment like update failed.',
    };
  }
}


// ABSU Connect Service Worker — WhatsApp-Grade Offline Shell & Supabase API Cache
const CACHE_NAME = 'absu-connect-shell-v4';
const SUPABASE_CACHE_NAME = 'absu-supabase-api-v1';
const FIVE_MINUTES_MS = 5 * 60 * 1000;

const STATIC_ASSETS = [
  '/manifest.json',
  '/icon.svg',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
  '/favicon.ico',
];

// 1. Install: precache shell assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
      .catch((err) => {
        console.warn('[SW] Precache notice:', err);
      })
  );
});

// 2. Activate: claim clients immediately and prune old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME && key !== SUPABASE_CACHE_NAME)
            .map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

// 3. Fetch interceptor
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Skip mutations, auth tokens, backend /api endpoints, and dev tools
  if (
    event.request.method !== 'GET' ||
    url.pathname.includes('/auth/v1/') ||
    url.pathname.includes('/storage/v1/') ||
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/@') ||
    url.pathname.startsWith('/src/') ||
    url.pathname.startsWith('/node_modules/')
  ) {
    return;
  }

  // A. Supabase REST API caching (5-minute TTL with offline fallback)
  if (url.hostname.includes('supabase.co') && url.pathname.includes('/rest/v1')) {
    event.respondWith(
      caches.open(SUPABASE_CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(event.request);

        // If online, fetch from network and update cache
        if (navigator.onLine) {
          try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s timeout on slow 2G/3G

            const networkResponse = await fetch(event.request, {
              signal: controller.signal,
            });
            clearTimeout(timeoutId);

            if (networkResponse && networkResponse.status === 200) {
              const headers = new Headers(networkResponse.headers);
              headers.set('sw-cached-time', Date.now().toString());
              const blob = await networkResponse.clone().blob();
              const responseToCache = new Response(blob, {
                status: networkResponse.status,
                statusText: networkResponse.statusText,
                headers,
              });
              cache.put(event.request, responseToCache).catch(() => {});
            }
            return networkResponse;
          } catch (fetchErr) {
            // Network timed out or failed: fall back to cached data
            if (cached) return cached;
            throw fetchErr;
          }
        }

        // If offline: return cached response regardless of age so chats/feed display
        if (cached) {
          return cached;
        }

        // Return empty fallback array for database queries if offline with no cache
        return new Response('[]', {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      })
    );
    return;
  }

  // B. Navigation requests (HTML document): Network First, fallback to cached shell
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put('/', clone)).catch(() => {});
          }
          return networkResponse;
        })
        .catch(async () => {
          const cachedApp = await caches.match('/');
          return (
            cachedApp ||
            new Response('<html><body>ABSU Connect is ready offline.</body></html>', {
              headers: { 'Content-Type': 'text/html' },
            })
          );
        })
    );
    return;
  }

  // C. Bundled JS, CSS, and manifest: Network First so deployed bugfixes apply immediately
  if (
    url.pathname.startsWith('/assets/') ||
    url.pathname.endsWith('.js') ||
    url.pathname.endsWith('.css') ||
    url.pathname === '/manifest.json'
  ) {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === 'basic'
          ) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseClone));
          }
          return networkResponse;
        })
        .catch(async () => {
          const cached = await caches.match(event.request);
          return cached || new Response('', { status: 504 });
        })
    );
    return;
  }

  // D. Other static assets (Icons, Fonts, Images): Stale While Revalidate
  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fetchPromise = fetch(event.request)
        .then((networkResponse) => {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === 'basic'
          ) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseClone));
          }
          return networkResponse;
        })
        .catch(() => cached);

      return cached || fetchPromise;
    })
  );
});

// -------------------------------------------------------------
// WEB PUSH NOTIFICATION HANDLERS
// -------------------------------------------------------------

self.addEventListener('push', (event) => {
  let data = {
    title: 'ABSU Connect',
    body: 'You have a new campus notification.',
    icon: '/pwa-192x192.png',
    badge: '/icon.svg',
    url: '/',
  };

  if (event.data) {
    try {
      const json = event.data.json();
      data = { ...data, ...json };
    } catch {
      data.body = event.data.text() || data.body;
    }
  }

  const notificationOptions = {
    body: data.body,
    icon: data.icon || '/pwa-192x192.png',
    badge: data.badge || '/icon.svg',
    tag: data.tag || `absu-${data.data?.type || 'general'}-${Date.now()}`,
    renotify: true,
    vibrate: [200, 100, 200],
    data: {
      url: data.url || data.data?.url || '/',
      timestamp: Date.now(),
    },
    actions: [{ action: 'open', title: 'Open ABSU Connect' }],
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'ABSU Connect', notificationOptions)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (const client of windowClients) {
        if (client.url && 'focus' in client) {
          if (targetUrl !== '/') {
            client.navigate(targetUrl);
          }
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});

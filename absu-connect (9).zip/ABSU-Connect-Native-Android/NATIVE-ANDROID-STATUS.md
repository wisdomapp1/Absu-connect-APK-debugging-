# ABSU Connect native Android milestone status — 7 November 2026

## Done in this source revision

- Removed the WebView-style social shell from the current native app entry point. `MainActivity` is a native Android Activity and the app does not load `absu-connect.vercel.app`.
- Added Supabase Auth sign-in/sign-up with encrypted local session storage and authenticated PostgREST access using the existing public client key.
- Added native Home, Friends, Messages, Alerts, More, Profile, Communities, Events and Game Center navigation/screens.
- Connected community discovery, creation, membership and community text posts to the existing Supabase `communities`, `community_members` and `posts` tables.
- Connected event discovery, submission-for-review, attendee responses and saved events to the existing `campus_events`, `event_participants` and `saved_events` tables.
- Added notification permission request, high-importance channels, a foreground Realtime listener and the FCM client/service hooks.
- Added native one-to-one WebRTC voice/video call flow, microphone/camera permission prompts, foreground call notification/service, secure Realtime signalling, call lifecycle RPCs and missed-call expiry.
- Added data-saver defaults and lower video quality (240p / 12 fps / ~180 kbps target) for mobile-data use.
- Retained the existing seven native game activities.

## Live Supabase inspection

Project reference: `aqzolewmhpmrcvkrvchn`.

The project already contains and has RLS enabled for `communities`, `community_members`, `posts`, `campus_events`, `event_participants`, `saved_events`, `notifications` and `device_push_tokens`. Community creation has an owner-bootstrap trigger; private-community join requests are changed to `pending` by a database trigger. Event creation policy permits an authenticated organiser to submit `draft` / `pending_review` events; public discovery is limited to events with `status='published'` and `visibility='public'`. This milestone uses these existing rules rather than weakening them or duplicating the tables.

The existing `send-android-push` Supabase Edge Function was confirmed active. Its source requires a valid FCM device token and `FIREBASE_SERVICE_ACCOUNT_JSON` function secret. Whether that secret is configured correctly has not been verified.

## Not done / not verified

- Native WebRTC voice/video call code, private call signalling, lifecycle RPCs, incoming-call actions and a foreground call service are now included. The Android Activity layer has not been compiled or tested between two physical phones.
- The matching Firebase Android client configuration is now included at `app/google-services.json`. The Android `applicationId` is set to `com.absuconnect.app`, matching the registered Firebase Android app; Java namespace remains `com.absuconnect.games`.
- Live Supabase has `send-android-push` v4 and `send-android-call-push` v2. At last inspection there were zero rows in `device_push_tokens` for platform `android`. Therefore no native phone token was registered yet and background FCM delivery has not been confirmed. Because the push function returns early when there are no device tokens, its log HTTP 200 does not prove the Firebase service-account secret was exercised successfully.
- No real two-phone call, push, friend request, chat, community or event acceptance test was run.
- Not every website feature is ported: media upload, threaded comments and several advanced social/admin flows remain future work.
- No Play Store release signing, app bundle, privacy/data-safety submission or production release review has been done.

## Build environment result

Portable game/domain checks passed. Android Gradle build did not run because this environment has no Android SDK / SDK Platform 35 and DNS resolution for `services.gradle.org` failed while the Gradle wrapper tried to download Gradle 8.9. As a result, the Android Java/Activity layer has not been compiler-verified here and no APK is claimed. No two-phone test was possible from this environment.

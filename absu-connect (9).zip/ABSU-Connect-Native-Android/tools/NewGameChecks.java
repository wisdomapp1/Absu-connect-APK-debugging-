import com.absuconnect.games.whot.WhotEngine;
import com.absuconnect.games.whot.WhotEngine.Card;
import com.absuconnect.games.billiards.BilliardsEngine;
import com.absuconnect.games.racing.RacingEngine;
import com.absuconnect.games.racing.RacingCatalog;
import com.absuconnect.games.fighter.FighterCombatModel;

public final class NewGameChecks {
    private static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    public static void main(String[] args){whotChecks();poolChecks();raceChecks(false);raceChecks(true);racingProgressionChecks();fighterChecks();System.out.println("WHOT, billiards, racing, and local fighter checks passed.");}
    private static void whotChecks(){
        WhotEngine game=new WhotEngine(2,23L);
        check(game.handSize(0)==6&&game.handSize(1)==6,"WHOT deals six cards each");
        check(game.drawCount()+game.handSize(0)+game.handSize(1)+game.discardCount()==54,"Nigerian WHOT deck has 54 cards");
        int checkedPenalty=0;
        for(long seed=0;seed<800&&checkedPenalty==0;seed++){
            WhotEngine g=new WhotEngine(2,seed);
            for(int turn=0;turn<90&&!g.isGameOver();turn++){
                Card pick=null;for(Card c:g.currentHand())if(g.isPlayable(c)){pick=c;break;}
                if(pick==null)g.drawForCurrentPlayer();
                else{
                    boolean testFirstPenalty=g.currentPlayer()==0&&!g.hasPenalty()&&(pick.number==2||pick.number==5);
                    g.play(pick,pick.isWhot()?g.cpuSuitChoice():pick.suit);
                    if(testFirstPenalty){
                        check(g.hasPenalty(),"2/5 creates a stacked draw penalty");
                        check(g.pendingPenalty()==(pick.number==2?2:3),"correct first penalty count");
                        check(g.currentPlayer()==1,"penalty goes to next player");
                        if(!g.hasPlayableCard()){
                            int hand=g.handSize(1);g.drawForCurrentPlayer();
                            check(g.pendingPenalty()==0&&g.handSize(1)>=hand+2,"penalty draw clears stack");
                        }
                        checkedPenalty=1;break;
                    }
                }
            }
        }
        check(checkedPenalty==1,"seeded play reaches a pick-two or pick-three rule");
        for(int seats=2;seats<=4;seats++){
            WhotEngine multi=new WhotEngine(seats,77L+seats);
            check(multi.playerCount()==seats,"seat count retained");
            for(int i=0;i<300&&!multi.isGameOver();i++){
                Card card=null;for(Card c:multi.currentHand())if(multi.isPlayable(c)){card=c;break;}
                if(card==null)multi.drawForCurrentPlayer();else multi.play(card,card.isWhot()?multi.cpuSuitChoice():card.suit);
                int cards=multi.drawCount()+multi.discardCount();for(int p=0;p<seats;p++)cards+=multi.handSize(p);
                check(cards==54,"all WHOT cards accounted for");
            }
        }
    }
    private static void poolChecks(){
        BilliardsEngine game=new BilliardsEngine();
        check(game.balls().size()==16,"pool table starts with cue plus fifteen object balls");
        check(!game.shoot(0,0,0.5f),"zero-vector shot rejected");
        check(game.shoot(1,0,0.75f),"valid opening shot starts");
        boolean moved=false;float first=game.ball(1).x;
        for(int i=0;i<2400&&game.isMoving();i++){game.update(1f/60f);if(Math.abs(game.ball(1).x-first)>0.1f)moved=true;}
        check(moved,"shot moves balls through physics");check(!game.isMoving(),"shot settles");
        check(game.currentPlayer()==0||game.currentPlayer()==1,"turn remains valid");
        int nextPlayer=game.currentPlayer();check(game.shootCpu()==(nextPlayer==1),"CPU only starts a shot on its own turn");
        BilliardsEngine newRack=new BilliardsEngine();check(!newRack.placeCueBall(250,250),"cue cannot be placed without ball-in-hand");
    }
    private static void raceChecks(boolean motorcycle){
        RacingEngine race=new RacingEngine(motorcycle);check(race.isMotorcycle()==motorcycle,"race variant retained");
        race.setRacerLoadout(0,5,3,4);
        check("Ife / Sable".equals(race.driver(0).name),"selected racing driver retained");
        check(race.vehicle(0).name.equals((motorcycle?RacingCatalog.BIKES:RacingCatalog.CARS)[3].name),"selected car or motorcycle retained");
        check("Night Circuit".equals(race.livery(0).name),"selected vehicle skin retained");
        check(race.isCpuOpponent(),"solo mode starts with CPU opponent");
        race.setPressed(0,2,true);
        for(int i=0;i<2000&&race.isRunning();i++)race.update(0.05f);
        check(!race.isRunning()&&race.winner()>=0,"3-lap race finishes against CPU");
        race.reset(false);check(!race.isCpuOpponent(),"same-device multiplayer mode selected");
        race.setPressed(0,2,true);race.setPressed(1,2,true);
        for(int i=0;i<2000&&race.isRunning();i++)race.update(0.05f);
        check(!race.isRunning()&&race.winner()>=0,"two-player race finishes");
    }
    private static void racingProgressionChecks(){
        check(RacingCatalog.DRIVERS.length>=16&&RacingCatalog.CARS.length>=12&&RacingCatalog.BIKES.length>=12&&RacingCatalog.SKINS.length>=16,"large driver, car, bike and livery collections");
        check(RacingCatalog.eligibleCount(RacingCatalog.DRIVERS,1)==6&&RacingCatalog.eligibleCount(RacingCatalog.DRIVERS,1)<RacingCatalog.DRIVERS.length/2,"most race drivers are locked behind ranks");
        check(RacingCatalog.eligibleCount(RacingCatalog.CARS,1)==5&&RacingCatalog.eligibleCount(RacingCatalog.BIKES,1)==5,"starter car and bike choices remain playable");
        RacingEngine base=new RacingEngine(false),upgraded=new RacingEngine(false);base.setRacerLoadout(0,0,0,0);upgraded.setRacerLoadout(0,0,0,0,5,5);base.setPressed(0,2,true);upgraded.setPressed(0,2,true);
        for(int i=0;i<80;i++){base.update(.05f);upgraded.update(.05f);}
        check(upgraded.racer(0).speed>base.racer(0).speed,"driver and vehicle upgrades change race performance");
        RacingEngine highGrip=new RacingEngine(false),lowGrip=new RacingEngine(false);highGrip.setRacerLoadout(0,13,3,0);lowGrip.setRacerLoadout(0,2,1,0);highGrip.setRacerLoadout(1,0,0,0);lowGrip.setRacerLoadout(1,0,0,0);highGrip.update(.05f);lowGrip.update(.05f);
        check(highGrip.racer(0).speed>lowGrip.racer(0).speed,"driver and vehicle handling profiles change collision slowdown");
        highGrip.setPressed(0,1,true);lowGrip.setPressed(0,1,true);highGrip.update(.05f);lowGrip.update(.05f);
        check(highGrip.racer(0).visualLane>lowGrip.racer(0).visualLane&&lowGrip.racer(0).visualLane>1f,
                "higher handling gives a smoother, faster lane transition in both race variants");
    }
    private static void fighterChecks(){
        FighterCombatModel duel=new FighterCombatModel();duel.setLocalDuel(true);long now=System.currentTimeMillis()+1500;
        duel.step(false,true,now);duel.step(false,true,now+1);
        duel.act(FighterCombatModel.Action.LIGHT,now);check(duel.snapshot().sparringHealth==91,"fighter P1 attack damages P2");
        duel.actOpponent(FighterCombatModel.Action.HEAVY,now+1000);check(duel.snapshot().playerHealth==82,"fighter P2 attack damages P1");
        duel.act(FighterCombatModel.Action.GUARD,now+1100);duel.actOpponent(FighterCombatModel.Action.LIGHT,now+2100);
        check(duel.snapshot().playerHealth==79,"fighter guard reduces incoming damage");
    }
}

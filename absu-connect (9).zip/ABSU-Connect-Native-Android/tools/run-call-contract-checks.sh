#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
require() {
  local file="$1" pattern="$2" message="$3"
  if ! grep -Eq "$pattern" "$file"; then
    echo "FAILED: $message" >&2
    exit 1
  fi
}
require app/src/main/java/com/absuconnect/games/ui/CallActivity.java 'create_call_session' 'Native call start must use the authenticated call-session RPC.'
require app/src/main/java/com/absuconnect/games/ui/CallActivity.java 'send-android-call-push' 'Native outgoing calls must dispatch the call-specific FCM function.'
require app/src/main/java/com/absuconnect/games/ui/CallActivity.java 'new CallRealtimeChannel' 'Native calls must connect to private Supabase Realtime signalling.'
require app/src/main/java/com/absuconnect/games/ui/CallActivity.java 'createOffer|createAnswer' 'Native calls must implement both offer and answer negotiation.'
require app/src/main/java/com/absuconnect/games/ui/CallActivity.java 'IceRestart' 'Native calls must include an ICE restart attempt.'
require app/src/main/java/com/absuconnect/games/push/AbsuFirebaseMessagingService.java 'call_invite' 'FCM must recognize incoming call data messages.'
require app/src/main/java/com/absuconnect/games/calls/IncomingCallNotifications.java 'CallStyle.forIncomingCall' 'Incoming calls must create an actionable call-style notification.'
require app/src/main/AndroidManifest.xml 'android.permission.RECORD_AUDIO' 'Microphone permission must be declared.'
require app/src/main/AndroidManifest.xml 'android.permission.CAMERA' 'Camera permission must be declared.'
require app/src/main/AndroidManifest.xml 'USE_FULL_SCREEN_INTENT' 'Incoming call pop-up permission must be declared.'
require supabase/migrations/20261107184642_native_call_sessions_and_private_signaling.sql 'can_access_absu_call_topic' 'Supabase migration must define private call-channel authorization.'
require supabase/migrations/20261107191502_call_expiry_and_timeout_guard.sql 'expire_unanswered_calls' 'Supabase migration must expire unanswered call sessions.'
echo "Native calling integration contract checks passed (12 source/config assertions)."
echo "These checks are static wiring checks; they do not replace an Android build or two-device call test."

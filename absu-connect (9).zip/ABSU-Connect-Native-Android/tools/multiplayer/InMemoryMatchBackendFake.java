import com.absuconnect.games.GameCatalog;
import com.absuconnect.games.multiplayer.MatchInviteRepository;
import com.absuconnect.games.multiplayer.MatchProtocol.ActionReceipt;
import com.absuconnect.games.multiplayer.MatchProtocol.Invite;
import com.absuconnect.games.multiplayer.MatchProtocol.InviteInboxListener;
import com.absuconnect.games.multiplayer.MatchProtocol.InviteStatus;
import com.absuconnect.games.multiplayer.MatchProtocol.Listener;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchAction;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchException;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchSnapshot;
import com.absuconnect.games.multiplayer.MatchProtocol.Room;
import com.absuconnect.games.multiplayer.MatchProtocol.RoomStatus;
import com.absuconnect.games.multiplayer.MatchProtocol.Subscription;
import com.absuconnect.games.multiplayer.MatchTransport;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** TEST ONLY. No sockets, Supabase calls, real authentication, server physics, or release wiring. */
public final class InMemoryMatchBackendFake implements MatchInviteRepository,MatchTransport {
    private final Map<String,Invite> invites=new LinkedHashMap<>();
    private final Map<String,String> inviteRoomIds=new HashMap<>();
    private final Map<String,Room> rooms=new LinkedHashMap<>();
    private final Map<String,MatchSnapshot> snapshots=new HashMap<>();
    private final Map<String,List<Listener>> listeners=new HashMap<>();
    private final Map<String,List<InviteInboxListener>> inboxListeners=new HashMap<>();
    private final Map<String,ActionReceipt> receiptsById=new HashMap<>();
    private int nextId=1;

    @Override public synchronized List<Invite> listIncomingInvites(String recipient){
        List<Invite> result=new ArrayList<>();
        for(Invite invite:invites.values())if(invite.recipientId.equals(recipient)&&invite.status==InviteStatus.PENDING)result.add(invite);
        return Collections.unmodifiableList(result);
    }
    @Override public synchronized List<Invite> listSentInvites(String sender){
        List<Invite> result=new ArrayList<>();
        for(Invite invite:invites.values())if(invite.senderId.equals(sender)&&invite.status==InviteStatus.PENDING)result.add(invite);
        return Collections.unmodifiableList(result);
    }
    @Override public synchronized Subscription subscribeIncomingInvites(String recipient,InviteInboxListener listener) throws MatchException {
        if(recipient==null||listener==null)throw new MatchException("Recipient and inbox listener are required.");
        inboxListeners.computeIfAbsent(recipient,k->new ArrayList<>()).add(listener);
        for(Invite invite:listIncomingInvites(recipient))listener.onInviteChanged(invite);
        return ()->{synchronized(InMemoryMatchBackendFake.this){List<InviteInboxListener> ls=inboxListeners.get(recipient);if(ls!=null)ls.remove(listener);}};
    }
    @Override public synchronized Invite createInvite(String gameId,String hostId,String friendId,int maxPlayers,long expiry) throws MatchException {
        requireGame(gameId,maxPlayers);
        if(hostId==null||friendId==null||hostId.equals(friendId))throw new MatchException("Invalid host/friend pair.");
        String matchId="fake-match-"+nextId++,inviteId="fake-invite-"+nextId++;
        Map<Integer,String> players=new LinkedHashMap<>();players.put(0,hostId);
        rooms.put(matchId,new Room(matchId,gameId,maxPlayers,RoomStatus.WAITING,1,players));
        snapshots.put(matchId,new MatchSnapshot(matchId,gameId,RoomStatus.WAITING,0,1,-1,"{}"));
        Invite invite=new Invite(inviteId,matchId,gameId,hostId,friendId,InviteStatus.PENDING,expiry);
        invites.put(inviteId,invite);inviteRoomIds.put(inviteId,matchId);notifyInbox(invite);return invite;
    }
    @Override public synchronized Invite inviteFriendToRoom(String matchId,String inviterId,String friendId,long expiry) throws MatchException {
        Room room=rooms.get(matchId);
        if(room==null||!room.includes(inviterId)||room.status!=RoomStatus.WAITING)throw new MatchException("Room is not accepting invites.");
        if(friendId==null||friendId.equals(inviterId))throw new MatchException("Invalid friend.");
        int reserved=room.playersBySeat.size();
        for(Invite invite:invites.values())if(invite.matchId.equals(matchId)&&invite.status==InviteStatus.PENDING)reserved++;
        if(reserved>=room.maxPlayers)throw new MatchException("Room has no open seats.");
        String inviteId="fake-invite-"+nextId++;
        Invite invite=new Invite(inviteId,matchId,room.gameId,inviterId,friendId,InviteStatus.PENDING,expiry);
        invites.put(inviteId,invite);inviteRoomIds.put(inviteId,matchId);notifyInbox(invite);return invite;
    }
    @Override public synchronized Invite respondToInvite(String inviteId,String recipient,boolean accept,long now) throws MatchException {
        Invite invite=invites.get(inviteId);
        if(invite==null||!invite.recipientId.equals(recipient))throw new MatchException("Invite not found for this recipient.");
        if(invite.status!=InviteStatus.PENDING)throw new MatchException("Invite is no longer pending.");
        if(now>=invite.expiresAtEpochMs){Invite expired=copy(invite,InviteStatus.EXPIRED);invites.put(inviteId,expired);notifyInbox(expired);throw new MatchException("Invite expired.");}
        if(!accept){Invite declined=copy(invite,InviteStatus.DECLINED);invites.put(inviteId,declined);notifyInbox(declined);return declined;}
        String matchId=inviteRoomIds.get(inviteId);Room room=rooms.get(matchId);
        if(room==null||room.status!=RoomStatus.WAITING)throw new MatchException("Room is not accepting players.");
        Map<Integer,String> players=new LinkedHashMap<>(room.playersBySeat);int seat=0;
        while(players.containsKey(seat)&&seat<room.maxPlayers)seat++;
        if(seat>=room.maxPlayers)throw new MatchException("Room is full.");
        players.put(seat,recipient);
        RoomStatus status=players.size()==room.maxPlayers?RoomStatus.READY:RoomStatus.WAITING;
        Room updatedRoom=new Room(room.matchId,room.gameId,room.maxPlayers,status,room.version+1,players);rooms.put(matchId,updatedRoom);
        MatchSnapshot old=snapshots.get(matchId);
        MatchSnapshot snapshot=new MatchSnapshot(matchId,room.gameId,status,old.stateVersion,old.nextSequence,old.activeSeat,old.stateJson);
        snapshots.put(matchId,snapshot);
        Invite accepted=copy(invite,InviteStatus.ACCEPTED);invites.put(inviteId,accepted);notifyInbox(accepted);broadcast(matchId,snapshot);return accepted;
    }
    @Override public synchronized void cancelInvite(String inviteId,String sender) throws MatchException {
        Invite invite=invites.get(inviteId);
        if(invite==null||!invite.senderId.equals(sender))throw new MatchException("Only the sender may cancel this invite.");
        if(invite.status!=InviteStatus.PENDING)throw new MatchException("Only a pending invite can be cancelled.");
        Invite cancelled=copy(invite,InviteStatus.CANCELLED);invites.put(inviteId,cancelled);notifyInbox(cancelled);
    }
    @Override public synchronized Room fetchRoom(String matchId,String participant) throws MatchException {
        Room room=rooms.get(matchId);
        if(room==null||!room.includes(participant))throw new MatchException("Room not found for this participant.");
        return room;
    }
    @Override public synchronized Subscription subscribe(String matchId,String userId,long afterVersion,Listener listener) throws MatchException {
        fetchRoom(matchId,userId);if(listener==null)throw new MatchException("Listener is required.");
        listeners.computeIfAbsent(matchId,k->new ArrayList<>()).add(listener);
        listener.onSnapshot(snapshots.get(matchId));
        return ()->{synchronized(InMemoryMatchBackendFake.this){List<Listener> ls=listeners.get(matchId);if(ls!=null)ls.remove(listener);}};
    }
    @Override public synchronized MatchSnapshot fetchSnapshot(String matchId,String userId) throws MatchException {
        fetchRoom(matchId,userId);MatchSnapshot snapshot=snapshots.get(matchId);
        if(snapshot==null)throw new MatchException("No test snapshot exists.");
        return snapshot;
    }
    @Override public synchronized ActionReceipt submitAction(MatchAction action) throws MatchException {
        if(action==null)throw new MatchException("Action is required.");
        String actionKey=action.matchId+":"+action.actorId+":"+action.clientActionId;
        if(receiptsById.containsKey(actionKey))return receiptsById.get(actionKey);
        Room room=rooms.get(action.matchId);MatchSnapshot current=snapshots.get(action.matchId);
        if(room==null||current==null||!room.gameId.equals(action.gameId))return reject("Unknown match/game.",current);
        if(!room.includes(action.actorId)||room.seatFor(action.actorId)!=action.seat)return reject("Actor/seat mismatch.",current);
        if(current.status!=RoomStatus.READY&&current.status!=RoomStatus.IN_PROGRESS)return reject("Room is not active.",current);
        if(action.sequence!=current.nextSequence||action.expectedVersion!=current.stateVersion)return reject("Stale sequence/version.",current);
        RoomStatus status=RoomStatus.IN_PROGRESS;
        String state="{\"eventCount\":"+(current.stateVersion+1)+",\"lastAction\":\""+action.type+"\",\"lastSeat\":"+action.seat+"}";
        MatchSnapshot updated=new MatchSnapshot(action.matchId,action.gameId,status,current.stateVersion+1,current.nextSequence+1,-1,state);
        snapshots.put(action.matchId,updated);rooms.put(action.matchId,new Room(room.matchId,room.gameId,room.maxPlayers,status,room.version+1,room.playersBySeat));
        ActionReceipt receipt=new ActionReceipt(true,"accepted by test fake only",updated);receiptsById.put(actionKey,receipt);broadcast(action.matchId,updated);return receipt;
    }
    public synchronized Invite inviteForTest(String inviteId){return invites.get(inviteId);}
    private ActionReceipt reject(String reason,MatchSnapshot current){return new ActionReceipt(false,reason,current);}
    private void notifyInbox(Invite invite){List<InviteInboxListener> inbox=inboxListeners.get(invite.recipientId);if(inbox!=null)for(InviteInboxListener listener:new ArrayList<>(inbox))listener.onInviteChanged(invite);}
    private void broadcast(String matchId,MatchSnapshot snapshot){List<Listener> roomListeners=listeners.get(matchId);if(roomListeners!=null)for(Listener listener:new ArrayList<>(roomListeners))listener.onSnapshot(snapshot);}
    private static Invite copy(Invite invite,InviteStatus status){return new Invite(invite.inviteId,invite.matchId,invite.gameId,invite.senderId,invite.recipientId,status,invite.expiresAtEpochMs);}
    private static void requireGame(String gameId,int count) throws MatchException {
        GameCatalog.Module game=GameCatalog.find(gameId);
        if(game==null||count<game.minPlayers||count>game.maxPlayers)throw new MatchException("Invalid game ID or capacity.");
    }
}

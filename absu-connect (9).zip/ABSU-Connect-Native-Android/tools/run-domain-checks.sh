#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" \
	  "$ROOT/app/src/main/java/com/absuconnect/games/action/ActionContentCatalog.java" \
	  "$ROOT/app/src/main/java/com/absuconnect/games/action/GameCoinPricing.java" \
	  "$ROOT/app/src/main/java/com/absuconnect/games/action/LocalGameProgression.java" \
	  "$ROOT/app/src/main/java/com/absuconnect/games/shooter/ShooterMatchModel.java" \
	  "$ROOT/app/src/main/java/com/absuconnect/games/shooter/Shooter3DCamera.java" \
	  "$ROOT/app/src/main/java/com/absuconnect/games/racing/RacingCatalog.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/ludo/LudoEngine.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/fighter/FighterCombatModel.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/whot/WhotEngine.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/billiards/BilliardsEngine.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/racing/RacingEngine.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/wallet/GameWalletRepository.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/GameCatalog.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/MatchProtocol.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/MatchInviteRepository.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/MatchTransport.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/GameActionCodec.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/AllowlistGameActionCodec.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/MatchSessionCoordinator.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/examples/FighterArenaAdapter.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/examples/RacingMatchAdapter.java" \
  "$ROOT/app/src/main/java/com/absuconnect/games/multiplayer/examples/TurnBasedMatchAdapter.java" \
  "$ROOT/tools/multiplayer/InMemoryMatchBackendFake.java" \
  "$ROOT/tools/LudoEngineChecks.java" \
  "$ROOT/tools/FighterModelChecks.java" \
  "$ROOT/tools/NewGameChecks.java" \
  "$ROOT/tools/ActionGameChecks.java" \
  "$ROOT/tools/ShooterModelChecks.java" \
  "$ROOT/tools/MultiplayerScaffoldChecks.java"
java -cp "$OUT" LudoEngineChecks
java -cp "$OUT" FighterModelChecks
java -cp "$OUT" NewGameChecks
java -cp "$OUT" ActionGameChecks
java -cp "$OUT" com.absuconnect.games.shooter.ShooterModelChecks
java -cp "$OUT" MultiplayerScaffoldChecks

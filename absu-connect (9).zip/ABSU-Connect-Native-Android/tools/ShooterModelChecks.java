package com.absuconnect.games.shooter;

import com.absuconnect.games.action.ActionContentCatalog;

public final class ShooterModelChecks {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        pitchChangesHits();coverBlocksSight();emptyAmmoFeedback();trainingKeepsAmmo();jumpStateAndAirAim();endlessProgression();waveClearingAdvancesAutomatically();
        System.out.println("Shooter progression, no-timer, pitch, cover, ammunition, training and jump checks passed.");
    }
    private static void jumpStateAndAirAim(){
        ShooterMatchModel game=new ShooterMatchModel();long now=System.currentTimeMillis();
        check(game.jump(now),"grounded player can jump");check(!game.snapshot().grounded&&game.snapshot().jumpHeight>0,"model reports airborne height");
        check(!game.jump(now+200),"repeat input cannot retrigger jump");game.tick(now+700);check(game.snapshot().grounded,"jump returns to ground");
        check(!game.jump(now+800),"cooldown survives landing");
        ShooterMatchModel range=new ShooterMatchModel();range.setTrainingMode(true);range.jump(now);range.aimAt(50,25,0);
        int hp=range.snapshot().botHealth[2];check(range.fire(now+200),"airborne shot fires");check(range.snapshot().botHealth[2]==hp,"old ground aim misses airborne target");
        range.aimAt(50,25,-.04f);check(range.fire(now+600),"corrected airborne shot fires");check(range.snapshot().botHealth[2]<hp,"pitch compensation hits airborne target");
        jumpEvadesCpuShot();
    }
    private static void jumpEvadesCpuShot(){
        long now=System.currentTimeMillis();ShooterMatchModel exposed=new ShooterMatchModel();
        for(int i=0;i<40;i++)exposed.move(-.92f,-.39f,.08f);
        exposed.tick(now+1900);check(exposed.snapshot().playerHealth<exposed.snapshot().maxHealth,"clear CPU lane hits a grounded player");

        ShooterMatchModel evading=new ShooterMatchModel();
        for(int i=0;i<40;i++)evading.move(-.92f,-.39f,.08f);
        check(evading.jump(now+1450),"player can time jump before CPU shot");evading.tick(now+1900);
        check(evading.snapshot().playerHealth==evading.snapshot().maxHealth,"well-timed jump avoids the CPU shot");
        check(evading.snapshot().status.contains("evaded"),"successful jump evade is reported");
    }
    private static void pitchChangesHits(){
        ShooterMatchModel level=new ShooterMatchModel();level.setTrainingMode(true);level.aimAt(50,25,0f);
        int before=level.snapshot().botHealth[2];check(level.fire(System.currentTimeMillis()+5000),"level reticle fires");
        check(level.snapshot().botHealth[2]<before,"level reticle hits target");
        ShooterMatchModel high=new ShooterMatchModel();high.setTrainingMode(true);high.aimAt(50,25,.45f);
        before=high.snapshot().botHealth[2];check(high.fire(System.currentTimeMillis()+5000),"pitched reticle fires");
        check(high.snapshot().botHealth[2]==before,"high pitch misses target");
    }
    private static void coverBlocksSight(){
        ActionContentCatalog.Cover[] cover={new ActionContentCatalog.Cover(4,4,6,6)};
        check(ShooterMatchModel.lineBlocked(0,5,10,5,cover),"segment through cover is blocked");
        check(!ShooterMatchModel.lineBlocked(0,1,10,1,cover),"clear lane remains open");
        ShooterMatchModel game=new ShooterMatchModel();for(int i=0;i<42;i++)game.move(1,0,.08f);
        check(game.snapshot().playerX>79f,"player reaches the intended test lane");game.aimAt(75,14);
        int before=game.snapshot().botHealth[1];check(game.fire(System.currentTimeMillis()+5000),"covered target shot fires");
        check(game.snapshot().botHealth[1]==before,"map cover blocks a player hit");
    }
    private static void emptyAmmoFeedback(){
        ShooterMatchModel game=new ShooterMatchModel();game.aimAt(50,25);long start=System.currentTimeMillis()+10000;
        for(int i=0;i<ActionContentCatalog.GUNS[0].magazine;i++)check(game.fire(start+i*400L),"magazine shot "+i+" fires");
        check(game.snapshot().ammo==0,"full magazine is consumed");
        check(!game.fire(start+ActionContentCatalog.GUNS[0].magazine*400L),"empty magazine cannot fire");
        check(game.snapshot().status.contains("Magazine empty"),"empty magazine tells player to reload");
    }
    private static void endlessProgression(){
        check(ShooterMatchModel.enemyHealthForLevel(2)>ShooterMatchModel.enemyHealthForLevel(1),"level two health rises gently");
        check(ShooterMatchModel.enemyHealthForLevel(10)>ShooterMatchModel.enemyHealthForLevel(2),"health keeps scaling");
        check(ShooterMatchModel.enemyDamageForLevel(10)>ShooterMatchModel.enemyDamageForLevel(2),"damage keeps scaling");
        ShooterMatchModel game=new ShooterMatchModel();game.tick(System.currentTimeMillis()+181000);
        check(!game.snapshot().matchOver&&game.snapshot().timeLeftMs==-1,"elapsed time cannot end campaign");
    }
    private static void waveClearingAdvancesAutomatically(){
        float[][] starts={{25,13},{75,14},{50,25},{19,38},{81,37}};float longest=0f;
        for(float[] target:starts){float dx=target[0]-50f,dy=target[1]-51f;longest=Math.max(longest,(float)Math.sqrt(dx*dx+dy*dy));}
        int weapon=0;for(int i=0;i<ActionContentCatalog.GUNS.length;i++)if(ActionContentCatalog.GUNS[i].range>=longest&&ActionContentCatalog.GUNS[i].damage>ActionContentCatalog.GUNS[weapon].damage)weapon=i;
        int clearMap=-1;
        for(int map=0;map<ActionContentCatalog.ARENAS.length;map++){
            ShooterMatchModel candidate=new ShooterMatchModel();candidate.configure(0,weapon,0,map,0);
            boolean clear=true;for(float[] target:starts)if(ShooterMatchModel.lineBlocked(50,51,target[0],target[1],candidate.arena().coverPieces))clear=false;
            if(clear){clearMap=map;break;}
        }
        check(clearMap>=0,"at least one arena has a clear firing lane to each wave target");
        ShooterMatchModel campaign=new ShooterMatchModel();campaign.configure(0,weapon,0,clearMap,0);campaign.setTrainingMode(true);
        long now=System.currentTimeMillis()+10000;
        for(int wave=1;wave<=2;wave++){
            int shots=0,startingLevel=campaign.snapshot().level;
            while(campaign.snapshot().level==startingLevel&&shots<1000){
                ShooterMatchModel.Result state=campaign.snapshot();int target=0;while(target<5&&state.botHealth[target]<=0)target++;
                if(target>=5)break;
                campaign.aimAt(state.botX[target],state.botY[target]);
                boolean accepted=campaign.fire(now);check(accepted,"training campaign shot is accepted: "+campaign.snapshot().status+" · weapon "+weapon+" · level "+campaign.snapshot().level);now+=3000;shots++;
            }
            ShooterMatchModel.Result after=campaign.snapshot();
            check(after.level==wave+1&&after.aliveBots==5,"clearing a wave automatically opens the next five-target level; got level "+after.level+" with "+after.aliveBots+" live targets");
        }
    }
    private static void trainingKeepsAmmo(){
        ShooterMatchModel game=new ShooterMatchModel();game.setTrainingMode(true);game.aimAt(50,25);int ammo=game.snapshot().ammo;
        check(game.fire(System.currentTimeMillis()+5000),"training shot one fires");
        check(game.fire(System.currentTimeMillis()+6000),"training shot two fires");
        check(game.snapshot().ammo==ammo,"training does not consume ammo");
    }
}

import com.absuconnect.games.fighter.FighterCombatModel;

public final class FighterModelChecks {
    public static void main(String[] args) {
        FighterCombatModel model = new FighterCombatModel();
        long start = System.currentTimeMillis() + 10000;
        model.step(false, true, start);
        model.step(false, true, start + 1);
        FighterCombatModel.Result light = model.act(FighterCombatModel.Action.LIGHT, start + 2);
        check(light.sparringHealth == 91 && light.stamina == 92, "light strike damage/stamina");
        long now = start + 1000;
        FighterCombatModel.Result guard = model.act(FighterCombatModel.Action.GUARD, now);
        check(guard.pose == 2, "guard pose");
        FighterCombatModel.Result dodge = model.act(FighterCombatModel.Action.DODGE, now + 50);
        check(dodge.pose == 3 && dodge.stamina == 88, "dodge spends stamina");
        System.out.println("FighterCombatModel checks passed");
    }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
}

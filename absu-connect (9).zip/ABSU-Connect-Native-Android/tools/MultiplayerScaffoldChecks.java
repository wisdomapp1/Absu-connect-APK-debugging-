import com.absuconnect.games.multiplayer.MatchProtocol.ActionIntent;
import com.absuconnect.games.multiplayer.MatchProtocol.ActionReceipt;
import com.absuconnect.games.multiplayer.MatchProtocol.Invite;
import com.absuconnect.games.multiplayer.MatchProtocol.InviteResponse;
import com.absuconnect.games.multiplayer.MatchProtocol.InviteStatus;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchAction;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchException;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchSnapshot;
import com.absuconnect.games.multiplayer.MatchProtocol.Room;
import com.absuconnect.games.multiplayer.MatchProtocol.RoomStatus;
import com.absuconnect.games.multiplayer.MatchProtocol.Subscription;
import com.absuconnect.games.multiplayer.MatchSessionCoordinator;
import com.absuconnect.games.multiplayer.examples.FighterArenaAdapter;
import com.absuconnect.games.multiplayer.examples.RacingMatchAdapter;
import com.absuconnect.games.multiplayer.examples.TurnBasedMatchAdapter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class MultiplayerScaffoldChecks {
    private static int checks=0;
    public static void main(String[] args) throws Exception {
        inviteAcceptDeclineSeatsAndCapacity();
        fighterArenaBroadcastVersionAndReconnect();
        racingAndOtherGameCodecs();
        System.out.println("Multiplayer scaffold contract checks passed ("+checks+" assertions); no live network was used.");
    }
    private static void inviteAcceptDeclineSeatsAndCapacity() throws Exception {
        InMemoryMatchBackendFake backend=new InMemoryMatchBackendFake();MatchSessionCoordinator coordinator=new MatchSessionCoordinator(backend,backend);
        List<String> inboxChanges=new ArrayList<>();
        Subscription inbox=backend.subscribeIncomingInvites("guest",new com.absuconnect.games.multiplayer.MatchProtocol.InviteInboxListener(){
            @Override public void onInviteChanged(Invite invite){inboxChanges.add(invite.status.name());}
            @Override public void onDisconnected(String reason){throw new AssertionError(reason);}
        });
        Invite pending=coordinator.createInvite("campus_duel","host","guest",2,Long.MAX_VALUE);
        check(pending.status==InviteStatus.PENDING&&pending.gameId.equals("campus_duel"),"create creates a game-bound pending invite");
        check(backend.listIncomingInvites("guest").size()==1&&backend.listSentInvites("host").size()==1,"incoming and outgoing invite lists are scoped by recipient/sender");
        check(inboxChanges.contains("PENDING"),"invite inbox subscription receives a new invite");
        expectFailure(()->coordinator.respond(pending.inviteId,"stranger",true,1),"invite response is recipient scoped");
        InviteResponse accepted=coordinator.respond(pending.inviteId,"guest",true,1);
        check(accepted.invite.status==InviteStatus.ACCEPTED&&accepted.room.status==RoomStatus.READY,"accepted two-seat duel moves room to ready");
        check(inboxChanges.contains("ACCEPTED")&&backend.listIncomingInvites("guest").isEmpty(),"accepted invite leaves the pending list and notifies the inbox");
        check(accepted.room.seatFor("host")==0&&accepted.room.seatFor("guest")==1,"host/guest seats are assigned and visible");
        expectFailure(()->coordinator.join(accepted.room.matchId,"stranger"),"only a room participant can join");

        Invite declined=coordinator.createInvite("kart_racing","race-host","race-guest",2,Long.MAX_VALUE);
        InviteResponse decline=coordinator.respond(declined.inviteId,"race-guest",false,1);
        check(decline.invite.status==InviteStatus.DECLINED&&decline.room==null,"decline closes the invite without assigning a guest seat");
        expectFailure(()->coordinator.respond(declined.inviteId,"race-guest",true,2),"closed invite cannot later be accepted");
        expectFailure(()->coordinator.createInvite("campus_fireline","fire-host","fire-guest",2,Long.MAX_VALUE),"Fireline cannot be invited to multiplayer");
        Invite expiring=coordinator.createInvite("campus_duel","duel-host","duel-guest",2,100);
        expectFailure(()->coordinator.respond(expiring.inviteId,"duel-guest",true,100),"expired invite cannot be accepted");
        check(backend.inviteForTest(expiring.inviteId).status==InviteStatus.EXPIRED,"expired invite leaves pending status");

        Invite ludo=coordinator.createInvite("campus_ludo","board-host","board-one",4,Long.MAX_VALUE);
        InviteResponse first=coordinator.respond(ludo.inviteId,"board-one",true,1);
        check(first.room.status==RoomStatus.WAITING&&first.room.maxPlayers==4,"multi-seat Ludo may remain a lobby while more friends are invited");
        Invite second=coordinator.inviteAnotherFriend(ludo.matchId,"board-host","board-two",Long.MAX_VALUE);
        InviteResponse secondAccepted=coordinator.respond(second.inviteId,"board-two",true,2);
        check(secondAccepted.room.seatFor("board-two")==2,"additional friend receives the next available seat");
        inbox.close();
    }

    private static void fighterArenaBroadcastVersionAndReconnect() throws Exception {
        InMemoryMatchBackendFake backend=new InMemoryMatchBackendFake();MatchSessionCoordinator coordinator=new MatchSessionCoordinator(backend,backend);
        Invite invite=coordinator.createInvite("campus_duel","fighter-a","fighter-b",2,Long.MAX_VALUE);
        coordinator.respond(invite.inviteId,"fighter-b",true,1);
        MatchSessionCoordinator.Session host=coordinator.join(invite.matchId,"fighter-a");
        MatchSessionCoordinator.Session guest=coordinator.join(invite.matchId,"fighter-b");
        List<Long> guestVersions=new ArrayList<>();
        Subscription hostSub=coordinator.subscribe(host,new RecordingListener(new ArrayList<>()));
        Subscription guestSub=coordinator.subscribe(guest,new RecordingListener(guestVersions));
        FighterArenaAdapter fighter=new FighterArenaAdapter();
        ActionIntent attack=fighter.encode("attack",Collections.singletonMap("move","light"));
        ActionReceipt accepted=coordinator.sendIntent(host,fighter,attack);
        check(accepted.accepted&&accepted.snapshot.stateVersion==1&&accepted.snapshot.nextSequence==2,"fighter intent receives an acknowledged sequence/version");
        check(guestVersions.contains(1L),"opponent receives the newer authoritative snapshot event");
        check(coordinator.reconnect(guest).stateVersion==1,"reconnect obtains a complete current snapshot");
        MatchAction stale=new MatchAction(invite.matchId,"fighter-a",0,"stale-action",1,0,attack);
        ActionReceipt rejected=backend.submitAction(stale);
        check(!rejected.accepted&&rejected.reason.contains("Stale"),"stale sequence/version is rejected and returns current state");
        expectFailure(()->fighter.encode("teleport",Collections.emptyMap()),"fighter codec blocks unknown action types");
        expectFailure(()->coordinator.sendIntent(host,new RacingMatchAdapter("kart_racing"),attack),"cross-game adapter cannot send into the fighter room");
        hostSub.close();guestSub.close();host.close();guest.close();
    }

    private static void racingAndOtherGameCodecs() throws Exception {
        InMemoryMatchBackendFake backend=new InMemoryMatchBackendFake();MatchSessionCoordinator coordinator=new MatchSessionCoordinator(backend,backend);
        Invite invite=coordinator.createInvite("bike_racing","rider-a","rider-b",2,Long.MAX_VALUE);
        coordinator.respond(invite.inviteId,"rider-b",true,1);
        MatchSessionCoordinator.Session rider=coordinator.join(invite.matchId,"rider-b");
        RacingMatchAdapter bike=new RacingMatchAdapter("bike_racing");
        ActionIntent throttle=bike.encode("throttle",Collections.singletonMap("value","0.75"));
        ActionReceipt receipt=coordinator.sendIntent(rider,bike,throttle);
        check(receipt.accepted&&receipt.snapshot.gameId.equals("bike_racing"),"bike race uses its own game ID and player input stream");
        expectFailure(()->new RacingMatchAdapter("campus_duel"),"racing adapter refuses non-racing game IDs");

        check(com.absuconnect.games.GameCatalog.find("campus_fireline").minPlayers==1
                &&com.absuconnect.games.GameCatalog.find("campus_fireline").maxPlayers==1,"Fireline is catalogued as a one-player campaign");
        TurnBasedMatchAdapter ludo=new TurnBasedMatchAdapter("campus_ludo"),whot=new TurnBasedMatchAdapter("naija_whot"),pool=new TurnBasedMatchAdapter("billiards");
        check(ludo.encode("roll",Collections.singletonMap("client_hint","roll")).gameId.equals("campus_ludo")
                &&ludo.encode("move",Collections.singletonMap("token","0")).gameId.equals("campus_ludo"),"Ludo intents match the migration's roll/move allowlist");
        check(whot.encode("play_card",Collections.singletonMap("card","card-1")).gameId.equals("naija_whot")
                &&whot.encode("draw_card",Collections.emptyMap()).gameId.equals("naija_whot"),"WHOT intents match the migration's play/draw allowlist");
        check(pool.encode("shoot",Collections.singletonMap("shot","cue-input")).gameId.equals("billiards")
                &&pool.encode("place_cue_ball",Collections.singletonMap("x","250")).gameId.equals("billiards"),"8-Ball intents match the migration's shot/placement allowlist");
        expectFailure(()->ludo.encode("submit_turn",Collections.singletonMap("move","piece-1")),"obsolete generic turn intent is rejected before networking");
        rider.close();
    }

    private static final class RecordingListener implements MatchProtocolListener {
        private final List<Long> versions;
        RecordingListener(List<Long> versions){this.versions=versions;}
        @Override public void onSnapshot(MatchSnapshot snapshot){versions.add(snapshot.stateVersion);}
        @Override public void onDisconnected(String reason){throw new AssertionError(reason);}
    }
    private interface MatchProtocolListener extends com.absuconnect.games.multiplayer.MatchProtocol.Listener {}
    private interface Checked { void run() throws Exception; }
    private static void expectFailure(Checked call,String message) throws Exception {boolean failed=false;try{call.run();}catch(MatchException|IllegalArgumentException expected){failed=true;}check(failed,message);}
    private static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
}

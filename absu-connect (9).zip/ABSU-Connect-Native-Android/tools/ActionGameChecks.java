import com.absuconnect.games.action.ActionContentCatalog;
import com.absuconnect.games.action.LocalGameProgression;
import com.absuconnect.games.GameCatalog;
import com.absuconnect.games.fighter.FighterCombatModel;
import com.absuconnect.games.shooter.Shooter3DCamera;
import com.absuconnect.games.shooter.ShooterMatchModel;

public final class ActionGameChecks {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        check(ActionContentCatalog.FIGHTERS.length>=18&&ActionContentCatalog.OPERATORS.length>=18,"large fighter and shooter rosters");
        check(ActionContentCatalog.GUNS.length>=16,"many fictional gun classes");
        check(ActionContentCatalog.FIGHTING_WEAPONS.length>=16,"many fighter training-weapon styles");
        check(ActionContentCatalog.SHOOTER_SKILLS.length>=12&&ActionContentCatalog.FIGHTING_SKILLS.length>=12,"large skill rosters for both action titles");
        check(ActionContentCatalog.ARENAS.length>=8,"multiple maps and named campus-inspired locations");
        check(ActionContentCatalog.SKINS.length>=16,"large original visual-skin collection");
        check(ActionContentCatalog.eligibleCount(ActionContentCatalog.FIGHTERS,1)==6&&ActionContentCatalog.eligibleCount(ActionContentCatalog.FIGHTERS,1)<ActionContentCatalog.FIGHTERS.length/2,"fighter starter choices remain open while most fighters are locked");
        check(ActionContentCatalog.eligibleCount(ActionContentCatalog.OPERATORS,1)==6&&ActionContentCatalog.eligibleCount(ActionContentCatalog.GUNS,1)<ActionContentCatalog.GUNS.length/2,"operator and gun progression keeps most options locked");
        check(ActionContentCatalog.eligibleCount(ActionContentCatalog.FIGHTING_WEAPONS,1)==6&&ActionContentCatalog.eligibleCount(ActionContentCatalog.SHOOTER_SKILLS,1)<ActionContentCatalog.SHOOTER_SKILLS.length/2,"starter weapons/skills are open and most later options are locked");
        check(GameCatalog.find("campus_fireline")!=null,"shooter is registered in the game catalog");
        valueBasedCoinEstimates();
        careerProgressionUnlocksAndUpgrades();
        fighterLoadoutAffectsCombat();
        fighterMovementAndUpgrades();
        shooterUpgradesAffectStats();
        movementAimFireReloadAndCycle();
        trainingAmmoIsUnlimited();
        pitchChangesFirelineHitEligibility();
        threeDimensionalCameraBasis();
        skillAndCpuRound();
        System.out.println("Action content catalog and shooter model checks passed.");
    }
    private static void valueBasedCoinEstimates(){
        int balanced=com.absuconnect.games.action.GameCoinPricing.fighter(ActionContentCatalog.FIGHTERS[0]);
        check(com.absuconnect.games.action.GameCoinPricing.fighter(ActionContentCatalog.FIGHTERS[1])>balanced,"faster fighter has a higher illustrative value");
        check(com.absuconnect.games.action.GameCoinPricing.fighter(ActionContentCatalog.FIGHTERS[16])>balanced,"more durable high-rank fighter has a higher illustrative value");
        check(com.absuconnect.games.action.GameCoinPricing.meleeWeapon(ActionContentCatalog.FIGHTING_WEAPONS[15])>com.absuconnect.games.action.GameCoinPricing.meleeWeapon(ActionContentCatalog.FIGHTING_WEAPONS[0]),"stronger high-rank melee style has higher value");
        check(com.absuconnect.games.action.GameCoinPricing.firearm(ActionContentCatalog.GUNS[15])>com.absuconnect.games.action.GameCoinPricing.firearm(ActionContentCatalog.GUNS[0]),"higher-damage gun has higher value");
        check(com.absuconnect.games.action.GameCoinPricing.skill(ActionContentCatalog.SHOOTER_SKILLS[11])>com.absuconnect.games.action.GameCoinPricing.skill(ActionContentCatalog.SHOOTER_SKILLS[0]),"stronger high-rank skill has higher value");
        check(com.absuconnect.games.action.GameCoinPricing.skin(ActionContentCatalog.SKINS[15])>com.absuconnect.games.action.GameCoinPricing.skin(ActionContentCatalog.SKINS[0]),"higher-rank skin has higher rarity value");
        check(com.absuconnect.games.action.GameCoinPricing.driver(com.absuconnect.games.racing.RacingCatalog.DRIVERS[15])>com.absuconnect.games.action.GameCoinPricing.driver(com.absuconnect.games.racing.RacingCatalog.DRIVERS[0]),"higher-handling driver has higher value");
        check(com.absuconnect.games.action.GameCoinPricing.vehicle(com.absuconnect.games.racing.RacingCatalog.CARS[11])>com.absuconnect.games.action.GameCoinPricing.vehicle(com.absuconnect.games.racing.RacingCatalog.CARS[0]),"faster vehicle has higher value");
        check(com.absuconnect.games.action.GameCoinPricing.upgrade(balanced,1)>com.absuconnect.games.action.GameCoinPricing.upgrade(balanced,0),"later upgrade levels cost more in the illustrative model");
        check(com.absuconnect.games.action.GameCoinPricing.upgrade(com.absuconnect.games.action.GameCoinPricing.fighter(ActionContentCatalog.FIGHTERS[16]),0)>com.absuconnect.games.action.GameCoinPricing.upgrade(balanced,0),"upgrade estimate scales with base item value");
    }
    private static void fighterLoadoutAffectsCombat(){
        FighterCombatModel fighter=new FighterCombatModel();
        fighter.configureLoadout(ActionContentCatalog.FIGHTING_WEAPONS[1],ActionContentCatalog.FIGHTING_SKILLS[3]);
        long now=System.currentTimeMillis()+10000;
        fighter.step(false,true,now);fighter.step(false,true,now+1);
        check(fighter.act(FighterCombatModel.Action.LIGHT,now).sparringHealth==92,"selected Twin Batons use their lighter damage profile");
        fighter.act(FighterCombatModel.Action.HEAVY,now+1000);
        check(fighter.activateSkill(now+2000).stamina==100,"selected Second Wind skill restores stamina");
    }
    private static void fighterMovementAndUpgrades(){
        FighterCombatModel fast=new FighterCombatModel(),slow=new FighterCombatModel();
        fast.configureLoadout(ActionContentCatalog.FIGHTING_WEAPONS[0],ActionContentCatalog.FIGHTING_SKILLS[0],100,100,100,100,0,0,0,1.3f,1f,1.0f);
        slow.configureLoadout(ActionContentCatalog.FIGHTING_WEAPONS[0],ActionContentCatalog.FIGHTING_SKILLS[0],100,100,100,100,0,0,0,.7f,1f,.7f);
        check(fast.snapshot().dodgeWindowMs>slow.snapshot().dodgeWindowMs,"fighter movement archetype and weapon handling change evade window");
        FighterCombatModel upgraded=new FighterCombatModel();upgraded.configureLoadout(ActionContentCatalog.FIGHTING_WEAPONS[0],ActionContentCatalog.FIGHTING_SKILLS[0],100,100,100,100,2,0,3,1f,1f,1f);
        check(upgraded.snapshot().playerMaxHealth==110,"earned fighter upgrade increases local health");
        long attack=System.currentTimeMillis()+10000;upgraded.step(false,true,attack);upgraded.step(false,true,attack+1);check(upgraded.act(FighterCombatModel.Action.LIGHT,attack+2).sparringHealth==80,"fighter and melee-weapon upgrades increase local strike damage");
    }
    private static void shooterUpgradesAffectStats(){
        ShooterMatchModel base=new ShooterMatchModel(),upgraded=new ShooterMatchModel();upgraded.configure(0,0,0,0,0,2,3);
        check(upgraded.snapshot().maxHealth==110,"operator upgrade increases local health cap");base.aimAt(50,25);upgraded.aimAt(50,25);
        long now=System.currentTimeMillis()+8000;base.fire(now);upgraded.fire(now);
        check(upgraded.snapshot().botHealth[2]<base.snapshot().botHealth[2],"gun upgrade increases local shot damage");
        ShooterMatchModel quick=new ShooterMatchModel();quick.configure(0,0,0,0,0,2,0);base.configure(0,0,0,0,0);float x0=quick.snapshot().playerX;quick.move(1,0,.08f);base.move(1,0,.08f);
        check(quick.snapshot().playerX>x0&&quick.snapshot().playerX>base.snapshot().playerX,"operator upgrade changes local movement speed");
    }
    private static void movementAimFireReloadAndCycle(){
        ShooterMatchModel game=new ShooterMatchModel();
        ShooterMatchModel.Result before=game.snapshot();
        game.move(1,0,0.08f);ShooterMatchModel.Result moved=game.snapshot();
        check(moved.playerX>before.playerX,"joystick movement advances operator");
        game.aimAt(50,25);long now=System.currentTimeMillis()+10000;
        int oldHp=game.snapshot().botHealth[2];int oldAmmo=game.snapshot().ammo;
        check(game.fire(now),"aimed arcade gun fires");
        ShooterMatchModel.Result hit=game.snapshot();
        check(hit.botHealth[2]<oldHp,"aimed fire damages the nearest target");
        check(hit.ammo==oldAmmo-1,"shot consumes one magazine round");
        check(game.reload(now+1000),"reload starts with reserve ammunition");
        game.tick(now+4000);check(!game.snapshot().reloading,"reload completes after its timer");
        check(game.snapshot().ammo>hit.ammo,"reload restores magazine ammunition");
        int oldWeapon=game.getWeaponIndex();game.cycleWeapon();
        check(game.getWeaponIndex()!=oldWeapon,"weapon cycling selects another gun class");
        for(int gun=0;gun<ActionContentCatalog.GUNS.length;gun++){
            game.configure(0,gun,0,0,0);game.setTrainingMode(true);game.aimAt(50,25);
            check(game.fire(System.currentTimeMillis()+20000+gun*2000L),"every selectable firearm can be used");
        }
    }
    private static void skillAndCpuRound(){
        ShooterMatchModel game=new ShooterMatchModel();game.configure(0,0,0,0,0);
        check(game.activateSkill(System.currentTimeMillis()+20000),"ready action skill activates");
        check(!game.activateSkill(System.currentTimeMillis()+20001),"skill cooldown prevents immediate reactivation");
        check(game.snapshot().bursting,"Burst Step enables a timed movement boost");
        game.configure(0,0,3,1,2);check("Rainline Courtyard".equals(game.snapshot().map),"selected arena appears in round state");
        check("Copper Leaf".equals(game.snapshot().skin),"selected skin appears in round state");
        game.setTrainingMode(true);game.reset();game.tick(System.currentTimeMillis()+181000);
        check(!game.snapshot().matchOver&&game.snapshot().level==1,"elapsed time does not end an unfinished Fireline campaign or training run");
    }
    private static void trainingAmmoIsUnlimited(){
        ShooterMatchModel range=new ShooterMatchModel();range.setTrainingMode(true);range.aimAt(50,25);
        int ammo=range.snapshot().ammo;
        check(range.fire(System.currentTimeMillis()+5000),"training range accepts the first shot");
        check(range.fire(System.currentTimeMillis()+6000),"training range accepts repeat shots");
        check(range.snapshot().ammo==ammo,"training range does not consume magazine ammo");
    }
    private static void pitchChangesFirelineHitEligibility(){
        ShooterMatchModel level=new ShooterMatchModel();level.setTrainingMode(true);level.aimAt(50,25,0f);
        int before=level.snapshot().botHealth[2];check(level.fire(System.currentTimeMillis()+5000),"level aim fires");
        check(level.snapshot().botHealth[2]<before,"center-height reticle hits the target");
        ShooterMatchModel high=new ShooterMatchModel();high.setTrainingMode(true);high.aimAt(50,25,.45f);
        before=high.snapshot().botHealth[2];check(high.fire(System.currentTimeMillis()+5000),"pitched aim fires");
        check(high.snapshot().botHealth[2]==before,"looking far above a target makes the shot miss");
    }
    private static void threeDimensionalCameraBasis(){
        Shooter3DCamera camera=new Shooter3DCamera();
        Shooter3DCamera.Vector2 forward=camera.movement(0,1),right=camera.movement(1,0);
        check(Math.abs(forward.x)<.001f&&Math.abs(forward.z+1f)<.001f,"forward movement follows the initial first-person camera");
        check(Math.abs(right.x-1f)<.001f&&Math.abs(right.z)<.001f,"strafe-right follows the camera's side axis");
        camera.setAngles((float)(Math.PI/2),0);
        Shooter3DCamera.Vector2 turned=camera.movement(0,1);
        check(Math.abs(turned.x-1f)<.001f&&Math.abs(turned.z)<.001f,"camera-relative forward movement rotates with yaw");
        camera.look(0,-10000);
        check(camera.pitch()<.79f,"vertical aim stays inside the viewable pitch range");
        check(Math.abs(camera.direction().length()-1f)<.001f,"center-reticle 3D direction remains normalized");
    }
    private static void careerProgressionUnlocksAndUpgrades(){
        LocalGameProgression career=new LocalGameProgression();
        check(!career.unlockedAtRank(ActionContentCatalog.FIGHTERS[6].unlockRank),"higher fighter starts locked");
        career.recordMatch("campus_duel",130,140,true);
        check(career.rank()==2&&career.unlockedAtRank(ActionContentCatalog.FIGHTERS[6].unlockRank),"match XP advances rank and opens rank-two fighter");
        check(career.streak("campus_duel")==1&&career.matchCount("campus_duel")==1,"first daily match records a local streak");
        check(career.upgrade("fighter:nia",5),"earned practice credits purchase a fighter upgrade");
        check(career.upgradeLevel("fighter:nia")==1,"upgrade level persists in career state");
        check(!career.upgrade("fighter:nia",5),"upgrade cannot exceed available practice credits");
        career.recordMatch("campus_duel",50,50,false);
        check(career.matchCount("campus_duel")==2&&career.streak("campus_duel")==1,"repeat match advances mastery without duplicate daily streak");
    }
}

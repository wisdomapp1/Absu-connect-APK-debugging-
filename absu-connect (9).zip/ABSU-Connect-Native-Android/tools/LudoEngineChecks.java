import com.absuconnect.games.ludo.LudoEngine;

/** Tiny dependency-free smoke checks; run with javac/java when Android/Gradle is unavailable. */
public final class LudoEngineChecks {
    public static void main(String[] args) {
        LudoEngine e = new LudoEngine(LudoEngine.Rules.campusVariant());
        check(e.currentPlayer() == 0, "first seat starts");
        check(e.roll(6), "six accepted");
        LudoEngine.MoveResult launch = e.move(0);
        check(e.progressOf(0, 0) == 0 && launch.extraTurn, "six launches and keeps turn");
        check(launch.fromProgress == -1 && launch.toProgress == 0 && launch.capturedPlayer == -1 && launch.capturedToken == -1,
                "launch move exposes yard-to-track animation data without a false capture");
        check(e.roll(5), "next roll accepted");
        LudoEngine.MoveResult step = e.move(0);
        check(e.progressOf(0, 0) == 5 && e.currentPlayer() == 1, "non-six passes turn");
        check(step.fromProgress == 0 && step.toProgress == 5 && step.nextPlayer == 1,
                "accepted route movement exposes exact start and destination for animation");

        LudoEngine triple = new LudoEngine(LudoEngine.Rules.campusVariant());
        triple.roll(6); triple.move(0);
        triple.roll(6); triple.move(0);
        triple.roll(6);
        check(triple.currentPlayer() == 1 && triple.dieValue() == 0, "third six forfeits turn");
        System.out.println("LudoEngine checks passed");
    }
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}

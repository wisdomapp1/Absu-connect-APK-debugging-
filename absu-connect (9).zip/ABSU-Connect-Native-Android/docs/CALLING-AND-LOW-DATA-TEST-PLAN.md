# ABSU Connect — calling and low-data validation

## Current source behaviour

- Voice and video are available only between accepted ABSU Connect friends.
- Only one active call per participant is allowed.
- Calls use private Supabase Realtime signalling and native WebRTC.
- Incoming call data messages are high-priority FCM data messages; Android creates the incoming CallStyle notification with Answer / Decline actions.
- Ringing call sessions expire after 35 seconds. The Android caller also times out locally; a Supabase Cron job expires unanswered rows if the caller app is closed.
- Low Data Mode is enabled by default. It reduces list-fetch sizes and uses 240p / 12 fps video with an approximate 180 kbps outbound video cap. Users can switch it off from More or from the video-call screen before answering/placing the call.

## Firebase configuration and device-token check

1. Ensure the Firebase Android app is registered with application ID `com.absuconnect.games`.
2. Add the matching `google-services.json` at `app/google-services.json` for a local build. For GitHub Actions, put its base64-encoded contents in secret `GOOGLE_SERVICES_JSON_B64`.
3. Install the built app on an Android phone and sign in. The app calls Firebase Messaging to obtain its FCM token and writes it to `public.device_push_tokens` with `platform='android'`.
4. Check Supabase for an Android token row for that signed-in account. The last inspection during this work found zero Android token rows, so background delivery has not yet been demonstrated.
5. The `send-android-push` Edge Function uses `FIREBASE_SERVICE_ACCOUNT_JSON` only after it finds at least one token. A log entry with HTTP 200 while the token table is empty does not validate the service-account credentials. Trigger a real push only after the Android token exists.

## Two-phone test sequence

Use two different Android phones and two different accepted friend accounts. For the first test, use one mobile-data connection and one Wi-Fi connection rather than placing both phones on the same Wi-Fi.

1. Sign in on both phones and confirm each has a row in `device_push_tokens`.
2. Grant notification permission on the receiving phone. Enable the ABSU Connect Calls notification channel and, where the phone supports it, allow full-screen call alerts.
3. With both apps open, place a voice call from Phone A to Phone B. Answer on B and verify that both screens show Connected, audio is two-way, mute/speaker work, and End call closes both sides.
4. Repeat with Phone B in the background and then with its screen locked. Confirm the incoming call notification appears and its Answer / Decline actions work.
5. Repeat with video. Keep Low Data Mode enabled and check that the video is visibly lower resolution and stable. Turn it off and compare.
6. Repeat with mobile data on both phones, then with one device on a restrictive carrier network. Record ICE state and whether the call connects. A dedicated TURN relay may be required for some carrier NAT/firewall combinations.
7. Check `public.call_sessions` after the tests: accepted, ended, declined and missed statuses should match what happened on the phones.

## Limits to expect

No implementation can promise zero connection delay or unrestricted carrier access. FCM is a best-effort push transport, and Android may suppress full-screen presentation because of user settings, permission state, Do Not Disturb or manufacturer battery management. The current OpenRelay TURN configuration is a shared public fallback, not a dedicated production relay. The code must be built and tested on actual devices before calling this release-ready.

## Offline/static checks already run

- `bash tools/run-domain-checks.sh`
- `bash tools/run-call-contract-checks.sh`

These pass. They are source/domain checks only; they do not replace Gradle compilation, FCM delivery, WebRTC negotiation or the physical two-phone tests above.

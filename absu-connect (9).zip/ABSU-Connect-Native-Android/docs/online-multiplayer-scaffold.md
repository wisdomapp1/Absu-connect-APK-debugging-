# Friend matches — multiplayer scaffold status

## Bottom line

The supplied project contains useful invite, room, action-journal and Supabase transport groundwork, but **none of the game activities is wired into a shared match session**. The six intended titles—Campus Ludo, Campus Duel, Naija WHOT!, Campus 8-Ball, Campus Car Racing and Campus Bike Racing—cannot yet be played synchronously across two phones. Campus Fireline remains solo-only.

## What the archive implements

- `backend/GameBackendService.java` reads accepted friends, creates friend invites, resolves an invite to a room ID, invites another friend into an open room, and accepts/declines invitations using authenticated Supabase requests.
- `supabase/migrations/20261106_games_invites_rooms.sql` creates private rooms, player seats and invitation records; it defines `is_game_room_member`, friend-only invite/accept RPCs, expiry, RLS read policies and Realtime publication for room/invite changes.
- `supabase/migrations/20261107_games_match_journal.sql` adds authenticated start, snapshot and action-journal RPCs. It assigns actor identity/seat from `auth.uid()` and membership, requires the expected state version and next sequence, rejects stale actions, enforces unique client-action IDs, limits payload size and rejects client-supplied winner/score/currency outcomes.
- `multiplayer/SupabaseMatchTransport.java` calls those RPCs and subscribes to Realtime action inserts, then fetches a full journal snapshot. `MatchSessionCoordinator.java` wraps join/send/reconnect and now ignores older snapshots rather than delivering them to listeners.
- `TurnBasedMatchAdapter.java`, `FighterArenaAdapter.java` and `RacingMatchAdapter.java` are client-side shape allowlists. Turn-based action names now line up with the SQL migration. The allowlists do not make a move legal.
- `tools/multiplayer/InMemoryMatchBackendFake.java` supports portable contract tests only; it is not an online service.

The migrations have **not** been applied to the user’s Supabase project, and no live backend data has been changed.

## What still blocks live gameplay

1. **No launch/session UI.** Game Center still manages invite/lobby records but no game screen starts the match, joins the same room ID on the other phone, constructs a session, or closes it with the activity lifecycle. `OnlineMatchLink.java` is not present in the supplied archive.
2. **No game screen networking.** The six titles do not send actions to `MatchSessionCoordinator`, consume remote snapshots, replay actions into their existing engines or update their rendering from server state.
3. **No server-side game rules.** `game_match_states.state_version`, `next_sequence`, `active_seat` and status are journal metadata; snapshots expose an ordered action journal rather than canonical game state. The SQL accepts per-game action names but does not simulate or validate legal turns, cards, token moves, 8-ball shots, fighter hits or race progression. `active_seat` is initialized to -1 and is not advanced by these RPCs.
4. **No completion/absence protocol.** There is no implemented leave, timeout/forfeit, heartbeat-presence policy, authoritative winner calculation, result-recording function or trusted online rewards. The transport reports disconnection and the coordinator offers a manual `reconnect()` fetch; the activity must retry, recover and render the result.
5. **No device/backend verification.** No Supabase staging deployment, Realtime/RLS test, two-account/two-device gameplay test or packet-loss test has been performed.

## Exact integration sequence

1. Review and apply `20261106_games_invites_rooms.sql`, then `20261107_games_match_journal.sql`, to a **staging** Supabase project. Confirm `public.profiles(id)` corresponds to authenticated user IDs, `public.friendships(requester_id, addressee_id, status)` exists, invite friendships are accepted, and `supabase_realtime` is enabled. Check every RLS policy and RPC privilege before production.
2. Connect accepted invitations and returned room UUIDs to the host start/join screen. Start only after at least two accepted room members are seated. Each device must join using its own current authenticated account; the server derives identity from auth, not UI input.
3. Build one authoritative server state machine per game. Validate active seat, phase and legal action, produce the next canonical state and version, define allowed game-specific payloads, and make Ludo dice/results/rewards server-owned. Do not trust local engine outcomes for online records.
4. Wire the existing six non-Fireline Activities to the session coordinator. Convert each user action to the correct intent, display pending/rejected actions, apply only ordered authoritative state and re-render both devices. Do not remove or replace local CPU/pass-and-play modes.
5. Implement explicit reconnect/snapshot restore, background/resume handling, player leave, timeout, forfeit, match completion and trusted result persistence. Decide what happens if a host never starts a partially filled room.
6. Test invitation create/accept/decline/expiry/cancel, room capacity, both authenticated identities, simultaneous submissions, duplicated action IDs, stale versions, illegal turns/moves, out-of-order notifications, reconnect, packet loss, player exit/timeout and match completion on two real accounts and separate Android devices. Only then label a game cross-phone playable.

## SQL and configuration supplied

The existing migrations create these tables and functions:

- `game_rooms`, `game_room_players`, `game_invites`
- `game_match_states`, `game_match_actions`
- `is_game_room_member`, `create_game_invite`, `invite_friend_to_game_room`, `respond_game_invite`, `start_game_match`, `get_game_match_snapshot`, `submit_game_match_action`, and `cancel_game_invite`

The first migration assumes the existing profiles/friendships schema. The second permits `campus_ludo`, `campus_duel`, `naija_whot`, `billiards`, `kart_racing` and `bike_racing`; it explicitly excludes Fireline. It records intents, not a finished result or authoritative state. No new database migration is required for the current offline animation changes; the server-side gameplay functions above remain future work.

The Android client reads `supabaseUrl` and `supabasePublishableKey` Gradle properties. Only a publishable/anon key belongs in the APK; never ship a service-role key. Database configuration and credentials still need to be supplied by the main ABSU Connect integration.

## Current checks

`bash tools/run-domain-checks.sh` passes the project’s pure-Java checks, including 28 assertions against an in-memory fake. This checks neither the Supabase SQL/RLS nor network Realtime, Activity wiring, two-phone gameplay or authoritative game rules. The Android SDK/Platform 35 was unavailable here, so Android compilation and on-device testing remain outstanding.

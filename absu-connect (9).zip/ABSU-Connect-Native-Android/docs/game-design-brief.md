# ABSU Connect native games: design and current status

The Game Center keeps its original university-oriented presentation and seven game modules: **Campus Ludo, Campus Duel, Campus Fireline, Naija WHOT!, Campus 8-Ball, Campus Car Racing and Campus Bike Racing**.

## Action and racing expansion

- **Campus Duel** has 18 fighters, 16 melee-training weapon profiles, 12 skill effects, eight arenas/locations and 16 skins. Six fighters and six weapon profiles are available at Rank 1; higher tiers are rank-locked and previewable. Character health/stamina, weapon reach/damage, fighter upgrades and weapon upgrades affect local sparring. Local controls move either seat IN/OUT, attacks must be in reach, CPU sparring closes distance and alternates telegraphed heavy strikes with quick jabs, and both seats have separate stamina and action poses. The procedural OpenGL characters and arena details remain placeholders, not finished commercial models or a production-animated fighter.
- **Campus Fireline** is a solo-only first-person 3D OpenGL ES 2.0 game with an endless level campaign. Each five-target wave advances automatically; the following level becomes gradually harder through opponent health, movement, shot tempo and damage, with bounded scaling. Optional training remains. The original operators, fictional guns, skills, arenas and skins stay selectable. It remains a procedural low-poly local game, not production art, full 3D physics or an online FPS.
- **Car and bike racing** each have 16 drivers, 12 car/bike profiles and 16 liveries. Six drivers, five vehicles and six liveries are available at Rank 1. Selected driver/vehicle upgrades affect local race speed and acceleration.
- **Local career loop:** completed matches in all seven games award device-local XP and free Practice Points. First daily play per game adds bonus/streak progress. Rank unlocks content; shops/garages show locked previews and allow up to five levels of free test upgrades to the active loadout. These points are not currency or account entitlements.

See [action and racing content](action-games-content.md) for counts, unlock gates and implementation limits.

## Local play and online status

All six non-shooter games have solo and local multiplayer modes; Fireline is solo-only and does not appear in the invite picker or multiplayer catalog. Accepted-friend invites still create private lobby metadata only. The transport-neutral invite/session contracts and example codecs for the six multiplayer games are tested with an in-memory fake, but are not wired to activities or a real backend. **Real-time online play across separate phones is not implemented.** See [online multiplayer scaffold](online-multiplayer-scaffold.md).

## Originality, sound and assets

Character names, weapons, palettes, maps and simple preview art are original placeholders. No Shadow Fight 3 or Call of Duty Mobile code, branding, character, story, weapons, levels, artwork or audio has been copied. Fighter and shooter models and landmarks use procedural geometry; generated beeps are hooks rather than a sound library. Textured production assets, skeletal animation, authored audio, representative device/performance testing and student playtesting remain outstanding for both 3D games.

## Currency and payments

The updated proposal has two stages: a server-verified Paystack payment credits a **non-withdrawable account-level NGN game wallet**, then the user later converts/spends NGN in-app into **separate coins for one chosen game**. Paystack does not directly sell a game's coin pack. The NGN balance cannot be cashed out or transferred between users; game coins are not shared across titles. ₦1,000 → 10,000 coins is an illustrative conversion; the proposed minimum ₦1,500 top-up could add ₦1,500 to the NGN balance and later convert to 15,000 coins at the same assumed rate. These figures are not approved prices/offers. A separate review of Nigerian stored-value/e-money rules, Paystack terms and the chosen app-store payment rules is pending. Funding, NGN credit, conversion and game-coin purchases remain disabled. Free local Practice Points are a separate test system. See [wallet architecture](wallet-architecture.md).

## Release gates

Android SDK build/device validation, robust real-time multiplayer for the six non-shooter titles, procedural-art replacement, accessibility, performance/balance, secure currency backend and compliance review remain before release. Fireline is a solo endless-level campaign by design. Private lobby records are not an online match service. See [validation status](validation-status.md) and [roadmap](roadmap.md).

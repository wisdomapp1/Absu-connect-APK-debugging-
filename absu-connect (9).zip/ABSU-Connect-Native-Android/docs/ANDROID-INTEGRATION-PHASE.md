# ABSU Connect Android integration — Phase update

## What this source now does

- The Android launcher opens the existing live ABSU Connect website at `https://absu-connect.vercel.app/` in a secured WebView.
- The WebView keeps JavaScript and DOM storage enabled for the existing React/Supabase web application, blocks mixed content and local-file access, and only permits in-app navigation on the ABSU Connect host. External HTTPS/mail links are handed to Android.
- A native **Native Games** shortcut is injected into the trusted website page. It reads the existing Supabase JS session from the project's default storage key `sb-aqzolewmhpmrcvkrvchn-auth-token`, passes the session to the Android bridge, stores it in Android EncryptedSharedPreferences, and opens the native game hub.
- The native game hub and games use the same Supabase user ID and refreshed access token as the website account; the user does not need a second native-only account.
- The app label is ABSU Connect.
- The latest website source ZIP supplied for this task is included under `website-source-reference/` for reference. Runtime secret files and local `.env` files are intentionally excluded. The Android APK loads the deployed website; it does not bundle a local offline copy of the React app.

## Supabase work performed

On project `aqzolewmhpmrcvkrvchn` (ABSU Connect, eu-west-2), additive schema migration `games_invites_rooms_android_integration` was applied, followed by `fix_games_invite_room_insert_arguments` and `restrict_game_invite_rpc_to_authenticated`.

Created tables:
- `public.game_rooms`
- `public.game_room_players`
- `public.game_invites`

Created authenticated RPCs:
- `create_game_invite`
- `invite_friend_to_game_room`
- `respond_game_invite`
- `is_game_room_member`

RLS is enabled on all three tables. Direct client writes are not granted; room/invite creation and acceptance go through authenticated RPCs. A permission verification query confirmed `anon` cannot execute the four functions and `authenticated` can. Existing profile/friendship data was not changed.

The matching migration SQL is in `supabase/migrations/20261107_android_game_invites_production.sql`.

## Important limitations — do not treat as completed

- Friend lookup and invitation/lobby groundwork is present in the native game hub. It is not yet a complete invite-to-live-match flow.
- The supplied `20261107_games_match_journal.sql` was **not applied**. It is only an ordered action journal and does not validate game rules, advance turns, calculate canonical game state, determine winners, or securely award results.
- Native game activities are not yet wired to submit/replay actions through `SupabaseMatchTransport`. A created room or accepted invite is not proof of cross-phone gameplay.
- The existing web server game routes use a different older session schema and currently whitelist `whot`, `truth-or-dare`, `ludo`, and `400-questions`; they are not a drop-in authority for the seven native game IDs.
- No Android SDK Platform 35 or Gradle 8.9 distribution could be downloaded in this environment, so no APK build or device test was possible.
- The website WebView requires internet access. The native games source is present locally, but the hosted social app is not an offline bundle.

## Build

Open `absu-games-android/` in Android Studio with JDK 17 and Android SDK Platform 35. Run:

```bash
./gradlew :app:assembleDebug :app:testDebugUnitTest
bash tools/run-domain-checks.sh
```

Supply `supabaseUrl` and `supabasePublishableKey` in local Gradle properties if the project configuration is changed. Never add a Supabase service-role key to Android or web client source.

## Cloud APK build option

A GitHub Actions workflow is included at `.github/workflows/android-debug-apk.yml`. After the source is placed in a GitHub repository, running **Actions → Build ABSU Connect Android APK → Run workflow** builds a debug APK with JDK 17 and Android SDK 35 and uploads it as an artifact. This workflow has not been run from the user's GitHub account, so it is a build route, not a claimed build result.

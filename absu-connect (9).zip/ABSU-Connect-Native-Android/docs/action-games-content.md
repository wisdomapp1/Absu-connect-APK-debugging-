# Action and racing catalogues

## Rank availability: starter choices plus later tiers

The catalogues are ordered by rank. At Rank 1, some useful content is open while most later options are locked—not everything is locked. The Career/garage screens keep the full catalogues visible; locked items can be tapped for procedural previews, rank requirements and stat/effect descriptions. Ranks advance through local play, not payment.

| Collection | Total | Available at Rank 1 | Later-rank entries |
|---|---:|---:|---:|
| Campus Duel fighters | 18 | 6 | 12 |
| Campus Duel melee-training weapons | 16 | 6 | 10 |
| Campus Duel skills | 12 | 5 | 7 |
| Campus Fireline operators | 18 | 6 | 12 |
| Campus Fireline fictional gun profiles | 16 | 6 | 10 |
| Campus Fireline skills | 12 | 4 | 8 |
| Shared campus arenas/maps | 8 | 3 | 5 |
| Action-game skin palettes | 16 | 6 | 10 |
| Each racing game's drivers | 16 | 6 | 10 |
| Each racing game's cars or motorcycles | 12 | 5 | 7 |
| Racing liveries | 16 | 6 | 10 |

At the first rank, Campus Duel and Fireline each offer Nia / Beacon, Tari / Vector, Kene / Anchor, Lami / Pulse, Ayo / Drift and Ife / Sable as their first six character/operator choices. Later tiers add original stat archetypes with different durability, stamina or mobility profiles.

## Campus Duel — procedural 3D sparring

Choose a fighter, rival, melee-training weapon, skill, arena and skin. Sixteen original weapon styles include staffs, batons, gauntlets, blades, spear, shield, bracers, hammer, glaive, chain trainer and later mastery variants. Twelve skills span evasive step, timed guard, direct technique, stamina recovery and feint effects. Eight campus-inspired arenas/locations and 16 original skin palettes are shared as catalog data with Fireline. The local fight now has approach/retreat spacing, weapon-dependent reach, separate seat stamina/poses, and a CPU counter that closes distance and telegraphs before striking.

The selected fighter's health/stamina and equipped training weapon affect local combat. Earned fighter upgrades raise health/stamina and modest damage values; weapon levels increase strike damage. Both seats in local same-device mode share one on-device progression profile. The renderer now separates the fighters' movement, pose and attack animations and adds simple arena-specific landmarks, but remains low-detail procedural OpenGL geometry—not a finished rigged, motion-captured or commercial fighting game.

## Campus Fireline — original first-person 3D CPU shooter

Fireline's screen is now a landscape **first-person 3D OpenGL ES 2.0** view rather than the earlier top-down Canvas screen. It includes 18 operators, 16 fictional firearm profiles, 12 skills, eight campus-inspired 3D arena/map palettes and cover layouts, and 16 skins. Six operators, six guns, four skills, three locations and six skins are available at Rank 1; most later entries stay previewable but rank-locked. Operator profiles, weapon profiles, map selection, skin colours, bot silhouettes and local upgrade data are retained from the existing content system.

The 16 fictional firearm profiles cover sidearm, SMG, rifle, burst rifle, shotgun/scatter, marksman/precision, carbine and support-LMG arcade categories. Their local magazine, reserve ammunition, damage, range, cadence/reload and movement values differ. The 12 skills vary movement boost, damage reduction, healing, damage focus, CPU slow or recon-style effects. Operator upgrades affect health/movement; gun upgrades increase shot damage. Arenas use distinct names, campus locations, colour palettes and cover placements.

### Controls and match modes

- **Left virtual pad:** move relative to the view direction; hold **RUN** to move faster.
- **Drag the open right play area:** look and aim in first person.
- **Hold FIRE:** shoot the currently equipped gun; a small recoil and muzzle-flash cue play locally.
- **LOAD / GUN / skill:** reload, cycle the equipped gun, and use the selected field skill.
- **HOP:** short camera hop/bob effect; it is visual only and does not change hit height or provide full vertical platform physics.
- **Solo endless campaign:** clear each five-target wave to advance automatically. Level 2 is a small increase from Level 1; opponent health, movement speed, shot cadence and damage continue to rise gradually, using bounded scaling. The run has no time limit and ends when the player is defeated.
- **Optional training range:** moving targets do not fire and ammunition is unlimited; training also has no timer.

The arena, cover, operators and first-person weapon are procedural low-poly geometry; the maps are compact original arenas, not large open worlds. Reticle hits account for camera pitch, target alignment and arena cover, but still use a simplified arcade target-volume model, not production-grade ballistics or physics. Android tone cues are sound hooks, not an authored audio library. Fireline is intentionally solo-only and is excluded from friend invitations and networked match scaffolding.

## Racing garages

The car and bike games use an original three-lap oval, CPU or same-device two-player mode. Each has 16 drivers, 12 vehicle profiles and 16 original liveries. At Rank 1, six drivers, five vehicles and six liveries are usable; most choices remain rank-locked. The garage shows every option, procedural preview art, rank requirement and profile values.

Drivers have handling/launch archetypes; cars and motorcycles have different top-speed, acceleration, handling and silhouette/style data. Five device-local upgrade levels increase the selected driver's acceleration contribution and vehicle speed/acceleration. These upgrades affect only the local race. The oval and vector vehicle figures remain prototypes, not detailed production vehicles or broad open-world tracks.

## Illustrative future game-coin values

Action/racing inventory previews show individual proposed values in the relevant game's future coin unit. Estimates vary by unlock tier and item data: character health, stamina and movement; weapon damage, rate, magazine, reach and handling; skill effect strength, duration and cost; arena tier/cover; cosmetic tier; driver handling/launch; or vehicle speed, acceleration and handling. The next upgrade's example value scales with item estimate and upgrade level. Stronger or higher-rank items and later upgrades estimate higher costs; the model rounds estimates up to the next 50 coins.

These figures are **illustrations, not approved prices or offers**. Rank unlocks use XP in this prototype. Actual local test upgrades consume free, device-only Practice Points at fixed test costs; coin estimates cannot be paid or spent. Final prices, coin conversion and any live paid-upgrade system require product approval and Nigerian/platform compliance review.

## Shared local career progression

All seven local games award device-only XP and non-purchasable **Practice Points** when matches complete. A first match for a game on the device's local calendar day grants a daily bonus and advances that game's streak; a missed day resets that streak. Rank uses 150 XP per level, up to Rank 25. Local test upgrades cost 60 Practice Points initially, then 40 more for each subsequent level, up to five levels. These fixed test costs do not model the item-specific illustrative coin estimates.

Practice Points are a development/progression counter—not NGN, game coins, Paystack credit or account entitlements—and do not sync across devices or online matches. The separate future wallet proposal remains disabled: Paystack funding of a non-withdrawable account-level NGN balance, followed later by in-app conversion to a selected game's separate coins, is pending compliance review. Nothing monetary is implemented.

## Sound, originality and release boundaries

All character names, weapon profiles, maps, palettes and previews are original. No Shadow Fight 3 or Call of Duty Mobile code, content, branding or assets were copied. Both 3D games use procedurally assembled low-poly geometry and generated tone cues; they do not include textured production models, skeletal animation, authored sound libraries or polished commercial effects. Accessibility polish, balance tuning, representative-device/performance testing and student playtesting remain outstanding. Friend invites create private lobby records only; they do not provide synchronized online gameplay.

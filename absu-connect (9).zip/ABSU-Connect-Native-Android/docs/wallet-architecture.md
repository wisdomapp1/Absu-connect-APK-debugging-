# Proposed account NGN wallet and per-game coins

## Product direction (not active)

The proposed design has two balance layers and two distinct steps:

1. **Account-level NGN game wallet:** the user pays through a server-created Paystack checkout. After server-side confirmation of that payment, the app's account-level NGN balance is credited. This stored balance is **not withdrawable**, and users cannot transfer it to one another.
2. **Selected game's coin wallet:** later, the user uses available NGN game-wallet balance to buy/convert into coins for one chosen game. Each game has a separate coin ledger: Campus Duel coins, Fireline coins, Car Racing coins, Bike Racing coins, Ludo coins, WHOT coins and 8-Ball coins are not shared across games. Coins can then buy that game's items/upgrades.

This is **not** a direct Paystack purchase of a selected game's coin pack. Paystack is proposed only for funding the NGN balance; the later conversion/purchase happens in-app and must be server-authoritative. Game coin prices may vary by item strength/tier. The final catalog, conversion rate, minimum, pricing, refund handling, legal classification and transaction rules are not approved.

## Illustrations only — not prices or offers

A sample in-app conversion illustration is **₦1,000 from the account NGN wallet → 10,000 coins** at a hypothetical 10 coins per naira. The proposed minimum Paystack funding-top-up illustration is **₦1,500 → ₦1,500 added to the NGN game wallet**, which could later convert to **15,000 game coins** at the same hypothetical rate. These examples do not establish a purchasable top-up, actual conversion rate, price, entitlement, minimum or offer. The ₦1,000 example describes later conversion of an already-funded NGN balance, not a ₦1,000 Paystack top-up.

## Current implementation status

**All real-money and game-coin activity remains disabled.** The wallet screen is a read-only product preview. No NGN balance, funding request, Paystack checkout, confirmation/webhook, conversion, coin balance, item price, purchase, entitlement, refund or ledger operation is connected.

The game career system's **Practice Points are different**: they are free, repeat-play test progression saved only on the current device. Practice Points cannot be funded, withdrawn, shared, converted to NGN/game coins, or used in online competition. Local rank unlocks and point-funded stat upgrades demonstrate gameplay only; they are not the future coin shop.

## Required review before any launch

A separate compliance review is pending for Nigerian stored-value/e-money rules, Paystack's current terms and product fit, and the chosen app-distribution channel's payment policy. Do not activate funding, conversion, coin prices or purchases until that review is complete and the product design is approved.

If approved, engineering should keep the account-level NGN ledger and each game's coin ledger distinct. Paystack transaction confirmation must atomically credit only the authenticated user's non-withdrawable NGN game-wallet balance. A conversion must atomically debit that NGN balance and credit only the selected game's wallet, with idempotency, server-side user ownership, audited exchange rates, limits, receipts and reversal handling. Purchases and entitlements remain server-authoritative; the phone must never create money or award paid items. No cash withdrawals, peer transfers or cross-game coin transfers are part of the proposal.

Paystack remains a proposed funding provider only. The app must never contain Paystack secret keys. Use server-created references and verified webhooks/transaction checks; a client redirect alone must not credit NGN. Research and platform approval precede implementation.

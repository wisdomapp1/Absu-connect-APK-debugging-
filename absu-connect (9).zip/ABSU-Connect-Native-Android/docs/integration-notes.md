# Integration notes for the supplied ABSU Connect source

The supplied source is a React/Vite app and its `src/components/more/GameCenterView.tsx` contains preview-only cards; the supplied archives do not include a native Android project. The app's Supabase project is `https://aqzolewmhpmrcvkrvchn.supabase.co`, and its browser client uses a publishable key. Its friend service uses `friendships(requester_id, addressee_id, status)` with `status = 'accepted'`; the native invite migration uses that same relationship as the eligibility check.

The existing notification migration knows a `game_invite` notification type, but there is no game invitation lifecycle or room membership table in the supplied migrations. The included migration adds only those metadata tables and RPCs. It does not yet write a complete game state, process turns, decide winners, or host a fighter simulation.

The Android game module should be called from a native Game Center route in the eventual APK. It should not be used as an embedded website/webview. The current archive alone is not sufficient to convert all social features into an APK; sign-in, profile/friends, feed, messaging, moderation, push, data migration, and release work still need a whole-app Android plan.

For every future title, keep game-specific state machines under a separate package (`ludo`, `whot`, `billiards`, `racing`, `fighter`) and share only neutral app services: Supabase identity, accepted-friend selection, invitations, lobby metadata, analytics/abuse limits, accessibility helpers, and build/release tooling. Never share a game state model just because two games have a “turn”—their rules and cheating risks differ.

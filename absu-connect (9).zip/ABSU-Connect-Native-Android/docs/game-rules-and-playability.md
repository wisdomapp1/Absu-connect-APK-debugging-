# Games: what is playable in this source package

The Game Center lists seven modules: Ludo, Naija WHOT!, 8-Ball, Campus Duel, Campus Fireline, car racing and bike racing. **All seven have solo local play.** Ludo, WHOT, billiards, both racing variants and Campus Duel also offer same-device multiplayer. Campus Fireline is solo-only and advances through endless, gradually harder levels. Friend invites create private lobby metadata; no title has live online match-state sync.

## Naija WHOT!

The deck has 54 cards: five uneven shape suits plus five wild WHOT cards. Players receive six cards each, match shape or number, and WHOT calls the next shape. Rules in this build include **1** play again; **2** draw two and stack; **5** draw three and stack; **8** suspend the next turn (Star 8 suspends two); **14** makes other players draw one. The first player to empty their hand wins. CPU or 2–4 seat pass-and-play is supported; house-rule and network sync are not.

Rules follow [Pagat's Nigerian WHOT description](https://www.pagat.com/com/whot.html), which notes that local house rules vary.

## Campus 8-Ball

The casual rack has one cue ball and 15 object balls. Players alternate shots; the first valid pocket assigns solids or stripes. Clear your group before legally pocketing the 8-ball. A foul gives the next seat ball-in-hand. It is lightweight local 2D physics, not tournament/referee software; called shots and some formal rules are simplified. Reference: [WPA rules](https://wpapool.com/wp-content/uploads/2025/09/2025.09.15-WPA-Rules.pdf).

## Campus Duel

CPU sparring or local same-device 1v1. The original catalogue contains 18 fighters, 16 weapon profiles, 12 skills, eight arenas/locations and 16 skins; starter selections are open and most later tiers are rank-locked. Locked entries can be previewed in the Career screen. Character health/stamina, weapon reach/damage, and up to five levels of fighter/weapon upgrades affect local combat. Move IN/OUT to change spacing; strikes outside the selected weapon's reach do not land. In CPU mode, the rival closes distance and alternates a slower telegraphed heavy strike with a quick jab, spending stamina and using the lighter attack when low. Local seats retain separate stamina and action states. The scene remains procedural low-poly geometry, not a production-rigged fighter.

## Campus Fireline

Solo endless campaign or optional unlimited-ammo training range in an original **first-person 3D OpenGL ES** view. The campaign starts at Level 1 with five targets; defeating all five automatically begins the next level. Level 2 is a small step harder than Level 1, and opponent health, movement, shot cadence and damage continue to rise gradually with bounded scaling instead of ending on a timer. The run ends only when the player is defeated. Use the left virtual stick to move, drag the right play area to look/aim, hold FIRE to shoot, and use LOAD/GUN/SKILL/RUN/JUMP controls. Camera pitch and arena cover affect hits and CPU line of sight. Training targets move but do not fire. Arena geometry, opponents, cover and first-person gun remain procedural low-poly assets, and combat uses simplified hit volumes rather than full physics. Fireline is solo-only and cannot join a multiplayer room.

## Campus Car Racing and Campus Bike Racing

Both use an original three-lap oval and CPU or same-device 1v1. Each has 16 drivers, 12 cars/motorcycles and 16 liveries; six drivers, five vehicles and six paint options are open at Rank 1. Higher options have garage previews and unlock through local XP. Up to five earned Practice Point upgrades on the selected driver and vehicle affect local acceleration/speed. Track and vehicle art are simple vector shapes, not a large map or production 3D collection.

## Career rewards, sound and purchases

Finishing a match in any of the seven titles awards device-local XP and free Practice Points; the first match of each game on a local calendar day grants a bonus and streak progress. Practice Points can improve selected fighter/operator/driver/vehicle test stats; they are neither NGN nor paid game coins. The proposed future NGN funding wallet and separate per-game virtual coins are not implemented; all actual funding and purchases remain disabled pending compliance review.

No game has live online game-state sync. The six non-shooter titles have local solo and multiplayer modes; Fireline is solo-only. Lobby metadata alone is not a network match. Sound cues are short generated tones—not produced game audio. Both 3D games still need representative Android-device testing, performance and accessibility passes, further balance, original finished art/audio, and student playtesting before release. Check [the full content and rank table](action-games-content.md).

# Validation status — native game modules

## Checks run for this revision

- `bash tools/run-domain-checks.sh` passes with OpenJDK 21. It covers the game-domain checks, the Fireline no-timer/progression checks, and 27 fake-backed multiplayer scaffold assertions.
- Fireline checks cover a slightly tougher Level 2, continued difficulty increases at later levels, removal of the old round timer, and the existing movement/aim/ammo/training/jump behavior.
- The multiplayer checks use only an in-memory fake. They confirm invite/session contract behavior and reject Fireline invites; they do not connect to an online service.
- These are Java logic checks only. Focused JUnit suites, Android views, OpenGL rendering, touch input, and phone performance were not run or validated in this revision.

## Campus Fireline — solo endless campaign

Fireline is solo-only and is excluded from the invite picker, multiplayer capacity, action-codec examples, and the supplied SQL invite allowlist. Its campaign starts at Level 1. Clearing all five targets automatically begins the next level; Level 2 is a small difficulty increase, followed by continued gradual scaling of enemy health, movement speed, shot cadence, and damage. Early changes are intentionally modest and stat scaling has upper bounds. The run has no round timer and ends when player health reaches zero. Optional training remains available.

The campaign and training mode still use the local CPU simulation. Maps, operators, weapons, and effects remain procedural low-poly assets; combat is simplified arena-plane simulation rather than full 3D ballistics. Authored audio and device testing remain unfinished.

## Multiplayer status

The six non-shooter games retain local solo and multiplayer modes. Accepted-friend invitations currently create private lobby records only. Although the source includes a future invite/session/match-transport scaffold, it is not connected to a production repository, live transport, authoritative server, or the game screens. No game currently provides synchronized friend matches across separate phones. The Supabase migration remains unapplied and now excludes Fireline from invite rooms.

## Android build and device validation

This is a source-only ZIP handoff; no APK was rebuilt. The workspace has no Android SDK platform or emulator, so the Android app, GLES shaders, context lifecycle, multitouch controls, landscape layout, frame rate, heat/battery use, audio, and end-to-end play have not been verified on a phone. A previous API 35 assembly attempt recorded in the earlier package failed while downloading a dependency over TLS (`bad_record_mac`). Build with Android Studio, JDK 17, and Android SDK Platform 35, then test on representative low- and mid-range devices before distribution.

Rank, XP, Practice Points, and upgrades remain device-local. Real payments and game-coin purchases remain disabled pending separate compliance review. The source changes improve local playability but do not make the games production-complete or release-ready.

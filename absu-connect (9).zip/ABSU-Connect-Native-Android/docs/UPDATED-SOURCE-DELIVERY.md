# ABSU Connect Games — Updated Source Handoff

## What is included

This update was made inside the Android project from the ZIP you supplied. It keeps the existing project structure, game engines, local modes, progression, storage, reference material, and website-source reference. No APK is included, as requested; no live Supabase project or other backend was changed.

## Gameplay and animation work

**Naija WHOT!** keeps the original `WhotEngine` and its shuffled 54-card pack, six-card deal, shape/number matching, draw stacks, special-card effects, CPU choice, and local progress rewards. The screen now animates the shuffle and deal, flips and slides dealt cards into place, shows each opponent’s avatar, face-down card backs and card count, highlights legal cards, animates a played card rotating and moving to the active pile, pulses on special cards and turn changes, and shows an animated result dialog. The current shape, active card and turn remain visible.

**Campus Ludo** keeps the existing rules engine and CPU/pass-and-play modes. Dice now roll through changing faces before the engine receives the final value. Accepted tokens animate step by step from the yard around the track and into home; captures get an impact ring at the square, safe squares remain marked, legal tokens are highlighted after a roll, turn labels update, and the result dialog animates. The engine now supplies move-origin, destination and captured-token metadata to the renderer; the renderer does not determine which moves are legal.

**Campus 8-Ball** keeps the original 2D physics, CPU and pass-and-play modes. The CPU’s fallback now aims at the 8-ball only after its group is cleared. The screen has muteable cues and an animated result. A round continues if the activity is temporarily backgrounded. The billiards rules remain a simplified local implementation; it does not yet enforce every standard cushion-after-contact foul rule.

**Campus Duel** keeps its existing procedural 3D combat, CPU sparring, same-device two-player controls, loadouts and local progression. It now uses the shared sound mute control and no longer resets the current fight simply because Career was opened and closed.

**Campus Fireline** remains a solo endless-level campaign and is not added to multiplayer. It keeps its existing 3D gameplay, training mode and loadouts, adds the shared sound mute control, and resumes the same wave after a career-shop visit rather than reconfiguring the run.

**Campus Car Racing and Campus Bike Racing** keep their existing catalogs, CPU and two-player local modes, three-lap races, rewards and shared engine. Steering now interpolates between lanes at a rate affected by driver/vehicle handling, including bike-specific handling values. The screen has the shared mute control, preserves a race across a shop visit, and releases held controls when leaving the screen.

All seven screens use short Android system-tone cues, with a persistent device-wide **Sound on/Sound off** control. No large sound assets or new third-party dependencies were added.

## Multiplayer: groundwork, not live play

**Cross-phone play is not complete.** The ZIP contains an invite/lobby backend facade, a Supabase transport, a session coordinator, action codecs, and two SQL migrations, but none of the six multiplayer-capable game screens is connected to a shared live match session. The current Supabase transport journals action intents and refreshes snapshots after Realtime notifications; it does not apply those moves to the local game engines or run an authoritative game simulation. No two-device match was tested.

The first migration creates `game_rooms`, `game_room_players`, and `game_invites`, with friend-only invite/accept RPCs and expiry. The second creates `game_match_states` and `game_match_actions`, and RPCs to start a room, fetch a snapshot, and submit an authenticated action with an idempotency ID and expected version/sequence. The coordinator now ignores stale snapshots, and the turn-based client codecs now use the action names expected by the SQL allowlist.

Important gaps for the ABSU Connect integration developer:

- `OnlineMatchLink.java` is **not present** in the supplied archive.
- The game activities do not create sessions, start matches, send player actions, replay remote actions, or render remote state. A room ID or accepted invitation alone is not a playable match.
- SQL sequences and deduplicates actions, but it does **not** validate whose turn it is or whether a Ludo move, WHOT card, 8-ball shot, fighter action, or race input is legal. `active_seat` is not advanced by the supplied migration; snapshots contain an action journal, not canonical game state.
- There is no implemented remote leave/timeout/forfeit flow, automatic transport reconnect loop, authoritative completion/result RPC, or trusted result/reward record. `reconnect()` can fetch a fresh snapshot, but the screen must call it and restore the engine.
- The invite repository/session launch flow is not connected to Game Center, and the migrations have not been applied to the user’s backend.

To complete multiplayer, apply and test the migrations on a **staging** Supabase project; connect accepted invites and room IDs to both authenticated clients; implement a game-specific server-authoritative state machine for each of Ludo, WHOT, 8-Ball, Duel, car racing and bike racing; wire each screen to send intent and apply ordered snapshots; add presence/disconnect, leave/timeout, completion and result handling; then test duplicate/out-of-order requests, reconnect, packet loss and completed matches on two separate accounts/devices. Keep Fireline solo-only. Do not award online XP or rewards from client-reported outcomes.

### Required Supabase setup

The migration files to review and apply **in order** are:

1. `supabase/migrations/20261106_games_invites_rooms.sql`
2. `supabase/migrations/20261107_games_match_journal.sql`

The first migration assumes `public.profiles(id)` maps to authenticated Supabase users and `public.friendships(requester_id, addressee_id, status)` exists with accepted relationships. It creates the room, seat and invite tables, membership helper, RLS read policies, and invite RPCs. The second adds match state/action tables, authenticated snapshot/start/action RPCs and Realtime publication for the action journal. Review all SQL and RLS behavior in staging before production. **No additional SQL migration was created in this update.** The authoritative game rules, leave/timeout processing and result storage still need server-side SQL/RPC or Edge Function work.

The Android build reads the Supabase URL and publishable key from Gradle properties `supabaseUrl` and `supabasePublishableKey` (or the existing development defaults in `app/build.gradle`). Supply only a client-safe publishable/anon key in the Android app; never embed a service-role key.

## Files changed

- **WHOT and Ludo:** `app/src/main/java/com/absuconnect/games/ui/WhotActivity.java`; `app/src/main/java/com/absuconnect/games/ui/LudoActivity.java`; `app/src/main/java/com/absuconnect/games/ludo/LudoBoardView.java`; `app/src/main/java/com/absuconnect/games/ludo/LudoEngine.java`.
- **Shared audio:** added `app/src/main/java/com/absuconnect/games/ui/GameSound.java`.
- **8-Ball:** `app/src/main/java/com/absuconnect/games/billiards/BilliardsEngine.java`; `app/src/main/java/com/absuconnect/games/ui/BilliardsActivity.java`.
- **Duel and Fireline:** `app/src/main/java/com/absuconnect/games/ui/FighterActivity.java`; `app/src/main/java/com/absuconnect/games/ui/ShooterActivity.java`.
- **Car and bike racing:** `app/src/main/java/com/absuconnect/games/racing/RacingEngine.java`; `app/src/main/java/com/absuconnect/games/ui/RacingTrackView.java`; `app/src/main/java/com/absuconnect/games/ui/RacingActivity.java`.
- **Multiplayer scaffold correctness:** `app/src/main/java/com/absuconnect/games/multiplayer/MatchSessionCoordinator.java`; `app/src/main/java/com/absuconnect/games/multiplayer/examples/TurnBasedMatchAdapter.java`; `app/src/main/java/com/absuconnect/games/multiplayer/examples/FighterArenaAdapter.java`; `app/src/main/java/com/absuconnect/games/multiplayer/examples/RacingMatchAdapter.java`.
- **Regression checks:** `tools/LudoEngineChecks.java`; `tools/NewGameChecks.java`; `tools/MultiplayerScaffoldChecks.java`.
- **Documentation:** `README.md`; `docs/online-multiplayer-scaffold.md`; this file; and the archive-level `DELIVERY-README.md`.

The original `WhotEngine`, Supabase migrations, auth code, game catalogs, website reference, reference PDFs and other working game implementations were retained.

## Tests and verification

The portable Java suite passed after the changes. Run it from the Android project root:

```bash
bash tools/run-domain-checks.sh
```

It checks local WHOT, Ludo, billiards, racing, fighter, shooter/progression and the in-memory multiplayer scaffold; the multiplayer fake now reports 28 assertions. The expanded checks cover Ludo animation metadata, car/bike steering response and migration-aligned turn-based action names. The fake does **not** contact Supabase.

An Android build and JUnit/Activity test run could not be performed here because the Android SDK/Platform 35 is not installed. There is no emulator or device in this environment, so card/dice timing, touch feel, orientation behavior, OpenGL visuals, memory/performance and two-phone multiplayer remain unverified. The supplied manifest locks WHOT/Ludo to portrait and Duel/Fireline/8-Ball/racing to landscape. The current in-progress local round is not serialized across process death; only the existing device-local career progression is persistent.

## Build the APK locally

1. Open the existing `absu-games-android` directory in Android Studio using JDK 17 and Android SDK Platform 35; allow Gradle sync to finish.
2. Set `sdk.dir` in local `local.properties` if Android Studio does not configure the SDK automatically. Do not commit that machine-specific file.
3. Optional: supply the backend URL and publishable key as Gradle properties, not secrets with elevated service-role access:

   ```bash
   ./gradlew :app:assembleDebug -PsupabaseUrl=https://YOUR_PROJECT.supabase.co -PsupabasePublishableKey=YOUR_PUBLISHABLE_KEY
   ```

4. Build and run tests:

   ```bash
   ./gradlew :app:assembleDebug :app:testDebugUnitTest
   bash tools/run-domain-checks.sh
   ```

5. If Android Studio builds successfully, the debug APK is at `app/build/outputs/apk/debug/app-debug.apk`. Install on portrait and landscape Android phones and test all modes before handing off. A signed release APK requires your own release keystore and is outside this source-only delivery.

## Known limitations

- UI animations and sound were source-implemented but not visually/performance-tested on a physical Android device.
- Game tones are system-generated cues, not recorded or authored sound effects; mute preference is stored on the device and shared by all game screens.
- WHOT CPU play uses a lightweight card-scoring heuristic; Ludo CPU prioritizes the furthest-progress token. Neither is online-authoritative.
- 8-Ball remains simplified and does not yet implement every professional foul rule. Duel and Fireline use procedural prototype graphics; racing is an arcade oval, not a full racing simulation.
- Cross-phone gameplay is not available until the Supabase and main-app integration above is completed and tested.

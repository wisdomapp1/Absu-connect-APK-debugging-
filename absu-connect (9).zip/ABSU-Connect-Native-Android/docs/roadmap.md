# Native games roadmap

## Current development package

Seven game modules retain their local play loops. The source now contains rank-ordered rosters for 18 fighters/operators, 16 melee styles and fictional gun profiles, 12 action skills, eight campus-inspired locations and 16 action skins; each race has 16 drivers, 12 cars/bikes and 16 liveries. Starter choices are available at Rank 1 while most higher-tier content is locked but previewable. Finishing matches across all seven games awards on-device XP and free Practice Points; the local Career/garage UI previews entries, tracks rank/daily play and upgrades the equipped fighter/operator/driver/vehicle. Action/racing items and eligible upgrades show individual, stat-based illustrative game-coin values; they are placeholders only, not approved prices. Local progression values are not currency and do not affect online matches.

Campus Fireline is an original procedural first-person 3D OpenGL ES solo campaign. Five-target waves advance automatically forever, with small gradual increases to enemy health, movement, shot cadence and damage; optional training remains. Operators, cover, scenery and gun remain low-poly geometry rather than commissioned models/textures. Campus Duel has range-aware approach/retreat, per-seat local state, a CPU that alternates telegraphed heavy strikes and quick jabs with stamina costs, and procedural scene detail; it is still not a production-rigged fighting game. Race courses and models are simple vector shapes. The portable Java domain suite passes on this revision, including Fireline progression/no-timer checks and a 27-assertion fake invite/match contract suite. No APK is rebuilt, and Android/device verification is not available here. A previous API 35 assembly attempt recorded in the validation notes was blocked by a TLS dependency-download error. A transport-neutral invite/session/action/version/reconnect scaffold exists for six non-shooter games only; no production repository/transport/server is connected, and no game has online gameplay. The wallet and all real purchases are disabled. See `docs/online-multiplayer-scaffold.md` and `docs/validation-status.md`.

## Phase 1 — native build and on-device verification

1. Open the project in Android Studio with JDK 17 and SDK Platform 35; sync, assemble debug and install on representative low-/mid-range Android phones.
2. Test all activities, manifests, portrait/landscape behavior, navigation, pause/resume, touch targets, fighter controls, shooter multitouch movement/aim/fire, garage previews, storage persistence, text/accessibility, audio focus and battery/heat.
3. Exercise every rank tier, item preview, unlock, streak reset, daily bonus and level-up on-device. Verify all five upgrade levels alter the displayed/played fighter, operator, gun, car and bike stats.
4. Fix Android compilation, layout/rendering/orientation/performance issues before considering APK distribution.

## Phase 2 — authoritative online multiplayer

1. Review and apply the friend-only invitation/lobby migration on staging; verify accepted-friend constraints, RLS, seats, expiry and Realtime lobby/invite events.
2. Implement a production `MatchInviteRepository` adapter for the authenticated invite RPC/list/response flow, then deploy a secure authenticated match service behind `MatchTransport` with server-validated, versioned state, idempotency, reconnect and abuse controls. Lobby membership alone is not game sync.
3. Connect the sample fighter/racing/turn-based codecs to server-owned simulation and the six non-shooter Android screens. Use distinct designs for turn-based Ludo/WHOT, physics billiards, and low-latency fighter/racing; never trust client-authored winners, combat hits, races or paid wallet state. Fireline remains solo-only.
4. Test network modes for the six multiplayer games on separate accounts/devices; do not display lobby records or the test fake as playable online matches.

## Phase 3 — production game experience

1. Commission original licensed character, operator, weapon, vehicle and map assets; rig and animate the 3D fighter and add rich map/track variations without copying protected games.
2. Replace Android tones with an original mixable SFX/music/voice library and add mute/volume/focus controls.
3. Improve movement/combos, controls, CPU tactics, camera/readability, accessibility, balance, frame time, storage/compression and student playtesting.
4. Validate the progression economy across all ranks. Keep free Practice Points separate from future paid game coins and account entitlements.

## Phase 4 — review and secure NGN/game-coin system (not approved)

1. Complete the separate review of Nigerian stored-value/e-money rules, Paystack terms and selected-app-store payment policy. Determine whether Paystack-funded, non-withdrawable account-level NGN stored credit followed by in-app conversion to seven separate game-coin ledgers is permitted.
2. If approved, Paystack should fund the account NGN wallet only after verified transaction confirmation. Later, conversion debits that NGN balance and credits only the selected game's independent coin ledger; Paystack does not directly sell a game's coin pack. Do not enable cash withdrawals, peer transfers or cross-game coin transfers.
3. The ₦1,000→10,000 conversion and proposed minimum ₦1,500 top-up→₦1,500 NGN-wallet credit→15,000 coins are illustrative only, not current prices or offers. The prototype also calculates stat/rank-based item and upgrade price previews; approve final per-game item tiers/prices, conversion rate, minimum, receipts and refund/reversal rules before coding checkout.
4. Build verified Paystack server initialization/webhooks, atomic ledger writes, conversion quoting, audit and entitlement services only after policy approval. Client code cannot mint money/coins or grant a paid upgrade.

## Release gate

Sign and distribute only after Android/device tests, online-security work required for the product, art/accessibility/performance review, legal/payment review where applicable, privacy notices, support/refund routes, and release-channel requirements have passed. No APK is included with this source ZIP; any first build will be a development build until release signing and the device/release gates are complete.

alter table public.call_sessions
  add column if not exists expires_at timestamptz not null default (now() + interval '35 seconds');

create index if not exists call_sessions_ringing_expiry_idx
  on public.call_sessions(status, expires_at)
  where status = 'ringing';

create or replace function public.set_call_session_status(p_call_id uuid, p_status text)
returns setof public.call_sessions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_call public.call_sessions;
begin
  if v_user_id is null then raise exception 'Authentication required'; end if;
  if p_status not in ('accepted','declined','ended','missed','failed') then
    raise exception 'Invalid call status';
  end if;

  select * into v_call from public.call_sessions where id = p_call_id for update;
  if not found then raise exception 'Call not found'; end if;
  if v_user_id <> v_call.caller_id and v_user_id <> v_call.recipient_id then
    raise exception 'Not a call participant';
  end if;

  if p_status in ('accepted','declined') then
    if v_user_id <> v_call.recipient_id or v_call.status <> 'ringing' then
      raise exception 'Only the invited recipient can accept or decline a ringing call';
    end if;
    if p_status = 'accepted' and now() >= v_call.expires_at then
      raise exception 'This call has expired';
    end if;
    if p_status = 'declined' and now() >= v_call.expires_at then
      p_status := 'missed';
    end if;
  elsif p_status = 'missed' then
    if v_user_id <> v_call.caller_id or v_call.status <> 'ringing' or now() < v_call.expires_at then
      raise exception 'Call cannot be marked missed yet';
    end if;
  elsif p_status = 'ended' then
    if v_call.status not in ('ringing','accepted') then raise exception 'Call is already closed'; end if;
  elsif p_status = 'failed' then
    if v_call.status not in ('ringing','accepted') then raise exception 'Call is already closed'; end if;
  end if;

  update public.call_sessions
     set status = p_status,
         updated_at = now(),
         accepted_at = case when p_status = 'accepted' then now() else accepted_at end,
         ended_at = case when p_status in ('declined','ended','missed','failed') then now() else ended_at end
   where id = p_call_id
   returning * into v_call;

  return next v_call;
end;
$$;

create or replace function private.expire_unanswered_calls()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  update public.call_sessions
     set status = 'missed',
         updated_at = now(),
         ended_at = now()
   where status = 'ringing'
     and expires_at <= now();
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

revoke all on function private.expire_unanswered_calls() from public, anon, authenticated;

do $$
declare v_job_id bigint;
begin
  select jobid into v_job_id from cron.job where jobname = 'absu-call-expiry';
  if v_job_id is not null then perform cron.unschedule(v_job_id); end if;
  perform cron.schedule('absu-call-expiry', '* * * * *', 'select private.expire_unanswered_calls();');
end
$$;

-- ABSU Connect Games: friend-only invitations and private lobby membership.
-- Assumes the existing public.profiles(id) and public.friendships(requester_id, addressee_id, status) schema.
-- Apply to a staging project first; this is additive and intentionally does not grant clients authority to write match state.

create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  game_id text not null check (game_id in ('campus_ludo', 'campus_duel', 'naija_whot', 'billiards', 'kart_racing', 'bike_racing')),
  host_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'waiting' check (status in ('waiting', 'ready', 'in_progress', 'completed', 'abandoned')),
  max_players smallint not null check (max_players between 2 and 4),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 minutes')
);

create table if not exists public.game_room_players (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  seat smallint not null check (seat between 0 and 3),
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id),
  unique (room_id, seat)
);

create table if not exists public.game_invites (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  game_id text not null check (game_id in ('campus_ludo', 'campus_duel', 'naija_whot', 'billiards', 'kart_racing', 'bike_racing')),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'declined', 'expired', 'cancelled')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  expires_at timestamptz not null default (now() + interval '10 minutes'),
  constraint game_invites_no_self_invite check (sender_id <> recipient_id)
);

create index if not exists game_invites_recipient_status_created_idx
  on public.game_invites (recipient_id, status, created_at desc);
create index if not exists game_invites_sender_created_idx
  on public.game_invites (sender_id, created_at desc);
create index if not exists game_room_players_user_room_idx
  on public.game_room_players (user_id, room_id);
create index if not exists game_rooms_status_expiry_idx
  on public.game_rooms (status, expires_at);

alter table public.game_rooms enable row level security;
alter table public.game_room_players enable row level security;
alter table public.game_invites enable row level security;
grant select on public.game_rooms, public.game_room_players, public.game_invites to authenticated;

-- SECURITY DEFINER avoids recursive row-policy evaluation while checking shared room membership.
create or replace function public.is_game_room_member(p_room_id uuid)
returns boolean language sql stable security definer
set search_path = public set row_security = off
as $$
  select exists (select 1 from public.game_room_players p where p.room_id = p_room_id and p.user_id = auth.uid());
$$;
revoke all on function public.is_game_room_member(uuid) from public;
grant execute on function public.is_game_room_member(uuid) to authenticated;

-- Participants see only rooms they joined. Players see names/seat data only inside a shared room.
drop policy if exists "Room participants can read their rooms" on public.game_rooms;
create policy "Room participants can read their rooms"
  on public.game_rooms for select to authenticated
  using (public.is_game_room_member(id));

drop policy if exists "Room participants can read room seats" on public.game_room_players;
create policy "Room participants can read room seats"
  on public.game_room_players for select to authenticated
  using (user_id = auth.uid() or public.is_game_room_member(room_id));

drop policy if exists "Invite participants can read invites" on public.game_invites;
create policy "Invite participants can read invites"
  on public.game_invites for select to authenticated
  using (sender_id = auth.uid() or recipient_id = auth.uid());

-- No direct client INSERT/UPDATE/DELETE policies are provided for these tables.
-- Creation/response goes through the narrow authenticated RPCs below.
create or replace function public.create_game_invite(p_game_id text, p_friend_id uuid, p_max_players smallint default null)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_room uuid;
  v_invite uuid;
  v_max smallint;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_friend_id = v_user then raise exception 'You cannot invite yourself'; end if;
  if p_game_id not in ('campus_ludo', 'campus_duel', 'naija_whot', 'billiards', 'kart_racing', 'bike_racing') then
    raise exception 'Unsupported game';
  end if;
  if not exists (
    select 1 from public.friendships f
    where f.status = 'accepted'
      and ((f.requester_id = v_user and f.addressee_id = p_friend_id)
        or (f.requester_id = p_friend_id and f.addressee_id = v_user))
  ) then raise exception 'Game invitations are limited to accepted friends'; end if;

  v_max := coalesce(p_max_players, case when p_game_id in ('campus_ludo', 'naija_whot') then 4 else 2 end);
  if (p_game_id in ('campus_ludo', 'naija_whot') and v_max not between 2 and 4)
     or (p_game_id in ('campus_duel', 'billiards', 'kart_racing', 'bike_racing') and v_max <> 2) then
    raise exception 'Invalid player count for this game';
  end if;
  insert into public.game_rooms (game_id, host_id, max_players)
  values (p_game_id, v_user, v_max) returning id into v_room;
  insert into public.game_room_players (room_id, user_id, seat) values (v_room, v_user, 0);
  insert into public.game_invites (room_id, game_id, sender_id, recipient_id)
  values (v_room, p_game_id, v_user, p_friend_id) returning id into v_invite;
  return v_invite;
end;
$$;


create or replace function public.invite_friend_to_game_room(p_room_id uuid, p_friend_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_room public.game_rooms%rowtype;
  v_invite uuid;
  v_reserved integer;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select * into v_room from public.game_rooms where id = p_room_id for update;
  if not found or v_room.status <> 'waiting' or v_room.expires_at <= now() then
    raise exception 'Game room is no longer accepting players';
  end if;
  if not exists (select 1 from public.game_room_players where room_id = p_room_id and user_id = v_user) then
    raise exception 'Only room participants can invite another player';
  end if;
  if p_friend_id = v_user then raise exception 'You cannot invite yourself'; end if;
  if not exists (
    select 1 from public.friendships f where f.status = 'accepted'
      and ((f.requester_id = v_user and f.addressee_id = p_friend_id)
        or (f.requester_id = p_friend_id and f.addressee_id = v_user))
  ) then raise exception 'Game invitations are limited to accepted friends'; end if;
  if exists (select 1 from public.game_room_players where room_id = p_room_id and user_id = p_friend_id)
     or exists (select 1 from public.game_invites where room_id = p_room_id and recipient_id = p_friend_id and status = 'pending' and expires_at > now()) then
    raise exception 'That friend already has a seat or pending invitation';
  end if;
  select (select count(*) from public.game_room_players where room_id = p_room_id)
       + (select count(*) from public.game_invites where room_id = p_room_id and status = 'pending' and expires_at > now())
    into v_reserved;
  if v_reserved >= v_room.max_players then raise exception 'Game room has no open seats'; end if;
  insert into public.game_invites (room_id, game_id, sender_id, recipient_id)
    values (v_room.id, v_room.game_id, v_user, p_friend_id) returning id into v_invite;
  return v_invite;
end;
$$;

create or replace function public.respond_game_invite(p_invite_id uuid, p_accept boolean)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_invite public.game_invites%rowtype;
  v_room public.game_rooms%rowtype;
  v_seat smallint;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select * into v_invite from public.game_invites
  where id = p_invite_id for update;
  if not found or v_invite.recipient_id <> v_user then raise exception 'Invitation not found'; end if;
  if v_invite.status <> 'pending' or v_invite.expires_at <= now() then
    update public.game_invites set status = 'expired', responded_at = now()
      where id = v_invite.id and status = 'pending' and expires_at <= now();
    raise exception 'Invitation is no longer active';
  end if;

  if not p_accept then
    update public.game_invites set status = 'declined', responded_at = now() where id = v_invite.id;
    return v_invite.room_id;
  end if;

  select * into v_room from public.game_rooms where id = v_invite.room_id for update;
  if not found or v_room.status <> 'waiting' or v_room.expires_at <= now() then
    raise exception 'Game room is no longer available';
  end if;
  if exists (select 1 from public.game_room_players where room_id = v_room.id and user_id = v_user) then
    raise exception 'You have already joined this room';
  end if;
  select slots.seat into v_seat from generate_series(0, 3) as slots(seat)
  where slots.seat < v_room.max_players
    and not exists (select 1 from public.game_room_players p where p.room_id = v_room.id and p.seat = slots.seat)
  order by slots.seat limit 1;
  if v_seat is null then raise exception 'Game room is full'; end if;

  insert into public.game_room_players (room_id, user_id, seat) values (v_room.id, v_user, v_seat);
  update public.game_invites set status = 'accepted', responded_at = now() where id = v_invite.id;
  if (select count(*) from public.game_room_players where room_id = v_room.id) >= v_room.max_players then
    update public.game_rooms set status = 'ready', updated_at = now() where id = v_room.id;
  else
    update public.game_rooms set updated_at = now() where id = v_room.id;
  end if;
  return v_room.id;
end;
$$;

revoke all on function public.create_game_invite(text, uuid, smallint) from public;
revoke all on function public.invite_friend_to_game_room(uuid, uuid) from public;
revoke all on function public.respond_game_invite(uuid, boolean) from public;
grant execute on function public.create_game_invite(text, uuid, smallint) to authenticated;
grant execute on function public.invite_friend_to_game_room(uuid, uuid) to authenticated;
grant execute on function public.respond_game_invite(uuid, boolean) to authenticated;

do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'game_invites') then
    alter publication supabase_realtime add table public.game_invites;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'game_rooms') then
    alter publication supabase_realtime add table public.game_rooms;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'game_room_players') then
    alter publication supabase_realtime add table public.game_room_players;
  end if;
end $$;

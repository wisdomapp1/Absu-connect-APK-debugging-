create table if not exists public.call_sessions (
  id uuid primary key default gen_random_uuid(),
  caller_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  call_type text not null check (call_type in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','accepted','declined','ended','missed','failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  accepted_at timestamptz,
  ended_at timestamptz,
  constraint call_sessions_no_self_call check (caller_id <> recipient_id)
);

create index if not exists call_sessions_caller_created_idx on public.call_sessions(caller_id, created_at desc);
create index if not exists call_sessions_recipient_created_idx on public.call_sessions(recipient_id, created_at desc);
create index if not exists call_sessions_active_pair_idx on public.call_sessions(status, caller_id, recipient_id) where status in ('ringing','accepted');

alter table public.call_sessions enable row level security;
revoke all on public.call_sessions from anon, authenticated;
grant select on public.call_sessions to authenticated;

drop policy if exists call_sessions_participant_read on public.call_sessions;
create policy call_sessions_participant_read on public.call_sessions
for select to authenticated
using ((select auth.uid()) = caller_id or (select auth.uid()) = recipient_id);

create or replace function public.create_call_session(p_recipient_id uuid, p_call_type text)
returns setof public.call_sessions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_caller_id uuid := auth.uid();
  v_session public.call_sessions;
begin
  if v_caller_id is null then raise exception 'Authentication required'; end if;
  if p_recipient_id is null or p_recipient_id = v_caller_id then raise exception 'Invalid call recipient'; end if;
  if p_call_type not in ('audio','video') then raise exception 'Unsupported call type'; end if;

  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(least(v_caller_id::text,p_recipient_id::text),0));
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(greatest(v_caller_id::text,p_recipient_id::text),0));

  if not exists (
    select 1 from public.friendships f
    where f.status = 'accepted'
      and ((f.requester_id = v_caller_id and f.addressee_id = p_recipient_id)
        or (f.requester_id = p_recipient_id and f.addressee_id = v_caller_id))
  ) then raise exception 'Calls are available only between accepted friends'; end if;

  if exists (
    select 1 from public.call_sessions c
    where c.status in ('ringing','accepted')
      and (c.caller_id in (v_caller_id,p_recipient_id) or c.recipient_id in (v_caller_id,p_recipient_id))
  ) then raise exception 'One participant is already in another call'; end if;

  insert into public.call_sessions(caller_id,recipient_id,call_type,status)
  values(v_caller_id,p_recipient_id,p_call_type,'ringing')
  returning * into v_session;

  insert into public.notifications(recipient_id,actor_id,type,entity_type,entity_id,title,body)
  values(
    p_recipient_id,v_caller_id,'system','call',v_session.id,
    case when p_call_type = 'video' then 'Incoming video call' else 'Incoming voice call' end,
    'A friend is calling you on ABSU Connect.'
  );

  return next v_session;
end;
$$;

create or replace function public.set_call_session_status(p_call_id uuid, p_status text)
returns setof public.call_sessions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_call public.call_sessions;
begin
  if v_user_id is null then raise exception 'Authentication required'; end if;
  if p_status not in ('accepted','declined','ended','missed','failed') then raise exception 'Invalid call status'; end if;

  select * into v_call from public.call_sessions where id = p_call_id for update;
  if not found then raise exception 'Call not found'; end if;
  if v_user_id <> v_call.caller_id and v_user_id <> v_call.recipient_id then raise exception 'Not a call participant'; end if;

  if p_status in ('accepted','declined') then
    if v_user_id <> v_call.recipient_id or v_call.status <> 'ringing' then
      raise exception 'Only the invited recipient can accept or decline a ringing call';
    end if;
  elsif p_status = 'missed' then
    if v_user_id <> v_call.caller_id or v_call.status <> 'ringing'
      or v_call.created_at > now() - interval '30 seconds' then
      raise exception 'Call cannot be marked missed yet';
    end if;
  elsif p_status = 'ended' then
    if v_call.status not in ('ringing','accepted') then raise exception 'Call is already closed'; end if;
  elsif p_status = 'failed' then
    if v_call.status not in ('ringing','accepted') then raise exception 'Call is already closed'; end if;
  end if;

  update public.call_sessions
     set status = p_status,
         updated_at = now(),
         accepted_at = case when p_status = 'accepted' then now() else accepted_at end,
         ended_at = case when p_status in ('declined','ended','missed','failed') then now() else ended_at end
   where id = p_call_id
   returning * into v_call;

  return next v_call;
end;
$$;

revoke all on function public.create_call_session(uuid,text) from public, anon;
revoke all on function public.set_call_session_status(uuid,text) from public, anon;
grant execute on function public.create_call_session(uuid,text) to authenticated;
grant execute on function public.set_call_session_status(uuid,text) to authenticated;

create or replace function private.can_access_absu_call_topic()
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_topic text := realtime.topic();
  v_call_id uuid;
begin
  if v_topic is null or v_topic not like 'absu-call:%' then return false; end if;
  begin
    v_call_id := split_part(v_topic,':',2)::uuid;
  exception when others then
    return false;
  end;
  return exists (
    select 1 from public.call_sessions c
    where c.id = v_call_id
      and auth.uid() in (c.caller_id,c.recipient_id)
      and c.status in ('ringing','accepted','ended','declined','missed','failed')
  );
end;
$$;

revoke all on function private.can_access_absu_call_topic() from public, anon;
grant execute on function private.can_access_absu_call_topic() to authenticated;

drop policy if exists absu_call_broadcast_receive on realtime.messages;
create policy absu_call_broadcast_receive on realtime.messages
for select to authenticated
using (extension = 'broadcast' and private.can_access_absu_call_topic());

drop policy if exists absu_call_broadcast_send on realtime.messages;
create policy absu_call_broadcast_send on realtime.messages
for insert to authenticated
with check (extension = 'broadcast' and private.can_access_absu_call_topic());

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'call_sessions'
  ) then
    alter publication supabase_realtime add table public.call_sessions;
  end if;
end
$$;

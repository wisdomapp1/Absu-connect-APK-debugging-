-- ABSU Connect Games: authenticated online match action journal.
-- Additive and intentionally separate from local game simulation. Apply after
-- 20261106_games_invites_rooms.sql in a staging Supabase project first.
-- IMPORTANT: this journal authenticates participants and sequences/replays input
-- events; it does NOT simulate game rules or make client-reported winners/scores trusted.

create table if not exists public.game_match_states (
  room_id uuid primary key references public.game_rooms(id) on delete cascade,
  game_id text not null check (game_id in ('campus_ludo', 'campus_duel', 'naija_whot', 'billiards', 'kart_racing', 'bike_racing')),
  status text not null default 'in_progress' check (status in ('in_progress', 'completed', 'abandoned')),
  state_version bigint not null default 0 check (state_version >= 0),
  next_sequence bigint not null default 1 check (next_sequence >= 1),
  active_seat smallint not null default -1 check (active_seat between -1 and 3),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_match_actions (
  room_id uuid not null references public.game_match_states(room_id) on delete cascade,
  sequence bigint not null check (sequence >= 1),
  client_action_id uuid not null,
  actor_id uuid not null references public.profiles(id) on delete cascade,
  seat smallint not null check (seat between 0 and 3),
  action_type text not null check (action_type ~ '^[a-z][a-z0-9_]{0,31}$'),
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object'),
  created_at timestamptz not null default now(),
  primary key (room_id, sequence),
  unique (room_id, actor_id, client_action_id)
);

create index if not exists game_match_actions_room_sequence_idx
  on public.game_match_actions (room_id, sequence desc);

alter table public.game_match_states enable row level security;
alter table public.game_match_actions enable row level security;
grant select on public.game_match_states, public.game_match_actions to authenticated;

-- A match is visible only to accounts seated in its associated private room.
drop policy if exists "Match participants can read match state" on public.game_match_states;
create policy "Match participants can read match state"
  on public.game_match_states for select to authenticated
  using (public.is_game_room_member(room_id));

drop policy if exists "Match participants can read match actions" on public.game_match_actions;
create policy "Match participants can read match actions"
  on public.game_match_actions for select to authenticated
  using (public.is_game_room_member(room_id));

-- No direct client writes: all journal changes go through narrow auth.uid()-scoped RPCs.

create or replace function public.get_game_match_snapshot(p_room_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
set row_security = off
as $$
declare
  v_user uuid := auth.uid();
  v_state public.game_match_states%rowtype;
  v_actions jsonb;
  v_room_status text;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not public.is_game_room_member(p_room_id) then raise exception 'Match participant required'; end if;
  select * into v_state from public.game_match_states where room_id = p_room_id;
  if not found then raise exception 'Online match has not started'; end if;
  select status into v_room_status from public.game_rooms where id = p_room_id;
  select coalesce(jsonb_agg(jsonb_build_object(
      'sequence', a.sequence,
      'client_action_id', a.client_action_id,
      'actor_id', a.actor_id,
      'seat', a.seat,
      'type', a.action_type,
      'payload', a.payload,
      'created_at', a.created_at
    ) order by a.sequence), '[]'::jsonb)
    into v_actions
    from public.game_match_actions a
    where a.room_id = p_room_id;
  return jsonb_build_object(
    'match_id', v_state.room_id,
    'game_id', v_state.game_id,
    'status', case when v_state.status = 'in_progress' then 'in_progress' else v_state.status end,
    'state_version', v_state.state_version,
    'next_sequence', v_state.next_sequence,
    'active_seat', v_state.active_seat,
    'room_status', v_room_status,
    'state_json', jsonb_build_object('actions', v_actions)
  );
end;
$$;

create or replace function public.start_game_match(p_room_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
set row_security = off
as $$
declare
  v_user uuid := auth.uid();
  v_room public.game_rooms%rowtype;
  v_player_count integer;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select * into v_room from public.game_rooms where id = p_room_id for update;
  if not found then raise exception 'Game room not found'; end if;
  if not public.is_game_room_member(p_room_id) then raise exception 'Match participant required'; end if;
  if not exists (select 1 from public.game_room_players where room_id = p_room_id and user_id = v_user and seat = 0) then
    raise exception 'Only the room host can start this match';
  end if;
  if v_room.game_id = 'campus_fireline' then raise exception 'Campus Fireline is solo-only'; end if;
  if exists (select 1 from public.game_match_states where room_id = p_room_id) then
    return public.get_game_match_snapshot(p_room_id);
  end if;
  if v_room.status not in ('waiting', 'ready') or v_room.expires_at <= now() then
    raise exception 'Game room is no longer available';
  end if;
  select count(*) into v_player_count from public.game_room_players where room_id = p_room_id;
  if v_player_count < 2 then raise exception 'At least two accepted players are required'; end if;
  insert into public.game_match_states (room_id, game_id, status, state_version, next_sequence, active_seat)
    values (p_room_id, v_room.game_id, 'in_progress', 0, 1, -1);
  update public.game_rooms set status = 'in_progress', updated_at = now() where id = p_room_id;
  return public.get_game_match_snapshot(p_room_id);
end;
$$;

create or replace function public.submit_game_match_action(
  p_room_id uuid,
  p_client_action_id uuid,
  p_action_type text,
  p_payload jsonb default '{}'::jsonb,
  p_expected_version bigint default null,
  p_expected_sequence bigint default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
set row_security = off
as $$
declare
  v_user uuid := auth.uid();
  v_seat smallint;
  v_state public.game_match_states%rowtype;
  v_payload jsonb := coalesce(p_payload, '{}'::jsonb);
  v_allowed boolean := false;
  v_existing public.game_match_actions%rowtype;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_client_action_id is null then raise exception 'Action ID is required'; end if;
  if p_action_type is null or p_action_type !~ '^[a-z][a-z0-9_]{0,31}$' then raise exception 'Invalid action type'; end if;
  if jsonb_typeof(v_payload) <> 'object' or octet_length(v_payload::text) > 2048 then raise exception 'Invalid action payload'; end if;
  if not public.is_game_room_member(p_room_id) then raise exception 'Match participant required'; end if;
  select seat into v_seat from public.game_room_players where room_id = p_room_id and user_id = v_user;
  if v_seat is null then raise exception 'No seat in this match'; end if;
  select * into v_state from public.game_match_states where room_id = p_room_id for update;
  if not found then raise exception 'Online match has not started'; end if;
  if v_state.status <> 'in_progress' then raise exception 'This match is no longer active'; end if;

  -- Idempotent retry: return the current snapshot rather than duplicating an action.
  select * into v_existing from public.game_match_actions
    where room_id = p_room_id and actor_id = v_user and client_action_id = p_client_action_id;
  if found then
    return jsonb_build_object('accepted', true, 'reason', 'Already received', 'snapshot', public.get_game_match_snapshot(p_room_id));
  end if;

  if p_expected_version is distinct from v_state.state_version
     or p_expected_sequence is distinct from v_state.next_sequence then
    return jsonb_build_object('accepted', false, 'reason', 'Match changed; sync the latest state and retry', 'snapshot', public.get_game_match_snapshot(p_room_id));
  end if;

  v_allowed := case v_state.game_id
    when 'campus_duel' then p_action_type in ('ready','move','attack','guard','dodge','skill','resign')
    when 'kart_racing' then p_action_type in ('ready','steer','throttle','brake','boost','resign')
    when 'bike_racing' then p_action_type in ('ready','steer','throttle','brake','boost','resign')
    when 'campus_ludo' then p_action_type in ('ready','roll','move','pass','resign')
    when 'naija_whot' then p_action_type in ('ready','play_card','draw_card','call_suit','pass','resign')
    when 'billiards' then p_action_type in ('ready','shoot','place_cue_ball','resign')
    else false
  end;
  if not v_allowed then raise exception 'Action is not supported for this game'; end if;

  -- A Ludo die is generated by the database, not accepted from the player's payload.
  if v_state.game_id = 'campus_ludo' and p_action_type = 'roll' then
    v_payload := jsonb_build_object('die', floor(random() * 6 + 1)::integer);
  end if;
  -- Prevent client payloads from masquerading as trusted match outcomes or value changes.
  if v_payload ?| array['winner','result','score','currency','balance','xp','coins','practice_points','state','seat','actor_id'] then
    raise exception 'Outcome, identity, and currency fields are server-owned';
  end if;

  insert into public.game_match_actions (room_id, sequence, client_action_id, actor_id, seat, action_type, payload)
    values (p_room_id, v_state.next_sequence, p_client_action_id, v_user, v_seat, p_action_type, v_payload);
  update public.game_match_states
    set state_version = state_version + 1,
        next_sequence = next_sequence + 1,
        updated_at = now()
    where room_id = p_room_id;
  return jsonb_build_object('accepted', true, 'reason', '', 'snapshot', public.get_game_match_snapshot(p_room_id));
end;
$$;

create or replace function public.cancel_game_invite(p_invite_id uuid)
returns void
language plpgsql
security definer
set search_path = public
set row_security = off
as $$
declare
  v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  update public.game_invites
    set status = 'cancelled', responded_at = now()
    where id = p_invite_id and sender_id = v_user and status = 'pending' and expires_at > now();
  if not found then raise exception 'Pending invitation not found'; end if;
end;
$$;

revoke all on function public.get_game_match_snapshot(uuid) from public;
revoke all on function public.start_game_match(uuid) from public;
revoke all on function public.submit_game_match_action(uuid, uuid, text, jsonb, bigint, bigint) from public;
revoke all on function public.cancel_game_invite(uuid) from public;
grant execute on function public.get_game_match_snapshot(uuid) to authenticated;
grant execute on function public.start_game_match(uuid) to authenticated;
grant execute on function public.submit_game_match_action(uuid, uuid, text, jsonb, bigint, bigint) to authenticated;
grant execute on function public.cancel_game_invite(uuid) to authenticated;

do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'game_match_actions') then
    alter publication supabase_realtime add table public.game_match_actions;
  end if;
end $$;

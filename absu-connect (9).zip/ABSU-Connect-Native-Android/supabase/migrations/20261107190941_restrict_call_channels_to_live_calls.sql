create or replace function private.can_access_absu_call_topic()
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_topic text := realtime.topic();
  v_call_id uuid;
begin
  if v_topic is null or v_topic not like 'absu-call:%' then return false; end if;
  begin
    v_call_id := split_part(v_topic, ':', 2)::uuid;
  exception when others then
    return false;
  end;
  return exists (
    select 1 from public.call_sessions c
    where c.id = v_call_id
      and auth.uid() in (c.caller_id, c.recipient_id)
      and c.status in ('ringing', 'accepted')
  );
end;
$$;
revoke all on function private.can_access_absu_call_topic() from public, anon;
grant execute on function private.can_access_absu_call_topic() to authenticated;

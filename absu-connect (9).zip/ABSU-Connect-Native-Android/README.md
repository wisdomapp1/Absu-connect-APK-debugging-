# ABSU Connect — Native Android app source

This is a **standalone native Android application** for ABSU Connect. The social screens are built with Android Views and native Android components; there is no WebView and the hosted website is not rendered inside the app. The existing website remains a separate frontend. Both clients use the same Supabase project and user accounts.

The project also retains the seven existing native campus games. This source is a development milestone, not a signed release APK and not yet a Play Store release candidate.

## Included native screens

- **Sign in / sign up:** Supabase Auth, encrypted local session storage and automatic refresh before authenticated REST requests.
- **Home:** reads the ABSU Connect feed from `posts`, displays authors from `profiles`, lets a signed-in user publish a text post and react to posts.
- **Friends:** reads existing friendship records, displays incoming requests, accepts/declines requests, discovers profiles and creates/opens one-to-one conversations.
- **Messages:** reads conversations and messages, sends text messages and stores everything in the existing Supabase tables.
- **Alerts:** reads the signed-in user's `notifications` rows and marks them read.
- **Communities:** reads the existing `communities` and `community_members` tables, searches active communities, creates public/private communities, joins public communities, submits requests to join private communities, and reads/writes community posts through `posts.community_id`. The existing database trigger adds a creator as the community owner and changes private-community joins to `pending`.
- **Events:** reads published public `campus_events`, searches events, saves/unsaves events, records `interested` / `going` responses in `event_participants`, opens registration URLs, displays the user's own submissions and submits new events for admin review. The form includes native date/time pickers and supports online events.
- **Game Center:** opens the seven included native game activities.
- **Profile:** reads and updates the signed-in user's existing `profiles` row.

The native app uses the existing Supabase schema and RLS policies. Communities and events already existed in the live project, so this milestone did not add duplicate communities/events tables or a parallel data model. The low-data mode is ON by default; it reduces feed, chat, friends, communities and events fetch limits and uses 240p / 12 fps video with an approximate 180 kbps outbound video cap. The app does not provide zero-rated or free internet; normal carrier data charges still apply. Community posts use the existing `posts.community_id` field; there is no separate `community_posts` table in this project.

## Navigation and visual system

The app uses a native five-item bottom navigation bar (Home, Friends, Messages, Alerts, More), a native toolbar, scrollable native screens, native forms, dialogs and date/time pickers. The UI follows the current ABSU Connect purple / warm-neutral visual direction, but it is not yet a pixel-for-pixel recreation of every website interaction.

## Notifications

Implemented in source:

- Android 13+ `POST_NOTIFICATIONS` runtime permission request.
- High-importance Android notification channels for general alerts and calls.
- A notification-settings screen that can open Android's channel settings so a user can enable Alerting / heads-up behaviour.
- A foreground Supabase Realtime subscription for the signed-in user's notification inserts, with Phoenix heartbeat frames and local heads-up notifications.
- Firebase Cloud Messaging SDK/service integration, device-token upsert to `device_push_tokens`, and background notification handling.
- Removal of the current device token from Supabase during sign-out to avoid cross-account notification leakage.

**FCM readiness from live Supabase inspection:** the `send-android-push` Edge Function is active at v4 and `send-android-call-push` at v2. However, the live `device_push_tokens` table currently has zero Android device tokens. The push function returns early when no token exists, before it attempts the Firebase service-account exchange; therefore an HTTP 200 log entry is not proof that the server-side Firebase service-account secret has been exercised. The Android Firebase client configuration has now been added at `app/google-services.json` and matches the registered Firebase Android app ID `com.absuconnect.app`. A real device token is still needed to complete an end-to-end push test. Android and manufacturer settings can still suppress heads-up alerts; the app cannot override user permissions, channel settings or Do Not Disturb.

## Native voice and video calls — source implementation added

This revision includes a native one-to-one WebRTC call flow for accepted ABSU Connect friends:

- Outgoing voice/video call creation through the authenticated `create_call_session` RPC.
- Incoming call delivery through the Supabase `send-android-call-push` function, which validates the live call and forwards to `send-android-push`.
- Private Supabase Realtime channel `absu-call:<call-id>` for offer, answer, ICE candidates and call-state signalling. Channel access is limited to the two call participants while the call is ringing or accepted.
- Accept, decline, missed, failed and end states, plus a database expiry guard and scheduled cleanup for unanswered calls.
- Native microphone/camera runtime prompts, mute, speaker, camera toggle, camera flip, elapsed-call timer, connection-state display and limited ICE-restart attempts.
- High-importance incoming call notifications with Answer / Decline actions and full-screen presentation where Android grants it. An ongoing foreground notification is shown during a call.

The implementation uses the pinned `io.github.webrtc-sdk:android:150.7871.04` artifact. It includes Google STUN and a shared OpenRelay TURN fallback. That public TURN fallback is not a dedicated production relay and is not a guarantee that every carrier NAT or restricted Wi-Fi network will connect. Before a broad public release, configure and test a dedicated TURN service with private credentials; never hard-code private TURN credentials in the APK.

**Firebase Android client configuration added in this revision:** `app/google-services.json` is included and validated against Firebase project `absu-connect0`, Android package `com.absuconnect.app`. The Gradle `applicationId` is set to `com.absuconnect.app` to match it (the Java namespace remains `com.absuconnect.games`, which is independent). The Supabase Android token table currently contains zero Android device tokens, so FCM has not yet delivered to a registered native device. Supabase Edge Functions `send-android-push` (v4) and `send-android-call-push` (v2) are active, but the service-account secret cannot be proven valid from an invocation that exits early because no device tokens exist. After adding the Firebase Android config and signing in on a phone, confirm that its token row is created, then test a real background call notification.

Android 14+ may require the user to grant special full-screen notification access. The app requests it and falls back to a normal call notification when unavailable; Android/Play policy, notification permissions, channel settings, battery controls and Do Not Disturb can prevent a heads-up/full-screen pop-up. No app can override those user or OS settings.

**Not yet verified:** there has been no Android compiler build, APK installation, two-phone voice/video call, background FCM delivery or mobile-network/TURN test in this execution environment. Treat calling as implemented in source, not yet a proven release feature.

## Other incomplete features

This is a native social-app foundation, not a feature-complete clone of the website. Post media upload, full threaded comments, complete profile photo editing, attachment sending and several advanced message states are not integrated in this source revision. Some website administration/moderation capabilities are also not surfaced in the native UI. Voice/video calling is integrated in source but has not passed a physical two-phone test. The multiplayer engine inside the games is still not proven as fully synchronized cross-device gameplay; the existing match transport is scaffolding, not a verified live match implementation.

## Build

Requirements:

- Android Studio with JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Gradle 8.9 (the included wrapper downloads it on first use)

Open this folder in Android Studio, sync Gradle and build:

```bash
./gradlew --no-daemon :app:testDebugUnitTest :app:assembleDebug
```

The project includes a GitHub Actions workflow at `.github/workflows/android-debug-apk.yml` that can build a debug APK remotely after the source is pushed to a GitHub repository and the workflow is run. This source ZIP already includes the matching `app/google-services.json`. If you use a public repository, remove that file from the public commit and store its base64-encoded contents as the GitHub Actions secret `GOOGLE_SERVICES_JSON_B64`; the workflow restores it only during the build. The Firebase Android config is client-side configuration, not the Firebase service-account private key. Never place the service-account JSON in the Android app or repository.

## Validation completed for this milestone

`bash tools/run-domain-checks.sh` passes, covering the existing Ludo, WHOT, billiards, racing, local fighter/shooter progression and multiplayer-scaffold contract tests (28 assertions). These tests do not compile or instrument the Android Activity layer and do not prove a live Supabase login, FCM delivery, events/communities transaction, phone call or Play Store readiness.

A local Android APK build was attempted but could not start because this execution environment has no Android SDK installed and cannot resolve `services.gradle.org` to download Gradle. **No APK was built or device-tested in this milestone.** Use Android Studio or the included GitHub Actions workflow for the first actual Android build, then test on at least two separate Android phones.

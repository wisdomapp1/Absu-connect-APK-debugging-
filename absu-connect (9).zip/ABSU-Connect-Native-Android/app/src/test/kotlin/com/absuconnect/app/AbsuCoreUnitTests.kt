package com.absuconnect.app

import com.absuconnect.app.model.AppTab
import com.absuconnect.app.model.FriendTab
import com.absuconnect.app.model.Profile
import com.absuconnect.app.util.DiscoveryScorer
import com.absuconnect.app.util.MediaValidator
import com.absuconnect.app.util.NotificationRouter
import com.absuconnect.app.util.UrlUtils
import org.junit.Assert.*
import org.junit.Test

class AbsuCoreUnitTests {

    @Test
    fun urlDetectionRecognizesHttpHttpsAndWwwLinks() {
        val text = "Join ABSU portal at www.absuconnect.edu.ng, docs: https://supabase.com/docs! Check http://uturu.local/map."
        val segments = UrlUtils.segmentTextWithUrls(text)
        val urls = segments.mapNotNull { it.url }

        assertEquals(
            listOf(
                "https://www.absuconnect.edu.ng",
                "https://supabase.com/docs",
                "http://uturu.local/map"
            ),
            urls
        )
    }

    @Test
    fun discoveryScorerPrioritizesDeptFacultyLevelInterestsAndOnlinePresence() {
        val me = Profile(
            id = "me",
            displayName = "Chidi",
            department = "Computer Science",
            faculty = "Physical Sciences",
            level = "300L",
            interests = listOf("AI", "Football")
        )
        val sameDeptOnline = Profile(
            id = "u1",
            displayName = "Ada",
            department = "Computer Science",
            faculty = "Physical Sciences",
            level = "300L",
            interests = listOf("AI"),
            isOnline = true
        )
        val otherDeptOffline = Profile(
            id = "u2",
            displayName = "Emeka",
            department = "Law",
            faculty = "Law",
            level = "200L",
            isOnline = false
        )
        val alreadyFriend = Profile(id = "u3", displayName = "Ngozi", department = "Computer Science")

        val ranked = DiscoveryScorer.scoreCandidates(
            currentUser = me,
            candidates = listOf(otherDeptOffline, alreadyFriend, sameDeptOnline),
            excludedIds = setOf("u3")
        )

        assertEquals(2, ranked.size)
        assertEquals("u1", ranked[0].profile.id)
        assertTrue(ranked[0].matchReasons.contains("Same Department"))
        assertTrue(ranked[0].matchReasons.contains("Online now"))
        assertTrue(ranked[0].score > ranked[1].score)
    }

    @Test
    fun mediaValidatorRejectsCorruptEmptyAndNonImageFiles() {
        assertFalse(MediaValidator.isValidImageBytes(ByteArray(0)) { true })
        assertFalse(MediaValidator.isValidImageBytes(byteArrayOf(1, 2, 3)) { false })
        assertTrue(MediaValidator.isValidImageBytes(byteArrayOf(1, 2, 3, 4)) { true })
        assertTrue(MediaValidator.isSupportedPostMimeType("image/jpeg"))
        assertFalse(MediaValidator.isSupportedPostMimeType("video/mp4"))
    }

    @Test
    fun notificationRouterRoutesWelcomeAndDiscoveryToFriendsDiscoverTab() {
        val welcome = NotificationRouter.resolveDestination("system", "discovery_welcome")
        assertEquals(AppTab.FRIENDS, welcome.tab)
        assertEquals(FriendTab.DISCOVER, welcome.friendTab)

        val suggestion = NotificationRouter.resolveDestination("discovery_suggestion", null)
        assertEquals(AppTab.FRIENDS, suggestion.tab)
        assertEquals(FriendTab.DISCOVER, suggestion.friendTab)

        val message = NotificationRouter.resolveDestination("message", "conversation")
        assertEquals(AppTab.MESSAGES, message.tab)
        assertNull(message.friendTab)
    }
}

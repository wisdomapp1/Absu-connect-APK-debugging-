package com.absuconnect.games.ludo;

import static org.junit.Assert.*;
import org.junit.Test;

public class LudoEngineTest {
    @Test public void sixReleasesTokenAndGrantsBonusRoll() {
        LudoEngine engine = new LudoEngine(LudoEngine.Rules.campusVariant());
        assertTrue(engine.roll(6));
        assertEquals(0, engine.move(0).nextPlayer);
        assertEquals(0, engine.progressOf(0, 0));
        assertEquals(0, engine.currentPlayer());
        assertEquals(0, engine.dieValue());
    }

    @Test public void threeConsecutiveSixesForfeitTurn() {
        LudoEngine engine = new LudoEngine(LudoEngine.Rules.campusVariant());
        engine.roll(6); engine.move(0);
        engine.roll(6); engine.move(0);
        assertTrue(engine.roll(6));
        assertEquals(1, engine.currentPlayer());
    }

    @Test public void exactRollIsRequiredToFinish() {
        LudoEngine engine = new LudoEngine(LudoEngine.Rules.campusVariant());
        engine.roll(6); engine.move(0);
        int[] increments = {6,5,6,5,6,5,6,5,6,5}; // progress reaches 55 without three sixes
        for (int roll : increments) {
            advanceToSeatZero(engine);
            engine.roll(roll);
            engine.move(0);
        }
        assertEquals(55, engine.progressOf(0,0));
        advanceToSeatZero(engine);
        engine.roll(3);
        assertFalse(engine.legalTokens().contains(0));
        // A non-six with no legal move advances automatically.
        assertEquals(1, engine.currentPlayer());
        advanceToSeatZero(engine);
        engine.roll(2);
        LudoEngine.MoveResult finish=engine.move(0);
        assertTrue(finish.finishedToken);
        assertEquals(57,engine.progressOf(0,0));
    }

    @Test public void captureBonusIsConfigurable() {
        assertFalse(LudoEngine.Rules.classicNoCaptureBonus().bonusRollOnCapture);
        assertTrue(LudoEngine.Rules.campusVariant().bonusRollOnCapture);
    }

    private void advanceToSeatZero(LudoEngine engine) {
        while(engine.currentPlayer()!=0) engine.roll(1); // no CPU tokens are out; roll is skipped
    }
}

package com.absuconnect.games.fighter;

import static org.junit.Assert.*;
import com.absuconnect.games.action.ActionContentCatalog;
import org.junit.Test;

public class FighterCombatModelTest {
    private static void closeRange(FighterCombatModel model,long now){
        model.step(false,true,now);
        model.step(false,true,now+1);
    }

    @Test public void movementChangesSpacingAndAnOutOfRangeStrikeDoesNotSpendStamina(){
        FighterCombatModel model=new FighterCombatModel();long now=System.currentTimeMillis()+10000;
        FighterCombatModel.Result before=model.snapshot();
        FighterCombatModel.Result miss=model.act(FighterCombatModel.Action.LIGHT,now);
        assertEquals(before.sparringHealth,miss.sparringHealth);
        assertEquals(before.stamina,miss.stamina);
        assertTrue(miss.message.contains("Out of range"));
        FighterCombatModel.Result closed=model.step(false,true,now+10);
        assertTrue(closed.distance<before.distance);
        closeRange(model,now+20);
        FighterCombatModel.Result hit=model.act(FighterCombatModel.Action.LIGHT,now+30);
        assertEquals(91,hit.sparringHealth);
        assertEquals(92,hit.stamina);
    }

    @Test public void guardAndDodgeAreDifferentActions(){
        FighterCombatModel model=new FighterCombatModel();long now=System.currentTimeMillis()+10000;
        assertEquals(2,model.act(FighterCombatModel.Action.GUARD,now).playerPose);
        FighterCombatModel.Result dodge=model.act(FighterCombatModel.Action.DODGE,now+50);
        assertEquals(3,dodge.playerPose);
        assertEquals(88,dodge.stamina);
    }

    @Test public void specialTechniqueHasHigherCostAndImpact(){
        FighterCombatModel model=new FighterCombatModel();long now=System.currentTimeMillis()+10000;closeRange(model,now);
        FighterCombatModel.Result r=model.act(FighterCombatModel.Action.SPECIAL,now+10);
        assertEquals(73,r.sparringHealth);
        assertEquals(65,r.stamina);
    }

    @Test public void heavyRecoveryAlsoBlocksSpecials(){
        FighterCombatModel model=new FighterCombatModel();long now=System.currentTimeMillis()+10000;closeRange(model,now);
        FighterCombatModel.Result heavy=model.act(FighterCombatModel.Action.HEAVY,now+10);
        FighterCombatModel.Result duringRecovery=model.act(FighterCombatModel.Action.SPECIAL,now+60);
        assertEquals(heavy.sparringHealth,duringRecovery.sparringHealth);
        assertTrue(duringRecovery.message.contains("Recovering"));
    }

    @Test public void twoLocalSeatsHaveIndependentPosesAndStamina(){
        FighterCombatModel model=new FighterCombatModel();model.setLocalDuel(true);long now=System.currentTimeMillis()+10000;closeRange(model,now);model.tick(now+400);
        FighterCombatModel.Result p2=model.actOpponent(FighterCombatModel.Action.LIGHT,now+500);
        assertEquals(0,p2.playerPose);
        assertEquals(1,p2.opponentPose);
        assertEquals(100,p2.stamina);
        assertEquals(92,p2.opponentStamina);
        assertEquals(91,p2.playerHealth);
    }

    @Test public void opponentSpecialObeysRecoveryAndSelectedLoadoutChangesReach(){
        FighterCombatModel model=new FighterCombatModel();model.setLocalDuel(true);long now=System.currentTimeMillis()+10000;closeRange(model,now);
        FighterCombatModel.Result first=model.actOpponent(FighterCombatModel.Action.SPECIAL,now+10);
        FighterCombatModel.Result second=model.actOpponent(FighterCombatModel.Action.SPECIAL,now+50);
        assertEquals(first.playerHealth,second.playerHealth);
        assertTrue(second.message.contains("recovering"));

        FighterCombatModel shortWeapon=new FighterCombatModel();
        shortWeapon.configureLoadout(ActionContentCatalog.FIGHTING_WEAPONS[11],ActionContentCatalog.FIGHTING_SKILLS[0]);
        FighterCombatModel longWeapon=new FighterCombatModel();
        longWeapon.configureLoadout(ActionContentCatalog.FIGHTING_WEAPONS[0],ActionContentCatalog.FIGHTING_SKILLS[0]);
        assertTrue(longWeapon.step(false,true,now).distance<shortWeapon.step(false,true,now).distance);
        assertTrue(longWeapon.snapshot().distance>=1.35f);
    }

    @Test public void cpuWarnsBeforeAResolvedCounter(){
        FighterCombatModel model=new FighterCombatModel();long now=System.currentTimeMillis()+5000;FighterCombatModel.Result windup=model.snapshot();int tick=0;
        for(;tick<35;tick++){windup=model.tick(now+tick*120L);if(windup.message.contains("winds up"))break;}
        assertTrue("CPU must telegraph before the counter lands",windup.message.contains("winds up"));
        FighterCombatModel.Result impact=model.tick(now+tick*120L+500);
        assertTrue(impact.playerHealth<100);
    }

    @Test public void cpuVariesAttackIntentAndTelegraphsTheSpecificThreat(){
        FighterCombatModel model=new FighterCombatModel();long now=System.currentTimeMillis()+5000;
        FighterCombatModel.Result windup=model.snapshot();int tick=0;
        for(;tick<35;tick++){windup=model.tick(now+tick*120L);if(windup.message.contains("heavy strike"))break;}
        assertTrue("first CPU threat should be clearly identified",windup.message.contains("heavy strike"));
        FighterCombatModel.Result heavy=model.tick(now+tick*120L+500);
        assertEquals(86,heavy.playerHealth);
        assertEquals(81,heavy.opponentStamina);

        long secondStart=now+tick*120L+1700;
        boolean sawJab=false;
        for(int i=0;i<35;i++){
            FighterCombatModel.Result next=model.tick(secondStart+i*120L);
            if(next.message.contains("quick jab")){sawJab=true;break;}
        }
        assertTrue("CPU should vary its next intent and telegraph it",sawJab);
    }
}

package com.absuconnect.games.shooter;

import static org.junit.Assert.*;
import com.absuconnect.games.action.ActionContentCatalog;
import org.junit.Test;

public class ShooterMatchModelTest {
    @Test public void jumpHasModelHeightAndCannotBeRetriggeredUntilCooldown(){
        ShooterMatchModel game=new ShooterMatchModel();long now=System.currentTimeMillis();
        assertTrue(game.jump(now));assertFalse(game.snapshot().grounded);assertTrue(game.snapshot().jumpHeight>0f);
        assertFalse("held/repeated jump must not extend airtime",game.jump(now+200));
        game.tick(now+700);assertTrue(game.snapshot().grounded);
        assertFalse("landing does not bypass cooldown",game.jump(now+800));
        assertTrue(game.jump(now+1100));
    }

    @Test public void airborneHeightChangesVerticalShotAlignment(){
        ShooterMatchModel game=new ShooterMatchModel();game.setTrainingMode(true);long now=System.currentTimeMillis();
        game.jump(now);game.aimAt(50,25,0f);int before=game.snapshot().botHealth[2];
        assertTrue(game.fire(now+200));assertEquals("ground-level aim should miss while airborne",before,game.snapshot().botHealth[2]);
        game.aimAt(50,25,-.04f);assertTrue(game.fire(now+600));
        assertTrue("pitch must compensate for the raised camera",game.snapshot().botHealth[2]<before);
    }

    @Test public void wellTimedJumpConsumesAndAvoidsAnOtherwiseSuccessfulCpuShot(){
        long now=System.currentTimeMillis();ShooterMatchModel exposed=new ShooterMatchModel();
        for(int i=0;i<40;i++)exposed.move(-.92f,-.39f,.08f);
        exposed.tick(now+1900);assertTrue("the clear-lane CPU shot should hit a grounded player",exposed.snapshot().playerHealth<exposed.snapshot().maxHealth);

        ShooterMatchModel evading=new ShooterMatchModel();
        for(int i=0;i<40;i++)evading.move(-.92f,-.39f,.08f);
        assertTrue(evading.jump(now+1450));evading.tick(now+1900);
        assertEquals("a timed jump should avoid the incoming shot",evading.snapshot().maxHealth,evading.snapshot().playerHealth);
        assertTrue(evading.snapshot().status.contains("evaded"));
    }

    @Test public void verticalCameraPitchAffectsReticleHitEligibility(){
        ShooterMatchModel level=new ShooterMatchModel();level.setTrainingMode(true);
        level.aimAt(50,25,0f);int before=level.snapshot().botHealth[2];
        assertTrue(level.fire(System.currentTimeMillis()+5000));
        assertTrue(level.snapshot().botHealth[2]<before);

        ShooterMatchModel lookingHigh=new ShooterMatchModel();lookingHigh.setTrainingMode(true);
        lookingHigh.aimAt(50,25,.45f);before=lookingHigh.snapshot().botHealth[2];
        assertTrue(lookingHigh.fire(System.currentTimeMillis()+5000));
        assertEquals(before,lookingHigh.snapshot().botHealth[2]);
    }

    @Test public void coverOccludesPlayerShotsAndCpuLineOfSight(){
        ActionContentCatalog.Cover[] cover={new ActionContentCatalog.Cover(4,4,6,6)};
        assertTrue(ShooterMatchModel.lineBlocked(0,5,10,5,cover));
        assertFalse(ShooterMatchModel.lineBlocked(0,1,10,1,cover));
        assertFalse(ShooterMatchModel.lineBlocked(0,0,3,3,cover));

        ShooterMatchModel game=new ShooterMatchModel();
        for(int i=0;i<42;i++)game.move(1,0,.08f);
        ShooterMatchModel.Result moved=game.snapshot();
        assertTrue(moved.playerX>79f);
        game.aimAt(75,14);int before=game.snapshot().botHealth[1];
        assertTrue(game.fire(System.currentTimeMillis()+5000));
        assertEquals("The target should be behind the selected map's central cover.",before,game.snapshot().botHealth[1]);
    }

    @Test public void emptyMagazineReportsReloadEvenWhenTheLastShotIsOnCooldown(){
        ShooterMatchModel game=new ShooterMatchModel();game.aimAt(50,25);
        long start=System.currentTimeMillis()+10000;
        for(int i=0;i<ActionContentCatalog.GUNS[0].magazine;i++){
            assertTrue("shot "+i,game.fire(start+i*400L));
        }
        assertEquals(0,game.snapshot().ammo);
        assertFalse(game.fire(start+ActionContentCatalog.GUNS[0].magazine*400L));
        assertTrue(game.snapshot().status.contains("Magazine empty"));
    }

    @Test public void trainingModeKeepsAmmoAndSoloRunHasNoArbitraryTimeEnd(){
        ShooterMatchModel range=new ShooterMatchModel();range.setTrainingMode(true);range.aimAt(50,25);
        int ammo=range.snapshot().ammo;
        assertTrue(range.fire(System.currentTimeMillis()+5000));
        assertTrue(range.fire(System.currentTimeMillis()+6000));
        assertEquals(ammo,range.snapshot().ammo);

        ShooterMatchModel round=new ShooterMatchModel();
        round.tick(System.currentTimeMillis()+181000);
        assertFalse("elapsed time must not end the solo campaign",round.snapshot().matchOver);
        assertEquals(1,round.snapshot().level);
        assertEquals(-1L,round.snapshot().timeLeftMs);
    }
    @Test public void progressionScalesGentlyAndContinuesBeyondEarlyLevels(){
        assertTrue(ShooterMatchModel.enemyHealthForLevel(2)>ShooterMatchModel.enemyHealthForLevel(1));
        assertTrue(ShooterMatchModel.enemyDamageForLevel(2)>=ShooterMatchModel.enemyDamageForLevel(1));
        assertTrue(ShooterMatchModel.enemyHealthForLevel(10)>ShooterMatchModel.enemyHealthForLevel(2));
        assertTrue(ShooterMatchModel.enemyDamageForLevel(10)>ShooterMatchModel.enemyDamageForLevel(2));
        assertTrue(ShooterMatchModel.enemyShotIntervalForLevel(10)<ShooterMatchModel.enemyShotIntervalForLevel(2));
        assertTrue(ShooterMatchModel.enemySpeedForLevel(10)>ShooterMatchModel.enemySpeedForLevel(2));
    }
}

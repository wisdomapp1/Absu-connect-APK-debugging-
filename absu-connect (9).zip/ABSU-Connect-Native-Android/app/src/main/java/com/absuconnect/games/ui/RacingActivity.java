package com.absuconnect.games.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.racing.RacingCatalog;
import com.absuconnect.games.racing.RacingEngine;
import com.absuconnect.games.action.LocalGameProgression;
import com.absuconnect.games.action.LocalGameProgressStore;

/** Original arcade racing screen with multiple selectable drivers, vehicles, and skins. */
public final class RacingActivity extends AppCompatActivity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private RacingEngine engine;
    private RacingTrackView track;
    private TextView title,status,score;
    private LinearLayout secondControls;
    private GameSound sound;
    private android.widget.Button soundButton;
    private boolean motorcycle,dialogShown,cpuMode=true,shopOpened,raceRewarded;
    private final int[][] choices={{0,0,0},{1,1,1}};
    private long lastTick;
    private final Runnable tick=new Runnable(){@Override public void run(){
        if(engine==null||!engine.isRunning())return;
        long now=System.nanoTime();float dt=lastTick==0?0.016f:(now-lastTick)/1_000_000_000f;lastTick=now;
        engine.update(dt);track.invalidate();
        if(score!=null)score.setText("P1 LAP "+engine.racer(0).lap()+"/3  ·  "+Math.round(engine.racer(0).speed)+" km/h       P2 LAP "+engine.racer(1).lap()+"/3");
        if(status!=null)status.setText(loadoutSummary());
        if(!engine.isRunning()){lastTick=0;showResult();return;}
        handler.postDelayed(this,16);
    }};
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);motorcycle=getIntent().getBooleanExtra("motorcycle",false);engine=new RacingEngine(motorcycle);
        sound=new GameSound(this);setContentView(build());chooseMode();
    }
    private LinearLayout build(){
        LinearLayout root=UiKit.vertical(this);root.setBackgroundColor(0xff142a23);root.setPadding(UiKit.dp(this,8),UiKit.dp(this,5),UiKit.dp(this,8),UiKit.dp(this,6));
        LinearLayout header=UiKit.row(this);root.addView(header,new LinearLayout.LayoutParams(-1,UiKit.dp(this,42)));
        title=UiKit.text(this,"",14,0xffffffff,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        soundButton=UiKit.button(this,sound.isMuted()?"Sound off":"Sound on",false);header.addView(soundButton);soundButton.setOnClickListener(v->{boolean muted=sound.toggleMuted();soundButton.setText(muted?"Sound off":"Sound on");if(!muted)sound.play(ToneGenerator.TONE_PROP_ACK,90);});
        android.widget.Button loadout=UiKit.button(this,"Loadouts",false);header.addView(loadout);loadout.setOnClickListener(v->chooseRacer(0));
        android.widget.Button career=UiKit.button(this,"Career",false);header.addView(career);career.setOnClickListener(v->openCareer());
        android.widget.Button reset=UiKit.button(this,"New race",false);header.addView(reset);reset.setOnClickListener(v->chooseMode());
        track=new RacingTrackView(this,engine);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,0,1);tp.topMargin=UiKit.dp(this,2);tp.bottomMargin=UiKit.dp(this,2);root.addView(track,tp);
        score=UiKit.text(this,"",10,0xffe5e8d6,true);score.setGravity(Gravity.CENTER);root.addView(score,new LinearLayout.LayoutParams(-1,UiKit.dp(this,20)));
        status=UiKit.text(this,"",9,0xffffffff,false);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,UiKit.dp(this,18)));
        root.addView(controlRow(0),new LinearLayout.LayoutParams(-1,UiKit.dp(this,43)));
        secondControls=controlRow(1);root.addView(secondControls,new LinearLayout.LayoutParams(-1,UiKit.dp(this,43)));
        refresh();return root;
    }
    private LinearLayout controlRow(int seat){
        LinearLayout row=UiKit.row(this);TextView label=UiKit.text(this,seat==0?"P1":"P2",11,seat==0?0xff25c7a0:0xffffba58,true);row.addView(label,new LinearLayout.LayoutParams(UiKit.dp(this,28),-2));
        addSteerButton(row,seat,"Left",-1);addSteerButton(row,seat,"Right",1);addHoldButton(row,seat,"GO",2);addHoldButton(row,seat,"Brake",3);return row;
    }
    private void addSteerButton(LinearLayout row,int seat,String name,int dir){
        android.widget.Button b=UiKit.button(this,name,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);row.addView(b,lp);
        b.setOnClickListener(v->{engine.steer(seat,dir);playCue("steer");track.invalidate();refresh();});
    }
    private void addHoldButton(LinearLayout row,int seat,String name,int control){
        android.widget.Button b=UiKit.button(this,name,control==2);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);row.addView(b,lp);
        b.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){engine.setPressed(seat,control,true);if(control==2)playCue("go");return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){engine.setPressed(seat,control,false);return true;}return true;});
    }
    private void chooseMode(){
        String kind=motorcycle?"Campus Bike Sprint":"Campus Car Sprint";String[] options={"Solo vs CPU","Two players on this device"};
        new AlertDialog.Builder(this).setTitle(kind).setMessage("Original 3-lap oval race · choose a driver, vehicle and paint/skin. Local play only.")
                .setItems(options,(d,w)->{cpuMode=w==0;engine.reset(cpuMode);dialogShown=false;secondControls.setVisibility(cpuMode?android.view.View.GONE:android.view.View.VISIBLE);
                    if(cpuMode){int rank=LocalGameProgressStore.load(this).rank();int drivers=RacingCatalog.eligibleCount(RacingCatalog.DRIVERS,rank),vehicles=RacingCatalog.eligibleCount(motorcycle?RacingCatalog.BIKES:RacingCatalog.CARS,rank),skins=RacingCatalog.eligibleCount(RacingCatalog.SKINS,rank);choices[1][0]=(choices[0][0]+1)%drivers;choices[1][1]=(choices[0][1]+1)%vehicles;choices[1][2]=(choices[0][2]+2)%skins;applyLoadouts();}
                    else chooseRacer(0);}).setCancelable(false).show();
    }
    private void chooseRacer(int seat){
        chooseDriver(seat,()->chooseVehicle(seat,()->chooseSkin(seat,()->{if(seat==0&&!cpuMode)chooseRacer(1);else applyLoadouts();})));
    }
    private void chooseDriver(int seat,Runnable next){int rank=LocalGameProgressStore.load(this).rank();choose("Choose P"+(seat+1)+" driver",RacingCatalog.namesAtRank(RacingCatalog.DRIVERS,rank),choices[seat][0],value->{choices[seat][0]=value;next.run();});}
    private void chooseVehicle(int seat,Runnable next){Object[] list=motorcycle?RacingCatalog.BIKES:RacingCatalog.CARS;int rank=LocalGameProgressStore.load(this).rank();choose("Choose P"+(seat+1)+(motorcycle?" motorcycle":" car"),RacingCatalog.namesAtRank(list,rank),choices[seat][1],value->{choices[seat][1]=value;next.run();});}
    private void chooseSkin(int seat,Runnable next){int rank=LocalGameProgressStore.load(this).rank();choose("Choose P"+(seat+1)+" paint / vehicle skin",RacingCatalog.namesAtRank(RacingCatalog.SKINS,rank),choices[seat][2],value->{choices[seat][2]=value;next.run();});}
    private interface Pick {void accept(int value);}
    private void choose(String title,String[] options,int selected,Pick result){new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options,selected,(d,w)->{d.dismiss();result.accept(w);}).setNegativeButton("Cancel",(d,w)->refresh()).show();}
    private void applyLoadouts(){
        for(int seat=0;seat<2;seat++){String vehicleKey=(motorcycle?"bike":"car")+":"+choices[seat][1];int driverLevel=LocalGameProgressStore.upgradeLevel(this,"racing_driver:"+choices[seat][0]),vehicleLevel=LocalGameProgressStore.upgradeLevel(this,vehicleKey);engine.setRacerLoadout(seat,choices[seat][0],choices[seat][1],choices[seat][2],driverLevel,vehicleLevel);}
        raceRewarded=false;
        engine.reset(cpuMode);dialogShown=false;lastTick=0;refresh();track.setEngine(engine);track.invalidate();handler.removeCallbacks(tick);handler.post(tick);
    }
    private String loadoutSummary(){return engine.driver(0).name.split(" /")[0]+" · "+engine.vehicle(0).name+" · "+engine.livery(0).name+"   |   "+engine.driver(1).name.split(" /")[0]+" · "+engine.vehicle(1).name+" · "+engine.livery(1).name;}
    private void refresh(){if(title==null)return;title.setText((motorcycle?"CAMPUS BIKE SPRINT":"CAMPUS CAR SPRINT")+"  ·  "+engine.vehicle(0).name);if(score!=null)score.setText("P1 LAP "+engine.racer(0).lap()+"/3  ·  "+Math.round(engine.racer(0).speed)+" km/h       P2 LAP "+engine.racer(1).lap()+"/3");if(status!=null)status.setText(loadoutSummary());}
    private void showResult(){if(dialogShown)return;dialogShown=true;String winner=engine.driver(engine.winner()).name+(engine.winner()==1&&engine.isCpuOpponent()?" (CPU)":"");
        LocalGameProgressStore.MatchReward reward=LocalGameProgressStore.recordMatch(this,motorcycle?"bike_racing":"kart_racing",engine.winner()==0?70:45,engine.winner()==0?48:30);raceRewarded=true;
        new AlertDialog.Builder(this).setTitle(winner+" wins").setMessage("Race complete · +"+reward.xp+" XP · +"+reward.credits+" Practice Points"+(reward.rankUp?" · Rank "+reward.rank+" unlocked!":"")+"\n"+loadoutSummary()+"\n\nTry another run with a different driver, vehicle, or skin?").setPositiveButton("Race again",(d,w)->chooseMode()).setNegativeButton("Career / garage",(d,w)->openCareer()).setNeutralButton("Back to Game Center",(d,w)->finish()).show();
    }
    private void openCareer(){handler.removeCallbacks(tick);lastTick=0;Intent i=new Intent(this,ProgressionShopActivity.class);i.putExtra("shop_kind",motorcycle?"bike":"car").putExtra("game_id",motorcycle?"bike_racing":"kart_racing").putExtra("active_a",choices[0][0]).putExtra("active_b",choices[0][1]).putExtra("active_c",choices[0][2]);shopOpened=true;startActivity(i);}
    private void playCue(String cue){if(sound==null)return;int tone="go".equals(cue)?ToneGenerator.TONE_PROP_ACK:"steer".equals(cue)?ToneGenerator.TONE_PROP_PROMPT:ToneGenerator.TONE_PROP_BEEP;sound.play(tone,65);}
    @Override protected void onResume(){super.onResume();if(shopOpened){shopOpened=false;/* Keep the in-progress race; shop upgrades apply after the next setup. */}if(engine!=null&&engine.isRunning()&&handler!=null){lastTick=0;handler.removeCallbacks(tick);handler.post(tick);}}
    @Override protected void onPause(){handler.removeCallbacks(tick);if(engine!=null)engine.clearInputs();super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(sound!=null)sound.close();super.onDestroy();}
}

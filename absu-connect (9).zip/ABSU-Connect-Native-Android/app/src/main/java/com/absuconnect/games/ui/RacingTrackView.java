package com.absuconnect.games.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import com.absuconnect.games.racing.RacingCatalog;
import com.absuconnect.games.racing.RacingEngine;

/** Lightweight original oval circuit with selectable driver, vehicle silhouette, and livery colours. */
public final class RacingTrackView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private RacingEngine engine;
    public RacingTrackView(Context c,RacingEngine e){super(c);engine=e;}
    public void setEngine(RacingEngine e){engine=e;invalidate();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);canvas.drawColor(0xff18372d);
        float s=Math.min(getWidth()/1000f,getHeight()/560f),ox=(getWidth()-1000*s)/2f,oy=(getHeight()-560*s)/2f;
        canvas.save();canvas.translate(ox,oy);canvas.scale(s,s);
        p.setStyle(Paint.Style.FILL);p.setColor(0xff28613e);canvas.drawRect(0,0,1000,560,p);
        p.setColor(0xffad7741);canvas.drawOval(new RectF(48,36,952,524),p);
        p.setColor(0xff454e4a);canvas.drawOval(new RectF(68,54,932,506),p);
        p.setColor(0xff28613e);canvas.drawOval(new RectF(333,167,667,393),p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xffe1d9bd);canvas.drawOval(new RectF(75,61,925,499),p);canvas.drawOval(new RectF(333,167,667,393),p);
        p.setColor(0x99e5ddc4);p.setStrokeWidth(1.5f);p.setPathEffect(new android.graphics.DashPathEffect(new float[]{12,13},0));canvas.drawOval(new RectF(203,113,797,447),p);canvas.drawOval(new RectF(119,69,881,491),p);p.setPathEffect(null);
        p.setStyle(Paint.Style.FILL);p.setColor(0xfff3edda);canvas.drawRect(491,61,509,167,p);
        for(int i=0;i<6;i++){p.setColor((i%2==0)?Color.BLACK:Color.WHITE);canvas.drawRect(491+i*3,61,494+i*3,167,p);}
        p.setColor(0xfff3edda);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(18);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);canvas.drawText(engine.isMotorcycle()?"CAMPUS BIKE CIRCUIT":"CAMPUS MOTOR CIRCUIT",500,280,p);
        p.setTextSize(13);p.setTypeface(android.graphics.Typeface.DEFAULT);canvas.drawText("3 LAPS  ·  NO STAKES",500,303,p);
        drawRacer(canvas,engine.racer(0));drawRacer(canvas,engine.racer(1));canvas.restore();
    }
    private void drawRacer(Canvas c,RacingEngine.Racer r){
        float[] rx={370,414,458},ry={139,183,227};float a=r.fraction()*(float)(Math.PI*2)-(float)(Math.PI/2);
        float lane=Math.max(0f,Math.min(2f,r.visualLane));int low=(int)Math.floor(lane),high=Math.min(2,low+1);float blend=lane-low;
        float radiusX=rx[low]+(rx[high]-rx[low])*blend,radiusY=ry[low]+(ry[high]-ry[low])*blend;
        float x=500+(float)Math.cos(a)*radiusX,y=280+(float)Math.sin(a)*radiusY;boolean bike=engine.isMotorcycle();
        RacingCatalog.SkinSpec skin=engine.livery(r.seat);RacingCatalog.VehicleSpec vehicle=engine.vehicle(r.seat);
        c.save();c.translate(x,y);c.rotate((float)Math.toDegrees(a)+90);
        p.setStyle(Paint.Style.FILL);p.setColor(0x77000000);c.drawOval(new RectF(-10,-14,12,14),p);
        p.setColor(skin.primary);
        if(bike){
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(0,-11,4.3f,p);c.drawCircle(0,11,4.3f,p);p.setStyle(Paint.Style.FILL);
            if(vehicle.style==2){c.drawRoundRect(new RectF(-4,-8,4,9),2,3,p);}else c.drawRoundRect(new RectF(-3.5f,-10,3.5f,9),2,2,p);
            p.setColor(skin.trim);c.drawRect(-1.4f,-8,1.4f,6,p);p.setColor(0xff17251f);c.drawCircle(0,0,2,p);
            p.setColor(skin.primary);c.drawCircle(0,-2,4.1f,p);p.setColor(skin.trim);c.drawCircle(0,-3,2.1f,p);
        }else{
            float half=vehicle.style==1?9.5f:vehicle.style==2?7.4f:8.5f;
            c.drawRoundRect(new RectF(-half,-15,half,15),vehicle.style==4?8:4,vehicle.style==4?8:4,p);
            p.setColor(skin.trim);c.drawRoundRect(new RectF(-half*.48f,-10,half*.48f,9),3,3,p);
            p.setColor(0xffd8f0e8);c.drawRoundRect(new RectF(-half*.48f,-12,half*.48f,-7),2,2,p);
            p.setColor(0xff26302c);c.drawRect(-half-3,-9,-half,-4,p);c.drawRect(half,-9,half+3,-4,p);c.drawRect(-half-3,5,-half,10,p);c.drawRect(half,5,half+3,10,p);
        }
        // A small original driver helmet marker makes roster selection visible on both vehicle classes.
        p.setColor(skin.trim);c.drawCircle(0,-1,2.5f,p);p.setColor(0xff202721);c.drawArc(new RectF(-2.5f,-3.5f,2.5f,1.5f),180,180,false,p);
        c.restore();
        c.save();c.translate(x,y);p.setColor(skin.trim);p.setTextSize(13);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);
        c.drawText(engine.driver(r.seat).name.split(" /")[0],0,28,p);c.restore();
    }
}

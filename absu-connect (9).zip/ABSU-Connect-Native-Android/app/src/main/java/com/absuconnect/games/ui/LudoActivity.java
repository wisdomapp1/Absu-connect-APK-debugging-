package com.absuconnect.games.ui;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.action.LocalGameProgressStore;
import com.absuconnect.games.ludo.LudoBoardView;
import com.absuconnect.games.ludo.LudoEngine;
import java.util.List;
import java.util.Random;

public final class LudoActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private LudoEngine engine;
    private LudoBoardView board;
    private GameSound sound;
    private TextView status, dieText, seatsLabel;
    private android.widget.Button rollButton, soundButton;
    private int humanPlayers = 1, lastPromptedHuman = -1;
    private boolean cpuTurnScheduled, roundRewarded, rolling, tokenAnimating, resultDialogShown;
    private static final String[] DIE_FACES = {"⚀", "⚁", "⚂", "⚃", "⚄", "⚅"};

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        sound = new GameSound(this);
        engine = new LudoEngine(LudoEngine.Rules.campusVariant());
        buildScreen();
        chooseMode();
    }

    private void buildScreen() {
        LinearLayout root = UiKit.vertical(this);
        root.setBackgroundColor(UiKit.BG);
        root.setPadding(UiKit.dp(this, 16), UiKit.dp(this, 12), UiKit.dp(this, 16), UiKit.dp(this, 12));
        LinearLayout header = UiKit.row(this);
        android.widget.Button back = UiKit.button(this, "‹  Game Center", false);
        header.addView(back);
        back.setOnClickListener(v -> finish());
        TextView title = UiKit.text(this, "Campus Ludo", 20, UiKit.INK, true);
        title.setGravity(Gravity.CENTER);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        soundButton = UiKit.button(this, soundLabel(), false);
        header.addView(soundButton);
        soundButton.setOnClickListener(v -> toggleSound());
        seatsLabel = UiKit.text(this, "", 11, UiKit.GREEN, true);
        seatsLabel.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(header);
        root.addView(seatsLabel, new LinearLayout.LayoutParams(-1, UiKit.dp(this, 24)));
        status = UiKit.text(this, "", 14, UiKit.MUTED, false);
        status.setGravity(Gravity.CENTER_VERTICAL);
        UiKit.marginTop(this, status, root, 44, 8);
        board = new LudoBoardView(this, engine, this::moveToken);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 0, 1f);
        bp.topMargin = UiKit.dp(this, 8); bp.bottomMargin = UiKit.dp(this, 8);
        root.addView(board, bp);
        LinearLayout footer = UiKit.row(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        dieText = UiKit.text(this, "DIE  —", 21, UiKit.INK, true);
        footer.addView(dieText, new LinearLayout.LayoutParams(0, -2, 1));
        rollButton = UiKit.button(this, "Roll die", true);
        footer.addView(rollButton, new LinearLayout.LayoutParams(UiKit.dp(this, 154), UiKit.dp(this, 52)));
        rollButton.setOnClickListener(v -> humanRoll());
        root.addView(footer);
        TextView rules = UiKit.text(this, "Campus rules: six leaves the yard; safe squares protect tokens; exact roll to finish; six or a capture earns a bonus roll. Three sixes in a row forfeits the turn.", 11, UiKit.MUTED, false);
        UiKit.marginTop(this, rules, root, -2, 7);
        setContentView(root);
    }

    private String soundLabel() { return sound != null && sound.isMuted() ? "Sound off" : "Sound on"; }
    private void toggleSound() {
        boolean muted = sound.toggleMuted();
        soundButton.setText(muted ? "Sound off" : "Sound on");
        if (!muted) sound.play(ToneGenerator.TONE_PROP_ACK, 90);
    }

    private void chooseMode() {
        String[] choices = {"Solo practice vs CPU seats", "2 human players + 2 CPU seats", "3 human players + 1 CPU seat", "4 human players, pass-and-play"};
        new AlertDialog.Builder(this).setTitle("Start Campus Ludo").setItems(choices, (d, which) -> {
            handler.removeCallbacksAndMessages(null);
            humanPlayers = which + 1;
            lastPromptedHuman = -1; cpuTurnScheduled = false; roundRewarded = false; rolling = false; tokenAnimating = false; resultDialogShown = false;
            engine = new LudoEngine(LudoEngine.Rules.campusVariant());
            board.setEngine(engine);
            seatsLabel.setText(which == 0 ? "SOLO vs CPU" : humanPlayers + " LOCAL PLAYERS");
            dieText.setText("DIE  —");
            advanceTurn("Player 1 begins. Roll the die.");
        }).setCancelable(false).show();
    }

    private void humanRoll() {
        if (engine.isFinished() || engine.currentPlayer() >= humanPlayers || engine.dieValue() != 0 || rolling || tokenAnimating) return;
        int finalRoll = random.nextInt(6) + 1;
        animateDie(finalRoll, false, () -> applyRoll(finalRoll, false));
    }

    private void animateDie(int finalValue, boolean cpu, Runnable onSettled) {
        rolling = true;
        if (rollButton != null) rollButton.setEnabled(false);
        int frames = 11;
        for (int i = 0; i < frames; i++) {
            final int frame = i;
            handler.postDelayed(() -> {
                if (isFinishing() || isDestroyed() || engine.isFinished()) return;
                int shown = frame == frames - 1 ? finalValue : random.nextInt(6) + 1;
                dieText.setText(DIE_FACES[shown - 1] + "  " + shown + (cpu ? " · CPU" : ""));
                dieText.setScaleX(frame == frames - 1 ? 1f : 1.12f);
                dieText.setScaleY(frame == frames - 1 ? 1f : 1.12f);
                if (frame % 3 == 0) sound.play(ToneGenerator.TONE_PROP_BEEP, 45);
                if (frame == frames - 1) {
                    ObjectAnimator sx = ObjectAnimator.ofFloat(dieText, View.SCALE_X, 1.2f, 1f); sx.setDuration(150); sx.start();
                    ObjectAnimator sy = ObjectAnimator.ofFloat(dieText, View.SCALE_Y, 1.2f, 1f); sy.setDuration(150); sy.start();
                    sound.play(ToneGenerator.TONE_PROP_ACK, 120);
                    rolling = false;
                    if (onSettled != null) onSettled.run();
                }
            }, i * 72L);
        }
    }

    private void applyRoll(int roll, boolean cpu) {
        if (engine.isFinished()) return;
        int player = engine.currentPlayer();
        if (!engine.roll(roll)) { advanceTurn(null); return; }
        board.invalidate();
        if (engine.currentPlayer() != player) {
            if (roll == 6) updateStatus("Three sixes in a row: the turn is forfeited.");
            else updateStatus((cpu ? "CPU seat " : "Seat ") + (player + 1) + " has no legal move.");
            advanceTurn(null);
            return;
        }
        if (engine.dieValue() == 0) {
            updateStatus((cpu ? "CPU seat " : "Seat ") + (player + 1) + " rolled a six with no legal move. Roll again for the bonus six.");
            if (cpu) scheduleCpu(); else updateControls();
            return;
        }
        updateStatus((cpu ? "CPU seat " : "Seat ") + (player + 1) + " rolled " + roll + ". " + (cpu ? "Choosing a move…" : "Tap a highlighted token."));
        if (cpu) playCpuMove(); else updateControls();
    }

    private void moveToken(int token) {
        if (engine.currentPlayer() >= humanPlayers || engine.dieValue() == 0 || rolling || tokenAnimating) return;
        int player = engine.currentPlayer();
        LudoEngine.MoveResult result;
        try { result = engine.move(token); }
        catch (IllegalStateException ignored) { return; }
        tokenAnimating = true;
        rollButton.setEnabled(false);
        if (result.captured) sound.play(ToneGenerator.TONE_PROP_BEEP, 220);
        else sound.play(ToneGenerator.TONE_PROP_ACK, 110);
        board.animateMove(result, () -> finishMoveAnimation(result, player));
    }

    private void finishMoveAnimation(LudoEngine.MoveResult result, int player) {
        tokenAnimating = false;
        dieText.setText("DIE  —");
        if (result.gameWon) {
            rewardMatch(player < humanPlayers);
            updateStatus((player < humanPlayers ? "Seat " : "CPU seat ") + (player + 1) + " wins. All four tokens reached home.");
            showResult(player, player < humanPlayers);
            return;
        }
        String note = result.captured ? " A rival token was captured and returned to its yard." : result.finishedToken ? " A token reached home." : "";
        updateStatus(result.extraTurn ? "Bonus roll for seat " + (player + 1) + "." + note : "Seat " + (player + 1) + " completed a move." + note);
        if (!result.extraTurn) advanceTurn(null);
        else if (engine.currentPlayer() >= humanPlayers) scheduleCpu();
        else updateControls();
    }

    private void playCpuMove() {
        if (engine.isFinished() || engine.currentPlayer() < humanPlayers || engine.dieValue() == 0) { advanceTurn(null); return; }
        List<Integer> moves = engine.legalTokens();
        if (moves.isEmpty()) { advanceTurn(null); return; }
        int player = engine.currentPlayer();
        int choice = moves.get(0), best = engine.progressOf(player, choice);
        for (int token : moves) {
            int at = engine.progressOf(player, token);
            if (at > best) { best = at; choice = token; }
        }
        final int selected = choice;
        handler.postDelayed(() -> {
            if (engine.currentPlayer() != player || engine.dieValue() == 0 || isFinishing()) { advanceTurn(null); return; }
            LudoEngine.MoveResult result;
            try { result = engine.move(selected); } catch (IllegalStateException ignored) { advanceTurn(null); return; }
            tokenAnimating = true;
            if (result.captured) sound.play(ToneGenerator.TONE_PROP_BEEP, 220);
            else sound.play(ToneGenerator.TONE_PROP_ACK, 110);
            board.animateMove(result, () -> finishMoveAnimation(result, player));
        }, 300L);
    }

    private void scheduleCpu() {
        if (cpuTurnScheduled || rolling || tokenAnimating || engine.isFinished() || engine.currentPlayer() < humanPlayers) return;
        cpuTurnScheduled = true;
        handler.postDelayed(() -> {
            cpuTurnScheduled = false;
            if (engine.isFinished() || engine.currentPlayer() < humanPlayers) { advanceTurn(null); return; }
            int roll = random.nextInt(6) + 1;
            animateDie(roll, true, () -> applyRoll(roll, true));
        }, 460L);
    }

    private void advanceTurn(String opening) {
        if (engine.isFinished()) return;
        int seat = engine.currentPlayer();
        if (seat >= humanPlayers) {
            seatsLabel.setText("CPU SEAT " + (seat + 1) + " · TURN");
            scheduleCpu();
            return;
        }
        seatsLabel.setText("PLAYER " + (seat + 1) + " · YOUR TURN");
        if (humanPlayers > 1 && seat > 0 && lastPromptedHuman != seat) {
            lastPromptedHuman = seat;
            new AlertDialog.Builder(this).setTitle("Pass the phone").setMessage("Player " + (seat + 1) + " is up. Pass the device, then continue.")
                    .setPositiveButton("Ready", (d, w) -> { lastPromptedHuman = -1; updateStatus("Player " + (seat + 1) + ": roll when ready."); updateControls(); })
                    .setCancelable(false).show();
        }
        updateStatus(opening != null ? opening : "Player " + (seat + 1) + " to roll.");
        updateControls();
    }

    private void updateControls() {
        if (rollButton != null) rollButton.setEnabled(!engine.isFinished() && !rolling && !tokenAnimating && engine.currentPlayer() < humanPlayers && engine.dieValue() == 0);
    }

    private void rewardMatch(boolean won) {
        if (roundRewarded) return;
        roundRewarded = true;
        LocalGameProgressStore.MatchReward r = LocalGameProgressStore.recordMatch(this, "campus_ludo", won ? 65 : 35, won ? 45 : 22);
        android.widget.Toast.makeText(this, "Career +" + r.xp + " XP · +" + r.credits + " Practice Points" + (r.rankUp ? " · Rank " + r.rank + " unlocked!" : ""), android.widget.Toast.LENGTH_LONG).show();
    }

    private void showResult(int winner, boolean humanWon) {
        if (resultDialogShown) return;
        resultDialogShown = true;
        sound.play(humanWon ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_NACK, 320);
        TextView title = UiKit.text(this, humanWon ? "✦  VICTORY!  ✦" : "MATCH OVER", 24, humanWon ? UiKit.GREEN : UiKit.GOLD, true);
        title.setGravity(Gravity.CENTER);
        AlertDialog dialog = new AlertDialog.Builder(this).setCustomTitle(title)
                .setMessage(humanWon ? "Player " + (winner + 1) + " brought all four tokens home. Local career progress has been saved." : "CPU seat " + (winner + 1) + " reached home first. The match result is saved locally.")
                .setPositiveButton("New game", (d, w) -> chooseMode()).setNegativeButton("Back", (d, w) -> finish()).create();
        dialog.setOnShowListener(d -> { title.setScaleX(.72f); title.setScaleY(.72f); title.setAlpha(0f); title.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(420).start(); });
        dialog.setCancelable(false);
        dialog.show();
    }

    private void updateStatus(String text) { if (status != null) status.setText(text); }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (sound != null) sound.close();
        super.onDestroy();
    }
}

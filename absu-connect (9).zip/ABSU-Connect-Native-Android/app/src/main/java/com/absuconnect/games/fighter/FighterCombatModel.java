package com.absuconnect.games.fighter;

import com.absuconnect.games.action.ActionContentCatalog.SkillSpec;
import com.absuconnect.games.action.ActionContentCatalog.WeaponSpec;

/** Original local combat model; never use client-side values as an online match authority. */
public final class FighterCombatModel {
    public enum Action { LIGHT, HEAVY, GUARD, RELEASE_GUARD, DODGE, SPECIAL }
    public static final class Result {
        public final int playerHealth,sparringHealth,stamina,opponentStamina,playerMaxHealth,sparringMaxHealth,staminaMax,opponentStaminaMax;
        public final String message;
        /** pose remains an alias for playerPose for compatibility with older UI code. */
        public final int pose,playerPose,opponentPose;
        public final float distance;
        public final int dodgeWindowMs,opponentDodgeWindowMs;
        public final boolean playerSkillActivated,opponentSkillActivated;
        Result(int hp,int enemy,int stamina,int enemyStamina,int playerMax,int enemyMax,int staminaMax,int enemyStaminaMax,
               String message,int playerPose,int opponentPose,float distance,int dodgeWindowMs,int opponentDodgeWindowMs,boolean playerSkillActivated,boolean opponentSkillActivated){
            this.playerHealth=hp;this.sparringHealth=enemy;this.stamina=stamina;this.opponentStamina=enemyStamina;
            this.playerMaxHealth=playerMax;this.sparringMaxHealth=enemyMax;this.staminaMax=staminaMax;this.opponentStaminaMax=enemyStaminaMax;
            this.message=message;this.pose=playerPose;this.playerPose=playerPose;this.opponentPose=opponentPose;this.distance=distance;this.dodgeWindowMs=dodgeWindowMs;this.opponentDodgeWindowMs=opponentDodgeWindowMs;
            this.playerSkillActivated=playerSkillActivated;this.opponentSkillActivated=opponentSkillActivated;
        }
    }
    private int playerHealth=100,sparringHealth=100,stamina=100,opponentStamina=100;
    private long lastUpdate=System.currentTimeMillis(),opponentLastUpdate=System.currentTimeMillis(),lastEnemyStrike=System.currentTimeMillis();
    private long attackReadyAt=0,dodgeUntil=0,opponentAttackReadyAt=0,opponentDodgeUntil=0,skillReadyAt=0,opponentSkillReadyAt=0;
    private long playerGuardUntil,opponentGuardUntil,playerPoseUntil,opponentPoseUntil,enemyStrikeImpactAt;
    private boolean guarding,opponentGuarding,localDuel,cpuStrikePending,playerSkillActivated,opponentSkillActivated;
    private int cpuAttackType,cpuAttackCount;
    private String message="Step into range, then time your strike or defence.";
    private int playerPose,opponentPose;
    private int lightDamage=9,heavyDamage=18,skillDamage=27,skillCost=35,playerMaxHealth=100,sparringMaxHealth=100,playerMaxStamina=100,opponentMaxStamina=100;
    private int skillCooldownMs=4500;
    private String skillEffect="STRIKE",skillName="Technique";
    private int skillDurationMs=650;
    private int lightRecoveryMs=430,heavyRecoveryMs=820;
    private float playerMovement=1f,rivalMovement=1f,weaponMovement=1f,weaponReach=2.2f,distance=3.15f;

    /** Original local loadout profile; tuning is client-side playtest data only. */
    public synchronized void configureLoadout(WeaponSpec weapon,SkillSpec skill){
        configureLoadout(weapon,skill,100,100,100,100,0,0,0);
    }
    public synchronized void configureLoadout(WeaponSpec weapon,SkillSpec skill,int playerHealth,int rivalHealth,int playerStamina,int rivalStamina,int fighterUpgrade,int rivalUpgrade,int weaponUpgrade){
        configureLoadout(weapon,skill,playerHealth,rivalHealth,playerStamina,rivalStamina,fighterUpgrade,rivalUpgrade,weaponUpgrade,1f,1f,weapon.movementScale);
    }
    public synchronized void configureLoadout(WeaponSpec weapon,SkillSpec skill,int playerHealth,int rivalHealth,int playerStamina,int rivalStamina,int fighterUpgrade,int rivalUpgrade,int weaponUpgrade,float playerMovement,float rivalMovement,float weaponMovement){
        playerMaxHealth=Math.max(50,playerHealth+Math.max(0,fighterUpgrade)*5);sparringMaxHealth=Math.max(50,rivalHealth+Math.max(0,rivalUpgrade)*5);
        playerMaxStamina=Math.max(50,playerStamina+Math.max(0,fighterUpgrade)*2);opponentMaxStamina=Math.max(50,rivalStamina+Math.max(0,rivalUpgrade)*2);
        lightDamage=Math.max(4,weapon.damage+Math.max(0,weaponUpgrade)*2+Math.max(0,fighterUpgrade));
        heavyDamage=Math.max(lightDamage+2,Math.round(weapon.damage*1.75f)+Math.max(0,weaponUpgrade)*3+Math.max(0,fighterUpgrade));
        this.playerMovement=clamp(playerMovement,.7f,1.35f);this.rivalMovement=clamp(rivalMovement,.7f,1.35f);this.weaponMovement=clamp(weaponMovement,.7f,1.1f);
        weaponReach=clamp(1.55f+(this.weaponMovement-.75f)*3.2f,1.55f,2.55f);
        lightRecoveryMs=Math.max(260,Math.min(900,weapon.cooldownMs));heavyRecoveryMs=Math.max(lightRecoveryMs+180,Math.round(lightRecoveryMs*1.7f));
        skillDamage=Math.max(8,skill.value+Math.max(0,fighterUpgrade)*2);skillCost=Math.max(8,skill.staminaCost==0?24:skill.staminaCost);
        skillCooldownMs=Math.max(1200,skill.cooldownMs);skillEffect=skill.effect;skillName=skill.name;skillDurationMs=Math.max(300,skill.durationMs);reset();
    }
    public synchronized String selectedSkillName(){return skillName;}

    /** Steps a seat toward or away from its opponent; distance changes affect attack reach. */
    public synchronized Result step(boolean opponent,boolean toward,long now){
        if(playerHealth==0||sparringHealth==0)return result();
        float movement=opponent?rivalMovement:playerMovement;
        float delta=.52f*movement*weaponMovement;
        distance=clamp(distance+(toward?-delta:delta),1.35f,4.5f);
        setPose(opponent,3,now+300);
        message=(opponent?"Player 2":"Player 1")+(toward?" closes the gap.":" creates space.");
        return result();
    }

    /** Triggers the selected skill's unique local effect and enforces its cooldown. */
    public synchronized Result activateSkill(long now){
        recover(now);playerSkillActivated=false;if(playerHealth==0||sparringHealth==0)return result();
        if(now<skillReadyAt){message=skillName+" is cooling down.";return result();}
        switch(skillEffect){
            case "DODGE":
                if(stamina<12){message="Not enough stamina to step out.";return result();}
                skillReadyAt=now+skillCooldownMs;playerSkillActivated=true;return act(Action.DODGE,now);
            case "GUARD":
                skillReadyAt=now+skillCooldownMs;playerSkillActivated=true;playerGuardUntil=now+skillDurationMs;setPose(false,2,playerGuardUntil);message=skillName+" raises a timed guard.";break;
            case "RECOVER":
                skillReadyAt=now+skillCooldownMs;playerSkillActivated=true;stamina=Math.min(playerMaxStamina,stamina+skillDamage);setPose(false,0,now+350);message=skillName+" restores stamina.";break;
            case "FEINT":
                if(now<attackReadyAt){message="Recovering—wait for the opening.";return result();}
                if(distance>weaponReach+.12f){message="Out of range — step in before the feint.";return result();}
                if(stamina<8){message="Recover stamina before the feint.";return result();}
                skillReadyAt=now+skillCooldownMs;playerSkillActivated=true;stamina-=8;attackReadyAt=now+Math.max(240,Math.round(lightRecoveryMs*.65f));setPose(false,1,now+360);
                sparringHealth=Math.max(0,sparringHealth-(targetDodging(now)?0:targetGuarding(now)?3:Math.max(5,skillDamage/2)));
                message=sparringHealth==0?(localDuel?"Player 1 wins the duel!":"Sparring round complete."):targetDodging(now)?"Player 2 evaded the feint.":skillName+" draws a quick opening.";break;
            case "STRIKE":default:
                if(now<attackReadyAt){message="Recovering—wait for the opening.";return result();}
                if(distance>weaponReach+.22f){message="Out of range — step in before the technique.";return result();}
                if(stamina<skillCost){message=skillName+" needs "+skillCost+" stamina.";return result();}
                skillReadyAt=now+skillCooldownMs;playerSkillActivated=true;stamina-=skillCost;attackReadyAt=now+1100;setPose(false,4,now+520);
                sparringHealth=Math.max(0,sparringHealth-(targetDodging(now)?0:targetGuarding(now)?Math.max(4,skillDamage/3):skillDamage));
                message=sparringHealth==0?(localDuel?"Player 1 wins the duel!":"Sparring round complete."):targetDodging(now)?"Player 2 evaded the technique.":skillName+" lands its technique.";break;
        }
        return result();
    }

    public synchronized Result activateOpponentSkill(long now){
        opponentSkillActivated=false;if(!localDuel){message="Switch to local duel mode to control Player 2.";return result();}
        if(now<opponentSkillReadyAt){message=skillName+" is cooling down for Player 2.";return result();}
        switch(skillEffect){
            case "DODGE":
                if(opponentStamina<12){message="Player 2 needs more stamina to step out.";return result();}
                opponentSkillReadyAt=now+skillCooldownMs;opponentSkillActivated=true;return actOpponent(Action.DODGE,now);
            case "GUARD":
                opponentSkillReadyAt=now+skillCooldownMs;opponentSkillActivated=true;opponentGuardUntil=now+skillDurationMs;setPose(true,2,opponentGuardUntil);message=skillName+" raises Player 2's timed guard.";break;
            case "RECOVER":
                recoverOpponent(now);opponentSkillReadyAt=now+skillCooldownMs;opponentSkillActivated=true;opponentStamina=Math.min(opponentMaxStamina,opponentStamina+skillDamage);setPose(true,0,now+350);message=skillName+" restores Player 2 stamina.";break;
            case "FEINT":
                if(now<opponentAttackReadyAt){message="Player 2 is recovering.";return result();}
                if(distance>weaponReach+.12f){message="Player 2 is out of range — step in.";return result();}
                if(opponentStamina<8){message="Player 2 needs more stamina for the feint.";return result();}
                opponentSkillReadyAt=now+skillCooldownMs;opponentSkillActivated=true;return actOpponent(Action.LIGHT,now);
            case "STRIKE":default:
                if(now<opponentAttackReadyAt){message="Player 2 is recovering.";return result();}
                if(distance>weaponReach+.22f){message="Player 2 is out of range — step in.";return result();}
                if(opponentStamina<skillCost){message="Player 2 needs more stamina for the technique.";return result();}
                opponentSkillReadyAt=now+skillCooldownMs;opponentSkillActivated=true;return actOpponent(Action.SPECIAL,now);
        }
        return result();
    }

    public synchronized Result act(Action action,long now){
        recover(now);if(playerHealth==0||sparringHealth==0)return result();
        switch(action){
            case GUARD:guarding=true;setPose(false,2,Long.MAX_VALUE);message="Player 1 holds guard.";break;
            case RELEASE_GUARD:guarding=false;if(now>=playerGuardUntil)setPose(false,0,now+200);message="Player 1 released guard.";break;
            case DODGE:
                if(stamina<12)message="Not enough stamina to step out.";
                else{stamina-=12;dodgeUntil=now+Math.round(430*playerMovement*weaponMovement);distance=clamp(distance+.18f,1.35f,4.5f);setPose(false,3,dodgeUntil);message="Player 1 evades. Time the step against the counter.";}break;
            case LIGHT:
                if(now<attackReadyAt)message="Recovering—wait for the opening.";
                else if(distance>weaponReach)message="Out of range — step in before striking.";
                else if(stamina<8)message="Recover stamina before the next strike.";
                else{stamina-=8;attackReadyAt=now+lightRecoveryMs;setPose(false,1,now+360);sparringHealth=Math.max(0,sparringHealth-(targetDodging(now)?0:targetGuarding(now)?Math.max(2,lightDamage/3):lightDamage));message=sparringHealth==0?(localDuel?"Player 1 wins the duel!":"Sparring round complete. Reset the drill to continue."):(targetDodging(now)?"Player 2 evaded the strike.":targetGuarding(now)?"The strike was guarded.":"Clean light strike.");}break;
            case HEAVY:
                if(now<attackReadyAt)message="Recovering—wait for the opening.";
                else if(distance>weaponReach+.15f)message="Out of range — step in before the power strike.";
                else if(stamina<19)message="A heavy strike needs more stamina.";
                else{stamina-=19;attackReadyAt=now+heavyRecoveryMs;setPose(false,4,now+520);sparringHealth=Math.max(0,sparringHealth-(targetDodging(now)?0:targetGuarding(now)?Math.max(3,heavyDamage/4):heavyDamage));message=sparringHealth==0?(localDuel?"Player 1 wins the duel!":"Sparring round complete. Reset the drill to continue."):(targetDodging(now)?"Player 2 evaded the heavy strike.":targetGuarding(now)?"Heavy impact absorbed in guard.":"Committed heavy strike. Recover before acting again.");}break;
            case SPECIAL:
                if(now<attackReadyAt)message="Recovering—wait for the opening.";
                else if(distance>weaponReach+.22f)message="Out of range — step in before the technique.";
                else if(stamina<skillCost)message="Selected technique needs "+skillCost+" stamina.";
                else{stamina-=skillCost;attackReadyAt=now+1100;setPose(false,4,now+520);sparringHealth=Math.max(0,sparringHealth-(targetDodging(now)?0:targetGuarding(now)?Math.max(4,skillDamage/3):skillDamage));message=sparringHealth==0?(localDuel?"Player 1 wins the duel!":"Sparring round complete. Reset the drill to continue."):"Original training technique. High impact, long recovery.";}break;
        }
        return result();
    }
    /** Actions for seat two in same-device local duel mode. */
    public synchronized Result actOpponent(Action action,long now){
        recover(now);recoverOpponent(now);if(!localDuel){message="Switch to local duel mode to control Player 2.";return result();}
        if(playerHealth==0||sparringHealth==0)return result();
        switch(action){
            case GUARD:opponentGuarding=true;setPose(true,2,Long.MAX_VALUE);message="Player 2 holds guard.";break;
            case RELEASE_GUARD:opponentGuarding=false;if(now>=opponentGuardUntil)setPose(true,0,now+200);message="Player 2 released guard.";break;
            case DODGE:
                if(opponentStamina<12)message="Player 2 needs more stamina to step.";
                else{opponentStamina-=12;opponentDodgeUntil=now+Math.round(430*rivalMovement*weaponMovement);distance=clamp(distance+.18f,1.35f,4.5f);setPose(true,3,opponentDodgeUntil);message="Player 2 steps clear.";}break;
            case LIGHT:
                if(now<opponentAttackReadyAt)message="Player 2 is recovering.";
                else if(distance>weaponReach)message="Player 2 is out of range — step in.";
                else if(opponentStamina<8)message="Player 2 needs more stamina.";
                else{opponentStamina-=8;opponentAttackReadyAt=now+lightRecoveryMs;setPose(true,1,now+360);playerHealth=Math.max(0,playerHealth-(incomingGuarded(now)?Math.max(2,lightDamage/3):lightDamage));message=playerHealth==0?"Player 2 wins the duel!":incomingGuarded(now)?"Player 1 guarded the strike.":"Player 2 lands a light strike.";}break;
            case HEAVY:
                if(now<opponentAttackReadyAt)message="Player 2 is recovering.";
                else if(distance>weaponReach+.15f)message="Player 2 is out of range — step in.";
                else if(opponentStamina<19)message="Player 2 needs more stamina.";
                else{opponentStamina-=19;opponentAttackReadyAt=now+heavyRecoveryMs;setPose(true,4,now+520);playerHealth=Math.max(0,playerHealth-(incomingGuarded(now)?Math.max(3,heavyDamage/4):heavyDamage));message=playerHealth==0?"Player 2 wins the duel!":incomingGuarded(now)?"Player 1 absorbed the heavy strike.":"Player 2 lands a heavy strike.";}break;
            case SPECIAL:
                if(now<opponentAttackReadyAt)message="Player 2 is recovering.";
                else if(distance>weaponReach+.22f)message="Player 2 is out of range — step in before the technique.";
                else if(opponentStamina<skillCost)message="Player 2 needs more stamina for the technique.";
                else{opponentStamina-=skillCost;opponentAttackReadyAt=now+1100;setPose(true,4,now+520);playerHealth=Math.max(0,playerHealth-(incomingGuarded(now)?Math.max(4,skillDamage/3):skillDamage));message=playerHealth==0?"Player 2 wins the duel!":"Player 2 used an original training technique.";}break;
        }
        return result();
    }
    private boolean targetGuarding(long now){return localDuel&&(opponentGuarding||now<opponentGuardUntil);}
    private boolean targetDodging(long now){return localDuel&&now<=opponentDodgeUntil;}
    private boolean incomingGuarded(long now){if(now<=dodgeUntil)return true;return guarding||now<playerGuardUntil;}

    /** Stamina recovery plus telegraphed CPU sparring: close distance, wind up, then resolve defence. */
    public synchronized Result tick(long now){
        recover(now);recoverOpponent(now);
        if(playerPoseUntil!=Long.MAX_VALUE&&now>=playerPoseUntil){playerPose=guarding?2:0;playerPoseUntil=guarding?Long.MAX_VALUE:0;}
        if(opponentPoseUntil!=Long.MAX_VALUE&&now>=opponentPoseUntil){opponentPose=opponentGuarding?2:0;opponentPoseUntil=opponentGuarding?Long.MAX_VALUE:0;}
        if(!localDuel&&playerHealth>0&&sparringHealth>0){
            if(distance>weaponReach-.18f)distance=Math.max(weaponReach-.18f,distance-.045f);
            if(!cpuStrikePending&&now-lastEnemyStrike>=1650&&distance<=weaponReach+.08f){
                // Alternate a slower, stamina-hungry power attack with quick jabs. If exhausted,
                // the CPU conserves its remaining energy and falls back to the light attack.
                cpuAttackType=(cpuAttackCount%2==0&&opponentStamina>=19)?1:0;
                cpuStrikePending=true;enemyStrikeImpactAt=now+(cpuAttackType==1?480:400);lastEnemyStrike=now;
                opponentPose=cpuAttackType==1?4:1;opponentPoseUntil=enemyStrikeImpactAt;
                message=cpuAttackType==1
                        ?"Sparring partner winds up a heavy strike — evade or brace!"
                        :"Sparring partner winds up a quick jab — guard or evade now.";
            }
            if(cpuStrikePending&&now>=enemyStrikeImpactAt){
                cpuStrikePending=false;opponentPose=0;opponentPoseUntil=0;
                int damage=cpuAttackType==1?14:7;
                int cost=cpuAttackType==1?19:8;
                opponentStamina=Math.max(0,opponentStamina-cost);cpuAttackCount++;
                if(now<=dodgeUntil)message="You evaded the sparring counter.";
                else if(guarding||now<playerGuardUntil){playerHealth=Math.max(0,playerHealth-Math.max(2,damage/4));stamina=Math.max(0,stamina-5);message="Guard absorbed most of the "+(cpuAttackType==1?"heavy strike.":"quick jab.");}
                else{playerHealth=Math.max(0,playerHealth-damage);message=cpuAttackType==1?"Sparring partner's heavy strike lands — reset your spacing.":"Sparring partner's quick jab lands — reset your spacing.";}
            }
        }
        if(sparringHealth==0)message=localDuel?"Player 1 wins the duel!":"Sparring round complete. Reset the drill to continue.";
        if(playerHealth==0)message=localDuel?"Player 2 wins the duel!":"Drill ended. Reset and work on defence.";
        return result();
    }
    public synchronized void setLocalDuel(boolean enabled){localDuel=enabled;reset();}
    public synchronized boolean isLocalDuel(){return localDuel;}
    public synchronized void reset(){
        playerHealth=playerMaxHealth;sparringHealth=sparringMaxHealth;stamina=playerMaxStamina;opponentStamina=opponentMaxStamina;
        guarding=false;opponentGuarding=false;playerGuardUntil=opponentGuardUntil=0;cpuStrikePending=false;cpuAttackType=0;cpuAttackCount=0;
        distance=3.15f;attackReadyAt=0;dodgeUntil=0;opponentAttackReadyAt=0;opponentDodgeUntil=0;skillReadyAt=0;opponentSkillReadyAt=0;
        lastUpdate=System.currentTimeMillis();opponentLastUpdate=lastUpdate;lastEnemyStrike=lastUpdate;playerPose=opponentPose=0;playerPoseUntil=opponentPoseUntil=0;
        playerSkillActivated=opponentSkillActivated=false;message=localDuel?"Local duel ready · move into range and control each seat.":"Step into range, then time your strike or defence.";
    }
    public synchronized Result snapshot(){return result();}
    private void setPose(boolean opponent,int value,long until){if(opponent){opponentPose=value;opponentPoseUntil=until;}else{playerPose=value;playerPoseUntil=until;}}
    private void recover(long now){long delta=Math.max(0,now-lastUpdate);int amount=(int)(delta/120);if(amount>0){stamina=Math.min(playerMaxStamina,stamina+amount);lastUpdate=now;}}
    private void recoverOpponent(long now){long delta=Math.max(0,now-opponentLastUpdate);int amount=(int)(delta/120);if(amount>0){opponentStamina=Math.min(opponentMaxStamina,opponentStamina+amount);opponentLastUpdate=now;}}
    private Result result(){return new Result(playerHealth,sparringHealth,stamina,opponentStamina,playerMaxHealth,sparringMaxHealth,playerMaxStamina,opponentMaxStamina,message,playerPose,opponentPose,distance,Math.round(430*playerMovement*weaponMovement),Math.round(430*rivalMovement*weaponMovement),playerSkillActivated,opponentSkillActivated);}
    private static float clamp(float value,float min,float max){return Math.max(min,Math.min(max,value));}
}

package com.absuconnect.games.calls;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.absuconnect.games.backend.NativeSupabaseApi;
import org.json.JSONObject;

/** Handles notification-level decline/hang-up actions without exposing backend keys. */
public final class CallActionReceiver extends BroadcastReceiver {
    public static final String ACTION_DECLINE = "com.absuconnect.games.calls.DECLINE";
    public static final String ACTION_END = "com.absuconnect.games.calls.END";

    @Override public void onReceive(Context context, Intent intent) {
        String callId = intent == null ? null : intent.getStringExtra("call_id");
        if (callId == null || callId.isEmpty()) return;
        String targetStatus = ACTION_DECLINE.equals(intent.getAction()) ? "declined" : "ended";
        new Thread(() -> {
            try {
                new NativeSupabaseApi(context).rpc("set_call_session_status", new JSONObject()
                        .put("p_call_id", callId).put("p_status", targetStatus));
            } catch (Exception error) { Log.w("ABSU-CALL", "Notification call action could not be synchronized", error); }
            IncomingCallNotifications.cancel(context, callId);
            CallOngoingService.stop(context);
            if (ACTION_DECLINE.equals(intent.getAction())) {
                Intent main = new Intent(context, com.absuconnect.games.ui.MainActivity.class)
                        .putExtra("absu_open_page", "alerts").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(main);
            }
        }, "absu-call-notification-action").start();
    }
}

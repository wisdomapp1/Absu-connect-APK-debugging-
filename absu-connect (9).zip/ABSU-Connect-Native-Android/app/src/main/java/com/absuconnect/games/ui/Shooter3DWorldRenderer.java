package com.absuconnect.games.ui;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import com.absuconnect.games.action.ActionContentCatalog;
import com.absuconnect.games.action.ActionContentCatalog.ArenaSpec;
import com.absuconnect.games.action.ActionContentCatalog.CharacterSpec;
import com.absuconnect.games.action.ActionContentCatalog.Cover;
import com.absuconnect.games.action.ActionContentCatalog.SkinSpec;
import com.absuconnect.games.action.ActionContentCatalog.WeaponSpec;
import com.absuconnect.games.shooter.Shooter3DCamera;
import com.absuconnect.games.shooter.ShooterMatchModel;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Procedural low-poly 3D world and first-person weapon renderer; original assets only. */
final class Shooter3DWorldRenderer implements GLSurfaceView.Renderer {
    interface Host {void onSound(String cue);void onRoundOver(ShooterMatchModel.Result result);}
    private static final float RAD_TO_DEG=57.2957795f;
    private static final String VERTEX_SHADER=
            "uniform mat4 uMvp; uniform mat4 uModel; attribute vec3 aPosition; attribute vec3 aNormal; "+
            "varying vec3 vNormal; void main(){ gl_Position=uMvp*vec4(aPosition,1.0); "+
            "vNormal=mat3(uModel)*aNormal; }";
    private static final String FRAGMENT_SHADER=
            "precision mediump float; uniform vec4 uColor; varying vec3 vNormal; "+
            "void main(){ vec3 n=normalize(vNormal); vec3 l=normalize(vec3(-0.32,0.88,0.36)); "+
            "float light=0.48+0.52*max(dot(n,l),0.0); gl_FragColor=vec4(uColor.rgb*light,uColor.a); }";

    private final ShooterMatchModel match;
    private final Shooter3DCamera camera;
    private final Shooter3DGameView.InputState input;
    private final float[] projection=new float[16],view=new float[16],viewProjection=new float[16],modelMatrix=new float[16],mvp=new float[16];
    private FloatBuffer cubeVertices;
    private int program,positionHandle,normalHandle,mvpHandle,modelHandle,colorHandle;
    private int surfaceWidth=1,surfaceHeight=1;
    private long lastFrame,lastShotAt,jumpStart;
    private float recoil;
    private volatile boolean roundReported;
    private volatile Host host;

    Shooter3DWorldRenderer(ShooterMatchModel match,Shooter3DCamera camera,Shooter3DGameView.InputState input){
        this.match=match;this.camera=camera;this.input=input;
    }
    void setHost(Host host){this.host=host;}
    void resetRoundReported(){roundReported=false;lastShotAt=0;jumpStart=0;recoil=0;lastFrame=0;}

    @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){
        program=buildProgram(VERTEX_SHADER,FRAGMENT_SHADER);
        positionHandle=GLES20.glGetAttribLocation(program,"aPosition");
        normalHandle=GLES20.glGetAttribLocation(program,"aNormal");
        mvpHandle=GLES20.glGetUniformLocation(program,"uMvp");
        modelHandle=GLES20.glGetUniformLocation(program,"uModel");
        colorHandle=GLES20.glGetUniformLocation(program,"uColor");
        cubeVertices=createCube();
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthFunc(GLES20.GL_LEQUAL);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        GLES20.glClearColor(.04f,.075f,.09f,1f);
        lastFrame=System.currentTimeMillis();
    }
    @Override public void onSurfaceChanged(GL10 gl,int width,int height){
        surfaceWidth=Math.max(1,width);surfaceHeight=Math.max(1,height);
        GLES20.glViewport(0,0,surfaceWidth,surfaceHeight);
        float near=.12f,top=(float)(near*Math.tan(Math.toRadians(71.0)*.5)),right=top*surfaceWidth/surfaceHeight;
        Matrix.frustumM(projection,0,-right,right,-top,top,near,180f);
    }
    @Override public void onDrawFrame(GL10 gl){
        long now=System.currentTimeMillis();
        float dt=lastFrame==0?.016f:clamp((now-lastFrame)/1000f,0,.055f);lastFrame=now;
        ShooterMatchModel.Result before=match.snapshot();
        if(input.jumpRequested){input.jumpRequested=false;if(match.jump(now))notifySound("jump");}
        if(!before.matchOver){
            Shooter3DCamera.Vector2 step=camera.movement(input.strafe,input.forward);
            float scaledDt=dt*(input.sprinting?1.42f:1f);
            match.move(step.x,step.z,scaledDt);
            double yaw=camera.yaw();
            ShooterMatchModel.Result moved=match.snapshot();
            match.aimAt(moved.playerX+(float)Math.sin(yaw)*60f,moved.playerY-(float)Math.cos(yaw)*60f,camera.pitch());
            match.tick(now);
                if(input.fireHeld){if(match.fire(now)){lastShotAt=now;recoil=Math.min(.12f,recoil+.026f);notifySound("fire");}}
        } else if(input.fireHeld){input.fireHeld=false;}
        ShooterMatchModel.Result state=match.snapshot();
        if(state.matchOver&&!roundReported){roundReported=true;Host h=host;if(h!=null)h.onRoundOver(state);}
        renderWorld(state,now,dt);
    }

    private void renderWorld(ShooterMatchModel.Result state,long now,float dt){
        int clear=blend(match.arena().ground,0xff0b1820,.54f);
        GLES20.glClearColor(red(clear),green(clear),blue(clear),1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);
        bindCube();
        float moving=Math.min(1f,Math.abs(input.forward)+Math.abs(input.strafe));
        float walkBob=(float)Math.sin(now*.014f)*.028f*moving;
        float yaw=camera.yaw(),pitch=camera.pitch()+recoil,cp=(float)Math.cos(pitch);
        float eyeX=state.playerX,eyeY=1.66f+walkBob+state.jumpHeight,eyeZ=state.playerY;
        float dirX=(float)Math.sin(yaw)*cp,dirY=(float)Math.sin(pitch),dirZ=-(float)Math.cos(yaw)*cp;
        Matrix.setLookAtM(view,0,eyeX,eyeY,eyeZ,eyeX+dirX,eyeY+dirY,eyeZ+dirZ,0,1,0);
        Matrix.multiplyMM(viewProjection,0,projection,0,view,0);
        drawArena(state,now);
        for(int i=0;i<state.botX.length;i++)if(state.botHealth[i]>0)drawOperator(state,i,now);
        drawFirstPersonWeapon(state,now,dt);
    }
    private void drawArena(ShooterMatchModel.Result state,long now){
        ArenaSpec arena=match.arena();int ground=arena.ground,cover=arena.cover,accent=arena.accent;
        drawBox(50,-.24f,30,104,.48f,64,ground,0);
        int grid=blend(ground,accent,.20f),lane=blend(ground,accent,.34f);
        for(int x=0;x<=100;x+=10)drawBox(x,.014f,30,.045f,.018f,60,grid,0);
        for(int z=0;z<=60;z+=10)drawBox(50,.015f,z,100,.018f,.045f,grid,0);
        drawBox(50,.025f,30,94,.025f,.10f,lane,0);
        drawBox(50,.026f,30,.10f,.025f,54,lane,0);
        drawBox(50,.04f,2,102,2.9f,1.3f,cover,0);
        drawBox(50,.04f,58,102,2.9f,1.3f,cover,0);
        drawBox(1,.04f,30,1.3f,2.9f,58,cover,0);
        drawBox(99,.04f,30,1.3f,2.9f,58,cover,0);
        int facade=blend(cover,0xff102126,.50f);
        drawBox(50,7f,-7f,104,11f,5f,facade,0);
        drawBox(50,7f,67f,104,11f,5f,facade,0);
        drawBox(-7f,6f,30,5f,11f,68f,facade,0);
        drawBox(107f,6f,30,5f,11f,68f,facade,0);
        for(int x=9;x<=91;x+=16){
            drawBox(x,6.6f,-4.32f,8f,1.35f,.10f,accent,0);
            drawBox(x,6.6f,64.32f,8f,1.35f,.10f,accent,0);
            drawBox(-4.32f,6.6f,x*.60f, .10f,1.35f,8f,accent,0);
        }
        for(Cover c:arena.coverPieces){
            float width=c.right-c.left,depth=c.bottom-c.top,cx=(c.left+c.right)*.5f,cz=(c.top+c.bottom)*.5f;
            float h=(match.getMapIndex()==2||match.getMapIndex()==7)?1.35f:1.08f;
            drawBox(cx,h*.5f,cz,width,h,depth,cover,0);
            drawBox(cx,h+.035f,cz,width+.12f,.07f,depth+.12f,accent,0);
            drawBox(cx,h+.11f,cz,width*.58f,.045f,.06f,blend(accent,0xffffffff,.20f),0);
        }
        drawLandmark(match.getMapIndex(),cover,accent,now);
    }
    private void drawLandmark(int map,int cover,int accent,long now){
        int bright=blend(accent,0xffffffff,.20f),dark=blend(cover,0xff111e20,.24f);
        switch(map){
            case 0: // Glasscourt Walkways — glass fins and illuminated frame.
                for(int x=14;x<=86;x+=18){drawBox(x,3.2f,-1,.30f,6.4f,.30f,bright,0);drawBox(x,3.2f,61,.30f,6.4f,.30f,bright,0);}
                drawBox(50,6.5f,-1,74,.16f,.30f,dark,0);break;
            case 1: // Rainline Courtyard — covered commons canopy at the far approach.
                drawBox(50,5.8f,-4,65,.28f,22,dark,0);
                for(int x=20;x<=80;x+=30)for(int z:new int[]{-5,-14})drawBox(x,2.8f,z,.34f,5.6f,.34f,bright,0);
                break;
            case 2: // Old Stone Steps — broad stepped amphitheatre behind the arena.
            case 7: // Studio Steps — staggered arts-block risers.
                for(int i=0;i<5;i++){float z=-2-i*1.55f;float h=.45f+i*.42f;drawBox(50,h*.5f,z,82-i*7,h,1.9f,blend(cover,accent,i*.10f),0);}
                for(int x=25;x<=75;x+=25)drawBox(x,2.4f,-10,.25f,4.8f,.25f,bright,0);
                break;
            case 3: // Lantern Commons — garden columns and a light canopy.
                for(int x=13;x<=87;x+=18){drawBox(x,2.6f,-2,.42f,5.2f,.42f,dark,0);drawBox(x,5.3f,-2,1.1f,.16f,1.1f,bright,0);}
                drawBox(50,5.9f,-2,78,.16f,.30f,bright,0);break;
            case 4: // Canopy Bridge — high overhead canopy; support columns sit beyond the floor.
                drawBox(50,5.8f,30,64,.26f,58,dark,0);
                for(int x:new int[]{20,80})for(int z:new int[]{-1,61})drawBox(x,2.8f,z,.34f,5.6f,.34f,bright,0);
                drawBox(50,5.96f,30,64,.08f,.22f,bright,0);break;
            case 5: // Observatory Court — a distant beacon behind the arena boundary.
                drawBox(50,.22f,-5,14,.44f,2,dark,0);drawBox(50,.50f,-5,10,.18f,1.5f,bright,0);
                drawBox(50,3f,-7,.48f,5.8f,.48f,bright,0);drawBox(50,6f,-7,1.35f,.42f,1.35f,accent,0);
                break;
            case 6: // Echo Gardens — stylised trees outside the playable boundary.
                for(int x:new int[]{11,28,72,89})for(int z:new int[]{-1,61}){
                    drawBox(x,1.8f,z,.42f,3.6f,.42f,dark,0);drawBox(x,3.8f,z,2.2f,1.5f,2.2f,bright,now*.012f%360f);
                }
                break;
            default:
                drawBox(50,4.2f,-2,56,.22f,1.2f,bright,0);
        }
    }
    private void drawOperator(ShooterMatchModel.Result state,int index,long now){
        float x=state.botX[index],z=state.botY[index];
        float dx=state.playerX-x,dz=state.playerY-z;
        float yaw=(float)Math.atan2(dx,-dz),bob=(float)Math.sin(now*.008+index*1.7)*.035f;
        CharacterSpec profile=ActionContentCatalog.OPERATORS[(modelOperatorIndex()+index+1)%ActionContentCatalog.OPERATORS.length];
        int body=profile.primary,trim=profile.trim,shadow=blend(body,0xff10171b,.62f);
        drawLocalBox(x,z,yaw,0,1.02f+bob,0,.58f,.88f,.36f,body);
        drawLocalBox(x,z,yaw,0,1.76f+bob,0,.38f,.38f,.38f,blend(body,0xffd7c1a0,.42f));
        drawLocalBox(x,z,yaw,0,2.00f+bob,0,.43f,.15f,.43f,trim);
        drawLocalBox(x,z,yaw,-.40f,1.05f+bob,-.02f,.22f,.66f,.25f,body);
        drawLocalBox(x,z,yaw,.40f,1.05f+bob,-.02f,.22f,.66f,.25f,body);
        drawLocalBox(x,z,yaw,-.18f,.39f,.02f,.23f,.70f,.26f,shadow);
        drawLocalBox(x,z,yaw,.18f,.39f,.02f,.23f,.70f,.26f,shadow);
        drawLocalBox(x,z,yaw,0,1.23f+bob,-.36f,.16f,.12f,.74f,0xff252a29);
        drawLocalBox(x,z,yaw,0,1.23f+bob,-.72f,.22f,.13f,.18f,trim);
        drawLocalBox(x,z,yaw,0,2.20f,0,.78f,.065f,.06f,0xff132322);
        float fill=Math.max(.02f,state.botHealth[index]/78f);
        float facing=-yaw*RAD_TO_DEG;
        drawBox(x,2.40f,z,.88f,.10f,.035f,0xff172122,facing);
        drawLocalBox(x,z,yaw,-.44f+fill*.44f,2.40f,.008f,.88f*fill,.065f,.045f,0xff60dc94);
    }
    private void drawFirstPersonWeapon(ShooterMatchModel.Result state,long now,float dt){
        SkinSpec skin=ActionContentCatalog.SKINS[match.getSkinIndex()];
        WeaponSpec weapon=match.gun();
        float moving=(Math.abs(input.forward)+Math.abs(input.strafe))>0.12f?1f:0f;
        float sway=(float)Math.sin(now*.012)*.018f*moving;
        if(recoil>0){recoil=Math.max(0,recoil-dt*.65f);}
        Matrix.setLookAtM(view,0,0f,0f,0f,0f,0f,-1f,0f,1f,0f);
        Matrix.multiplyMM(viewProjection,0,projection,0,view,0);
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT);
        float width=weapon.type.contains("LMG")?.50f:weapon.type.contains("Shotgun")||weapon.type.contains("Scatter")?.43f:.34f;
        float barrel=weapon.type.contains("Marksman")||weapon.type.contains("Precision")?1.30f:weapon.type.contains("Shotgun")?1.06f:.78f;
        drawBox(.49f+sway,-.37f-recoil*.45f,-1.22f,width,.28f,.68f,0xff222b2d,0);
        drawBox(.49f+sway,-.36f-recoil*.45f,-1.52f,width*.72f,.16f,.38f,skin.primary,0);
        drawBox(.49f+sway,-.29f-recoil*.45f,-1.88f,.115f,.12f,barrel,0xff293134,0);
        drawBox(.49f+sway,-.30f-recoil*.45f,-1.88f-barrel*.52f,.19f,.15f,.10f,skin.trim,0);
        drawBox(.49f+sway,-.22f-recoil*.45f,-1.11f,.14f,.13f,.18f,skin.trim,0);
        drawBox(.37f+sway,-.62f-recoil*.25f,-1.00f,.17f,.39f,.22f,skin.primary,-8);
        drawBox(.67f+sway,-.56f-recoil*.25f,-.94f,.18f,.34f,.22f,blend(skin.primary,0xffd5b28e,.22f),-14);
        drawBox(.48f+sway,-.42f-recoil*.45f,-.86f,.50f,.23f,.38f,blend(skin.trim,0xff242b29,.48f),0);
        if(now-lastShotAt<95){
            drawBox(.49f+sway,-.29f,-1.88f-barrel-.14f,.34f,.25f,.28f,0xffffd47b,0);
            drawBox(.49f+sway,-.29f,-1.88f-barrel-.32f,.16f,.15f,.16f,0xfffff0b0,0);
        }
        // Restore the world camera for the next frame (matrices are recomputed each render).
    }
    private int modelOperatorIndex(){return match.getOperatorIndex();}
    private void drawLocalBox(float ox,float oz,float yaw,float lx,float y,float lz,float w,float h,float d,int color){
        float rotation=-yaw;
        float x=ox+(float)Math.cos(rotation)*lx+(float)Math.sin(rotation)*lz;
        float z=oz-(float)Math.sin(rotation)*lx+(float)Math.cos(rotation)*lz;
        drawBox(x,y,z,w,h,d,color,-yaw*RAD_TO_DEG);
    }
    private void drawBox(float x,float y,float z,float sx,float sy,float sz,int color,float rotateY){
        Matrix.setIdentityM(modelMatrix,0);
        Matrix.translateM(modelMatrix,0,x,y,z);
        if(rotateY!=0)Matrix.rotateM(modelMatrix,0,rotateY,0,1,0);
        Matrix.scaleM(modelMatrix,0,sx,sy,sz);
        Matrix.multiplyMM(mvp,0,viewProjection,0,modelMatrix,0);
        GLES20.glUniformMatrix4fv(mvpHandle,1,false,mvp,0);
        GLES20.glUniformMatrix4fv(modelHandle,1,false,modelMatrix,0);
        GLES20.glUniform4f(colorHandle,red(color),green(color),blue(color),1f);
        cubeVertices.position(0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);
    }
    private void bindCube(){
        cubeVertices.position(0);GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle,3,GLES20.GL_FLOAT,false,24,cubeVertices);
        cubeVertices.position(3);GLES20.glEnableVertexAttribArray(normalHandle);
        GLES20.glVertexAttribPointer(normalHandle,3,GLES20.GL_FLOAT,false,24,cubeVertices);
        cubeVertices.position(0);
    }
    private void notifySound(String cue){Host h=host;if(h!=null)h.onSound(cue);}

    private static FloatBuffer createCube(){
        float[] data=new float[36*6];int[] cursor={0};
        face(data,cursor,0,0,1,new float[][]{{-.5f,-.5f,.5f},{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f}});
        face(data,cursor,0,0,-1,new float[][]{{.5f,-.5f,-.5f},{-.5f,-.5f,-.5f},{-.5f,.5f,-.5f},{.5f,.5f,-.5f}});
        face(data,cursor,1,0,0,new float[][]{{.5f,-.5f,.5f},{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{.5f,.5f,.5f}});
        face(data,cursor,-1,0,0,new float[][]{{-.5f,-.5f,-.5f},{-.5f,-.5f,.5f},{-.5f,.5f,.5f},{-.5f,.5f,-.5f}});
        face(data,cursor,0,1,0,new float[][]{{-.5f,.5f,.5f},{.5f,.5f,.5f},{.5f,.5f,-.5f},{-.5f,.5f,-.5f}});
        face(data,cursor,0,-1,0,new float[][]{{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,-.5f,.5f},{-.5f,-.5f,.5f}});
        FloatBuffer buffer=ByteBuffer.allocateDirect(data.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();buffer.put(data).position(0);return buffer;
    }
    private static void face(float[] out,int[] cursor,float nx,float ny,float nz,float[][] points){
        int[] order={0,1,2,0,2,3};
        for(int index:order){float[] p=points[index];out[cursor[0]++]=p[0];out[cursor[0]++]=p[1];out[cursor[0]++]=p[2];out[cursor[0]++]=nx;out[cursor[0]++]=ny;out[cursor[0]++]=nz;}
    }
    private static int buildProgram(String vertex,String fragment){
        int vs=compile(GLES20.GL_VERTEX_SHADER,vertex),fs=compile(GLES20.GL_FRAGMENT_SHADER,fragment);
        int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,vs);GLES20.glAttachShader(p,fs);GLES20.glLinkProgram(p);
        int[] ok=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);
        if(ok[0]==0){String log=GLES20.glGetProgramInfoLog(p);GLES20.glDeleteProgram(p);throw new IllegalStateException("Fireline shader link failed: "+log);}
        GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);return p;
    }
    private static int compile(int type,String source){
        int shader=GLES20.glCreateShader(type);GLES20.glShaderSource(shader,source);GLES20.glCompileShader(shader);
        int[] ok=new int[1];GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,ok,0);
        if(ok[0]==0){String log=GLES20.glGetShaderInfoLog(shader);GLES20.glDeleteShader(shader);throw new IllegalStateException("Fireline shader compile failed: "+log);}
        return shader;
    }
    private static int blend(int from,int to,float amount){
        float a=clamp(amount,0,1);int r=mix((from>>16)&255,(to>>16)&255,a),g=mix((from>>8)&255,(to>>8)&255,a),b=mix(from&255,to&255,a);
        return 0xff000000|(r<<16)|(g<<8)|b;
    }
    private static int mix(int a,int b,float t){return Math.max(0,Math.min(255,Math.round(a+(b-a)*t)));}
    private static float red(int color){return((color>>16)&255)/255f;}
    private static float green(int color){return((color>>8)&255)/255f;}
    private static float blue(int color){return(color&255)/255f;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
}

package com.absuconnect.games.push;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.absuconnect.games.R;
import com.absuconnect.games.auth.AuthSession;
import com.absuconnect.games.auth.AuthSessionStore;
import com.absuconnect.games.backend.NativeSupabaseApi;
import com.absuconnect.games.ui.MainActivity;
import com.absuconnect.games.ui.CallActivity;
import com.absuconnect.games.calls.IncomingCallNotifications;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.time.Instant;
import org.json.JSONObject;

/** Native FCM receiver. Firebase delivery is enabled after google-services.json is added. */
public final class AbsuFirebaseMessagingService extends FirebaseMessagingService {
    private static final String PREFS = "absu_native_push";
    private static final String TOKEN_KEY = "pending_fcm_token";

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(TOKEN_KEY, token).putString("registered_fcm_token",token).apply();
        registerTokenForCurrentUser(token);
    }

    private void registerTokenForCurrentUser(String token) {
        AuthSession session = AuthSessionStore.load(this);
        if (session == null || token == null || token.isEmpty()) return;
        new Thread(() -> {
            try {
                new NativeSupabaseApi(this).postArray(
                        "device_push_tokens?on_conflict=user_id,token",
                        new JSONObject().put("user_id", session.userId).put("token", token)
                                .put("platform", "android").put("updated_at", Instant.now().toString()),
                        "resolution=merge-duplicates,return=minimal");
            } catch (Exception ex) {
                android.util.Log.w("ABSU-FCM", "Could not sync the refreshed device token yet.", ex);
            }
        }, "absu-fcm-token-sync").start();
    }

    @Override public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        String callType = remoteMessage.getData().get("type");
        if ("call_invite".equals(callType)) {
            String callId = remoteMessage.getData().get("call_id");
            String mediaType = remoteMessage.getData().get("call_type");
            String callerName = remoteMessage.getData().get("caller_name");
            if (callId == null || callId.isEmpty()) return;
            if (MainActivity.isForeground) {
                Intent call = new Intent(this, CallActivity.class)
                        .putExtra("call_id", callId).putExtra("call_type", "video".equals(mediaType) ? "video" : "audio")
                        .putExtra("incoming", true).putExtra("peer_name", callerName)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(call);
            } else {
                IncomingCallNotifications.show(this, callId, mediaType, callerName);
            }
            return;
        }
        // The in-app Supabase Realtime listener handles foreground non-call alerts.
        if (MainActivity.isForeground) return;

        String title = remoteMessage.getNotification() != null
                ? remoteMessage.getNotification().getTitle() : remoteMessage.getData().get("title");
        String body = remoteMessage.getNotification() != null
                ? remoteMessage.getNotification().getBody() : remoteMessage.getData().get("body");
        if (title == null || title.trim().isEmpty()) title = "ABSU Connect";
        if (body == null) body = "You have a new notification.";
        String type = remoteMessage.getData().get("type");
        String entityType = remoteMessage.getData().get("entity_type");
        boolean isDiscovery = "welcome_discovery".equals(type) || "discovery_suggestion".equals(type) || "discovery_reminder".equals(type)
                || "discovery_welcome".equals(entityType) || "discovery_reminder".equals(entityType) || "discovery".equals(entityType);
        String target = isDiscovery ? "friends"
                : "message".equals(type) ? "messages"
                : ("friend_request".equals(type) || "friend_accepted".equals(type)) ? "friends" : "alerts";
        String subTab = isDiscovery ? "discover" : null;
        showNotification(title, body, remoteMessage.getData().get("notification_id"), target, subTab);
    }

    private void showNotification(String title, String body, String notificationId, String target, String friendTab) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            NotificationChannel channel = new NotificationChannel(
                    "absu_notifications", "ABSU Connect Notifications", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Messages, friend activity and campus alerts");
            channel.enableVibration(true);
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class)
                .putExtra("absu_open_page", target)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (friendTab != null) open.putExtra("absu_friend_tab", friendTab);
        if (notificationId != null) open.putExtra("notification_id", notificationId);
        PendingIntent pending = PendingIntent.getActivity(this,
                notificationId == null ? (int) System.currentTimeMillis() : notificationId.hashCode(),
                open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int id = notificationId == null ? (int) System.currentTimeMillis() : notificationId.hashCode();
        androidx.core.app.NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "absu_notifications")
                .setSmallIcon(R.drawable.ic_absu_logo)
                .setContentTitle(title).setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true).setContentIntent(pending);
        try { NotificationManagerCompat.from(this).notify(id, builder.build()); }
        catch (SecurityException denied) { android.util.Log.i("ABSU-FCM", "Notifications are not permitted by Android settings."); }
    }
}

package com.absuconnect.games.auth;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

public final class AuthSessionStore {
    private static final String PREFS = "absu_game_auth";
    private AuthSessionStore() {}

    private static SharedPreferences preferences(Context context) throws Exception {
        MasterKey masterKey = new MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
        return EncryptedSharedPreferences.create(context, PREFS, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
    }

    public static void save(Context context, AuthSession session) throws Exception {
        preferences(context).edit()
                .putString("access", session.accessToken)
                .putString("refresh", session.refreshToken)
                .putString("user", session.userId)
                .putString("email", session.email)
                .putLong("expires", session.expiresAtEpochSeconds)
                .apply();
    }

    public static AuthSession load(Context context) {
        try {
            SharedPreferences p = preferences(context);
            String access = p.getString("access", null);
            String refresh = p.getString("refresh", null);
            String user = p.getString("user", null);
            if (access == null || refresh == null || user == null) return null;
            return new AuthSession(access, refresh, user, p.getString("email", ""), p.getLong("expires", 0L));
        } catch (Exception ignored) {
            return null;
        }
    }

    public static void clear(Context context) {
        try { preferences(context).edit().clear().apply(); } catch (Exception ignored) { }
    }
}

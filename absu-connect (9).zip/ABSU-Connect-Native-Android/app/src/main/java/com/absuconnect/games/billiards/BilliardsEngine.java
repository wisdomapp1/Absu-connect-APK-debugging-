package com.absuconnect.games.billiards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A lightweight original 2D pool model: ball collision, cushions, pockets, turns and 8-ball win rules. */
public final class BilliardsEngine {
    public static final float WIDTH=1000f, HEIGHT=500f, BALL_R=13f;
    public static final class Ball {
        public final int number;
        public float x,y,vx,vy;
        public boolean active=true;
        Ball(int number,float x,float y){this.number=number;this.x=x;this.y=y;}
        public boolean isCue(){return number==0;}
        public boolean isEight(){return number==8;}
        public boolean isStripe(){return number>=9;}
    }
    public static final class ShotResult {
        public final String message;
        public final boolean settled, gameOver;
        ShotResult(String message,boolean settled,boolean gameOver){this.message=message;this.settled=settled;this.gameOver=gameOver;}
    }
    private final List<Ball> balls=new ArrayList<>();
    private final List<Integer> pottedThisTurn=new ArrayList<>();
    private final int[] groups={-1,-1}; // 0 solids, 1 stripes
    private int currentPlayer, winner=-1, firstHit=-1;
    private boolean inShot, cueBallInHand;
    private String message="Player 1 breaks. Drag toward the shot and release.";

    public BilliardsEngine(){reset();}
    public void reset(){
        balls.clear(); pottedThisTurn.clear(); groups[0]=groups[1]=-1; currentPlayer=0; winner=-1; firstHit=-1; inShot=false; cueBallInHand=false;
        balls.add(new Ball(0,250,250));
        // Standard triangle rack, deliberately original geometry and clean colors.
        int[][] rows={{1},{2,8},{9,3,10},{4,11,5,12},{13,6,14,7,15}};
        float baseX=690f, spacing=BALL_R*2.02f;
        for(int row=0;row<rows.length;row++){
            float x=baseX+row*spacing;
            float y=HEIGHT/2f-row*BALL_R + (row==0?0:0);
            for(int col=0;col<rows[row].length;col++) balls.add(new Ball(rows[row][col],x,y+col*spacing));
        }
        message="Player 1 breaks. Touch a direction on the table and release to shoot.";
    }
    public List<Ball> balls(){return Collections.unmodifiableList(balls);}
    public int currentPlayer(){return currentPlayer;}
    public int winner(){return winner;}
    public boolean isGameOver(){return winner>=0;}
    public boolean isMoving(){return inShot;}
    public boolean needsCueBallPlacement(){return cueBallInHand;}
    public int groupFor(int player){return groups[player];}
    public String groupLabel(int player){return groups[player]<0?"Open table":groups[player]==0?"Solids":"Stripes";}
    public String message(){return message;}
    public Ball cueBall(){return balls.get(0);}
    public Ball ball(int number){for(Ball b:balls)if(b.number==number)return b;return null;}

    /** Shoot in a direction vector with a normalized power range 0..1. */
    public boolean shoot(float directionX,float directionY,float power){
        if(inShot||winner>=0||cueBallInHand)return false;
        Ball cue=cueBall(); if(!cue.active)return false;
        float len=(float)Math.hypot(directionX,directionY); if(len<0.001f)return false;
        float strength=220f+Math.max(0,Math.min(1,power))*900f;
        cue.vx=directionX/len*strength; cue.vy=directionY/len*strength;
        pottedThisTurn.clear(); firstHit=-1; inShot=true;
        message="Player "+(currentPlayer+1)+" is shooting.";
        return true;
    }
    /** Advance physics. Call around 60 times per second; collisions are resolved with substeps. */
    public ShotResult update(float elapsedSeconds){
        if(!inShot)return new ShotResult(message,true,winner>=0);
        float remaining=Math.max(0,Math.min(elapsedSeconds,0.05f));
        int steps=Math.max(1,(int)Math.ceil(remaining/0.008f));
        float dt=remaining/steps;
        for(int step=0;step<steps;step++){
            for(Ball b:balls)if(b.active){b.x+=b.vx*dt;b.y+=b.vy*dt;}
            resolveCushions();
            resolveBallCollisions();
            pocketBalls();
            applyFriction(dt);
        }
        if(!anyMoving()){
            for(Ball b:balls){if(Math.abs(b.vx)<4)b.vx=0;if(Math.abs(b.vy)<4)b.vy=0;}
            inShot=false;
            finishTurn();
            return new ShotResult(message,true,winner>=0);
        }
        return new ShotResult(message,false,winner>=0);
    }
    private void resolveCushions(){
        for(Ball b:balls)if(b.active){
            if(b.x<62+BALL_R){b.x=62+BALL_R;b.vx=Math.abs(b.vx)*0.88f;}
            if(b.x>WIDTH-62-BALL_R){b.x=WIDTH-62-BALL_R;b.vx=-Math.abs(b.vx)*0.88f;}
            if(b.y<62+BALL_R){b.y=62+BALL_R;b.vy=Math.abs(b.vy)*0.88f;}
            if(b.y>HEIGHT-62-BALL_R){b.y=HEIGHT-62-BALL_R;b.vy=-Math.abs(b.vy)*0.88f;}
        }
    }
    private void resolveBallCollisions(){
        for(int i=0;i<balls.size();i++){
            Ball a=balls.get(i); if(!a.active)continue;
            for(int j=i+1;j<balls.size();j++){
                Ball b=balls.get(j);if(!b.active)continue;
                float dx=b.x-a.x,dy=b.y-a.y,dist2=dx*dx+dy*dy,diam=BALL_R*2;
                if(dist2>=diam*diam||dist2<0.001f)continue;
                float dist=(float)Math.sqrt(dist2),nx=dx/dist,ny=dy/dist;
                float overlap=diam-dist;
                a.x-=nx*overlap/2;a.y-=ny*overlap/2;b.x+=nx*overlap/2;b.y+=ny*overlap/2;
                float rel=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny;
                if(rel<0){float impulse=-(1.94f)*rel/2f;a.vx-=impulse*nx;a.vy-=impulse*ny;b.vx+=impulse*nx;b.vy+=impulse*ny;}
                if((a.isCue()||b.isCue())&&firstHit<0)firstHit=a.isCue()?b.number:a.number;
            }
        }
    }
    private void pocketBalls(){
        float[][] pockets={{62,62},{WIDTH/2,58},{WIDTH-62,62},{62,HEIGHT-62},{WIDTH/2,HEIGHT-58},{WIDTH-62,HEIGHT-62}};
        for(Ball b:balls)if(b.active){
            for(float[] p:pockets){float dx=b.x-p[0],dy=b.y-p[1];if(dx*dx+dy*dy<31*31){
                b.active=false;b.vx=0;b.vy=0;if(b.isCue())cueBallInHand=true;else pottedThisTurn.add(b.number);break;
            }}
        }
    }
    private void applyFriction(float dt){
        float drag=(float)Math.pow(0.982,dt*60);
        for(Ball b:balls)if(b.active){b.vx*=drag;b.vy*=drag;if(Math.hypot(b.vx,b.vy)<5){b.vx=0;b.vy=0;}}
    }
    private boolean anyMoving(){for(Ball b:balls)if(b.active&&(Math.abs(b.vx)>0.5f||Math.abs(b.vy)>0.5f))return true;return false;}
    private void finishTurn(){
        boolean foul=cueBallInHand||firstHit<0||!legalFirstHit(firstHit);
        boolean eightPocketed=pottedThisTurn.contains(8);
        int shooter=currentPlayer;
        if(eightPocketed){
            boolean cleared=groups[shooter]>=0&&groupCleared(shooter);
            winner=foul||!cleared?1-shooter:shooter;
            message=(winner==shooter?"Eight ball legally pocketed. You win!":"Eight ball was pocketed too early or on a foul. Player "+(winner+1)+" wins.");
            return;
        }
        if(foul){
            currentPlayer=1-shooter;
            if(cueBallInHand)message="Foul. Opponent has ball in hand: tap the table to place the cue ball.";
            else message="Foul: no legal first contact. Player "+(currentPlayer+1)+" shoots next.";
            cueBallInHand=true;
            return;
        }
        if(groups[shooter]<0){
            for(int n:pottedThisTurn)if(n!=8){groups[shooter]=n<=7?0:1;groups[1-shooter]=1-groups[shooter];break;}
        }
        boolean pottedOwn=false;
        for(int n:pottedThisTurn)if(n!=8&&((groups[shooter]==0&&n<=7)||(groups[shooter]==1&&n>=9)))pottedOwn=true;
        if(pottedOwn){message="Good shot. Player "+(shooter+1)+" keeps the table.";}
        else {currentPlayer=1-shooter;message=pottedThisTurn.isEmpty()?"No ball pocketed. Player "+(currentPlayer+1)+" shoots next.":"Turn passes. Player "+(currentPlayer+1)+" shoots next.";}
    }
    private boolean legalFirstHit(int number){
        if(number==8)return groups[currentPlayer]>=0&&groupCleared(currentPlayer);
        int group=groups[currentPlayer];
        return group<0||(group==0?number<=7:number>=9);
    }
    private boolean groupCleared(int player){
        int group=groups[player];if(group<0)return false;
        for(Ball b:balls)if(b.active&&!b.isCue()&&!b.isEight()&&(group==0?b.number<=7:b.number>=9))return false;
        return true;
    }
    /** Place the cue after a scratch. Illegal positions are rejected. */
    public boolean placeCueBall(float x,float y){
        if(!cueBallInHand)return false;
        float px=Math.max(62+BALL_R,Math.min(WIDTH-62-BALL_R,x));
        float py=Math.max(62+BALL_R,Math.min(HEIGHT-62-BALL_R,y));
        for(Ball b:balls)if(b.active&&!b.isCue()&&Math.hypot(px-b.x,py-b.y)<BALL_R*2+1)return false;
        Ball cue=cueBall();cue.x=px;cue.y=py;cue.active=true;cue.vx=cue.vy=0;cueBallInHand=false;
        message="Cue ball placed. Player "+(currentPlayer+1)+" may shoot.";return true;
    }
    /** Basic deterministic opponent shot used only in local-vs-CPU mode. */
    public boolean shootCpu(){
        if(currentPlayer!=1||inShot||cueBallInHand||winner>=0)return false;
        Ball cue=cueBall(),target=null;float best=Float.MAX_VALUE;
        for(Ball b:balls)if(b.active&&!b.isCue()&&!b.isEight()&&(groups[1]<0||(groups[1]==0?b.number<=7:b.number>=9))){
            float d=(b.x-cue.x)*(b.x-cue.x)+(b.y-cue.y)*(b.y-cue.y);if(d<best){best=d;target=b;}
        }
        if(target==null&&groups[1]>=0&&groupCleared(1))target=ball(8);
        if(target==null||!target.active)return false;
        float dx=target.x-cue.x,dy=target.y-cue.y;
        return shoot(dx,dy,0.48f);
    }
}

package com.absuconnect.games.ludo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Deterministic 4-seat Ludo rules model; rendering and dice randomness stay outside the engine. */
public final class LudoEngine {
    public static final int PLAYERS = 4;
    public static final int TOKENS_PER_PLAYER = 4;
    public static final int TRACK_LENGTH = 52;
    public static final int FINISH_PROGRESS = 57;

    public static final class Rules {
        public final boolean bonusRollOnSix;
        public final boolean bonusRollOnCapture;
        public final boolean threeSixesForfeit;
        private final boolean[] safeSquares;

        public Rules(boolean bonusRollOnSix, boolean bonusRollOnCapture,
                     boolean threeSixesForfeit, boolean[] safeSquares) {
            if (safeSquares == null || safeSquares.length != TRACK_LENGTH) {
                throw new IllegalArgumentException("safeSquares must contain 52 entries");
            }
            this.bonusRollOnSix = bonusRollOnSix;
            this.bonusRollOnCapture = bonusRollOnCapture;
            this.threeSixesForfeit = threeSixesForfeit;
            this.safeSquares = Arrays.copyOf(safeSquares, safeSquares.length);
        }

        public static Rules campusVariant() {
            boolean[] safe = new boolean[TRACK_LENGTH];
            int[] indices = {0, 8, 13, 21, 26, 34, 39, 47};
            for (int index : indices) safe[index] = true;
            return new Rules(true, true, true, safe);
        }

        public static Rules classicNoCaptureBonus() {
            Rules campus = campusVariant();
            return new Rules(true, false, true, campus.safeSquares);
        }

        boolean isSafe(int trackIndex) { return safeSquares[Math.floorMod(trackIndex, TRACK_LENGTH)]; }
    }

    public static final class MoveResult {
        public final int player;
        public final int token;
        public final boolean captured;
        public final boolean finishedToken;
        public final boolean gameWon;
        public final boolean extraTurn;
        public final int nextPlayer;
        public final int fromProgress;
        public final int toProgress;
        public final int capturedPlayer;
        public final int capturedToken;

        private MoveResult(int player, int token, boolean captured, boolean finishedToken,
                           boolean gameWon, boolean extraTurn, int nextPlayer, int fromProgress,
                           int toProgress, int capturedPlayer, int capturedToken) {
            this.player = player;
            this.token = token;
            this.captured = captured;
            this.finishedToken = finishedToken;
            this.gameWon = gameWon;
            this.extraTurn = extraTurn;
            this.nextPlayer = nextPlayer;
            this.fromProgress = fromProgress;
            this.toProgress = toProgress;
            this.capturedPlayer = capturedPlayer;
            this.capturedToken = capturedToken;
        }
    }

    private final Rules rules;
    private final int[][] progress = new int[PLAYERS][TOKENS_PER_PLAYER]; // -1=yard, 0..56=route, 57=home
    private int currentPlayer;
    private int dieValue;
    private int consecutiveSixes;
    private int winner = -1;
    private int lastCapturedPlayer = -1;

    public LudoEngine(Rules rules) {
        if (rules == null) throw new IllegalArgumentException("rules are required");
        this.rules = rules;
        for (int[] row : progress) Arrays.fill(row, -1);
    }

    public int currentPlayer() { return currentPlayer; }
    public int dieValue() { return dieValue; }
    public int winner() { return winner; }
    public boolean isFinished() { return winner >= 0; }
    public int lastCapturedPlayer() { return lastCapturedPlayer; }
    public int progressOf(int player, int token) { checkIndex(player, token); return progress[player][token]; }
    public int finishedCount(int player) {
        checkPlayer(player);
        int count = 0;
        for (int value : progress[player]) if (value == FINISH_PROGRESS) count++;
        return count;
    }

    /** Apply a die value supplied by a trusted local dice source. Returns false when not rollable. */
    public boolean roll(int value) {
        if (isFinished() || dieValue != 0 || value < 1 || value > 6) return false;
        lastCapturedPlayer = -1;
        if (value == 6 && rules.threeSixesForfeit && consecutiveSixes == 2) {
            consecutiveSixes = 0;
            advancePlayer();
            return true;
        }
        consecutiveSixes = value == 6 ? consecutiveSixes + 1 : 0;
        dieValue = value;
        if (legalTokens().isEmpty()) {
            boolean extra = value == 6 && rules.bonusRollOnSix;
            if (!extra) advancePlayer();
            else dieValue = 0;
        }
        return true;
    }

    public List<Integer> legalTokens() {
        if (isFinished() || dieValue == 0) return Collections.emptyList();
        List<Integer> legal = new ArrayList<>();
        for (int token = 0; token < TOKENS_PER_PLAYER; token++) {
            int at = progress[currentPlayer][token];
            if (at == -1) {
                if (dieValue == 6 && !crossesBlockade(currentPlayer, -1, 0)) legal.add(token);
            } else if (at < FINISH_PROGRESS && at + dieValue <= FINISH_PROGRESS
                    && !crossesBlockade(currentPlayer, at, at + dieValue)) {
                legal.add(token);
            }
        }
        return legal;
    }

    public MoveResult move(int token) {
        if (dieValue == 0 || isFinished() || !legalTokens().contains(token)) {
            throw new IllegalStateException("Token is not a legal move");
        }
        int player = currentPlayer;
        int rolled = dieValue;
        int before = progress[player][token];
        progress[player][token] = before == -1 ? 0 : before + rolled;
        boolean finishedToken = progress[player][token] == FINISH_PROGRESS;
        int capturedCode = captureAt(player, progress[player][token]);
        lastCapturedPlayer = capturedCode < 0 ? -1 : capturedCode / TOKENS_PER_PLAYER;
        int capturedToken = capturedCode < 0 ? -1 : capturedCode % TOKENS_PER_PLAYER;
        boolean won = finishedCount(player) == TOKENS_PER_PLAYER;
        if (won) winner = player;
        boolean bonusSix = rolled == 6 && rules.bonusRollOnSix;
        boolean bonusCapture = lastCapturedPlayer >= 0 && rules.bonusRollOnCapture;
        boolean extraTurn = (bonusSix || bonusCapture) && !won;
        dieValue = 0;
        if (!extraTurn && !won) advancePlayer();
        return new MoveResult(player, token, lastCapturedPlayer >= 0, finishedToken, won, extraTurn,
                currentPlayer, before, progress[player][token], lastCapturedPlayer, capturedToken);
    }

    /** Opponents stacked two deep form a blockade; a move cannot land on or pass it. */
    private boolean crossesBlockade(int player, int fromProgress, int toProgress) {
        int first = fromProgress < 0 ? 0 : fromProgress + 1;
        for (int route = first; route <= toProgress && route < TRACK_LENGTH; route++) {
            int square = Math.floorMod(startIndex(player) + route, TRACK_LENGTH);
            for (int opponent = 0; opponent < PLAYERS; opponent++) {
                if (opponent == player) continue;
                int stack = 0;
                for (int token = 0; token < TOKENS_PER_PLAYER; token++) {
                    int at = progress[opponent][token];
                    if (at >= 0 && at < TRACK_LENGTH
                            && Math.floorMod(startIndex(opponent) + at, TRACK_LENGTH) == square) stack++;
                }
                if (stack >= 2) return true;
            }
        }
        return false;
    }

    private int captureAt(int player, int tokenProgress) {
        if (tokenProgress < 0 || tokenProgress >= TRACK_LENGTH) return -1;
        int trackIndex = Math.floorMod(startIndex(player) + tokenProgress, TRACK_LENGTH);
        if (rules.isSafe(trackIndex)) return -1;
        for (int opponent = 0; opponent < PLAYERS; opponent++) {
            if (opponent == player) continue;
            for (int other = 0; other < TOKENS_PER_PLAYER; other++) {
                int otherProgress = progress[opponent][other];
                if (otherProgress >= 0 && otherProgress < TRACK_LENGTH
                        && Math.floorMod(startIndex(opponent) + otherProgress, TRACK_LENGTH) == trackIndex) {
                    progress[opponent][other] = -1;
                    return opponent * TOKENS_PER_PLAYER + other;
                }
            }
        }
        return -1;
    }

    public static int startIndex(int player) {
        checkPlayer(player);
        return player * 13;
    }

    /** Track coordinate 0..51 for a token; returns -1 for yard/home lane/finished. */
    public int trackIndex(int player, int token) {
        checkIndex(player, token);
        int at = progress[player][token];
        return at >= 0 && at < TRACK_LENGTH ? Math.floorMod(startIndex(player) + at, TRACK_LENGTH) : -1;
    }

    private void advancePlayer() {
        dieValue = 0;
        currentPlayer = (currentPlayer + 1) % PLAYERS;
    }

    private static void checkIndex(int player, int token) {
        checkPlayer(player);
        if (token < 0 || token >= TOKENS_PER_PLAYER) throw new IndexOutOfBoundsException("token");
    }

    private static void checkPlayer(int player) {
        if (player < 0 || player >= PLAYERS) throw new IndexOutOfBoundsException("player");
    }
}

package com.absuconnect.games.ui;

import android.app.AlertDialog;
import android.media.ToneGenerator;
import android.content.Intent;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.action.ActionContentCatalog;
import com.absuconnect.games.action.LocalGameProgression;
import com.absuconnect.games.action.LocalGameProgressStore;
import com.absuconnect.games.action.ActionContentCatalog.ArenaSpec;
import com.absuconnect.games.action.ActionContentCatalog.CharacterSpec;
import com.absuconnect.games.action.ActionContentCatalog.SkillSpec;
import com.absuconnect.games.action.ActionContentCatalog.SkinSpec;
import com.absuconnect.games.action.ActionContentCatalog.WeaponSpec;
import com.absuconnect.games.fighter.FighterCombatModel;
import com.absuconnect.games.fighter.FighterSceneRenderer;

/** Original procedural-3D campus sparring scene. Characters, gear and palettes are data-driven placeholders. */
public final class FighterActivity extends AppCompatActivity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final FighterCombatModel model=new FighterCombatModel();
    private FighterSceneRenderer renderer;
    private GLSurfaceView surface;
    private ProgressBar playerHp,enemyHp,stamina,opponentStaminaBar;
    private TextView message,heading;
    private LinearLayout opponentControls;
    private GameSound sound;
    private android.widget.Button soundButton;
    private boolean localDuel,shopOpened,roundRewarded;
    private int fighterIndex,rivalIndex=1,weaponIndex,skillIndex,arenaIndex,skinIndex;
    private final Runnable tick=new Runnable(){@Override public void run(){FighterCombatModel.Result r=model.tick(System.currentTimeMillis());render(r);handler.postDelayed(this,120);}};
    @Override protected void onCreate(Bundle state){super.onCreate(state);sound=new GameSound(this);build();chooseMode();}
    private void build(){
        FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(0xff11191a);
        surface=new GLSurfaceView(this);surface.setEGLContextClientVersion(2);renderer=new FighterSceneRenderer();surface.setRenderer(renderer);surface.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);frame.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout overlay=UiKit.vertical(this);overlay.setPadding(UiKit.dp(this,18),UiKit.dp(this,10),UiKit.dp(this,18),UiKit.dp(this,10));frame.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=UiKit.row(this);android.widget.Button back=UiKit.button(this,"‹  Game Center",false);top.addView(back);back.setOnClickListener(v->finish());
        heading=UiKit.text(this,"CAMPUS DUEL  /  3D PRACTICE",11,0xffffffff,true);heading.setGravity(Gravity.CENTER);top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        soundButton=UiKit.button(this,sound.isMuted()?"Sound off":"Sound on",false);top.addView(soundButton);soundButton.setOnClickListener(v->{boolean muted=sound.toggleMuted();soundButton.setText(muted?"Sound off":"Sound on");if(!muted)sound.play(ToneGenerator.TONE_PROP_ACK,90);});
        android.widget.Button loadout=UiKit.button(this,"Loadout",false);top.addView(loadout);loadout.setOnClickListener(v->chooseLoadout());
        android.widget.Button career=UiKit.button(this,"Career",false);top.addView(career);career.setOnClickListener(v->openCareer());
        android.widget.Button reset=UiKit.button(this,"Reset",false);top.addView(reset);reset.setOnClickListener(v->{model.reset();roundRewarded=false;render(model.snapshot());});overlay.addView(top);
        LinearLayout bars=UiKit.row(this);bars.setPadding(UiKit.dp(this,6),UiKit.dp(this,7),UiKit.dp(this,6),0);
        playerHp=bar(0xff4ca894);bars.addView(playerHp,new LinearLayout.LayoutParams(0,UiKit.dp(this,10),1));
        TextView vs=UiKit.text(this,"   VS   ",11,0xffe3e9e4,true);bars.addView(vs);
        enemyHp=bar(0xffd18a5d);bars.addView(enemyHp,new LinearLayout.LayoutParams(0,UiKit.dp(this,10),1));overlay.addView(bars);
        LinearLayout staminaBars=UiKit.row(this);staminaBars.setPadding(UiKit.dp(this,6),UiKit.dp(this,7),UiKit.dp(this,6),0);
        stamina=bar(0xffe0b75e);staminaBars.addView(stamina,new LinearLayout.LayoutParams(0,UiKit.dp(this,8),1));
        TextView staminaVs=UiKit.text(this,"   ·   ",10,0xffe3e9e4,true);staminaBars.addView(staminaVs);
        opponentStaminaBar=bar(0xffdba968);staminaBars.addView(opponentStaminaBar,new LinearLayout.LayoutParams(0,UiKit.dp(this,8),1));opponentStaminaBar.setVisibility(android.view.View.GONE);overlay.addView(staminaBars);
        android.widget.Space space=new android.widget.Space(this);overlay.addView(space,new LinearLayout.LayoutParams(1,0,1));
        message=UiKit.text(this,"",13,0xffffffff,true);message.setGravity(Gravity.CENTER);message.setBackground(UiKit.rounded(0xb0212c2d,this));message.setPadding(UiKit.dp(this,14),UiKit.dp(this,8),UiKit.dp(this,14),UiKit.dp(this,8));overlay.addView(message,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout p1=UiKit.row(this);LinearLayout.LayoutParams controlParams=new LinearLayout.LayoutParams(-1,UiKit.dp(this,45));controlParams.topMargin=UiKit.dp(this,7);overlay.addView(p1,controlParams);addControlSet(p1,false);
        opponentControls=UiKit.row(this);LinearLayout.LayoutParams p2Params=new LinearLayout.LayoutParams(-1,UiKit.dp(this,45));p2Params.topMargin=UiKit.dp(this,4);overlay.addView(opponentControls,p2Params);addControlSet(opponentControls,true);opponentControls.setVisibility(android.view.View.GONE);
        setContentView(frame);applyLoadout();render(model.snapshot());
    }
    private void addControlSet(LinearLayout row,boolean opponent){
        String prefix=opponent?"P2 ":"";
        addButton(row,prefix+"Strike",!opponent,()->action(opponent,FighterCombatModel.Action.LIGHT));
        addButton(row,prefix+"Power",false,()->action(opponent,FighterCombatModel.Action.HEAVY));
        android.widget.Button guard=addButton(row,prefix+"Guard",false,null);guard.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){action(opponent,FighterCombatModel.Action.GUARD);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){action(opponent,FighterCombatModel.Action.RELEASE_GUARD);return true;}return false;});
        addButton(row,prefix+"Step",false,()->action(opponent,FighterCombatModel.Action.DODGE));
        addButton(row,prefix+"IN",false,()->move(opponent,true));
        addButton(row,prefix+"OUT",false,()->move(opponent,false));
        addButton(row,prefix+"Skill",false,()->useSkill(opponent));
    }
    private void chooseMode(){
        String[] choices={"Solo practice vs CPU","Two-player local duel"};
        new AlertDialog.Builder(this).setTitle("Campus Duel · original 3D sparring")
                .setMessage("Move IN to close distance, OUT to reset spacing, then strike, guard or evade. CPU sparring telegraphs counters. Local 1v1 is same-device only; the 3D fighters remain procedural low-poly models.")
                .setItems(choices,(d,w)->{localDuel=w==1;model.setLocalDuel(localDuel);opponentControls.setVisibility(localDuel?android.view.View.VISIBLE:android.view.View.GONE);opponentStaminaBar.setVisibility(localDuel?android.view.View.VISIBLE:android.view.View.GONE);chooseLoadout();}).setCancelable(false).show();
    }
    private void chooseLoadout(){
        int rank=LocalGameProgressStore.load(this).rank();choose("Choose Player 1 character",ActionContentCatalog.namesAtRank(ActionContentCatalog.FIGHTERS,rank),fighterIndex,v->{fighterIndex=v;chooseRival();});
    }
    private void chooseRival(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose sparring partner / Player 2",ActionContentCatalog.namesAtRank(ActionContentCatalog.FIGHTERS,rank),rivalIndex,v->{rivalIndex=v;chooseWeapon();});}
    private void chooseWeapon(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose a melee training weapon",ActionContentCatalog.namesAtRank(ActionContentCatalog.FIGHTING_WEAPONS,rank),weaponIndex,v->{weaponIndex=v;chooseSkill();});}
    private void chooseSkill(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose a combat skill",ActionContentCatalog.namesAtRank(ActionContentCatalog.FIGHTING_SKILLS,rank),skillIndex,v->{skillIndex=v;chooseArena();});}
    private void chooseArena(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose arena and location",ActionContentCatalog.namesAtRank(ActionContentCatalog.ARENAS,rank),arenaIndex,v->{arenaIndex=v;chooseSkin();});}
    private void chooseSkin(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose Player 1 skin",ActionContentCatalog.namesAtRank(ActionContentCatalog.SKINS,rank),skinIndex,v->{skinIndex=v;applyLoadout();render(model.snapshot());});}
    private interface Pick{void accept(int index);}
    private void choose(String title,String[] values,int selected,Pick next){new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(values,selected,(d,w)->{d.dismiss();next.accept(w);}).setNegativeButton("Cancel",(d,w)->render(model.snapshot())).show();}
    private void applyLoadout(){
        WeaponSpec weapon=ActionContentCatalog.FIGHTING_WEAPONS[weaponIndex];SkillSpec skill=ActionContentCatalog.FIGHTING_SKILLS[skillIndex];
        CharacterSpec player=ActionContentCatalog.FIGHTERS[fighterIndex],rival=ActionContentCatalog.FIGHTERS[rivalIndex];
        int playerUpgrade=LocalGameProgressStore.upgradeLevel(this,"fighter:"+fighterIndex),rivalUpgrade=LocalGameProgressStore.upgradeLevel(this,"fighter:"+rivalIndex),weaponUpgrade=LocalGameProgressStore.upgradeLevel(this,"fighter_weapon:"+weaponIndex);
        model.configureLoadout(weapon,skill,player.health,rival.health,player.stamina,rival.stamina,playerUpgrade,rivalUpgrade,weaponUpgrade,player.moveScale,rival.moveScale,weapon.movementScale);roundRewarded=false;
        ArenaSpec arena=ActionContentCatalog.ARENAS[arenaIndex];SkinSpec selectedSkin=ActionContentCatalog.SKINS[skinIndex],rivalSkin=ActionContentCatalog.SKINS[(skinIndex+1)%ActionContentCatalog.SKINS.length];
        renderer.setWeapon(weaponIndex);renderer.setArena(arenaIndex);renderer.setSpacing(model.snapshot().distance);renderer.setPalette(blend(player.primary,selectedSkin.primary),player.trim,selectedSkin.trim,rival.primary,rival.trim,rivalSkin.trim,arena.ground,arena.accent);
        if(heading!=null)heading.setText("CAMPUS DUEL  /  "+arena.name.toUpperCase()+" · "+arena.location.toUpperCase());
        if(message!=null)message.setText(player.name+" · "+selectedSkin.name+" · "+weapon.name+" · "+skill.name+"   VS   "+rival.name);
    }
    private static int blend(int a,int b){int r=(((a>>16)&255)+((b>>16)&255))/2,g=(((a>>8)&255)+((b>>8)&255))/2,blue=((a&255)+(b&255))/2;return 0xff000000|(r<<16)|(g<<8)|blue;}
    private ProgressBar bar(int color){ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(100);p.setProgress(100);p.setProgressTintList(android.content.res.ColorStateList.valueOf(color));p.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0x557a8884));return p;}
    private android.widget.Button addButton(LinearLayout row,String label,boolean primary,Runnable action){android.widget.Button b=UiKit.button(this,label,primary);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);row.addView(b,p);if(action!=null)b.setOnClickListener(v->action.run());return b;}
    private void move(boolean opponent,boolean toward){render(model.step(opponent,toward,System.currentTimeMillis()));}
    private void action(boolean opponent,FighterCombatModel.Action a){FighterCombatModel.Result r=opponent?model.actOpponent(a,System.currentTimeMillis()):model.act(a,System.currentTimeMillis());playCue(a);render(r);}
    private void useSkill(boolean opponent){
        long now=System.currentTimeMillis();
        FighterCombatModel.Result r=opponent?model.activateOpponentSkill(now):model.activateSkill(now);playCue(FighterCombatModel.Action.SPECIAL);render(r);
    }
    private void playCue(FighterCombatModel.Action action){if(sound==null)return;int tone=action==FighterCombatModel.Action.HEAVY||action==FighterCombatModel.Action.SPECIAL?ToneGenerator.TONE_PROP_ACK:action==FighterCombatModel.Action.DODGE?ToneGenerator.TONE_PROP_PROMPT:ToneGenerator.TONE_PROP_BEEP;sound.play(tone,70);}
    private void render(FighterCombatModel.Result r){if(playerHp==null)return;playerHp.setMax(r.playerMaxHealth);playerHp.setProgress(r.playerHealth);enemyHp.setMax(r.sparringMaxHealth);enemyHp.setProgress(r.sparringHealth);stamina.setMax(r.staminaMax);stamina.setProgress(r.stamina);opponentStaminaBar.setMax(r.opponentStaminaMax);opponentStaminaBar.setProgress(r.opponentStamina);message.setText(r.message);if(renderer!=null){renderer.setPose(r.playerPose);renderer.setEnemyPose(r.opponentPose);renderer.setSpacing(r.distance);}if(!roundRewarded&&(r.playerHealth==0||r.sparringHealth==0)){roundRewarded=true;LocalGameProgressStore.MatchReward reward=LocalGameProgressStore.recordMatch(this,"campus_duel",r.sparringHealth==0?65:35,r.sparringHealth==0?48:24);android.widget.Toast.makeText(this,"Career +"+reward.xp+" XP · +"+reward.credits+" Practice Points"+(reward.rankUp?" · Rank "+reward.rank+" unlocked!":""),android.widget.Toast.LENGTH_LONG).show();}}
    private void openCareer(){Intent i=new Intent(this,ProgressionShopActivity.class);i.putExtra("shop_kind","fighter").putExtra("game_id","campus_duel").putExtra("active_a",fighterIndex).putExtra("active_b",weaponIndex).putExtra("active_c",skillIndex).putExtra("active_d",arenaIndex).putExtra("active_e",skinIndex);shopOpened=true;startActivity(i);}
    @Override protected void onResume(){super.onResume();if(surface!=null)surface.onResume();if(shopOpened){shopOpened=false;/* Keep this round's combat state; updated upgrades apply to the next setup. */}handler.removeCallbacks(tick);handler.post(tick);}
    @Override protected void onPause(){handler.removeCallbacks(tick);if(surface!=null)surface.onPause();super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(sound!=null)sound.close();super.onDestroy();}
}

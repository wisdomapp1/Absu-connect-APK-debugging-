package com.absuconnect.games.multiplayer;

import com.absuconnect.games.multiplayer.MatchProtocol.Invite;
import com.absuconnect.games.multiplayer.MatchProtocol.InviteInboxListener;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchException;
import com.absuconnect.games.multiplayer.MatchProtocol.Room;
import com.absuconnect.games.multiplayer.MatchProtocol.Subscription;
import java.util.List;

/**
 * Boundary for friend invites and lobby metadata. A production implementation must derive the caller
 * from the authenticated session; caller IDs below are correlation/context values, not credentials.
 */
public interface MatchInviteRepository {
    List<Invite> listIncomingInvites(String recipientUserId) throws MatchException;
    List<Invite> listSentInvites(String senderUserId) throws MatchException;
    Subscription subscribeIncomingInvites(String recipientUserId,InviteInboxListener listener) throws MatchException;
    Invite createInvite(String gameId, String hostUserId, String friendUserId, int maxPlayers,
                        long expiresAtEpochMs) throws MatchException;
    /** Reserve a further friend invitation in an existing multi-seat room (Ludo/WHOT). */
    Invite inviteFriendToRoom(String matchId, String inviterUserId, String friendUserId,
                              long expiresAtEpochMs) throws MatchException;
    Invite respondToInvite(String inviteId, String recipientUserId, boolean accept,
                           long nowEpochMs) throws MatchException;
    void cancelInvite(String inviteId, String senderUserId) throws MatchException;
    /** Only a current participant may fetch room/seat data. */
    Room fetchRoom(String matchId, String participantUserId) throws MatchException;
}

package com.absuconnect.games.backend;

import android.content.Context;
import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import com.absuconnect.games.auth.SupabaseAuthRepository;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Supabase REST facade. Invoke methods from a worker thread, never Android's main thread. */
public final class GameBackendService {
    public static final class Friend {
        public final String id, label;
        public Friend(String id, String label) { this.id = id; this.label = label; }
    }
    public static final class Invite {
        public final String id, gameId, senderId, senderLabel;
        public Invite(String id, String gameId, String senderId, String senderLabel) {
            this.id = id; this.gameId = gameId; this.senderId = senderId; this.senderLabel = senderLabel;
        }
    }

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private final Context context;
    private final OkHttpClient client = new OkHttpClient();
    private final SupabaseAuthRepository auth;

    public GameBackendService(Context context) {
        this.context = context.getApplicationContext();
        this.auth = new SupabaseAuthRepository(context);
    }

    private AuthSession session() throws IOException { return auth.freshSession(context); }

    private Request.Builder authorized(HttpUrl url, AuthSession s) {
        return new Request.Builder().url(url).header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer " + s.accessToken).header("Accept", "application/json");
    }

    private String execute(Request request) throws IOException {
        try (Response response = client.newCall(request).execute()) {
            String text = response.body() == null ? "" : response.body().string();
            if (!response.isSuccessful()) {
                try {
                    JSONObject error = new JSONObject(text);
                    throw new IOException(error.optString("message", error.optString("hint", "Game service request failed.")));
                } catch (org.json.JSONException ignored) {
                    throw new IOException("Game service request failed (HTTP " + response.code() + ").");
                }
            }
            return text;
        }
    }

    public List<Friend> fetchAcceptedFriends() throws IOException, JSONException {
        AuthSession s = session();
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/friendships").newBuilder()
                .addQueryParameter("select", "requester_id,addressee_id")
                .addQueryParameter("status", "eq.accepted")
                .addQueryParameter("or", "(requester_id.eq." + s.userId + ",addressee_id.eq." + s.userId + ")").build();
        JSONArray rows = new JSONArray(execute(authorized(url, s).get().build()));
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.getJSONObject(i);
            String a = row.getString("requester_id"), b = row.getString("addressee_id");
            ids.add(a.equals(s.userId) ? b : a);
        }
        Map<String, String> labels = fetchProfileLabels(ids, s);
        List<Friend> result = new ArrayList<>();
        for (String id : ids) result.add(new Friend(id, labels.getOrDefault(id, "Campus friend")));
        return result;
    }

    private Map<String, String> fetchProfileLabels(List<String> ids, AuthSession s) throws IOException, JSONException {
        Map<String, String> result = new LinkedHashMap<>();
        if (ids.isEmpty()) return result;
        String values = "in.(" + String.join(",", ids) + ")";
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/profiles").newBuilder()
                .addQueryParameter("select", "id,display_name,username").addQueryParameter("id", values).build();
        JSONArray rows = new JSONArray(execute(authorized(url, s).get().build()));
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.getJSONObject(i);
            String label = row.optString("display_name", "").trim();
            if (label.isEmpty()) label = row.optString("username", "").trim();
            if (label.isEmpty()) label = "Campus friend";
            result.put(row.getString("id"), label);
        }
        return result;
    }

    public String createInvite(String gameId, String friendId, int maxPlayers) throws IOException, JSONException {
        AuthSession s = session();
        JSONObject body = new JSONObject().put("p_game_id", gameId).put("p_friend_id", friendId).put("p_max_players", maxPlayers);
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/rpc/create_game_invite");
        String response = execute(authorized(url, s).post(RequestBody.create(body.toString(), JSON)).build()).trim();
        if (response.startsWith("\"")) return response.replace("\"", "");
        try { return new JSONObject(response).optString("create_game_invite", response); }
        catch (Exception ignored) { return response; }
    }

    public String roomIdForInvite(String inviteId) throws IOException, JSONException {
        AuthSession s = session();
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/game_invites").newBuilder()
                .addQueryParameter("select", "room_id").addQueryParameter("id", "eq." + inviteId).build();
        JSONArray rows = new JSONArray(execute(authorized(url, s).get().build()));
        if (rows.length() == 0) throw new IOException("Invitation room was not found.");
        return rows.getJSONObject(0).getString("room_id");
    }

    public String inviteFriendToRoom(String roomId, String friendId) throws IOException, JSONException {
        AuthSession s = session();
        JSONObject body = new JSONObject().put("p_room_id", roomId).put("p_friend_id", friendId);
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/rpc/invite_friend_to_game_room");
        return execute(authorized(url, s).post(RequestBody.create(body.toString(), JSON)).build()).trim();
    }

    public String respondInvite(String inviteId, boolean accept) throws IOException, JSONException {
        AuthSession s = session();
        JSONObject body = new JSONObject().put("p_invite_id", inviteId).put("p_accept", accept);
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/rpc/respond_game_invite");
        return execute(authorized(url, s).post(RequestBody.create(body.toString(), JSON)).build()).trim();
    }

    public List<Invite> fetchIncomingInvites() throws IOException, JSONException {
        AuthSession s = session();
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/game_invites").newBuilder()
                .addQueryParameter("select", "id,game_id,sender_id")
                .addQueryParameter("recipient_id", "eq." + s.userId)
                .addQueryParameter("status", "eq.pending")
                .addQueryParameter("expires_at", "gt." + java.time.Instant.now().toString())
                .addQueryParameter("order", "created_at.desc").build();
        JSONArray rows = new JSONArray(execute(authorized(url, s).get().build()));
        List<String> senders = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) senders.add(rows.getJSONObject(i).getString("sender_id"));
        Map<String, String> labels = fetchProfileLabels(senders, s);
        List<Invite> result = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.getJSONObject(i);
            String sender = row.getString("sender_id");
            result.add(new Invite(row.getString("id"), row.getString("game_id"), sender, labels.getOrDefault(sender, "Campus friend")));
        }
        return result;
    }
}

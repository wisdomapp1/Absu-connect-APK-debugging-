package com.absuconnect.games.multiplayer;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import com.absuconnect.games.auth.SupabaseAuthRepository;
import com.absuconnect.games.multiplayer.MatchProtocol.ActionReceipt;
import com.absuconnect.games.multiplayer.MatchProtocol.Listener;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchAction;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchException;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchSnapshot;
import com.absuconnect.games.multiplayer.MatchProtocol.RoomStatus;
import com.absuconnect.games.multiplayer.MatchProtocol.Subscription;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONObject;

/**
 * Supabase RPC + Realtime implementation of the match transport contract.
 * Run the synchronous RPC methods off the Android main thread. The accompanying SQL migration
 * authenticates room membership and sequences an action journal, but does not simulate game rules.
 */
public final class SupabaseMatchTransport implements MatchTransport {
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String UUID_PATTERN = "(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
    private final Context context;
    private final SupabaseAuthRepository auth;
    private final OkHttpClient client = new OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build();
    private final Handler main = new Handler(Looper.getMainLooper());

    public SupabaseMatchTransport(Context context) {
        this.context = context.getApplicationContext();
        this.auth = new SupabaseAuthRepository(context);
    }

    /** Host-only RPC: starts the shared room after at least two accepted participants have joined. */
    public MatchSnapshot startMatch(String matchId) throws MatchException {
        requireUuid(matchId, "matchId");
        try {
            AuthSession session = auth.freshSession(context);
            JSONObject result = callRpc("start_game_match", new JSONObject().put("p_room_id", matchId), session);
            return decodeSnapshot(result);
        } catch (MatchException e) {
            throw e;
        } catch (Exception e) {
            throw toMatchException("Could not start this online match", e);
        }
    }

    @Override public MatchSnapshot fetchSnapshot(String matchId, String authenticatedUserId) throws MatchException {
        requireUuid(matchId, "matchId");
        try {
            AuthSession session = auth.freshSession(context);
            requireSameAccount(session, authenticatedUserId);
            return decodeSnapshot(callRpc("get_game_match_snapshot",
                    new JSONObject().put("p_room_id", matchId), session));
        } catch (Exception e) {
            throw toMatchException("Could not fetch the latest match state", e);
        }
    }

    @Override public ActionReceipt submitAction(MatchAction action) throws MatchException {
        if (action == null) throw new MatchException("A match action is required.");
        requireUuid(action.matchId, "matchId");
        requireUuid(action.clientActionId, "clientActionId");
        try {
            AuthSession session = auth.freshSession(context);
            requireSameAccount(session, action.actorId);
            JSONObject payload = new JSONObject();
            for (Map.Entry<String, String> entry : action.fields.entrySet()) payload.put(entry.getKey(), entry.getValue());
            JSONObject request = new JSONObject()
                    .put("p_room_id", action.matchId)
                    .put("p_client_action_id", action.clientActionId)
                    .put("p_action_type", action.type)
                    .put("p_payload", payload)
                    .put("p_expected_version", action.expectedVersion)
                    .put("p_expected_sequence", action.sequence);
            JSONObject response = callRpc("submit_game_match_action", request, session);
            JSONObject snapshotJson = response.optJSONObject("snapshot");
            MatchSnapshot snapshot = snapshotJson == null ? null : decodeSnapshot(snapshotJson);
            return new ActionReceipt(response.optBoolean("accepted", false), response.optString("reason", ""), snapshot);
        } catch (Exception e) {
            throw toMatchException("Could not submit this match action", e);
        }
    }

    @Override public Subscription subscribe(String matchId, String authenticatedUserId, long afterVersion,
                                           Listener listener) throws MatchException {
        requireUuid(matchId, "matchId");
        if (listener == null) throw new MatchException("A match listener is required.");
        final AuthSession session;
        try { session = auth.freshSession(context); }
        catch (Exception e) { throw toMatchException("Could not refresh the signed-in session", e); }
        requireSameAccount(session, authenticatedUserId);
        HttpUrl base = HttpUrl.parse(BuildConfig.SUPABASE_URL);
        if (base == null) throw new MatchException("Supabase URL is invalid.");
        HttpUrl url = base.newBuilder().scheme("wss").addPathSegments("realtime/v1/websocket")
                .addQueryParameter("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .addQueryParameter("vsn", "1.0.0").build();
        AtomicBoolean closed = new AtomicBoolean(false);
        AtomicBoolean disconnected = new AtomicBoolean(false);
        ExecutorService snapshotWorker = Executors.newSingleThreadExecutor();
        ScheduledExecutorService heartbeats = Executors.newSingleThreadScheduledExecutor();
        final WebSocket[] socketRef = new WebSocket[1];
        final AtomicLong refs = new AtomicLong(1);
        final AtomicReference<String> joinRef = new AtomicReference<>();

        WebSocket socket = client.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                if (closed.get()) { webSocket.close(1000, "subscription closed"); return; }
                try {
                    JSONObject change = new JSONObject().put("event", "INSERT").put("schema", "public")
                            .put("table", "game_match_actions").put("filter", "room_id=eq." + matchId);
                    JSONObject config = new JSONObject()
                            .put("broadcast", new JSONObject().put("ack", false).put("self", false))
                            .put("presence", new JSONObject().put("key", ""))
                            .put("postgres_changes", new org.json.JSONArray().put(change))
                            .put("private", false);
                    String ref = Long.toString(refs.getAndIncrement());
                    joinRef.set(ref);
                    JSONObject join = new JSONObject().put("topic", "realtime:game-match-" + matchId)
                            .put("event", "phx_join")
                            .put("payload", new JSONObject().put("config", config).put("access_token", session.accessToken))
                            .put("ref", ref);
                    webSocket.send(join.toString());
                    heartbeats.scheduleAtFixedRate(() -> {
                        if (closed.get()) return;
                        JSONObject heartbeat = new JSONObject();
                        try {
                            heartbeat.put("topic", "phoenix").put("event", "heartbeat").put("payload", new JSONObject())
                                    .put("ref", Long.toString(refs.getAndIncrement()));
                            webSocket.send(heartbeat.toString());
                        } catch (Exception ignored) { }
                    }, 25, 25, TimeUnit.SECONDS);
                } catch (Exception e) {
                    notifyDisconnected("Could not join the match updates channel.");
                }
            }

            @Override public void onMessage(WebSocket webSocket, String text) {
                if (closed.get() || text == null) return;
                try {
                    JSONObject envelope = new JSONObject(text);
                    String event = envelope.optString("event", "");
                    if ("phx_reply".equals(event) && joinRef.get() != null
                            && joinRef.get().equals(envelope.optString("ref"))) {
                        JSONObject payload = envelope.optJSONObject("payload");
                        if (payload == null || !"ok".equalsIgnoreCase(payload.optString("status"))) {
                            notifyDisconnected("Supabase rejected the match updates subscription.");
                            return;
                        }
                        requestSnapshot();
                        return;
                    }
                    if ("phx_error".equals(event) || "phx_close".equals(event)) {
                        notifyDisconnected("Supabase closed the match updates subscription.");
                        return;
                    }
                    if (!"postgres_changes".equals(event) && !text.contains("postgres_changes")) return;
                } catch (Exception ignored) {
                    if (!text.contains("postgres_changes")) return;
                }
                requestSnapshot();
            }

            private void requestSnapshot() {
                snapshotWorker.execute(() -> {
                    if (closed.get()) return;
                    try {
                        MatchSnapshot snapshot = fetchSnapshot(matchId, authenticatedUserId);
                        main.post(() -> { if (!closed.get()) listener.onSnapshot(snapshot); });
                    } catch (MatchException e) {
                        main.post(() -> { if (!closed.get()) listener.onDisconnected(e.getMessage()); });
                    }
                });
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                notifyDisconnected("Live match updates disconnected. Reopen or reconnect to resync.");
                heartbeats.shutdownNow();
                snapshotWorker.shutdownNow();
            }

            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                notifyDisconnected("Live match updates closed. Reopen or reconnect to resync.");
                heartbeats.shutdownNow();
                snapshotWorker.shutdownNow();
            }

            private void notifyDisconnected(String reason) {
                if (!disconnected.compareAndSet(false, true)) return;
                main.post(() -> { if (!closed.get()) listener.onDisconnected(reason); });
            }
        });
        socketRef[0] = socket;
        return () -> {
            if (!closed.compareAndSet(false, true)) return;
            WebSocket active = socketRef[0];
            if (active != null) active.close(1000, "match screen closed");
            heartbeats.shutdownNow();
            snapshotWorker.shutdownNow();
        };
    }

    private JSONObject callRpc(String function, JSONObject body, AuthSession session) throws IOException {
        HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/rest/v1/rpc/" + function);
        if (url == null) throw new IOException("Invalid Supabase RPC URL");
        Request request = new Request.Builder().url(url)
                .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer " + session.accessToken)
                .header("Accept", "application/json")
                .post(RequestBody.create(body.toString(), JSON)).build();
        try (Response response = client.newCall(request).execute()) {
            String text = response.body() == null ? "{}" : response.body().string();
            if (!response.isSuccessful()) {
                String message = "Supabase match request failed (HTTP " + response.code() + ").";
                try {
                    JSONObject error = new JSONObject(text);
                    message = error.optString("message", error.optString("hint", message));
                } catch (Exception ignored) { }
                throw new IOException(message);
            }
            try { return new JSONObject(text); }
            catch (Exception e) { throw new IOException("Supabase returned an invalid match response.", e); }
        }
    }

    private MatchSnapshot decodeSnapshot(JSONObject json) throws MatchException {
        try {
            JSONObject state = json.optJSONObject("state_json");
            String stateJson = state == null ? json.optString("state_json", "{}") : state.toString();
            return new MatchSnapshot(json.getString("match_id"), json.getString("game_id"),
                    roomStatus(json.optString("status", "in_progress")),
                    json.getLong("state_version"), json.getLong("next_sequence"),
                    json.optInt("active_seat", -1), stateJson);
        } catch (Exception e) {
            throw new MatchException("Supabase returned an incomplete match snapshot.", e);
        }
    }

    private static RoomStatus roomStatus(String status) {
        if ("ready".equalsIgnoreCase(status)) return RoomStatus.READY;
        if ("completed".equalsIgnoreCase(status)) return RoomStatus.COMPLETED;
        if ("abandoned".equalsIgnoreCase(status)) return RoomStatus.ABANDONED;
        if ("waiting".equalsIgnoreCase(status)) return RoomStatus.WAITING;
        return RoomStatus.IN_PROGRESS;
    }

    private static void requireUuid(String value, String name) throws MatchException {
        if (value == null || !value.matches(UUID_PATTERN)) throw new MatchException("Invalid " + name + ".");
    }

    private static void requireSameAccount(AuthSession session, String expectedUserId) throws MatchException {
        if (expectedUserId == null || !expectedUserId.equals(session.userId))
            throw new MatchException("The signed-in account changed. Reopen this match using the current account.");
    }

    private static MatchException toMatchException(String prefix, Exception cause) {
        String detail = cause instanceof IOException ? cause.getMessage() : null;
        if (detail == null || detail.trim().isEmpty()) detail = "Check the signed-in session and Supabase setup.";
        return new MatchException(prefix + ": " + detail, cause);
    }
}

package com.absuconnect.games.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import com.absuconnect.games.shooter.ShooterMatchModel;

/** Original transparent touch/HUD layer for the GLES first-person shooter. */
public final class Shooter3DHudView extends View {
    public interface Listener {void onBack();void onSetup();void onShop();}
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ShooterMatchModel model;
    private final Shooter3DGameView game;
    private Listener listener;
    private boolean loop;
    private int stickId=-1,lookId=-1,fireId=-1,sprintId=-1;
    private float stickX,stickY,moveX,moveY,lastLookX,lastLookY;

    public Shooter3DHudView(Context context,ShooterMatchModel model,Shooter3DGameView game){
        super(context);this.model=model;this.game=game;setLayerType(View.LAYER_TYPE_HARDWARE,null);
        setFocusable(true);setContentDescription("Campus Fireline 3D first-person shooter controls");
    }
    public void setListener(Listener listener){this.listener=listener;}
    public void setLoopEnabled(boolean enabled){loop=enabled;if(enabled)postInvalidateOnAnimation();}
    private float d(float value){return value*getResources().getDisplayMetrics().density;}

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);ShooterMatchModel.Result r=model.snapshot();float w=getWidth(),h=getHeight();
        drawPanel(canvas,new RectF(d(9),d(8),w-d(9),d(69)),0xd918292a,d(14));
        paint.setTextAlign(Paint.Align.LEFT);paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setColor(0xff6dd8bd);paint.setTextSize(d(10));canvas.drawText("CAMPUS FIRELINE  /  3D FIELD OPS",d(20),d(25),paint);
        paint.setColor(0xfff2f2e9);paint.setTextSize(d(12));canvas.drawText(r.map+"  ·  "+r.operator,d(20),d(45),paint);
        paint.setColor(0xffb7c9c0);paint.setTextSize(d(9));canvas.drawText(r.skin+(r.training?"  ·  TRAINING":"  ·  SOLO CAMPAIGN"),d(20),d(60),paint);
        float healthX=w*.37f,healthW=w*.22f;
        drawBar(canvas,healthX,d(18),healthW,d(9),r.playerHealth/(float)Math.max(1,r.maxHealth),r.playerHealth<30?0xffe87662:0xff56d0aa);
        paint.setTextSize(d(9));paint.setColor(0xffedf3ec);canvas.drawText("HP  "+r.playerHealth+" / "+r.maxHealth,healthX,d(43),paint);
        paint.setColor(0xffffd779);canvas.drawText("LEVEL  "+r.level+"   ·   WAVE TARGETS  "+(5-r.aliveBots)+" / 5",healthX,d(59),paint);
        paint.setTextAlign(Paint.Align.RIGHT);paint.setColor(0xfff5f1e6);paint.setTextSize(d(10));
        canvas.drawText(r.weapon,w-d(20),d(29),paint);
        paint.setColor(0xffc3d1c8);paint.setTextSize(d(9));
        canvas.drawText(r.training?(r.reloading?"RELOADING":"AMMO  ∞"):(r.reloading?"RELOADING":"AMMO  "+r.ammo+" / "+r.reserveAmmo),w-d(20),d(47),paint);
        paint.setColor(r.skillReady?0xff72e0b5:0xff9ea9a4);
        canvas.drawText(r.skill+(r.skillReady?"  READY":"  COOLING"),w-d(20),d(61),paint);
        paint.setTextAlign(Paint.Align.LEFT);paint.setTextSize(d(8));paint.setColor(r.grounded?(r.jumpReady?0xffa7d7c1:0xff9ea9a4):0xffffd779);
        canvas.drawText(!r.grounded?"AIRBORNE":"JUMP  "+(r.jumpReady?"READY":"COOLDOWN"),d(20),d(79),paint);
        drawActionButtons(canvas,w,h,r);
        drawReticle(canvas,w*.5f,h*.49f,r.focused?0xffffd779:0xffe9f6e9);
        drawJoystick(canvas);
        if(!r.status.isEmpty()){
            float max=w*.58f;String status=fit(r.status,max,d(9));
            drawPanel(canvas,new RectF(w*.23f,h-d(144),w*.77f,h-d(121)),0xba111b1d,d(8));
            paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(d(9));paint.setColor(0xffeff4e9);canvas.drawText(status,w*.5f,h-d(129),paint);paint.setTextAlign(Paint.Align.LEFT);
        }
        paint.setColor(0xd4e4ebe5);paint.setTextSize(d(8));paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("LEFT PAD MOVE  ·  DRAG RIGHT TO AIM  ·  HOLD FIRE",w*.5f,h-d(12),paint);paint.setTextAlign(Paint.Align.LEFT);
        if(r.shielded){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d(3));paint.setColor(0x8868dcf2);canvas.drawRoundRect(new RectF(d(4),d(4),w-d(4),h-d(4)),d(20),d(20),paint);paint.setStyle(Paint.Style.FILL);}
        if(r.matchOver){drawPanel(canvas,new RectF(w*.34f,h*.40f,w*.66f,h*.57f),0xec132220,d(16));paint.setColor(0xfff5f5e8);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(d(22));paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);canvas.drawText(r.status,w*.5f,h*.49f,paint);paint.setTextAlign(Paint.Align.LEFT);}
        if(loop)postInvalidateDelayed(32);
    }
    private void drawActionButtons(Canvas c,float w,float h,ShooterMatchModel.Result r){
        button(c,w-d(74),h-d(87),d(39),"FIRE",0xffc96455);
        button(c,w-d(78),h-d(178),d(30),shortName(r.skill),r.skillReady?0xff318e79:0xff586963);
        button(c,w-d(164),h-d(83),d(25),"LOAD",0xff718d84);
        button(c,w-d(164),h-d(145),d(26),"GUN",0xff758c68);
        button(c,w-d(247),h-d(83),d(24),r.jumpReady?"JUMP":"WAIT",r.jumpReady?0xff9a7856:0xff59645f);
        button(c,w-d(247),h-d(145),d(24),"RUN",0xff5e8792);
        drawPanel(c,new RectF(w-d(256),d(8),w-d(182),d(42)),0xd6223231,d(9));
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);paint.setTextAlign(Paint.Align.CENTER);paint.setColor(0xffffd479);paint.setTextSize(d(8));c.drawText("CAREER",w-d(219),d(29),paint);
        drawPanel(c,new RectF(w-d(179),d(8),w-d(100),d(42)),0xd6223231,d(9));paint.setColor(0xffe6eee5);c.drawText("SETUP",w-d(139),d(29),paint);
        drawPanel(c,new RectF(w-d(96),d(8),w-d(9),d(42)),0xd6223231,d(9));paint.setColor(0xffe6eee5);c.drawText("‹ HUB",w-d(52),d(29),paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }
    private void drawJoystick(Canvas c){
        float cx=d(76),cy=getHeight()-d(83),r=d(53);
        paint.setColor(0x463b6258);c.drawCircle(cx,cy,r,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d(1));paint.setColor(0x927eb1a2);c.drawCircle(cx,cy,r,paint);paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x6e99b0a5);c.drawCircle(cx,cy,r*.62f,paint);
        paint.setColor(0xff6cc9ab);c.drawCircle(cx+moveX*r*.56f,cy+moveY*r*.56f,r*.27f,paint);
    }
    private void drawReticle(Canvas c,float x,float y,int color){
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d(1.7f));paint.setColor(color);
        c.drawCircle(x,y,d(9),paint);c.drawLine(x-d(17),y,x-d(5),y,paint);c.drawLine(x+d(5),y,x+d(17),y,paint);
        c.drawLine(x,y-d(17),x,y-d(5),paint);c.drawLine(x,y+d(5),x,y+d(17),paint);paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);c.drawCircle(x,y,d(1.8f),paint);
    }
    private void button(Canvas c,float x,float y,float radius,String label,int color){
        paint.setColor(0x7705090a);c.drawCircle(x+ d(1),y+d(2),radius+d(1),paint);paint.setColor(color);c.drawCircle(x,y,radius,paint);
        paint.setColor(0xfff2f4e9);paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(d(label.length()>7?7:9));c.drawText(label,x,y+d(3),paint);paint.setTextAlign(Paint.Align.LEFT);
    }
    private void drawBar(Canvas c,float x,float y,float width,float height,float amount,int color){
        paint.setColor(0xff384a45);c.drawRoundRect(new RectF(x,y,x+width,y+height),height/2,height/2,paint);
        float fill=width*Math.max(0,Math.min(1,amount));paint.setColor(color);c.drawRoundRect(new RectF(x,y,x+fill,y+height),height/2,height/2,paint);
    }
    private void drawPanel(Canvas c,RectF rect,int color,float radius){paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRoundRect(rect,radius,radius,paint);}
    private String fit(String text,float maxWidth,float textSize){
        paint.setTextSize(textSize);if(paint.measureText(text)<=maxWidth)return text;
        while(text.length()>8&&paint.measureText(text+"…")>maxWidth)text=text.substring(0,text.length()-1);return text+"…";
    }
    private String shortName(String name){return name.length()>7?name.substring(0,6).toUpperCase():name.toUpperCase();}
    private boolean inCircle(float x,float y,float cx,float cy,float radius){float dx=x-cx,dy=y-cy;return dx*dx+dy*dy<=radius*radius;}
    private boolean hit(float x,float y,float cx,float cy,float radius){return inCircle(x,y,cx,cy,radius);}
    private boolean zoneLook(float x,float y){return x>getWidth()*.32f&&y>getHeight()*.12f&&y<getHeight()-d(181);}

    @Override public boolean onTouchEvent(MotionEvent event){
        int action=event.getActionMasked(),index=event.getActionIndex(),id=event.getPointerId(index);
        float x=event.getX(index),y=event.getY(index),w=getWidth(),h=getHeight();
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            if(y<d(52)&&x>w-d(100)){if(listener!=null)listener.onBack();return true;}
            if(y<d(52)&&x>w-d(182)&&x<=w-d(100)){if(listener!=null)listener.onSetup();return true;}
            if(y<d(52)&&x>w-d(260)&&x<=w-d(182)){if(listener!=null)listener.onShop();return true;}
            if(hit(x,y,w-d(74),h-d(87),d(42))){fireId=id;game.setFireHeld(true);return true;}
            if(hit(x,y,w-d(78),h-d(178),d(33))){game.activateSkill(System.currentTimeMillis());invalidate();return true;}
            if(hit(x,y,w-d(164),h-d(83),d(29))){game.pressReload(System.currentTimeMillis());invalidate();return true;}
            if(hit(x,y,w-d(164),h-d(145),d(30))){game.cycleWeapon();invalidate();return true;}
            if(hit(x,y,w-d(247),h-d(83),d(28))){game.jump();invalidate();return true;}
            if(hit(x,y,w-d(247),h-d(145),d(28))){sprintId=id;game.setSprintHeld(true);return true;}
            if(x<d(160)&&y>h-d(152)){stickId=id;updateStick(x,y);return true;}
            if(zoneLook(x,y)){lookId=id;lastLookX=x;lastLookY=y;return true;}
            return true;
        }
        if(action==MotionEvent.ACTION_MOVE){
            if(stickId>=0){int i=event.findPointerIndex(stickId);if(i>=0)updateStick(event.getX(i),event.getY(i));}
            if(lookId>=0){int i=event.findPointerIndex(lookId);if(i>=0){float nx=event.getX(i),ny=event.getY(i);game.look(nx-lastLookX,ny-lastLookY);lastLookX=nx;lastLookY=ny;}}
            return true;
        }
        if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_CANCEL){
            if(id==stickId){stickId=-1;stickX=stickY=moveX=moveY=0;game.setMove(0,0);invalidate();}
            if(id==lookId)lookId=-1;
            if(id==fireId){fireId=-1;game.setFireHeld(false);}
            if(id==sprintId){sprintId=-1;game.setSprintHeld(false);}
            if(action==MotionEvent.ACTION_CANCEL){stickId=lookId=fireId=sprintId=-1;stickX=stickY=moveX=moveY=0;game.setMove(0,0);game.setFireHeld(false);game.setSprintHeld(false);}
            return true;
        }
        return true;
    }
    private void updateStick(float x,float y){
        float cx=d(76),cy=getHeight()-d(83),radius=d(50);float dx=(x-cx)/radius,dy=(y-cy)/radius;
        float len=(float)Math.sqrt(dx*dx+dy*dy);if(len>1){dx/=len;dy/=len;}
        stickX=dx;stickY=dy;moveX=dx;moveY=dy;game.setMove(dx,-dy);invalidate();
    }
}

package com.absuconnect.games.action;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** Device-local, offline-only career state. It is not the proposed NGN/game-coin wallets or an online authority. */
public final class LocalGameProgression {
    public static final int MAX_RANK=25;
    private int experience,practiceCredits;
    private final Map<String,Integer> upgrades=new HashMap<>();
    private final Map<String,Integer> playsByGame=new HashMap<>();
    private final Map<String,Integer> streakByGame=new HashMap<>();

    public LocalGameProgression(){this(0,0,null,null,null);}
    public LocalGameProgression(int experience,int practiceCredits,Map<String,Integer> upgrades,
                                Map<String,Integer> playsByGame,Map<String,Integer> streakByGame){
        this.experience=Math.max(0,experience);this.practiceCredits=Math.max(0,practiceCredits);
        if(upgrades!=null)this.upgrades.putAll(upgrades);
        if(playsByGame!=null)this.playsByGame.putAll(playsByGame);
        if(streakByGame!=null)this.streakByGame.putAll(streakByGame);
    }
    public int experience(){return experience;}
    public int practiceCredits(){return practiceCredits;}
    public int rank(){return Math.min(MAX_RANK,1+experience/150);}
    public int xpToNextRank(){return rank()>=MAX_RANK?0:150-(experience%150);}
    public int rankProgress(){return rank()>=MAX_RANK?150:experience%150;}
    public boolean unlockedAtRank(int requiredRank){return rank()>=requiredRank;}
    public int upgradeLevel(String key){String id=normalize(key);return upgrades.containsKey(id)?Math.max(0,upgrades.get(id)):0;}
    public int matchCount(String game){return playsByGame.containsKey(game)?Math.max(0,playsByGame.get(game)):0;}
    public int streak(String game){return streakByGame.containsKey(game)?Math.max(0,streakByGame.get(game)):0;}
    public void resetStreak(String game){streakByGame.put(normalize(game),0);}
    public Map<String,Integer> upgrades(){return Collections.unmodifiableMap(upgrades);}
    public Map<String,Integer> playsByGame(){return Collections.unmodifiableMap(playsByGame);}
    public Map<String,Integer> streaksByGame(){return Collections.unmodifiableMap(streakByGame);}

    /** Award repeatable offline match XP/Practice Credits plus one daily-play bonus per game/device day. */
    public void recordMatch(String game,int baseXp,int baseCredits,boolean firstPlayToday){
        String id=normalize(game);playsByGame.put(id,matchCount(id)+1);
        int old=streak(id);streakByGame.put(id,firstPlayToday?Math.min(999,old+1):old);
        int dailyXp=firstPlayToday?20+Math.min(20,old*2):0;
        int dailyCredits=firstPlayToday?15+Math.min(15,old):0;
        experience=Math.min(150000,experience+Math.max(0,baseXp)+dailyXp);
        practiceCredits=Math.min(1_000_000,practiceCredits+Math.max(0,baseCredits)+dailyCredits);
    }
    public int nextUpgradeCost(String key){return 60+40*upgradeLevel(key);}
    public boolean upgrade(String key,int maxLevel){
        String id=normalize(key);int level=upgradeLevel(id);if(level>=maxLevel)return false;
        int cost=nextUpgradeCost(id);if(practiceCredits<cost)return false;
        practiceCredits-=cost;upgrades.put(id,level+1);return true;
    }
    public int estimatedUpgradeCost(String key,int maxLevel){return upgradeLevel(key)>=maxLevel?0:nextUpgradeCost(key);}
    private static String normalize(String value){return value==null?"unknown":value.trim().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_.-]","_");}
}

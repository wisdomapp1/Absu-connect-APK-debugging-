package com.absuconnect.games.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.auth.AuthSession;
import com.absuconnect.games.auth.AuthSessionStore;
import com.absuconnect.games.backend.GameBackendService;
import com.absuconnect.games.backend.RealtimeInviteSubscription;
import com.absuconnect.games.action.LocalGameProgression;
import com.absuconnect.games.action.LocalGameProgressStore;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class GameHubActivity extends AppCompatActivity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private GameBackendService backend;
    private final RealtimeInviteSubscription live = new RealtimeInviteSubscription();
    private LinearLayout page, friendList, inviteList;
    private TextView friendStatus, inviteStatus,careerStatus;
    private AuthSession session;
    private final Map<String, String> hostRoomByGame = new ConcurrentHashMap<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        session = AuthSessionStore.load(this);
        if (session == null) { startActivity(new Intent(this, MainActivity.class)); finish(); return; }
        backend = new GameBackendService(this);
        setContentView(buildView());
        refreshFriends(); refreshInvites();refreshCareer();
        live.subscribe(session, new RealtimeInviteSubscription.Listener() {
            @Override public void onChanged() { runOnUiThread(GameHubActivity.this::refreshInvites); }
            @Override public void onDisconnected(String reason) { runOnUiThread(() -> inviteStatus.setText("Live updates paused. Pull to refresh or reopen the inbox.")); }
        });
    }

    private View buildView() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(UiKit.BG);
        page = UiKit.vertical(this); page.setPadding(UiKit.dp(this, 20), UiKit.dp(this, 28), UiKit.dp(this, 20), UiKit.dp(this, 34));
        scroll.addView(page);
        LinearLayout header = UiKit.row(this);
        LinearLayout titles = UiKit.vertical(this); header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        titles.addView(UiKit.text(this, "ABSU CONNECT  /  GAME CENTER", 11, UiKit.GREEN, true));
        TextView title = UiKit.text(this, "A good break,\nplayed together.", 27, UiKit.INK, true); UiKit.marginTop(this, title, titles, -2, 8);
        android.widget.Button wallet = UiKit.button(this, "Wallet", false); header.addView(wallet);
        wallet.setOnClickListener(v -> startActivity(new Intent(this, WalletStoreActivity.class)));
        android.widget.Button signOut = UiKit.button(this, "Sign out", false); header.addView(signOut);
        signOut.setOnClickListener(v -> { AuthSessionStore.clear(this); startActivity(new Intent(this, MainActivity.class)); finish(); });
        page.addView(header);
        UiKit.marginTop(this, UiKit.text(this, "No stakes. Accepted friends only. Designed to feel at home in a university app.", 14, UiKit.MUTED, false), page, -2, 8);

        addGameCard("Campus Ludo", "Classic local board play: solo against CPU seats, or 2–4 people passing one device.", "Play Ludo", () -> startActivity(new Intent(this, LudoActivity.class)), "Playable locally");
        addGameCard("Campus Duel", "Original procedural sparring prototype: 18 fighters, 16 training-weapon styles, 12 skills, eight arenas and 16 skins. Higher tiers preview in the Career shop; many unlock through match-earned ranks.", "Open fighter hall", () -> startActivity(new Intent(this, FighterActivity.class)), "Local practice");
        addGameCard("Campus Fireline", "Solo first-person 3D campaign with endless levels. Clear each five-target wave to advance; later waves become gradually harder. Training remains available.", "Play Fireline 3D", () -> startActivity(new Intent(this, ShooterActivity.class)), "Solo level campaign");
        addGameCard("Naija WHOT!", "A full local card-game implementation with common Nigerian power cards. Play solo against CPU or pass the phone for 2–4 players.", "Play WHOT", () -> startActivity(new Intent(this, WhotActivity.class)), "Playable locally");
        addGameCard("Campus 8-Ball", "An original touch-playable 8-ball table with ball physics, local rules, CPU practice and shared-device matches.", "Play billiards", () -> startActivity(new Intent(this, BilliardsActivity.class)), "Playable locally");
        addGameCard("Campus Car Racing", "Original oval race with 16 drivers, 12 selectable car profiles and 16 liveries. Earn local XP, preview higher ranks and upgrade the active driver/car in the garage.", "Race cars", () -> { Intent i = new Intent(this, RacingActivity.class); i.putExtra("motorcycle", false); startActivity(i); }, "Local progression");
        addGameCard("Campus Bike Racing", "Original oval race with 16 drivers, 12 selectable motorcycle profiles and 16 liveries. Earn local XP, preview higher ranks and upgrade the active driver/bike in the garage.", "Race bikes", () -> { Intent i = new Intent(this, RacingActivity.class); i.putExtra("motorcycle", true); startActivity(i); }, "Local progression");

        TextView careerHead=UiKit.text(this,"Your campus career",20,UiKit.INK,true);UiKit.marginTop(this,careerHead,page,-2,24);
        LinearLayout careerCard=UiKit.card(this);careerCard.setPadding(UiKit.dp(this,15),UiKit.dp(this,13),UiKit.dp(this,15),UiKit.dp(this,13));UiKit.marginTop(this,careerCard,page,-2,9);
        careerStatus=UiKit.text(this,"Loading local progress…",14,UiKit.GREEN,true);careerCard.addView(careerStatus);
        UiKit.marginTop(this,UiKit.text(this,"Finish local matches to earn XP and non-purchasable Practice Points. Each game has a first-match-of-the-day replay bonus; ranks reveal previews and stronger loadouts. Career data stays on this device and does not unlock online competition.",12,UiKit.MUTED,false),careerCard,-2,7);

        TextView friendsHead = UiKit.text(this, "Play with friends", 20, UiKit.INK, true); UiKit.marginTop(this, friendsHead, page, -2, 26);
        TextView friendsCopy = UiKit.text(this, "Only people already connected as accepted friends can receive a game invite.", 13, UiKit.MUTED, false); UiKit.marginTop(this, friendsCopy, page, -2, 4);
        friendStatus = UiKit.text(this, "Loading your accepted friends…", 13, UiKit.MUTED, false); UiKit.marginTop(this, friendStatus, page, -2, 12);
        friendList = UiKit.vertical(this); UiKit.marginTop(this, friendList, page, -2, 8);

        TextView inviteHead = UiKit.text(this, "Invitations", 20, UiKit.INK, true); UiKit.marginTop(this, inviteHead, page, -2, 26);
        inviteStatus = UiKit.text(this, "Loading invitations…", 13, UiKit.MUTED, false); UiKit.marginTop(this, inviteStatus, page, -2, 8);
        inviteList = UiKit.vertical(this); UiKit.marginTop(this, inviteList, page, -2, 6);

        TextView futureHead = UiKit.text(this, "Online play status", 19, UiKit.INK, true); UiKit.marginTop(this, futureHead, page, -2, 26);
        TextView foot = UiKit.text(this, "All seven games have solo local play. The six non-shooter games also offer local multiplayer modes. Campus Fireline is solo-only. Accepted-friend invitations create private lobby records, but live matches across separate phones are not connected yet.", 12, UiKit.MUTED, false);
        UiKit.marginTop(this, foot, page, -2, 20);
        return scroll;
    }

    private void addGameCard(String name, String description, String actionLabel, Runnable action, String badge) {
        LinearLayout card = UiKit.card(this); UiKit.marginTop(this, card, page, -2, 16);
        LinearLayout top = UiKit.row(this); card.addView(top);
        TextView title = UiKit.text(this, name, 19, UiKit.INK, true); top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView tag = UiKit.text(this, badge, 11, UiKit.GREEN, true); top.addView(tag);
        TextView copy = UiKit.text(this, description, 13, UiKit.MUTED, false); UiKit.marginTop(this, copy, card, -2, 7);
        android.widget.Button b = UiKit.button(this, actionLabel, true); UiKit.marginTop(this, b, card, 48, 14); b.setOnClickListener(v -> action.run());
    }

    private void addPlannedCard(String name, String details) {
        LinearLayout card = UiKit.card(this); card.setPadding(UiKit.dp(this, 15), UiKit.dp(this, 13), UiKit.dp(this, 15), UiKit.dp(this, 13));
        UiKit.marginTop(this, card, page, -2, 9);
        card.addView(UiKit.text(this, name, 15, UiKit.INK, true));
        UiKit.marginTop(this, UiKit.text(this, details, 12, UiKit.MUTED, false), card, -2, 5);
        card.addView(UiKit.text(this, "Planned", 10, UiKit.GOLD, true));
    }

    private void refreshCareer(){if(careerStatus==null)return;LocalGameProgression state=LocalGameProgressStore.load(this);int matches=0;for(Integer value:state.playsByGame().values())matches+=value;careerStatus.setText("RANK "+state.rank()+"  ·  "+state.experience()+" XP  ·  "+state.practiceCredits()+" Practice Points  ·  "+matches+" local matches");}
    @Override protected void onResume(){super.onResume();refreshCareer();}

    private void refreshFriends() {
        worker.execute(() -> {
            try {
                List<GameBackendService.Friend> data = backend.fetchAcceptedFriends();
                runOnUiThread(() -> {
                    friendList.removeAllViews();
                    if (data.isEmpty()) { friendStatus.setText("No accepted friends are available yet."); return; }
                    friendStatus.setText("Invite an accepted friend to a private lobby. Live online match sync is not available yet.");
                    for (GameBackendService.Friend friend : data) {
                        LinearLayout card = UiKit.card(this); card.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 12), UiKit.dp(this, 14), UiKit.dp(this, 12));
                        UiKit.marginTop(this, card, friendList, -2, 8);
                        card.addView(UiKit.text(this, friend.label, 15, UiKit.INK, true));
                        LinearLayout actions = UiKit.row(this); UiKit.marginTop(this, actions, card, 42, 8);
                        android.widget.Button games = UiKit.button(this, "Invite to a game…", true);
                        actions.addView(games, new LinearLayout.LayoutParams(-1, -1));
                        games.setOnClickListener(v -> chooseGame(friend));
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> friendStatus.setText("Friend list unavailable. Confirm sign-in, RLS, and the network, then retry."));
            }
        });
    }

    private void chooseLudoSeats(GameBackendService.Friend friend) {
        if (hostRoomByGame.containsKey("campus_ludo")) { invite(friend, "campus_ludo", 4); return; }
        String[] options = {"2 players", "3 players", "4 players"};
        new AlertDialog.Builder(this).setTitle("Choose a Ludo lobby size").setItems(options, (dialog, which) -> invite(friend, "campus_ludo", which + 2)).show();
    }

    private void chooseGame(GameBackendService.Friend friend) {
        String[] options = {"Campus Ludo", "Campus Duel", "Naija WHOT!", "Campus 8-Ball", "Campus Car Racing", "Campus Bike Racing"};
        new AlertDialog.Builder(this).setTitle("Invite " + friend.label + " to…").setItems(options, (dialog, which) -> {
            if (which == 0) chooseLudoSeats(friend);
            else if (which == 1) invite(friend, "campus_duel", 2);
            else if (which == 2) {
                String[] seats = {"2 players", "3 players", "4 players"};
                new AlertDialog.Builder(this).setTitle("Choose a WHOT lobby size").setItems(seats, (d, seat) -> invite(friend, "naija_whot", seat + 2)).show();
            } else if (which == 3) invite(friend, "billiards", 2);
            else if (which == 4) invite(friend, "kart_racing", 2);
            else invite(friend, "bike_racing", 2);
        }).show();
    }

    private void invite(GameBackendService.Friend friend, String gameId, int maxPlayers) {
        worker.execute(() -> {
            try {
                String roomId = hostRoomByGame.get(gameId);
                if (roomId == null) {
                    String inviteId = backend.createInvite(gameId, friend.id, maxPlayers);
                    roomId = backend.roomIdForInvite(inviteId);
                    hostRoomByGame.put(gameId, roomId);
                } else {
                    backend.inviteFriendToRoom(roomId, friend.id);
                }
                runOnUiThread(() -> {
                    inviteStatus.setText("Invite sent to " + friend.label + ". This is a private invitation/lobby only; live online match sync is not available yet.");
                    refreshInvites();
                });
            } catch (Exception e) {
                runOnUiThread(() -> inviteStatus.setText("Could not send invite. The room may be full or expired; confirm the migration and accepted-friend link."));
            }
        });
    }

    private void refreshInvites() {
        worker.execute(() -> {
            try {
                List<GameBackendService.Invite> data = backend.fetchIncomingInvites();
                runOnUiThread(() -> {
                    inviteList.removeAllViews();
                    if (data.isEmpty()) { inviteStatus.setText("No pending invitations."); return; }
                    inviteStatus.setText("Accept or decline an invitation. Accepted invites create a private lobby.");
                    for (GameBackendService.Invite invite : data) {
                        LinearLayout card = UiKit.card(this); card.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 12), UiKit.dp(this, 14), UiKit.dp(this, 12));
                        UiKit.marginTop(this, card, inviteList, -2, 8);
                        String game = gameTitle(invite.gameId);
                        card.addView(UiKit.text(this, invite.senderLabel + " invited you to " + game, 14, UiKit.INK, true));
                        LinearLayout actions = UiKit.row(this); UiKit.marginTop(this, actions, card, 42, 8);
                        android.widget.Button accept = UiKit.button(this, "Accept", true);
                        android.widget.Button decline = UiKit.button(this, "Decline", false);
                        actions.addView(accept, new LinearLayout.LayoutParams(0, -1, 1));
                        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1); p.leftMargin = UiKit.dp(this, 8); actions.addView(decline, p);
                        accept.setOnClickListener(v -> respond(invite, true)); decline.setOnClickListener(v -> respond(invite, false));
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> { inviteList.removeAllViews(); inviteStatus.setText("Invitations need the games migration applied to Supabase."); });
            }
        });
    }

    private void respond(GameBackendService.Invite invite, boolean accept) {
        worker.execute(() -> {
            try {
                backend.respondInvite(invite.id, accept);
                runOnUiThread(() -> {
                    inviteStatus.setText(accept ? "Invite accepted. The private lobby is created; live game-state sync is not yet available, so this does not start an online match." : "Invite declined.");
                    refreshInvites();
                });
            } catch (Exception e) {
                runOnUiThread(() -> inviteStatus.setText("Could not update invitation. It may have expired; refresh the inbox."));
            }
        });
    }

    private String gameTitle(String id) {
        if ("campus_ludo".equals(id)) return "Campus Ludo";
        if ("campus_duel".equals(id)) return "Campus Duel";
        if ("campus_fireline".equals(id)) return "Campus Fireline";
        if ("naija_whot".equals(id)) return "Naija WHOT!";
        if ("billiards".equals(id)) return "Billiards";
        if ("kart_racing".equals(id)) return "Campus Car Racing";
        if ("bike_racing".equals(id)) return "Campus Bike Racing";
        return "a game";
    }

    @Override protected void onDestroy() {
        live.close(); worker.shutdownNow(); super.onDestroy();
    }
}

package com.absuconnect.games.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import com.absuconnect.games.billiards.BilliardsEngine;

/** Original low-cost 2D pool rendering and drag-to-shoot input for Android devices. */
public final class PoolTableView extends View {
    public interface Listener { void onFrame(); void onShot(); void onPlacement(); }
    private static final int[] BALL_COLORS={Color.WHITE,0xffe8c93c,0xff2871c8,0xffcb3333,0xff7c45aa,0xffed8c2f,0xff308b54,0xff7b2f36,0xff151515,0xffe8c93c,0xff2871c8,0xffcb3333,0xff7c45aa,0xffed8c2f,0xff308b54,0xff7b2f36};
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private BilliardsEngine engine;
    private Listener listener;
    private float scale=1f,offsetX,offsetY,downX,downY,pointerX,pointerY;
    private boolean aiming,dragStartedNearCue;
    public PoolTableView(Context context,BilliardsEngine engine){super(context);this.engine=engine;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setListener(Listener l){listener=l;}
    public void setEngine(BilliardsEngine e){engine=e;aiming=false;invalidate();}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);scale=Math.min(w/BilliardsEngine.WIDTH,h/BilliardsEngine.HEIGHT);offsetX=(w-BilliardsEngine.WIDTH*scale)/2;offsetY=(h-BilliardsEngine.HEIGHT*scale)/2;}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);canvas.drawColor(0xff10251f);canvas.save();canvas.translate(offsetX,offsetY);canvas.scale(scale,scale);
        drawTable(canvas);drawBalls(canvas);drawAim(canvas);canvas.restore();
    }
    private void drawTable(Canvas c){
        p.setStyle(Paint.Style.FILL);p.setColor(0xff6e4326);c.drawRoundRect(new RectF(0,0,1000,500),28,28,p);
        p.setColor(0xffbd8b50);c.drawRoundRect(new RectF(11,11,989,489),22,22,p);
        p.setColor(0xff145744);c.drawRoundRect(new RectF(38,38,962,462),18,18,p);
        p.setColor(0xff1d7555);c.drawRect(62,62,938,438,p);
        p.setColor(0xff0d3329);
        float[][] holes={{62,62},{500,58},{938,62},{62,438},{500,442},{938,438}};
        for(float[] h:holes)c.drawCircle(h[0],h[1],25,p);
        p.setColor(0xffc6a56c);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(250,250,1.5f,p);c.drawLine(250,75,250,425,p);c.drawCircle(250,250,4,p);p.setStyle(Paint.Style.FILL);
        p.setColor(0x44ffffff);p.setTextSize(19);p.setTextAlign(Paint.Align.CENTER);c.drawText("ABSU  ·  8 BALL",500,28,p);
    }
    private void drawBalls(Canvas c){
        for(BilliardsEngine.Ball b:engine.balls())if(b.active){
            float r=BilliardsEngine.BALL_R;
            p.setStyle(Paint.Style.FILL);p.setColor(0x44000000);c.drawCircle(b.x+2,b.y+3,r+1,p);
            int color=BALL_COLORS[b.number];p.setColor(color);c.drawCircle(b.x,b.y,r,p);
            if(b.number>8){p.setColor(Color.WHITE);c.drawRect(b.x-r,b.y-r*0.42f,b.x+r,b.y+r*0.42f,p);p.setColor(color);c.drawRect(b.x-r,b.y-r*0.12f,b.x+r,b.y+r*0.12f,p);}
            if(b.number==0){p.setColor(0xffe4ece7);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.6f);c.drawCircle(b.x,b.y,r-1,p);p.setStyle(Paint.Style.FILL);}
            else{p.setColor(Color.WHITE);c.drawCircle(b.x,b.y,5.1f,p);p.setColor(0xff19221f);p.setTextSize(b.number==10?6.5f:8);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);c.drawText(String.valueOf(b.number),b.x,b.y+2.8f,p);}
            p.setColor(0x55ffffff);c.drawCircle(b.x-r*0.30f,b.y-r*0.32f,r*0.25f,p);
        }
    }
    private void drawAim(Canvas c){
        if(engine.isMoving()||engine.isGameOver())return;
        if(engine.needsCueBallPlacement()){
            p.setColor(0xffffffff);p.setTextSize(20);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);c.drawText("TAP THE TABLE TO PLACE THE CUE BALL",500,45,p);return;
        }
        BilliardsEngine.Ball cue=engine.cueBall();if(!cue.active)return;
        float dx,dy;
        if(aiming){if(dragStartedNearCue){dx=cue.x-pointerX;dy=cue.y-pointerY;}else{dx=pointerX-cue.x;dy=pointerY-cue.y;}}
        else{dx=cue.x-700;dy=cue.y-250;}
        float len=(float)Math.hypot(dx,dy);if(len<1)len=1;dx/=len;dy/=len;
        p.setColor(0xddf4e7c4);p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);
        c.drawLine(cue.x-dx*72,cue.y-dy*72,cue.x-dx*18,cue.y-dy*18,p);
        p.setColor(0xbaffffff);p.setStrokeWidth(1.4f);c.drawLine(cue.x+dx*15,cue.y+dy*15,cue.x+dx*220,cue.y+dy*220,p);p.setStyle(Paint.Style.FILL);
        if(aiming){p.setColor(0xfff0c46a);p.setStrokeWidth(5);c.drawLine(cue.x+dx*18,cue.y+dy*18,cue.x+dx*65,cue.y+dy*65,p);p.setStyle(Paint.Style.FILL);}
    }
    private float[] world(float sx,float sy){return new float[]{(sx-offsetX)/scale,(sy-offsetY)/scale};}
    @Override public boolean onTouchEvent(MotionEvent e){
        if(engine==null)return false;
        float[] pt=world(e.getX(),e.getY());float x=pt[0],y=pt[1];
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            if(engine.isMoving()||engine.isGameOver())return true;
            if(engine.needsCueBallPlacement()){if(engine.placeCueBall(x,y)&&listener!=null)listener.onPlacement();invalidate();return true;}
            BilliardsEngine.Ball cue=engine.cueBall();dragStartedNearCue=Math.hypot(x-cue.x,y-cue.y)<65;
            downX=x;downY=y;pointerX=x;pointerY=y;aiming=true;invalidate();return true;
        }
        if(e.getAction()==MotionEvent.ACTION_MOVE&&aiming){pointerX=x;pointerY=y;invalidate();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP&&aiming){
            pointerX=x;pointerY=y;BilliardsEngine.Ball cue=engine.cueBall();
            float dx=dragStartedNearCue?cue.x-x:x-cue.x,dy=dragStartedNearCue?cue.y-y:y-cue.y;
            float drag=(float)Math.hypot(x-downX,y-downY);
            float power=dragStartedNearCue?Math.max(0.18f,Math.min(1f,drag/250f)):Math.max(0.25f,Math.min(1f,0.25f+drag/280f));
            aiming=false;
            if(engine.shoot(dx,dy,power)&&listener!=null)listener.onShot();
            invalidate();return true;
        }
        if(e.getAction()==MotionEvent.ACTION_CANCEL){aiming=false;invalidate();return true;}
        return true;
    }
}

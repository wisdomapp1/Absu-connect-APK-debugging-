package com.absuconnect.games.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/** Read-only preview of the proposed NGN funding wallet and separate per-game coins. No balance or purchase exists. */
public final class WalletStoreActivity extends AppCompatActivity {
    private LinearLayout page;
    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(build());}
    private View build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(UiKit.BG);
        page=UiKit.vertical(this);page.setPadding(UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,30));scroll.addView(page);
        LinearLayout header=UiKit.row(this);page.addView(header);android.widget.Button back=UiKit.button(this,"‹  Game Center",false);header.addView(back);back.setOnClickListener(v->finish());
        TextView title=UiKit.text(this,"NGN Wallet & Game Coins",23,UiKit.INK,true);UiKit.marginTop(this,title,page,-2,15);
        UiKit.marginTop(this,UiKit.text(this,"Proposed flow: Paystack confirms a top-up, then credits your non-withdrawable account NGN game-wallet balance. Later, use that balance in-app to buy/convert into the separate coin wallet for one chosen game. No cash withdrawal or user-to-user transfer.",14,UiKit.MUTED,false),page,-2,5);
        LinearLayout balance=UiKit.card(this);UiKit.marginTop(this,balance,page,-2,16);
        balance.addView(UiKit.text(this,"NGN FUNDING WALLET",11,UiKit.GREEN,true));
        UiKit.marginTop(this,UiKit.text(this,"Not connected",22,UiKit.INK,true),balance,-2,7);
        UiKit.marginTop(this,UiKit.text(this,"No NGN balance, funding request or server ledger is configured. This screen does not create, store, receive or spend money.",13,UiKit.MUTED,false),balance,-2,5);
        LinearLayout topup=UiKit.card(this);UiKit.marginTop(this,topup,page,-2,12);topup.addView(UiKit.text(this,"Fund wallet / convert to game coins",17,UiKit.INK,true));
        UiKit.marginTop(this,UiKit.text(this,"Paystack would fund the account-level NGN balance only; it would not directly sell a game's coin pack. Payment verification would credit that balance, then a separate in-app conversion would credit the selected game's coin wallet. No server checkout, verified webhook, NGN credit or conversion is connected.",13,UiKit.MUTED,false),topup,-2,5);
        UiKit.marginTop(this,UiKit.text(this,"Illustrative examples only — not offers or final rates: ₦1,000 already in the account NGN wallet could later convert to 10,000 coins at a hypothetical 10:1 rate. The proposed minimum Paystack top-up example is ₦1,500 credited to the NGN wallet; at the same assumed rate it could later convert to 15,000 game coins. The ₦1,000 example is not a top-up offer. Rates, minimum, item prices and policy approval are not final.",12,UiKit.MUTED,false),topup,-2,7);
        android.widget.Button disabledTopup=UiKit.button(this,"Funding and conversion not connected",false);disabledTopup.setEnabled(false);UiKit.marginTop(this,disabledTopup,topup,48,11);
        LinearLayout perGame=UiKit.card(this);UiKit.marginTop(this,perGame,page,-2,12);perGame.addView(UiKit.text(this,"SEPARATE GAME COIN WALLETS",11,UiKit.GREEN,true));
        UiKit.marginTop(this,UiKit.text(this,"Campus Duel · Campus Fireline · Car Racing · Bike Racing · Ludo · Naija WHOT! · 8-Ball\n\nEach game would have its own balance. Every balance is currently not connected; no coins are issued or transferable.",13,UiKit.MUTED,false),perGame,-2,7);
        for(String game:new String[]{"Campus Duel","Campus Fireline","Campus Car Racing","Campus Bike Racing","Campus Ludo","Naija WHOT!","Campus 8-Ball"})addGameWallet(game);
        addSection("Campus Duel","Future fighter characters, melee-weapon styles, skills, upgrades and skins. Item prices may vary by strength; not connected.",new String[]{"Fighter / upgrade preview","Training weapon / skill preview","Skin preview"});
        addSection("Campus Fireline","Future operator characters, fictional gun profiles, skills, upgrades and skins. Item prices may vary by strength; not connected.",new String[]{"Operator preview","Gun / upgrade preview","Map and skin preview"});
        addSection("Car racing","Future car profiles, vehicle upgrades and liveries bought with this game's separate coins.",new String[]{"Car / upgrade preview","Paint and livery preview"});
        addSection("Bike racing","Future motorcycle profiles, vehicle upgrades and liveries bought with this game's separate coins.",new String[]{"Motorcycle / upgrade preview","Paint and livery preview"});
        addSection("Ludo, WHOT and 8-Ball","Future game-specific coin balances and optional cosmetics may be considered separately.",new String[]{"Board / dice preview","Card-back preview","Table / cue preview"});
        LinearLayout note=UiKit.card(this);note.setBackground(UiKit.rounded(0xfff0e8d7,this));UiKit.marginTop(this,note,page,-2,18);
        note.addView(UiKit.text(this,"Review required before release",15,UiKit.INK,true));
        UiKit.marginTop(this,UiKit.text(this,"Real funding and coin purchases remain disabled pending the separate compliance review of Nigerian stored-value/e-money rules, Paystack terms and the chosen app-store payment policy. A secure server-owned funding wallet and seven separate game ledgers would be required. Local Career XP and free Practice Points are a different offline-only test system, not money or game coins.",12,UiKit.MUTED,false),note,-2,6);
        return scroll;
    }
    private void addSection(String heading,String copy,String[] products){
        TextView h=UiKit.text(this,heading,19,UiKit.INK,true);UiKit.marginTop(this,h,page,-2,22);
        UiKit.marginTop(this,UiKit.text(this,copy,13,UiKit.MUTED,false),page,-2,4);
        for(String product:products){
            LinearLayout card=UiKit.card(this);card.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));UiKit.marginTop(this,card,page,-2,9);
            card.addView(UiKit.text(this,product,15,UiKit.INK,true));
            UiKit.marginTop(this,UiKit.text(this,"Game coin balance and price not connected",12,UiKit.MUTED,false),card,-2,3);
            android.widget.Button disabled=UiKit.button(this,"Purchase not connected",false);disabled.setEnabled(false);UiKit.marginTop(this,disabled,card,44,7);
        }
    }
    private void addGameWallet(String name){LinearLayout card=UiKit.card(this);card.setPadding(UiKit.dp(this,13),UiKit.dp(this,10),UiKit.dp(this,13),UiKit.dp(this,10));UiKit.marginTop(this,card,page,-2,7);LinearLayout row=UiKit.row(this);row.addView(UiKit.text(this,name,14,UiKit.INK,true),new LinearLayout.LayoutParams(0,-2,1));row.addView(UiKit.text(this,"NOT CONNECTED",10,UiKit.MUTED,true));card.addView(row);UiKit.marginTop(this,UiKit.text(this,"This game's coin balance and conversion flow do not exist yet.",11,UiKit.MUTED,false),card,-2,4);}
}

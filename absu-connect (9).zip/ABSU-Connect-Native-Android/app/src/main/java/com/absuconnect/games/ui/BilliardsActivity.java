package com.absuconnect.games.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.media.ToneGenerator;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.billiards.BilliardsEngine;
import com.absuconnect.games.action.LocalGameProgressStore;

/** Original touch-playable 2D 8-ball pool. Local CPU and shared-device modes; no live online sync. */
public final class BilliardsActivity extends AppCompatActivity implements PoolTableView.Listener {
    private final Handler handler=new Handler();
    private BilliardsEngine game;
    private PoolTableView table;
    private GameSound sound;
    private android.widget.Button soundButton;
    private TextView title,status,scoreLine;
    private boolean vsCpu=true, cpuQueued=false, resultDialogShown=false;
    private long lastFrame;
    @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff123b31);getWindow().getDecorView().setSystemUiVisibility(0);sound=new GameSound(this);game=new BilliardsEngine();setContentView(buildView());chooseMode();}
    private View buildView(){
        LinearLayout root=UiKit.vertical(this);root.setBackgroundColor(0xff10251f);root.setPadding(UiKit.dp(this,10),UiKit.dp(this,8),UiKit.dp(this,10),UiKit.dp(this,8));
        LinearLayout bar=UiKit.row(this);root.addView(bar,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
        title=UiKit.text(this,"CAMPUS 8-BALL",17,0xffffffff,true);bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        soundButton=UiKit.button(this,sound.isMuted()?"Sound off":"Sound on",false);bar.addView(soundButton);soundButton.setOnClickListener(v->{boolean muted=sound.toggleMuted();soundButton.setText(muted?"Sound off":"Sound on");if(!muted)sound.play(ToneGenerator.TONE_PROP_ACK,90);});
        android.widget.Button restart=UiKit.button(this,"New rack",false);bar.addView(restart);restart.setOnClickListener(v->chooseMode());
        table=new PoolTableView(this,game);table.setListener(this);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,0,1);tp.topMargin=UiKit.dp(this,5);root.addView(table,tp);
        scoreLine=UiKit.text(this,"",12,0xffd6e9df,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,UiKit.dp(this,26));root.addView(scoreLine,sp);
        status=UiKit.text(this,"",13,0xffffffff,false);root.addView(status,new LinearLayout.LayoutParams(-1,UiKit.dp(this,27)));
        refreshLabels();return root;
    }
    private void chooseMode(){
        handler.removeCallbacksAndMessages(null);lastFrame=0;cpuQueued=false;
        String[] choices={"Solo practice vs CPU","Pass & play (2 players on this device)"};
        new AlertDialog.Builder(this).setTitle("Start a new 8-ball rack").setItems(choices,(d,w)->{
            vsCpu=w==0;game=new BilliardsEngine();resultDialogShown=false;cpuQueued=false;table.setEngine(game);refreshLabels();maybeCpuShot();
        }).setCancelable(false).show();
    }
    private void refreshLabels(){
        if(table==null)return;
        String mode=vsCpu?"SOLO · CPU":"LOCAL PASS & PLAY";
        title.setText("CAMPUS 8-BALL   /   "+mode);
        String p1=game.groupLabel(0),p2=game.groupLabel(1);
        scoreLine.setText("PLAYER 1  ·  "+p1+"                 PLAYER 2"+(vsCpu?" / CPU":"")+"  ·  "+p2+"     |     SHOOTER: "+(game.currentPlayer()+1));
        status.setText(game.message());table.invalidate();
        if(game.isGameOver()&&!resultDialogShown){resultDialogShown=true;boolean won=game.winner()==0;sound.play(won?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_NACK,300);LocalGameProgressStore.MatchReward reward=LocalGameProgressStore.recordMatch(this,"billiards",won?65:38,won?45:25);android.widget.Toast.makeText(this,"Career +"+reward.xp+" XP · +"+reward.credits+" Practice Points"+(reward.rankUp?" · Rank "+reward.rank+" unlocked!":""),android.widget.Toast.LENGTH_LONG).show();handler.post(()->{
            TextView resultTitle=UiKit.text(this,won?"✦  RACK WON!  ✦":"RACK COMPLETE",22,won?UiKit.GREEN:UiKit.GOLD,true);resultTitle.setGravity(Gravity.CENTER);
            AlertDialog dialog=new AlertDialog.Builder(this).setCustomTitle(resultTitle).setMessage("Rack complete · local progress saved. Start another rack?").setPositiveButton("New rack",(d,w)->chooseMode()).setNegativeButton("Back to Game Center",(d,w)->finish()).create();
            dialog.setOnShowListener(d->{resultTitle.setScaleX(.75f);resultTitle.setScaleY(.75f);resultTitle.setAlpha(0f);resultTitle.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(400).start();});dialog.show();
        });}
    }
    @Override public void onFrame(){
        if(game.isMoving()){
            long now=System.nanoTime();float dt=lastFrame==0?0.016f:(now-lastFrame)/1_000_000_000f;lastFrame=now;
            game.update(dt);table.invalidate();
            if(!game.isMoving()){lastFrame=0;refreshLabels();maybeCpuShot();}
            else handler.postDelayed(()->onFrame(),16);
        }
    }
    @Override public void onShot(){lastFrame=0;sound.play(ToneGenerator.TONE_PROP_ACK,130);refreshLabels();onFrame();}
    @Override public void onPlacement(){refreshLabels();maybeCpuShot();}
    private void maybeCpuShot(){
        if(!vsCpu||game.currentPlayer()!=1||game.isGameOver()||game.isMoving()||game.needsCueBallPlacement()||cpuQueued)return;
        cpuQueued=true;status.setText("CPU is lining up a shot…");handler.postDelayed(()->{
            cpuQueued=false;if(isFinishing()||game.currentPlayer()!=1||game.isGameOver())return;
            game.shootCpu();refreshLabels();onFrame();
        },700);
    }
    @Override protected void onPause(){handler.removeCallbacksAndMessages(null);lastFrame=0;cpuQueued=false;super.onPause();}
    @Override protected void onResume(){super.onResume();if(game!=null){if(game.isMoving())onFrame();else maybeCpuShot();}}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(sound!=null)sound.close();super.onDestroy();}
}

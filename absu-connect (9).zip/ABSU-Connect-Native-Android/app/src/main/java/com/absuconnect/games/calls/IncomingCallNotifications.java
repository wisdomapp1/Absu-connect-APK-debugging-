package com.absuconnect.games.calls;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.Person;
import androidx.core.content.ContextCompat;
import com.absuconnect.games.ui.CallActivity;
import com.absuconnect.games.ui.MainActivity;

/** High-importance incoming-call notification with Answer/Decline and full-screen presentation where allowed. */
public final class IncomingCallNotifications {
    public static final String CHANNEL_ID = "absu_calls";
    private IncomingCallNotifications() { }

    public static int notificationId(String callId) { return 310000 + (callId == null ? 1 : Math.abs(callId.hashCode() % 100000)); }

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "ABSU Connect Calls", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Incoming voice and video calls");
        channel.enableVibration(true);
        channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        channel.setBypassDnd(false);
        manager.createNotificationChannel(channel);
    }

    public static void show(Context context, String callId, String callType, String callerName) {
        if (callId == null || callId.trim().isEmpty()) return;
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        ensureChannel(context);
        String name = callerName == null || callerName.trim().isEmpty() ? "ABSU Connect friend" : callerName;
        boolean video = "video".equalsIgnoreCase(callType);
        Intent open = new Intent(context, CallActivity.class)
                .putExtra("call_id", callId).putExtra("call_type", video ? "video" : "audio")
                .putExtra("incoming", true).putExtra("peer_name", name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fullScreen = PendingIntent.getActivity(context, notificationId(callId), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent answer = new Intent(context, CallActivity.class)
                .putExtra("call_id", callId).putExtra("call_type", video ? "video" : "audio")
                .putExtra("incoming", true).putExtra("action", "accept").putExtra("peer_name", name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent answerIntent = PendingIntent.getActivity(context, notificationId(callId) + 1, answer,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent decline = new Intent(context, CallActionReceiver.class)
                .setAction(CallActionReceiver.ACTION_DECLINE).putExtra("call_id", callId);
        PendingIntent declineIntent = PendingIntent.getBroadcast(context, notificationId(callId) + 2, decline,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Person person = new Person.Builder().setName(name).setImportant(true).build();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle(video ? "Incoming video call" : "Incoming voice call")
                .setContentText(name + " is calling you")
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true).setAutoCancel(false)
                .setFullScreenIntent(fullScreen, Build.VERSION.SDK_INT < 34 || context.getSystemService(NotificationManager.class).canUseFullScreenIntent())
                .setContentIntent(fullScreen);
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setStyle(NotificationCompat.CallStyle.forIncomingCall(person, declineIntent, answerIntent).setIsVideo(video));
        } else {
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Decline", declineIntent)
                    .addAction(android.R.drawable.sym_action_call, "Answer", answerIntent);
        }
        try { NotificationManagerCompat.from(context).notify(notificationId(callId), builder.build()); }
        catch (SecurityException ignored) { }
    }

    public static void cancel(Context context, String callId) {
        if (callId != null) NotificationManagerCompat.from(context).cancel(notificationId(callId));
    }

    public static PendingIntent hangupPendingIntent(Context context, String callId) {
        Intent end = new Intent(context, CallActionReceiver.class).setAction(CallActionReceiver.ACTION_END).putExtra("call_id", callId);
        return PendingIntent.getBroadcast(context, notificationId(callId) + 3, end,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static PendingIntent callActivityPendingIntent(Context context, String callId) {
        Intent open = new Intent(context, CallActivity.class).putExtra("call_id", callId)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(context, notificationId(callId) + 4, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}

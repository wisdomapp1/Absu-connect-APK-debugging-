package com.absuconnect.games.ui;

import android.app.Activity;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.absuconnect.games.auth.SupabaseAuthRepository;

final class SignInViews {
    private SignInViews() {}
    static View create(Activity activity) {
        ScrollView scroll = new ScrollView(activity); scroll.setFillViewport(true); scroll.setBackgroundColor(UiKit.BG);
        LinearLayout page = UiKit.vertical(activity); page.setPadding(UiKit.dp(activity, 26), UiKit.dp(activity, 44), UiKit.dp(activity, 26), UiKit.dp(activity, 28));
        scroll.addView(page);
        TextView eyebrow = UiKit.text(activity, "ABSU CONNECT  /  GAMES", 12, UiKit.GREEN, true);
        page.addView(eyebrow);
        TextView title = UiKit.text(activity, "Play between classes.", 29, UiKit.INK, true);
        UiKit.marginTop(activity, title, page, -2, 14);
        TextView copy = UiKit.text(activity, "Sign in with your existing campus account. Games stay in the app; invitations are limited to accepted friends.", 15, UiKit.MUTED, false);
        UiKit.marginTop(activity, copy, page, -2, 8);

        LinearLayout card = UiKit.card(activity);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = UiKit.dp(activity, 28); page.addView(card, cp);
        TextView label = UiKit.text(activity, "Your account", 18, UiKit.INK, true); card.addView(label);
        EditText email = input(activity, "Email address"); email.setInputType(33); UiKit.marginTop(activity, email, card, 54, 12);
        EditText password = input(activity, "Password"); password.setInputType(129); UiKit.marginTop(activity, password, card, 54, 12);
        TextView status = UiKit.text(activity, "", 13, UiKit.MUTED, false); UiKit.marginTop(activity, status, card, -2, 8);
        android.widget.Button signIn = UiKit.button(activity, "Sign in", true); UiKit.marginTop(activity, signIn, card, 52, 12);
        signIn.setOnClickListener(v -> {
            String address = email.getText().toString().trim(); String secret = password.getText().toString();
            if (address.isEmpty() || secret.isEmpty()) { status.setText("Enter your email and password."); return; }
            signIn.setEnabled(false); status.setText("Signing in securely…");
            new SupabaseAuthRepository(activity).signIn(address, secret, (session, error) -> {
                signIn.setEnabled(true);
                if (session == null) { status.setText(error == null ? "Could not sign in." : error); return; }
                activity.startActivity(new Intent(activity, GameHubActivity.class)); activity.finish();
            });
        });
        TextView foot = UiKit.text(activity, "This starter signs into the Supabase project used by the supplied app. Passwords are sent only to the configured Auth endpoint and are not saved locally.", 12, UiKit.MUTED, false);
        foot.setGravity(Gravity.CENTER_VERTICAL); UiKit.marginTop(activity, foot, page, -2, 18);
        return scroll;
    }
    private static EditText input(Activity a, String hint) {
        EditText e = new EditText(a); e.setSingleLine(true); e.setHint(hint); e.setTextSize(15);
        e.setPadding(UiKit.dp(a, 14), 0, UiKit.dp(a, 14), 0); e.setBackground(UiKit.rounded(UiKit.PAPER, a));
        return e;
    }
}

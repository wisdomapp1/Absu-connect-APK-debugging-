package com.absuconnect.games.whot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Original Nigerian WHOT rules engine. Independent of Android UI so it can be reused and tested. */
public final class WhotEngine {
    public static final String[] SUITS = {"Ball", "Angle", "Cross", "Carpet", "Star"};
    public static final class Card {
        public final int suit; // 0..4, or -1 for a WHOT wild
        public final int number; // 20 for WHOT
        Card(int suit, int number) { this.suit = suit; this.number = number; }
        public boolean isWhot() { return suit < 0; }
        public String label() { return isWhot() ? "WHOT 20" : SUITS[suit] + " " + number; }
        public String shortLabel() { return isWhot() ? "WHOT" : SUITS[suit] + "\n" + number; }
        @Override public String toString() { return label(); }
    }
    public static final class TurnResult {
        public final String message;
        public final boolean gameOver;
        TurnResult(String message, boolean gameOver) { this.message = message; this.gameOver = gameOver; }
    }

    private final Random random;
    private final int playerCount;
    private final List<List<Card>> hands = new ArrayList<>();
    private final List<Card> drawPile = new ArrayList<>();
    private final List<Card> discardPile = new ArrayList<>();
    private int currentPlayer;
    private int activeSuit;
    private int pendingPenalty;
    private int pendingRank;
    private int winner = -1;
    private String message = "";

    public WhotEngine(int players) { this(players, new Random()); }
    public WhotEngine(int players, long seed) { this(players, new Random(seed)); }
    private WhotEngine(int players, Random random) {
        if (players < 2 || players > 4) throw new IllegalArgumentException("WHOT supports 2 to 4 players.");
        this.random = random;
        this.playerCount = players;
        for (int i=0; i<players; i++) hands.add(new ArrayList<>());
        reset();
    }
    public void reset() {
        drawPile.clear(); discardPile.clear(); winner = -1; pendingPenalty = 0; pendingRank = 0; currentPlayer = 0;
        for (List<Card> hand : hands) hand.clear();
        // Nigerian pack: five uneven shape suits plus five wild 20s (54 cards).
        int[][] ranks = {
            {1,2,3,4,5,7,8,10,11,12,13,14},
            {1,2,3,4,5,7,8,10,11,12,13,14},
            {1,2,3,5,7,10,11,13,14},
            {1,2,3,5,7,10,11,13,14},
            {1,2,3,4,5,7,8}
        };
        for (int suit=0; suit<ranks.length; suit++) for (int n : ranks[suit]) drawPile.add(new Card(suit,n));
        for (int i=0; i<5; i++) drawPile.add(new Card(-1,20));
        Collections.shuffle(drawPile, random);
        for (int round=0; round<6; round++) for (List<Card> hand : hands) hand.add(drawPile.remove(drawPile.size()-1));
        Card opening = drawPile.remove(drawPile.size()-1);
        while (opening.isWhot()) { drawPile.add(opening); Collections.shuffle(drawPile, random); opening=drawPile.remove(drawPile.size()-1); }
        discardPile.add(opening);
        activeSuit = opening.suit;
        message = "Your turn. Match the shape or number, or play WHOT.";
    }
    public int playerCount() { return playerCount; }
    public int currentPlayer() { return currentPlayer; }
    public int winner() { return winner; }
    public boolean isGameOver() { return winner >= 0; }
    public boolean hasPenalty() { return pendingPenalty > 0; }
    public int pendingPenalty() { return pendingPenalty; }
    public int activeSuit() { return activeSuit; }
    public Card topCard() { return discardPile.get(discardPile.size()-1); }
    public int handSize(int player) { return hands.get(player).size(); }
    public List<Card> currentHand() { return Collections.unmodifiableList(new ArrayList<>(hands.get(currentPlayer))); }
    public List<Card> handFor(int player) { return Collections.unmodifiableList(new ArrayList<>(hands.get(player))); }
    public int drawCount() { return drawPile.size(); }
    public int discardCount() { return discardPile.size(); }
    public String message() { return message; }
    public boolean isPlayable(Card card) {
        if (isGameOver() || !hands.get(currentPlayer).contains(card)) return false;
        if (pendingPenalty > 0) return card.number == pendingRank;
        return card.isWhot() || card.suit == activeSuit || card.number == topCard().number;
    }
    public boolean hasPlayableCard() {
        for (Card c : hands.get(currentPlayer)) if (isPlayable(c)) return true;
        return false;
    }
    public TurnResult play(Card card, int declaredSuit) {
        if (!isPlayable(card)) throw new IllegalArgumentException("That card cannot be played now.");
        if (card.isWhot() && (declaredSuit < 0 || declaredSuit >= SUITS.length)) throw new IllegalArgumentException("Choose a shape for WHOT.");
        List<Card> hand = hands.get(currentPlayer);
        hand.remove(card);
        discardPile.add(card);
        if (card.isWhot()) activeSuit = declaredSuit; else activeSuit = card.suit;
        int actor = currentPlayer;
        if (hand.isEmpty()) {
            winner = actor;
            message = labelFor(actor) + " wins!";
            return new TurnResult(message, true);
        }
        if (card.number == 2 || card.number == 5) {
            pendingRank = card.number;
            pendingPenalty += card.number == 2 ? 2 : 3;
            currentPlayer = (actor + 1) % playerCount;
            message = labelFor(actor) + " played " + card.number + ". " + labelFor(currentPlayer) + " may stack a " + card.number + " or draw " + pendingPenalty + ".";
        } else if (card.number == 14) {
            int amount = 0;
            for (int p=0; p<playerCount; p++) if (p != actor) { drawCards(p, 1); amount++; }
            currentPlayer = (actor + 1) % playerCount;
            message = "General Market: every opponent draws 1. " + labelFor(currentPlayer) + " plays next.";
        } else if (card.number == 1) {
            currentPlayer = actor;
            message = "Hold on: " + labelFor(actor) + " plays again.";
        } else if (card.number == 8) {
            currentPlayer = (actor + (card.suit == 4 ? 3 : 2)) % playerCount;
            message = card.suit == 4 ? "Star 8: two turns suspended." : "Suspension: next player misses a turn.";
        } else {
            currentPlayer = (actor + 1) % playerCount;
            message = card.isWhot() ? "WHOT! " + SUITS[activeSuit] + " called. " + labelFor(currentPlayer) + " plays next." : labelFor(currentPlayer) + " plays next.";
        }
        return new TurnResult(message, false);
    }
    public TurnResult drawForCurrentPlayer() {
        if (isGameOver()) throw new IllegalStateException("The game is over.");
        int amount = pendingPenalty > 0 ? pendingPenalty : 1;
        int actor = currentPlayer;
        drawCards(actor, amount);
        pendingPenalty = 0; pendingRank = 0;
        currentPlayer = (actor + 1) % playerCount;
        message = labelFor(actor) + " drew " + amount + (amount == 1 ? " card." : " cards.") + " " + labelFor(currentPlayer) + " plays next.";
        return new TurnResult(message, false);
    }
    public Card chooseCpuCard() {
        List<Card> hand = hands.get(currentPlayer);
        Card best = null;
        int bestScore = Integer.MIN_VALUE;
        int[] suitCounts = new int[5];
        for (Card c : hand) if (!c.isWhot()) suitCounts[c.suit]++;
        for (Card c : hand) if (isPlayable(c)) {
            int score = (c.number == 2 || c.number == 5 || c.number == 8 || c.number == 14 ? 12 : 0) + (c.isWhot() ? -2 : 0) + random.nextInt(4);
            if (score > bestScore) { bestScore=score; best=c; }
        }
        return best;
    }
    public int cpuSuitChoice() {
        int[] counts = new int[5];
        for (Card c : hands.get(currentPlayer)) if (!c.isWhot()) counts[c.suit]++;
        int best=0; for (int i=1;i<counts.length;i++) if (counts[i]>counts[best]) best=i;
        return best;
    }
    private void drawCards(int player, int amount) {
        for (int i=0; i<amount; i++) {
            if (drawPile.isEmpty()) recycleDiscards();
            if (drawPile.isEmpty()) return;
            hands.get(player).add(drawPile.remove(drawPile.size()-1));
        }
    }
    private void recycleDiscards() {
        if (discardPile.size() <= 1) return;
        Card top = discardPile.remove(discardPile.size()-1);
        drawPile.addAll(discardPile);
        discardPile.clear(); discardPile.add(top);
        Collections.shuffle(drawPile, random);
    }
    private String labelFor(int player) { return player == 0 ? "You" : (playerCount == 2 && player == 1 ? "CPU" : "Player " + (player+1)); }
}

package com.absuconnect.games.multiplayer.examples;

import com.absuconnect.games.multiplayer.AllowlistGameActionCodec;

/**
 * Example input adapter for two seats sharing one Campus Duel arena. Inputs are intents only:
 * an authoritative match service must calculate movement, hit detection, damage and round results.
 */
public final class FighterArenaAdapter extends AllowlistGameActionCodec {
    public FighterArenaAdapter(){super("campus_duel","ready","move","attack","guard","dodge","skill","resign");}
}

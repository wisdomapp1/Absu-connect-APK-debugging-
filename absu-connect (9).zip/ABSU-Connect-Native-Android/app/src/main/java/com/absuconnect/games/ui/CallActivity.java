package com.absuconnect.games.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.absuconnect.games.NetworkMode;
import com.absuconnect.games.auth.AuthSession;
import com.absuconnect.games.auth.AuthSessionStore;
import com.absuconnect.games.backend.CallRealtimeChannel;
import com.absuconnect.games.backend.NativeSupabaseApi;
import com.absuconnect.games.calls.CallOngoingService;
import com.absuconnect.games.calls.IncomingCallNotifications;
import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.audio.JavaAudioDeviceModule;
import org.webrtc.MediaConstraints;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.RtpSender;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native one-to-one WebRTC voice/video call screen. Signaling and call state are authenticated by Supabase. */
public final class CallActivity extends AppCompatActivity {
    private static final int REQ_CALL_MEDIA = 8201;
    private static final int DARK = Color.rgb(20, 17, 29);
    private static final int PURPLE = Color.rgb(109, 69, 217);
    private static volatile boolean factoryInitialized;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<IceCandidate> pendingRemoteCandidates = new ArrayList<>();
    private final List<JSONObject> pendingSignals = new ArrayList<>();
    private final Object pendingSignalsLock = new Object();
    private final Object pendingCandidatesLock = new Object();
    private NativeSupabaseApi api;
    private AuthSession session;
    private CallRealtimeChannel signaling;
    private PeerConnectionFactory factory;
    private PeerConnection peerConnection;
    private AudioSource audioSource;
    private AudioTrack audioTrack;
    private VideoSource videoSource;
    private VideoTrack localVideoTrack;
    private VideoTrack remoteVideoTrack;
    private CameraVideoCapturer cameraCapturer;
    private SurfaceTextureHelper surfaceTextureHelper;
    private EglBase eglBase;
    private SurfaceViewRenderer remoteRenderer, localRenderer;
    private FrameLayout videoStage;
    private LinearLayout controls, root;
    private TextView stateLabel, peerLabel, durationLabel;
    private Button acceptButton, declineButton, muteButton, speakerButton, cameraButton, flipButton, endButton;
    private CheckBox dataSaverBox;
    private String callId, callType, peerId, peerName;
    private boolean outgoing, incoming, accepted, channelReady, localMediaReady, connected, isMuted, isSpeaker, cameraEnabled = true, isDataSaver, finished;
    private long connectedAt;
    private int elapsedSeconds;
    private Runnable durationTick, ringTimeout;
    private AudioManager audioManager;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        api = new NativeSupabaseApi(this);
        session = AuthSessionStore.load(this);
        Intent intent = getIntent();
        callId = intent.getStringExtra("call_id");
        callType = intent.getStringExtra("call_type");
        if (callType == null) callType = "audio";
        outgoing = intent.getBooleanExtra("outgoing", false);
        incoming = intent.getBooleanExtra("incoming", !outgoing);
        peerId = intent.getStringExtra("peer_id");
        peerName = intent.getStringExtra("peer_name");
        if (peerName == null || peerName.trim().isEmpty()) peerName = "ABSU Connect friend";
        if (session == null) { toast("Sign in to make calls."); finish(); return; }
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        buildCallUi();
        if (outgoing) beginOutgoingAfterPermission();
        else loadIncomingCall();
        if ("decline".equals(intent.getStringExtra("action"))) main.postDelayed(this::declineIncoming, 250L);
    }

    private void buildCallUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(DARK); root.setPadding(dp(16), dp(18), dp(16), dp(20));
        peerLabel = makeText(peerName, 24, Color.WHITE, true); peerLabel.setGravity(Gravity.CENTER); root.addView(peerLabel);
        stateLabel = makeText(outgoing ? "Preparing your call…" : "Incoming " + ("video".equals(callType) ? "video" : "voice") + " call", 14, Color.LTGRAY, false); stateLabel.setGravity(Gravity.CENTER); addTop(stateLabel, 8);
        durationLabel = makeText("", 14, Color.LTGRAY, false); durationLabel.setGravity(Gravity.CENTER); addTop(durationLabel, 4);
        videoStage = new FrameLayout(this); videoStage.setBackgroundColor(Color.rgb(35, 30, 45));
        LinearLayout.LayoutParams stageParams = new LinearLayout.LayoutParams(-1, 0, 1); stageParams.topMargin = dp(16); stageParams.bottomMargin = dp(18); root.addView(videoStage, stageParams);
        remoteRenderer = new SurfaceViewRenderer(this); remoteRenderer.setVisibility("video".equals(callType) ? View.VISIBLE : View.GONE);
        videoStage.addView(remoteRenderer, new FrameLayout.LayoutParams(-1, -1));
        localRenderer = new SurfaceViewRenderer(this); localRenderer.setVisibility(View.GONE);
        FrameLayout.LayoutParams localParams = new FrameLayout.LayoutParams(dp(116), dp(160), Gravity.TOP | Gravity.END); localParams.setMargins(0, dp(12), dp(12), 0);
        videoStage.addView(localRenderer, localParams);
        TextView placeholder = makeText("ABSU Connect", 17, Color.LTGRAY, true); placeholder.setGravity(Gravity.CENTER);
        videoStage.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
        controls = new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL); root.addView(controls);
        if ("video".equals(callType)) {
            dataSaverBox = new CheckBox(this);
            dataSaverBox.setText("Low data video · 240p / 12 fps");
            dataSaverBox.setTextColor(Color.WHITE);
            dataSaverBox.setChecked(NetworkMode.isLowData(this));
            dataSaverBox.setOnCheckedChangeListener((v, checked) -> NetworkMode.setLowData(this, checked));
            controls.addView(dataSaverBox);
        }
        isDataSaver = NetworkMode.isLowData(this);
        LinearLayout topActions = new LinearLayout(this); topActions.setGravity(Gravity.CENTER); controls.addView(topActions);
        muteButton = actionButton("Mute"); speakerButton = actionButton("Speaker"); cameraButton = actionButton("Camera off"); flipButton = actionButton("Flip");
        topActions.addView(muteButton); topActions.addView(speakerButton);
        if ("video".equals(callType)) { topActions.addView(cameraButton); topActions.addView(flipButton); }
        LinearLayout bottomActions = new LinearLayout(this); bottomActions.setGravity(Gravity.CENTER); addTop(bottomActions, 12); controls.addView(bottomActions);
        acceptButton = actionButton("Answer"); declineButton = actionButton("Decline"); endButton = actionButton("End call");
        if (incoming) { bottomActions.addView(acceptButton); bottomActions.addView(declineButton); }
        else bottomActions.addView(endButton);
        acceptButton.setOnClickListener(v -> requestAccept());
        declineButton.setOnClickListener(v -> declineIncoming());
        endButton.setOnClickListener(v -> endCall("ended"));
        muteButton.setOnClickListener(v -> toggleMute());
        speakerButton.setOnClickListener(v -> toggleSpeaker());
        cameraButton.setOnClickListener(v -> toggleCamera());
        flipButton.setOnClickListener(v -> flipCamera());
        setContentView(root);
        remoteRenderer.setZOrderMediaOverlay(false);
        localRenderer.setZOrderMediaOverlay(true);
        muteButton.setEnabled(false); speakerButton.setEnabled(false); cameraButton.setEnabled(false); flipButton.setEnabled(false);
        endButton.setEnabled(false);
    }

    private Button actionButton(String label) {
        Button button = new Button(this); button.setText(label); button.setAllCaps(false); button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf("End call".equals(label) || "Decline".equals(label) ? Color.rgb(191, 45, 65) : PURPLE));
        button.setMinHeight(dp(46)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(4), dp(2), dp(4), dp(2)); button.setLayoutParams(p); return button;
    }

    private TextView makeText(String text, float size, int color, boolean bold) {
        TextView view = new TextView(this); view.setText(text); view.setTextSize(size); view.setTextColor(color);
        view.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); return view;
    }
    private void addTop(View v, int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); root.addView(v, p); }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void beginOutgoingAfterPermission() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO) || ("video".equals(callType) && !hasPermission(Manifest.permission.CAMERA))) {
            ArrayList<String> ask = new ArrayList<>(); if (!hasPermission(Manifest.permission.RECORD_AUDIO)) ask.add(Manifest.permission.RECORD_AUDIO);
            if ("video".equals(callType) && !hasPermission(Manifest.permission.CAMERA)) ask.add(Manifest.permission.CAMERA);
            requestPermissions(ask.toArray(new String[0]), REQ_CALL_MEDIA); return;
        }
        startOutgoingCall();
    }

    private void startOutgoingCall() {
        if (peerId == null || peerId.trim().isEmpty()) { toast("The friend account could not be identified."); finish(); return; }
        isDataSaver = dataSaverBox != null ? dataSaverBox.isChecked() : NetworkMode.isLowData(this);
        NetworkMode.setLowData(this, isDataSaver);
        stateLabel.setText("Calling " + peerName + "…");
        acceptButton.setVisibility(View.GONE); declineButton.setVisibility(View.GONE); endButton.setEnabled(true);
        io.execute(() -> {
            try {
                Object result = api.rpc("create_call_session", new JSONObject().put("p_recipient_id", peerId).put("p_call_type", callType));
                JSONObject row = firstRow(result);
                if (row == null) throw new IllegalStateException("The call session was not created.");
                callId = row.optString("id");
                if (callId.isEmpty()) throw new IllegalStateException("The call session ID is missing.");
                try { api.invokeFunction("send-android-call-push", new JSONObject().put("call_id", callId)); }
                catch (Exception pushError) { android.util.Log.w("ABSU-CALL", "The call was created, but the background ring push did not confirm.", pushError); }
                runOnUiThread(() -> {
                    if (finished) return;
                    connectSignaling();
                    try { IncomingCallNotifications.cancel(this, callId); } catch (Exception ignored) { }
                    startCallTimeout();
                });
            } catch (Exception error) {
                runOnUiThread(() -> { toast(friendly(error)); finish(); });
            }
        });
    }

    private JSONObject firstRow(Object result) {
        if (result instanceof JSONArray) return ((JSONArray) result).optJSONObject(0);
        if (result instanceof JSONObject) return (JSONObject) result;
        return null;
    }

    private void loadIncomingCall() {
        if (callId == null || callId.isEmpty()) { toast("This incoming call is no longer available."); finish(); return; }
        io.execute(() -> {
            try {
                JSONObject call = api.getObject("call_sessions?select=id,caller_id,recipient_id,call_type,status,created_at&id=eq." + callId);
                if (!session.userId.equals(call.optString("recipient_id")) && !session.userId.equals(call.optString("caller_id"))) throw new IllegalStateException("You are not a participant in this call.");
                String callerId = call.optString("caller_id");
                String other = session.userId.equals(callerId) ? call.optString("recipient_id") : callerId;
                JSONObject profile = api.getObject("profiles?select=id,display_name,username,avatar_url&id=eq." + other);
                String name = profile.optString("display_name", profile.optString("username", "ABSU Connect friend"));
                runOnUiThread(() -> {
                    if (finished) return;
                    callType = call.optString("call_type", callType);
                    peerId = other;
                    if (!name.trim().isEmpty()) peerName = name;
                    peerLabel.setText(peerName);
                    if ("accepted".equals(call.optString("status"))) { stateLabel.setText("This call is already active on another device."); acceptButton.setEnabled(false); }
                    else if (!"ringing".equals(call.optString("status"))) { toast("This call has already ended."); finish(); }
                    else {
                        connectSignaling();
                        if ("accept".equals(getIntent().getStringExtra("action"))) main.postDelayed(this::requestAccept, 250L);
                    }
                });
            } catch (Exception error) { runOnUiThread(() -> { toast(friendly(error)); finish(); }); }
        });
    }

    private void connectSignaling() {
        if (callId == null || callId.isEmpty() || signaling != null) return;
        stateLabel.setText(outgoing ? "Ringing…" : "Incoming call" );
        AuthSession fresh;
        try { fresh = api.auth().freshSession(this); }
        catch (Exception error) { toast(friendly(error)); finish(); return; }
        signaling = new CallRealtimeChannel(callId, fresh, new CallRealtimeChannel.Listener() {
            @Override public void onReady() {
                channelReady = true;
                flushPendingSignals();
                if (incoming && accepted) sendSignal("accept", null, null);
            }
            @Override public void onSignal(JSONObject signal) { handleSignal(signal); }
            @Override public void onCallRow(JSONObject row) { handleCallRow(row); }
            @Override public void onDisconnected(String reason) {
                channelReady = false;
                if (!finished) { stateLabel.setText("Network interrupted · reconnecting call…"); android.util.Log.w("ABSU-CALL", reason); }
            }
        });
        signaling.connect();
    }

    private void requestAccept() {
        if (!incoming || accepted || finished) return;
        ArrayList<String> ask = new ArrayList<>();
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) ask.add(Manifest.permission.RECORD_AUDIO);
        if ("video".equals(callType) && !hasPermission(Manifest.permission.CAMERA)) ask.add(Manifest.permission.CAMERA);
        if (!ask.isEmpty()) { requestPermissions(ask.toArray(new String[0]), REQ_CALL_MEDIA); return; }
        acceptIncomingAfterPermission();
    }

    private void acceptIncomingAfterPermission() {
        if (accepted || finished) return;
        accepted = true;
        if (dataSaverBox != null) isDataSaver = dataSaverBox.isChecked();
        NetworkMode.setLowData(this, isDataSaver);
        acceptButton.setEnabled(false); declineButton.setVisibility(View.GONE);
        stateLabel.setText("Connecting…");
        initializeMediaAndPeer();
        io.execute(() -> {
            try {
                api.rpc("set_call_session_status", new JSONObject().put("p_call_id", callId).put("p_status", "accepted"));
                runOnUiThread(() -> {
                    if (finished) return;
                    CallOngoingService.start(this, callId, callType, peerName);
                    if (channelReady) sendSignal("accept", null, null);
                });
            } catch (Exception error) { runOnUiThread(() -> { toast(friendly(error)); endCall("failed"); }); }
        });
    }

    private void declineIncoming() {
        if (callId == null || callId.isEmpty()) { finish(); return; }
        declineButton.setEnabled(false); stateLabel.setText("Declining…");
        io.execute(() -> {
            try { api.rpc("set_call_session_status", new JSONObject().put("p_call_id", callId).put("p_status", "declined")); }
            catch (Exception error) { android.util.Log.w("ABSU-CALL", "Decline state could not be saved", error); }
            runOnUiThread(() -> { sendSignal("decline", null, null); finishCallUi(); });
        });
    }

    private void initializeMediaAndPeer() {
        if (localMediaReady || finished) return;
        try {
            if (!factoryInitialized) {
                synchronized (CallActivity.class) {
                    if (!factoryInitialized) {
                        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(getApplicationContext()).createInitializationOptions());
                        factoryInitialized = true;
                    }
                }
            }
            if (eglBase == null) eglBase = EglBase.create();
            remoteRenderer.init(eglBase.getEglBaseContext(), null);
            localRenderer.init(eglBase.getEglBaseContext(), null);
            remoteRenderer.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FILL);
            localRenderer.setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            localRenderer.setMirror(true);

            JavaAudioDeviceModule audioModule = JavaAudioDeviceModule.builder(getApplicationContext())
                    .setUseHardwareAcousticEchoCanceler(true).setUseHardwareNoiseSuppressor(true).createAudioDeviceModule();
            factory = PeerConnectionFactory.builder().setAudioDeviceModule(audioModule)
                    .setVideoEncoderFactory(new DefaultVideoEncoderFactory(eglBase.getEglBaseContext(), true, true))
                    .setVideoDecoderFactory(new DefaultVideoDecoderFactory(eglBase.getEglBaseContext())).createPeerConnectionFactory();

            List<PeerConnection.IceServer> servers = Arrays.asList(
                    PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
                    PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
                    PeerConnection.IceServer.builder("turn:openrelay.metered.ca:80").setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
                    PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443").setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
                    PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443?transport=tcp").setUsername("openrelayproject").setPassword("openrelayproject").createIceServer()
            );
            PeerConnection.RTCConfiguration config = new PeerConnection.RTCConfiguration(servers);
            config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
            config.iceCandidatePoolSize = 8;
            config.bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE;
            peerConnection = factory.createPeerConnection(config, new PeerConnection.Observer() {
                @Override public void onSignalingChange(PeerConnection.SignalingState state) { }
                @Override public void onIceConnectionChange(PeerConnection.IceConnectionState state) {
                    runOnUiThread(() -> {
                        if (finished) return;
                        if (state == PeerConnection.IceConnectionState.CONNECTED || state == PeerConnection.IceConnectionState.COMPLETED) markConnected();
                        else if (state == PeerConnection.IceConnectionState.DISCONNECTED) stateLabel.setText("Network interrupted · reconnecting…");
                        else if (state == PeerConnection.IceConnectionState.FAILED) {
                            stateLabel.setText("Network path failed · trying to reconnect…");
                            if (outgoing && peerConnection != null && !iceRestarting && iceRestartAttempts < 2) {
                                iceRestarting = true; iceRestartAttempts++;
                                main.postDelayed(() -> { if (!finished && peerConnection != null) { iceRestarting = false; createOffer(true); } }, 500L);
                            }
                        }
                    });
                }
                @Override public void onIceConnectionReceivingChange(boolean receiving) { }
                @Override public void onIceGatheringChange(PeerConnection.IceGatheringState state) { }
                @Override public void onIceCandidate(IceCandidate candidate) {
                    try { JSONObject json = new JSONObject().put("sdpMid", candidate.sdpMid).put("sdpMLineIndex", candidate.sdpMLineIndex).put("candidate", candidate.sdp); sendSignal("candidate", null, json); }
                    catch (Exception ignored) { }
                }
                @Override public void onIceCandidatesRemoved(IceCandidate[] candidates) { }
                @Override public void onAddStream(org.webrtc.MediaStream stream) { }
                @Override public void onRemoveStream(org.webrtc.MediaStream stream) { }
                @Override public void onDataChannel(org.webrtc.DataChannel channel) { }
                @Override public void onRenegotiationNeeded() { }
                @Override public void onAddTrack(RtpReceiver receiver, org.webrtc.MediaStream[] streams) {
                    if (receiver.track() instanceof VideoTrack) {
                        remoteVideoTrack = (VideoTrack) receiver.track();
                        runOnUiThread(() -> { if (!finished && remoteRenderer != null) { remoteRenderer.setVisibility(View.VISIBLE); remoteVideoTrack.addSink(remoteRenderer); } });
                    } else if (receiver.track() instanceof AudioTrack) ((AudioTrack) receiver.track()).setEnabled(true);
                }
            });
            if (peerConnection == null) throw new IllegalStateException("WebRTC could not create the peer connection.");

            MediaConstraints audioConstraints = new MediaConstraints();
            audioConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googEchoCancellation", "true"));
            audioConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googNoiseSuppression", "true"));
            audioSource = factory.createAudioSource(audioConstraints);
            audioTrack = factory.createAudioTrack("ABSU_AUDIO", audioSource);
            peerConnection.addTrack(audioTrack, Collections.singletonList("ABSU_STREAM"));
            if ("video".equals(callType)) {
                videoSource = factory.createVideoSource(false);
                cameraCapturer = createCameraCapturer();
                if (cameraCapturer == null) throw new IllegalStateException("No usable camera was found on this device.");
                surfaceTextureHelper = SurfaceTextureHelper.create("ABSU-Camera-Capture", eglBase.getEglBaseContext());
                cameraCapturer.initialize(surfaceTextureHelper, getApplicationContext(), videoSource.getCapturerObserver());
                int width = isDataSaver ? 320 : 640; int height = isDataSaver ? 240 : 480; int fps = isDataSaver ? 12 : 24;
                cameraCapturer.startCapture(width, height, fps);
                localVideoTrack = factory.createVideoTrack("ABSU_VIDEO", videoSource);
                localVideoTrack.addSink(localRenderer);
                RtpSender videoSender = peerConnection.addTrack(localVideoTrack, Collections.singletonList("ABSU_STREAM"));
                applyVideoBandwidth(videoSender);
                localRenderer.setVisibility(View.VISIBLE);
            }
            localMediaReady = true;
            if (dataSaverBox != null) dataSaverBox.setEnabled(false);
            muteButton.setEnabled(true); speakerButton.setEnabled(true); cameraButton.setEnabled("video".equals(callType)); flipButton.setEnabled("video".equals(callType));
            isSpeaker = "video".equals(callType); setAudioRoute();
            CallOngoingService.start(this, callId, callType, peerName);
            if (channelReady && incoming && accepted) sendSignal("accept", null, null);
            if (outgoing && channelReady) sendSignal("ringing", null, null);
        } catch (Exception error) {
            toast("Could not start media: " + (error.getMessage() == null ? "permission or device error" : error.getMessage()));
            endCall("failed");
        }
    }

    private CameraVideoCapturer createCameraCapturer() {
        CameraEnumerator enumerator = new Camera2Enumerator(this);
        for (String name : enumerator.getDeviceNames()) if (enumerator.isFrontFacing(name)) {
            CameraVideoCapturer capturer = enumerator.createCapturer(name, null); if (capturer != null) return capturer;
        }
        for (String name : enumerator.getDeviceNames()) {
            CameraVideoCapturer capturer = enumerator.createCapturer(name, null); if (capturer != null) return capturer;
        }
        return null;
    }

    private void handleSignal(JSONObject signal) {
        if (finished || !callId.equals(signal.optString("callId")) || session.userId.equals(signal.optString("senderId"))) return;
        String type = signal.optString("type");
        if ("accept".equals(type) && outgoing) {
            accepted = true;
            stateLabel.setText("Connecting…");
            if (!localMediaReady) initializeMediaAndPeer();
            maybeCreateOffer();
        } else if ("offer".equals(type) && incoming && accepted) {
            JSONObject sdp = signal.optJSONObject("sdp");
            if (sdp != null) handleRemoteDescription(SessionDescription.Type.OFFER, sdp.optString("sdp"));
        } else if ("answer".equals(type) && outgoing) {
            JSONObject sdp = signal.optJSONObject("sdp");
            if (sdp != null) handleRemoteDescription(SessionDescription.Type.ANSWER, sdp.optString("sdp"));
        } else if ("candidate".equals(type)) {
            JSONObject candidate = signal.optJSONObject("candidate");
            if (candidate != null) addRemoteCandidate(candidate);
        } else if ("decline".equals(type)) {
            stateLabel.setText("Call declined"); finishCallUi();
        } else if ("end".equals(type)) {
            stateLabel.setText("Call ended"); finishCallUi();
        } else if ("media_state".equals(type)) {
            JSONObject state = signal.optJSONObject("mediaState");
            if (state != null && state.has("isVideoEnabled") && !state.optBoolean("isVideoEnabled")) stateLabel.setText(peerName + " turned off their camera");
        }
    }

    private void createOffer() {
        if (peerConnection == null || finished) return;
        createOffer(false);
    }

    private void createOffer(boolean iceRestart) {
        if (peerConnection == null || finished) return;
        MediaConstraints constraints = new MediaConstraints();
        if (iceRestart) constraints.mandatory.add(new MediaConstraints.KeyValuePair("IceRestart", "true"));
        peerConnection.createOffer(new SimpleSdpObserver() {
            @Override public void onCreateSuccess(SessionDescription description) {
                peerConnection.setLocalDescription(new SimpleSdpObserver() {
                    @Override public void onSetSuccess() {
                        try { JSONObject sdp = new JSONObject().put("type", "offer").put("sdp", description.description); sendSignal("offer", sdp, null); }
                        catch (Exception ignored) { }
                    }
                    @Override public void onSetFailure(String error) { runOnUiThread(() -> { stateLabel.setText("Could not set up the call offer."); endCall("failed"); }); }
                }, description);
            }
            @Override public void onCreateFailure(String error) { runOnUiThread(() -> { toast("Could not create the call: " + error); endCall("failed"); }); }
        }, constraints);
    }

    private void handleRemoteDescription(SessionDescription.Type type, String sdpText) {
        if (peerConnection == null || sdpText == null || sdpText.isEmpty()) return;
        peerConnection.setRemoteDescription(new SimpleSdpObserver() {
            @Override public void onSetSuccess() {
                drainRemoteCandidates();
                if (type == SessionDescription.Type.OFFER) createAnswer();
            }
            @Override public void onSetFailure(String error) { runOnUiThread(() -> { toast("Call negotiation failed: " + error); endCall("failed"); }); }
        }, new SessionDescription(type, sdpText));
    }

    private void createAnswer() {
        if (peerConnection == null || finished) return;
        peerConnection.createAnswer(new SimpleSdpObserver() {
            @Override public void onCreateSuccess(SessionDescription description) {
                peerConnection.setLocalDescription(new SimpleSdpObserver() {
                    @Override public void onSetSuccess() {
                        try { JSONObject sdp = new JSONObject().put("type", "answer").put("sdp", description.description); sendSignal("answer", sdp, null); }
                        catch (Exception ignored) { }
                    }
                    @Override public void onSetFailure(String error) { runOnUiThread(() -> { toast("Could not answer call: " + error); endCall("failed"); }); }
                }, description);
            }
            @Override public void onCreateFailure(String error) { runOnUiThread(() -> { toast("Could not create call answer: " + error); endCall("failed"); }); }
        }, new MediaConstraints());
    }

    private void addRemoteCandidate(JSONObject json) {
        try {
            IceCandidate candidate = new IceCandidate(json.optString("sdpMid"), json.optInt("sdpMLineIndex"), json.optString("candidate"));
            if (peerConnection == null || peerConnection.getRemoteDescription() == null) {
                synchronized (pendingCandidatesLock) { pendingRemoteCandidates.add(candidate); }
            } else peerConnection.addIceCandidate(candidate);
        } catch (Exception ignored) { }
    }

    private void drainRemoteCandidates() {
        if (peerConnection == null || peerConnection.getRemoteDescription() == null) return;
        List<IceCandidate> queued;
        synchronized (pendingCandidatesLock) {
            queued = new ArrayList<>(pendingRemoteCandidates);
            pendingRemoteCandidates.clear();
        }
        for (IceCandidate candidate : queued) peerConnection.addIceCandidate(candidate);
    }

    private void sendSignal(String type, JSONObject sdp, JSONObject candidate) {
        if (callId == null || session == null) return;
        try {
            JSONObject signal = new JSONObject().put("callId", callId).put("senderId", session.userId).put("type", type).put("callType", callType);
            if (sdp != null) signal.put("sdp", sdp);
            if (candidate != null) signal.put("candidate", candidate);
            if ("media_state".equals(type)) signal.put("mediaState", new JSONObject().put("isMuted", isMuted).put("isVideoEnabled", cameraEnabled));
            CallRealtimeChannel channel = signaling;
            if (channel == null || !channelReady || !channel.isReady()) {
                synchronized (pendingSignalsLock) { pendingSignals.add(signal); }
                return;
            }
            channel.sendSignal(signal);
        } catch (Exception ignored) { }
    }

    private void flushPendingSignals() {
        if (signaling == null || !channelReady || !signaling.isReady()) return;
        List<JSONObject> queued;
        synchronized (pendingSignalsLock) {
            if (pendingSignals.isEmpty()) return;
            queued = new ArrayList<>(pendingSignals);
            pendingSignals.clear();
        }
        for (JSONObject signal : queued) signaling.sendSignal(signal);
    }

    private void handleCallRow(JSONObject row) {
        String status = row.optString("status");
        if ("accepted".equals(status)) {
            accepted = true;
            if (outgoing && localMediaReady && peerConnection != null) maybeCreateOffer();
        } else if ("declined".equals(status) || "missed".equals(status) || "ended".equals(status) || "failed".equals(status)) {
            runOnUiThread(() -> { if (!finished) { stateLabel.setText("Call " + status); finishCallUi(); } });
        }
    }

    private boolean offerStarted;
    private boolean iceRestarting;
    private int iceRestartAttempts;
    private void maybeCreateOffer() {
        if (offerStarted || finished || !outgoing || peerConnection == null || !localMediaReady || !accepted) return;
        offerStarted = true;
        createOffer();
    }

    private void applyVideoBandwidth(RtpSender sender) {
        try {
            org.webrtc.RtpParameters parameters = sender.getParameters();
            if (parameters.encodings == null || parameters.encodings.isEmpty()) return;
            org.webrtc.RtpParameters.Encoding encoding = parameters.encodings.get(0);
            encoding.maxBitrateBps = isDataSaver ? 180000 : 650000;
            encoding.maxFramerate = isDataSaver ? 12 : 24;
            sender.setParameters(parameters);
        } catch (Exception error) {
            android.util.Log.w("ABSU-CALL", "Could not apply optional video bitrate preference", error);
        }
    }

    private void markConnected() {
        if (connected || finished) return;
        connected = true; iceRestarting = false; connectedAt = System.currentTimeMillis(); elapsedSeconds = 0; stateLabel.setText("Connected");
        durationTick = new Runnable() { @Override public void run() {
            if (!connected || finished) return;
            elapsedSeconds = (int) ((System.currentTimeMillis() - connectedAt) / 1000L);
            durationLabel.setText(String.format(Locale.ROOT, "%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60));
            main.postDelayed(this, 1000L);
        }};
        main.post(durationTick);
        IncomingCallNotifications.cancel(this, callId);
    }

    private void startCallTimeout() {
        ringTimeout = () -> { if (!connected && !finished && outgoing) {
            io.execute(() -> { try { api.rpc("set_call_session_status", new JSONObject().put("p_call_id", callId).put("p_status", "missed")); } catch (Exception ignored) { } });
            stateLabel.setText("No answer"); finishCallUi();
        }};
        main.postDelayed(ringTimeout, 35000L);
    }

    private void toggleMute() {
        isMuted = !isMuted; if (audioTrack != null) audioTrack.setEnabled(!isMuted);
        muteButton.setText(isMuted ? "Unmute" : "Mute"); sendSignal("media_state", null, null);
    }
    private void toggleSpeaker() { isSpeaker = !isSpeaker; setAudioRoute(); speakerButton.setText(isSpeaker ? "Speaker on" : "Speaker off"); }
    private void setAudioRoute() { if (audioManager == null) return; audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION); audioManager.setSpeakerphoneOn(isSpeaker); }
    private void toggleCamera() {
        if (localVideoTrack == null) return;
        cameraEnabled = !cameraEnabled; localVideoTrack.setEnabled(cameraEnabled);
        if (cameraCapturer != null) {
            try { if (cameraEnabled) cameraCapturer.startCapture(isDataSaver ? 320 : 640, isDataSaver ? 240 : 480, isDataSaver ? 12 : 24); else cameraCapturer.stopCapture(); }
            catch (Exception ignored) { }
        }
        cameraButton.setText(cameraEnabled ? "Camera off" : "Camera on"); sendSignal("media_state", null, null);
    }
    private void flipCamera() {
        if (cameraCapturer == null) return;
        cameraCapturer.switchCamera(new CameraVideoCapturer.CameraSwitchHandler() {
            @Override public void onCameraSwitchDone(boolean frontCamera) { runOnUiThread(() -> localRenderer.setMirror(frontCamera)); }
            @Override public void onCameraSwitchError(String error) { runOnUiThread(() -> toast("Could not switch camera: " + error)); }
        });
    }

    private boolean hasPermission(String permission) { return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED; }
    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_CALL_MEDIA) return;
        boolean all = results.length > 0;
        for (int result : results) all &= result == PackageManager.PERMISSION_GRANTED;
        if (!all) { toast("Microphone and camera permission are needed for this call."); if (incoming) declineIncoming(); else finish(); return; }
        if (outgoing) startOutgoingCall(); else acceptIncomingAfterPermission();
    }

    private void endCall(String status) {
        if (finished) return;
        sendSignal("end", null, null);
        if (callId != null) io.execute(() -> { try { api.rpc("set_call_session_status", new JSONObject().put("p_call_id", callId).put("p_status", status)); } catch (Exception error) { android.util.Log.w("ABSU-CALL", "Could not persist call end status", error); } });
        stateLabel.setText("Call ended"); finishCallUi();
    }

    private void handleRemoteCallEnd(String status) { stateLabel.setText(status); finishCallUi(); }

    private void finishCallUi() {
        if (finished) return;
        finished = true; connected = false;
        synchronized (pendingSignalsLock) { pendingSignals.clear(); }
        synchronized (pendingCandidatesLock) { pendingRemoteCandidates.clear(); }
        if (durationTick != null) main.removeCallbacks(durationTick);
        if (ringTimeout != null) main.removeCallbacks(ringTimeout);
        if (signaling != null) { signaling.close(); signaling = null; }
        if (peerConnection != null) { peerConnection.close(); peerConnection.dispose(); peerConnection = null; }
        if (cameraCapturer != null) { try { cameraCapturer.stopCapture(); } catch (Exception ignored) { } cameraCapturer.dispose(); cameraCapturer = null; }
        if (localVideoTrack != null) { localVideoTrack.removeSink(localRenderer); localVideoTrack.dispose(); localVideoTrack = null; }
        if (remoteVideoTrack != null && remoteRenderer != null) { remoteVideoTrack.removeSink(remoteRenderer); remoteVideoTrack = null; }
        if (audioTrack != null) { audioTrack.setEnabled(false); audioTrack.dispose(); audioTrack = null; }
        if (audioSource != null) { audioSource.dispose(); audioSource = null; }
        if (videoSource != null) { videoSource.dispose(); videoSource = null; }
        if (surfaceTextureHelper != null) { surfaceTextureHelper.dispose(); surfaceTextureHelper = null; }
        if (factory != null) { factory.dispose(); factory = null; }
        if (remoteRenderer != null) { remoteRenderer.release(); remoteRenderer = null; }
        if (localRenderer != null) { localRenderer.release(); localRenderer = null; }
        if (eglBase != null) { eglBase.release(); eglBase = null; }
        if (audioManager != null) { audioManager.setSpeakerphoneOn(false); audioManager.setMode(AudioManager.MODE_NORMAL); }
        if (callId != null) IncomingCallNotifications.cancel(this, callId);
        CallOngoingService.stop(this);
        main.postDelayed(this::finish, 500L);
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private String friendly(Exception ex) {
        String message = ex.getMessage();
        if (message == null || message.trim().isEmpty()) return "The call could not be started. Check your connection.";
        if (message.contains("already in another call")) return "You or your friend is already in another call.";
        if (message.contains("accepted friends")) return "Voice and video calls are only available between accepted friends.";
        return message;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if ("accept".equals(intent.getStringExtra("action"))) requestAccept();
    }

    @Override public void onBackPressed() {
        if (finished) { super.onBackPressed(); return; }
        if (callId != null && incoming && !accepted) declineIncoming();
        else if (callId != null && (outgoing || accepted)) endCall("ended");
        else finishCallUi();
    }

    @Override protected void onDestroy() {
        if (!finished) finishCallUi();
        // Allow any call-state write queued by the back/decline/end action to finish cleanly.
        io.shutdown();
        super.onDestroy();
    }

    private abstract static class SimpleSdpObserver implements SdpObserver {
        @Override public void onSetSuccess() { }
        @Override public void onCreateSuccess(SessionDescription description) { }
        @Override public void onSetFailure(String error) { }
        @Override public void onCreateFailure(String error) { }
    }
}

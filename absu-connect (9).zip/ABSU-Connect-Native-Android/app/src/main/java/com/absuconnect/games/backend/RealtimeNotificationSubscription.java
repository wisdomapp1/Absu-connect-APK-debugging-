package com.absuconnect.games.backend;

import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import java.util.concurrent.TimeUnit;
import android.os.Handler;
import android.os.Looper;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONArray;
import org.json.JSONObject;

/** Foreground Realtime listener for this account's private notification rows. */
public final class RealtimeNotificationSubscription {
    public interface Listener { void onNotification(JSONObject row); void onDisconnected(String reason); }
    private final OkHttpClient client = new OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build();
    private WebSocket socket;
    private Listener listener;
    private volatile boolean closed;
    private final Handler heartbeatHandler = new Handler(Looper.getMainLooper());
    private int heartbeatRef = 2;
    private Runnable heartbeatTask;

    public void subscribe(AuthSession session, Listener listener) {
        this.listener = listener;
        HttpUrl base=HttpUrl.parse(BuildConfig.SUPABASE_URL);
        if(base==null){listener.onDisconnected("Invalid Supabase project URL.");return;}
        HttpUrl url=base.newBuilder().scheme("wss").addPathSegments("realtime/v1/websocket")
                .addQueryParameter("apikey",BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .addQueryParameter("vsn","1.0.0").build();
        socket=client.newWebSocket(new Request.Builder().url(url).build(),new WebSocketListener(){
            @Override public void onOpen(WebSocket ws,Response response){
                try{
                    JSONObject change=new JSONObject().put("event","INSERT").put("schema","public").put("table","notifications").put("filter","recipient_id=eq."+session.userId);
                    JSONArray changes=new JSONArray().put(change);
                    JSONObject config=new JSONObject().put("broadcast",new JSONObject().put("ack",false).put("self",false))
                            .put("presence",new JSONObject().put("key","" )).put("postgres_changes",changes).put("private",false);
                    JSONObject payload=new JSONObject().put("config",config).put("access_token",session.accessToken);
                    JSONObject join=new JSONObject().put("topic","realtime:absu-alerts-"+session.userId).put("event","phx_join").put("payload",payload).put("ref","1");
                    ws.send(join.toString());
                    startHeartbeat(ws);
                }catch(Exception e){if(RealtimeNotificationSubscription.this.listener!=null)RealtimeNotificationSubscription.this.listener.onDisconnected("Could not join notification updates.");}
            }
            @Override public void onMessage(WebSocket ws,String raw){
                if(closed)return;
                try{
                    JSONObject root=new JSONObject(raw);
                    JSONObject payload=root.optJSONObject("payload");
                    if(payload==null)return;
                    JSONObject data=payload.optJSONObject("data");
                    if(data==null)return;
                    if(!"INSERT".equalsIgnoreCase(data.optString("type")))return;
                    JSONObject record=data.optJSONObject("record");
                    if(record!=null&&RealtimeNotificationSubscription.this.listener!=null)RealtimeNotificationSubscription.this.listener.onNotification(record);
                }catch(Exception ignored){}
            }
            @Override public void onFailure(WebSocket ws,Throwable t,Response response){if(!closed&&RealtimeNotificationSubscription.this.listener!=null)RealtimeNotificationSubscription.this.listener.onDisconnected("Live alerts disconnected.");}
        });
    }


    private void startHeartbeat(WebSocket ws){
        heartbeatTask= new Runnable(){@Override public void run(){
            if(closed||socket!=ws)return;
            try{JSONObject beat=new JSONObject().put("topic","phoenix").put("event","heartbeat").put("payload",new JSONObject()).put("ref",String.valueOf(heartbeatRef++));ws.send(beat.toString());}
            catch(Exception ex){if(listener!=null)listener.onDisconnected("Live alerts heartbeat failed.");}
            heartbeatHandler.postDelayed(this,25000L);
        }};
        heartbeatHandler.postDelayed(heartbeatTask,25000L);
    }

    public void close(){closed=true;listener=null;if(heartbeatTask!=null)heartbeatHandler.removeCallbacks(heartbeatTask);if(socket!=null){socket.close(1000,"notifications listener stopped");socket=null;}client.dispatcher().executorService().shutdown();}
}

package com.absuconnect.games.multiplayer;

import com.absuconnect.games.GameCatalog;
import com.absuconnect.games.multiplayer.MatchProtocol.ActionIntent;
import com.absuconnect.games.multiplayer.MatchProtocol.ActionReceipt;
import com.absuconnect.games.multiplayer.MatchProtocol.Invite;
import com.absuconnect.games.multiplayer.MatchProtocol.InviteResponse;
import com.absuconnect.games.multiplayer.MatchProtocol.Listener;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchAction;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchException;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchSnapshot;
import com.absuconnect.games.multiplayer.MatchProtocol.Room;
import com.absuconnect.games.multiplayer.MatchProtocol.RoomStatus;
import com.absuconnect.games.multiplayer.MatchProtocol.Subscription;
import java.util.UUID;

/**
 * Reusable client orchestration only. Game screens are not wired to it; the Supabase transport journals
 * intents but does not simulate game rules. The real server must authorize every transition/action.
 */
public final class MatchSessionCoordinator {
    private final MatchInviteRepository invites;
    private final MatchTransport transport;

    public MatchSessionCoordinator(MatchInviteRepository invites,MatchTransport transport){
        if(invites==null||transport==null)throw new IllegalArgumentException("Invite repository and transport are required");
        this.invites=invites;this.transport=transport;
    }

    public Invite createInvite(String gameId,String hostUserId,String friendUserId,int maxPlayers,
                               long expiresAtEpochMs) throws MatchException {
        requireGameAndCapacity(gameId,maxPlayers);
        if(hostUserId==null||friendUserId==null||hostUserId.equals(friendUserId))throw new MatchException("Choose a different friend to invite.");
        return invites.createInvite(gameId,hostUserId,friendUserId,maxPlayers,expiresAtEpochMs);
    }

    /** Adds a further friend to a multi-seat Ludo/WHOT room; single-seat races/fights stay two-player. */
    public Invite inviteAnotherFriend(String matchId,String inviterUserId,String friendUserId,
                                      long expiresAtEpochMs) throws MatchException {
        Room room=invites.fetchRoom(matchId,inviterUserId);
        if(!room.includes(inviterUserId))throw new MatchException("Only a room participant can invite a friend.");
        return invites.inviteFriendToRoom(matchId,inviterUserId,friendUserId,expiresAtEpochMs);
    }

    public InviteResponse respond(String inviteId,String respondingUserId,boolean accept,
                                  long nowEpochMs) throws MatchException {
        Invite invite=invites.respondToInvite(inviteId,respondingUserId,accept,nowEpochMs);
        Room room=accept?invites.fetchRoom(invite.matchId,respondingUserId):null;
        return new InviteResponse(invite,room);
    }

    /** Opens waiting/ready/active rooms for participants. A WAITING room is lobby-only until server-ready. */
    public Session join(String matchId,String participantUserId) throws MatchException {
        Room room=invites.fetchRoom(matchId,participantUserId);
        int seat=room.seatFor(participantUserId);
        if(seat<0)throw new MatchException("This account has no seat in that match.");
        if(room.status==RoomStatus.COMPLETED||room.status==RoomStatus.ABANDONED)
            throw new MatchException("This match is no longer open.");
        MatchSnapshot snapshot=transport.fetchSnapshot(matchId,participantUserId);
        verifySnapshot(room,snapshot);
        return new Session(room,participantUserId,seat,snapshot);
    }

    /** The subscription replays newer snapshots; callers should close it with the screen/session lifecycle. */
    public Subscription subscribe(Session session,Listener listener) throws MatchException {
        requireSession(session);
        if(listener==null)throw new MatchException("A match listener is required.");
        Subscription next=transport.subscribe(session.room.matchId,session.userId,session.snapshot().stateVersion,new Listener(){
            @Override public void onSnapshot(MatchSnapshot snapshot){
                try{if(acceptSnapshot(session,snapshot))listener.onSnapshot(snapshot);}
                catch(MatchException invalid){listener.onDisconnected(invalid.getMessage());}
            }
            @Override public void onDisconnected(String reason){listener.onDisconnected(reason);}
        });
        session.replaceSubscription(next);
        return session.subscriptionHandle();
    }

    /** Sends only allow-listed client intent; the server computes authoritative state and returns a receipt. */
    public ActionReceipt sendIntent(Session session,GameActionCodec codec,ActionIntent rawIntent) throws MatchException {
        requireSession(session);
        if(session.snapshot().status!=RoomStatus.READY&&session.snapshot().status!=RoomStatus.IN_PROGRESS)
            throw new MatchException("Wait until the match is ready before sending gameplay input.");
        if(codec==null||!session.room.gameId.equals(codec.gameId()))throw new MatchException("This game adapter does not match the room.");
        final ActionIntent intent;
        try{intent=codec.validate(rawIntent);}catch(RuntimeException invalid){throw new MatchException("Game input was rejected by its codec.",invalid);}
        MatchSnapshot current=session.snapshot();
        MatchAction action=new MatchAction(session.room.matchId,session.userId,session.seat,
                UUID.randomUUID().toString(),current.nextSequence,current.stateVersion,intent);
        ActionReceipt receipt=transport.submitAction(action);
        if(receipt!=null&&receipt.snapshot!=null){acceptSnapshot(session,receipt.snapshot);return new ActionReceipt(receipt.accepted,receipt.reason,session.snapshot());}
        return receipt;
    }

    /** Fetch a complete, authoritative snapshot after reconnect or a sequence/version conflict. */
    public MatchSnapshot reconnect(Session session) throws MatchException {
        requireSession(session);
        MatchSnapshot snapshot=transport.fetchSnapshot(session.room.matchId,session.userId);
        acceptSnapshot(session,snapshot);
        return session.snapshot();
    }

    private boolean acceptSnapshot(Session session,MatchSnapshot snapshot) throws MatchException {
        verifySnapshot(session.room,snapshot);
        synchronized(session){
            if(snapshot.stateVersion<session.snapshot.stateVersion)return false;
            if(snapshot.stateVersion==session.snapshot.stateVersion){
                if(snapshot.nextSequence!=session.snapshot.nextSequence)throw new MatchException("Server snapshot has conflicting sequence metadata.");
                return false;
            }
            session.snapshot=snapshot;
            return true;
        }
    }

    private static void verifySnapshot(Room room,MatchSnapshot snapshot) throws MatchException {
        if(snapshot==null||!room.matchId.equals(snapshot.matchId)||!room.gameId.equals(snapshot.gameId))
            throw new MatchException("Server snapshot does not match this room/game.");
        if(snapshot.nextSequence<1||snapshot.stateVersion<0||snapshot.nextSequence!=snapshot.stateVersion+1)
            throw new MatchException("Server snapshot has invalid sequence metadata.");
    }
    private static void requireGameAndCapacity(String gameId,int maxPlayers) throws MatchException {
        GameCatalog.Module module=GameCatalog.find(gameId);
        if(module==null)throw new MatchException("Unknown game ID.");
        if("campus_fireline".equals(gameId))throw new MatchException("Campus Fireline is a solo-only level campaign.");
        if(maxPlayers<module.minPlayers||maxPlayers>module.maxPlayers)throw new MatchException("Invalid player count for this game.");
        if(("campus_duel".equals(gameId)||"billiards".equals(gameId)
                ||"kart_racing".equals(gameId)||"bike_racing".equals(gameId))&&maxPlayers!=2)
            throw new MatchException("This game currently supports exactly two match seats.");
    }
    private static void requireSession(Session session) throws MatchException {
        if(session==null||session.closed)throw new MatchException("Match session is closed.");
    }

    public static final class Session implements AutoCloseable {
        public final Room room;
        public final String userId;
        public final int seat;
        private MatchSnapshot snapshot;
        private Subscription subscription;
        private boolean closed;
        private Session(Room room,String userId,int seat,MatchSnapshot snapshot){this.room=room;this.userId=userId;this.seat=seat;this.snapshot=snapshot;}
        public synchronized MatchSnapshot snapshot(){return snapshot;}
        private synchronized void replaceSubscription(Subscription next){if(subscription!=null)subscription.close();subscription=next;}
        private synchronized Subscription subscriptionHandle(){
            return new Subscription(){@Override public void close(){Session.this.close();}};
        }
        @Override public synchronized void close(){if(closed)return;closed=true;if(subscription!=null){subscription.close();subscription=null;}}
    }
}

package com.absuconnect.games.multiplayer;

import com.absuconnect.games.multiplayer.MatchProtocol.ActionIntent;
import java.util.Map;

/** Game-specific allowlist/shape codec. It does not decide whether a hit, turn or race result is valid. */
public interface GameActionCodec {
    String gameId();
    ActionIntent encode(String actionType, Map<String,String> fields);
    ActionIntent validate(ActionIntent intent);
}

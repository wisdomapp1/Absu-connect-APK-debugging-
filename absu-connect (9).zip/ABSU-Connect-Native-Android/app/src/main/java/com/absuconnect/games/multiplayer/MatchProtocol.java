package com.absuconnect.games.multiplayer;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Transport-neutral contracts for a future authoritative online match service. No network code lives here. */
public final class MatchProtocol {
    public enum InviteStatus { PENDING, ACCEPTED, DECLINED, EXPIRED, CANCELLED }
    public enum RoomStatus { WAITING, READY, IN_PROGRESS, COMPLETED, ABANDONED }

    private MatchProtocol() {}

    public static final class MatchException extends Exception {
        public MatchException(String message) { super(message); }
        public MatchException(String message, Throwable cause) { super(message, cause); }
    }

    /** The invite binds an immutable game ID and match ID to host/guest identities and expiry. */
    public static final class Invite {
        public final String inviteId, matchId, gameId, senderId, recipientId;
        public final InviteStatus status;
        public final long expiresAtEpochMs;
        public Invite(String inviteId, String matchId, String gameId, String senderId, String recipientId,
                      InviteStatus status, long expiresAtEpochMs) {
            this.inviteId=required(inviteId,"inviteId"); this.matchId=required(matchId,"matchId");
            this.gameId=required(gameId,"gameId"); this.senderId=required(senderId,"senderId");
            this.recipientId=required(recipientId,"recipientId"); this.status=status;
            this.expiresAtEpochMs=expiresAtEpochMs;
        }
    }

    /** Host always owns seat 0; accepted invitees receive the lowest available seat. */
    public static final class Room {
        public final String matchId, gameId;
        public final int maxPlayers;
        public final RoomStatus status;
        public final long version;
        public final Map<Integer,String> playersBySeat;
        public Room(String matchId, String gameId, int maxPlayers, RoomStatus status, long version,
                    Map<Integer,String> playersBySeat) {
            this.matchId=required(matchId,"matchId"); this.gameId=required(gameId,"gameId");
            this.maxPlayers=maxPlayers; this.status=status; this.version=version;
            this.playersBySeat=Collections.unmodifiableMap(new LinkedHashMap<>(playersBySeat));
        }
        public int seatFor(String userId) {
            if (userId==null) return -1;
            for (Map.Entry<Integer,String> entry:playersBySeat.entrySet()) if (userId.equals(entry.getValue())) return entry.getKey();
            return -1;
        }
        public String playerAt(int seat) { return playersBySeat.get(seat); }
        public boolean includes(String userId) { return seatFor(userId)>=0; }
    }

    /** Small logical input intent. The server must still authenticate, validate and simulate it. */
    public static final class ActionIntent {
        public final String gameId, type;
        public final Map<String,String> fields;
        public ActionIntent(String gameId, String type, Map<String,String> fields) {
            this.gameId=required(gameId,"gameId"); this.type=required(type,"type");
            this.fields=Collections.unmodifiableMap(new LinkedHashMap<>(fields));
        }
    }

    /** Sequence/version metadata is supplied by the client but must be checked by the server. */
    public static final class MatchAction {
        public final String matchId, gameId, actorId, clientActionId, type;
        public final int seat;
        public final long sequence, expectedVersion;
        public final Map<String,String> fields;
        public MatchAction(String matchId, String actorId, int seat, String clientActionId,
                           long sequence, long expectedVersion, ActionIntent intent) {
            this.matchId=required(matchId,"matchId"); this.actorId=required(actorId,"actorId");
            this.gameId=intent.gameId; this.type=intent.type; this.seat=seat;
            this.clientActionId=required(clientActionId,"clientActionId");
            this.sequence=sequence; this.expectedVersion=expectedVersion;
            this.fields=Collections.unmodifiableMap(new LinkedHashMap<>(intent.fields));
        }
    }

    /** Full server snapshot makes reconnect/resynchronization independent of missed realtime events. */
    public static final class MatchSnapshot {
        public final String matchId, gameId, stateJson;
        public final RoomStatus status;
        public final long stateVersion, nextSequence;
        /** -1 for simultaneous-action games; otherwise the authoritative active seat. */
        public final int activeSeat;
        public MatchSnapshot(String matchId, String gameId, RoomStatus status, long stateVersion,
                             long nextSequence, int activeSeat, String stateJson) {
            this.matchId=required(matchId,"matchId"); this.gameId=required(gameId,"gameId");
            this.status=status; this.stateVersion=stateVersion; this.nextSequence=nextSequence;
            this.activeSeat=activeSeat; this.stateJson=stateJson==null?"{}":stateJson;
        }
    }

    /** Rejections may carry a fresh snapshot so a client can recover from stale state. */
    public static final class ActionReceipt {
        public final boolean accepted;
        public final String reason;
        public final MatchSnapshot snapshot;
        public ActionReceipt(boolean accepted, String reason, MatchSnapshot snapshot) {
            this.accepted=accepted; this.reason=reason==null?"":reason; this.snapshot=snapshot;
        }
    }

    public static final class InviteResponse {
        public final Invite invite;
        /** Null after decline; populated after acceptance so the recipient can enter the room. */
        public final Room room;
        public InviteResponse(Invite invite, Room room) { this.invite=invite; this.room=room; }
    }

    public interface InviteInboxListener {
        void onInviteChanged(Invite invite);
        void onDisconnected(String reason);
    }
    public interface Subscription { void close(); }
    public interface Listener {
        void onSnapshot(MatchSnapshot snapshot);
        void onDisconnected(String reason);
    }

    private static String required(String value,String name) {
        if (value==null||value.trim().isEmpty()) throw new IllegalArgumentException(name+" is required");
        return value;
    }
}

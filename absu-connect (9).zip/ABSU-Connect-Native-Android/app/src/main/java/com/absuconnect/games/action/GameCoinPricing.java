package com.absuconnect.games.action;

import com.absuconnect.games.action.ActionContentCatalog.ArenaSpec;
import com.absuconnect.games.action.ActionContentCatalog.CharacterSpec;
import com.absuconnect.games.action.ActionContentCatalog.SkillSpec;
import com.absuconnect.games.action.ActionContentCatalog.SkinSpec;
import com.absuconnect.games.action.ActionContentCatalog.WeaponSpec;
import com.absuconnect.games.racing.RacingCatalog;

/**
 * Illustrative per-game coin values for design previews only. These are not final prices,
 * purchasable offers, payment instructions or a connected economy.
 */
public final class GameCoinPricing {
    private GameCoinPricing(){}
    private static int quote(double value){return Math.max(100,(int)(Math.ceil(value/50.0)*50));}

    /** More health, stamina, speed and higher unlock rank increase the displayed example value. */
    public static int fighter(CharacterSpec item){return quote(250+item.unlockRank*90+(item.health-80)*8+(item.stamina-80)*3+(item.moveScale-.75f)*800);}
    public static int operator(CharacterSpec item){return quote(220+item.unlockRank*85+(item.health-80)*8+(item.stamina-80)*3+(item.moveScale-.75f)*900);}
    /** Damage, pace and mobility contribute; melee training styles remain fictional practice data. */
    public static int meleeWeapon(WeaponSpec item){return quote(220+item.unlockRank*80+item.damage*28+(1000.0/item.cooldownMs)*3+item.movementScale*100);}
    /** Higher damage, magazine size, reach and movement raise the fictional gun-profile estimate. */
    public static int firearm(WeaponSpec item){return quote(200+item.unlockRank*85+item.damage*16+item.magazine*5+item.range*4+item.movementScale*120+item.reserveMagazines*20+(8000.0/item.reloadMs)*20);}
    public static int skill(SkillSpec item){return quote(180+item.unlockRank*75+item.value*20+item.durationMs*.015+Math.max(0,45-item.staminaCost)*3);}
    public static int arena(ArenaSpec item){return quote(250+item.unlockRank*90+item.coverPieces.length*35);}
    /** Visual-only items use an intentionally lower value band, with rarer rank tiers higher. */
    public static int skin(SkinSpec item){return quote(150+item.unlockRank*65);}
    public static int driver(RacingCatalog.DriverSpec item){return quote(280+item.unlockRank*85+item.handling*180+item.launch*220);}
    public static int vehicle(RacingCatalog.VehicleSpec item){return quote(350+item.unlockRank*100+(item.topSpeed-350)*9+item.acceleration*450+item.handling*200);}
    public static int livery(RacingCatalog.SkinSpec item){return quote(150+item.unlockRank*65);}

    /** Later upgrade estimates cost more; high-value items also cost more at every level. */
    public static int upgrade(int itemPrice,int currentLevel){
        if(currentLevel<0)currentLevel=0;int next=currentLevel+1;
        return quote(Math.max(0,itemPrice)*(.28+.12*next)+next*100.0);
    }
}

package com.absuconnect.games.calls;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/** Keeps the active microphone/camera call visible to Android while the call screen is backgrounded. */
public final class CallOngoingService extends Service {
    public static final String ACTION_START = "com.absuconnect.games.calls.START";
    public static final String ACTION_STOP = "com.absuconnect.games.calls.STOP";
    private static final String EXTRA_CALL_ID = "call_id";
    private static final String EXTRA_CALL_TYPE = "call_type";
    private static final String EXTRA_PEER = "peer_name";
    private String activeCallId;

    public static void start(Context context, String callId, String callType, String peerName) {
        Intent intent = new Intent(context, CallOngoingService.class).setAction(ACTION_START)
                .putExtra(EXTRA_CALL_ID, callId).putExtra(EXTRA_CALL_TYPE, callType).putExtra(EXTRA_PEER, peerName);
        androidx.core.content.ContextCompat.startForegroundService(context, intent);
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, CallOngoingService.class));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        activeCallId = intent.getStringExtra(EXTRA_CALL_ID);
        String type = intent.getStringExtra(EXTRA_CALL_TYPE);
        String peer = intent.getStringExtra(EXTRA_PEER);
        if (activeCallId == null) { stopSelf(); return START_NOT_STICKY; }
        IncomingCallNotifications.ensureChannel(this);
        Notification notification = new NotificationCompat.Builder(this, IncomingCallNotifications.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_call_outgoing)
                .setContentTitle("ABSU Connect call")
                .setContentText(("video".equals(type) ? "Video call with " : "Voice call with ") + (peer == null ? "friend" : peer))
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true).setOnlyAlertOnce(true)
                .setContentIntent(IncomingCallNotifications.callActivityPendingIntent(this, activeCallId))
                .setStyle(NotificationCompat.CallStyle.forOngoingCall(
                        new androidx.core.app.Person.Builder().setName(peer == null ? "ABSU Connect friend" : peer).build(),
                        IncomingCallNotifications.hangupPendingIntent(this, activeCallId)))
                .build();
        int id = IncomingCallNotifications.notificationId(activeCallId) + 100000;
        if (Build.VERSION.SDK_INT >= 29) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            if ("video".equals(type)) serviceType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
            startForeground(id, notification, serviceType);
        } else startForeground(id, notification);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (activeCallId != null) NotificationManagerCompat.from(this).cancel(IncomingCallNotifications.notificationId(activeCallId) + 100000);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}

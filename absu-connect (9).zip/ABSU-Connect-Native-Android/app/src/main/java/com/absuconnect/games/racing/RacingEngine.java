package com.absuconnect.games.racing;

/** Original oval-track arcade racing model shared by configurable car and motorcycle modules. */
public final class RacingEngine {
    public static final class Racer {
        public final int seat;
        public float progress,speed,visualLane=1f;
        public int lane=1,driverIndex,vehicleIndex,skinIndex,driverUpgrade,vehicleUpgrade;
        Racer(int seat){this.seat=seat;}
        public int lap(){return Math.min(3,(int)progress+1);}
        public float fraction(){return progress-(float)Math.floor(progress);}
    }
    private final boolean motorcycle;
    private final Racer[] racers={new Racer(0),new Racer(1)};
    private final boolean[][] input=new boolean[2][4]; // left, right, accelerate, brake
    private boolean cpuOpponent=true,running=true;
    private int winner=-1;
    private float cpuLaneTimer;
    private String message="Three laps. Hold GO, steer between lanes, and avoid contact.";
    public RacingEngine(boolean motorcycle){this.motorcycle=motorcycle;reset(true);}
    public void reset(boolean againstCpu){
        cpuOpponent=againstCpu;running=true;winner=-1;cpuLaneTimer=0;
        message="Three laps. Hold GO, steer between lanes, and avoid contact.";
        for(int i=0;i<2;i++){racers[i].progress=0;racers[i].speed=170;racers[i].lane=1;racers[i].visualLane=1f;for(int j=0;j<4;j++)input[i][j]=false;}
    }
    public void setRacerLoadout(int seat,int driver,int vehicle,int skin){
        setRacerLoadout(seat,driver,vehicle,skin,0,0);
    }
    public void setRacerLoadout(int seat,int driver,int vehicle,int skin,int driverUpgrade,int vehicleUpgrade){
        if(seat<0||seat>1)return;Racer racer=racers[seat];racer.driverIndex=RacingCatalog.wrap(driver,RacingCatalog.DRIVERS.length);
        racer.vehicleIndex=RacingCatalog.wrap(vehicle,(motorcycle?RacingCatalog.BIKES:RacingCatalog.CARS).length);
        racer.skinIndex=RacingCatalog.wrap(skin,RacingCatalog.SKINS.length);racer.driverUpgrade=Math.max(0,Math.min(5,driverUpgrade));racer.vehicleUpgrade=Math.max(0,Math.min(5,vehicleUpgrade));
        message="P"+(seat+1)+" · "+driver(seat).name+" · "+vehicle(seat).name+" · "+livery(seat).name;
    }
    public boolean isMotorcycle(){return motorcycle;}
    public boolean isCpuOpponent(){return cpuOpponent;}
    public boolean isRunning(){return running;}
    public int winner(){return winner;}
    public Racer racer(int seat){return racers[seat];}
    public String message(){return message;}
    public void clearInputs(){for(int i=0;i<input.length;i++)for(int j=0;j<input[i].length;j++)input[i][j]=false;}
    public RacingCatalog.DriverSpec driver(int seat){return RacingCatalog.DRIVERS[racers[seat].driverIndex];}
    public RacingCatalog.VehicleSpec vehicle(int seat){return RacingCatalog.vehicle(motorcycle,racers[seat].vehicleIndex);}
    public RacingCatalog.SkinSpec livery(int seat){return RacingCatalog.SKINS[racers[seat].skinIndex];}
    public void setPressed(int seat,int control,boolean pressed){if(seat<0||seat>1||control<0||control>3)return;input[seat][control]=pressed;}
    public void steer(int seat,int direction){
        if(!running||seat<0||seat>1)return;racers[seat].lane=Math.max(0,Math.min(2,racers[seat].lane+direction));
        message=driver(seat).name+" moves to lane "+(racers[seat].lane+1)+".";
    }
    public void update(float seconds){
        if(!running)return;float dt=Math.max(0,Math.min(seconds,0.05f));
        for(int i=0;i<2;i++){
            Racer r=racers[i];boolean left=input[i][0],right=input[i][1],go=input[i][2],brake=input[i][3];
            if(i==1&&cpuOpponent){go=true;brake=false;cpuLaneTimer+=dt;if(cpuLaneTimer>3.6f){cpuLaneTimer=0;r.lane=(r.lane+1)%3;}}
            if(left&&r.lane>0){r.lane--;input[i][0]=false;}
            if(right&&r.lane<2){r.lane++;input[i][1]=false;}
            RacingCatalog.VehicleSpec v=vehicle(i);RacingCatalog.DriverSpec d=driver(i);
            float handling=Math.max(.65f,Math.min(1.8f,d.handling*v.handling));
            float steeringRate=(motorcycle?2.25f:2.75f)*handling;
            r.visualLane+=(r.lane-r.visualLane)*Math.min(1f,dt*steeringRate);
            if(Math.abs(r.lane-r.visualLane)<.015f)r.visualLane=r.lane;
            float upgradeSpeed=v.topSpeed+r.vehicleUpgrade*7+r.driverUpgrade*2;
            float upgradeAcceleration=v.acceleration*(1+r.vehicleUpgrade*.035f)*d.launch*(1+r.driverUpgrade*.018f);
            if(go)r.speed=Math.min(upgradeSpeed,r.speed+190*upgradeAcceleration*dt);else r.speed=Math.max(90,r.speed-28*dt);
            if(brake)r.speed=Math.max(70,r.speed-300*dt);
            float aiBoost=(i==1&&cpuOpponent)?10:0;
            r.progress+=(r.speed+aiBoost)*dt/2600f;
        }
        Racer a=racers[0],b=racers[1];float lapGap=Math.abs(a.progress-b.progress);lapGap=Math.min(lapGap,Math.abs(lapGap-Math.round(lapGap)));
        if(Math.abs(a.visualLane-b.visualLane)<.24f&&lapGap<0.022f){if(a.progress>b.progress)b.speed=Math.max(80,b.speed-contactPenalty(1,dt));else a.speed=Math.max(80,a.speed-contactPenalty(0,dt));}
        if(a.progress>=3||b.progress>=3){running=false;winner=a.progress>=3&&b.progress>=3?(a.progress>=b.progress?0:1):a.progress>=3?0:1;message=driver(winner).name+(winner==1&&cpuOpponent?" (CPU)":"")+" wins the race.";}
        else message=driver(0).name+" · Lap "+a.lap()+" of 3 · "+Math.round(a.speed)+" km/h";
    }
    private float contactPenalty(int seat,float dt){Racer racer=racers[seat];float handling=driver(seat).handling*vehicle(seat).handling*(1+racer.driverUpgrade*.02f+racer.vehicleUpgrade*.015f);return 100*dt/Math.max(.7f,handling);}
}

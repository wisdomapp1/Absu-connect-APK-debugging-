package com.absuconnect.games.multiplayer.examples;

import com.absuconnect.games.multiplayer.AllowlistGameActionCodec;

/** Client input-shape guard for turn-based games; it does not validate or apply authoritative rules. */
public final class TurnBasedMatchAdapter extends AllowlistGameActionCodec {
    public TurnBasedMatchAdapter(String gameId) { super(requireTurnGame(gameId), actionTypes(gameId)); }

    private static String requireTurnGame(String id) {
        if (!"campus_ludo".equals(id) && !"naija_whot".equals(id) && !"billiards".equals(id))
            throw new IllegalArgumentException("Turn-based adapter requires campus_ludo, naija_whot or billiards");
        return id;
    }

    private static String[] actionTypes(String id) {
        requireTurnGame(id);
        if ("campus_ludo".equals(id)) return new String[]{"ready", "roll", "move", "pass", "resign"};
        if ("naija_whot".equals(id)) return new String[]{"ready", "play_card", "draw_card", "call_suit", "pass", "resign"};
        return new String[]{"ready", "shoot", "place_cue_ball", "resign"};
    }
}

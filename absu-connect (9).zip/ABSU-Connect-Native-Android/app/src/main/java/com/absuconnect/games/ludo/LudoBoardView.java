package com.absuconnect.games.ludo;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;
import java.util.List;

/** Native vector board with step-by-step token motion and capture feedback. */
public final class LudoBoardView extends View {
    public interface TokenTapListener { void onTokenTap(int token); }
    private static final int[] COLORS = {0xFF9D4543, 0xFFB58437, 0xFF27806E, 0xFF405783};
    private static final int[] PALE = {0xFFF1DFDD, 0xFFF2E8D6, 0xFFDCECE7, 0xFFE1E7F0};
    private static final int[][] TRACK = {
        {6,1},{6,2},{6,3},{6,4},{6,5},
        {5,6},{4,6},{3,6},{2,6},{1,6},{0,6},{0,7},{0,8},
        {1,8},{2,8},{3,8},{4,8},{5,8},{6,9},
        {6,10},{6,11},{6,12},{6,13},{6,14},{7,14},{8,14},
        {8,13},{8,12},{8,11},{8,10},{8,9},{9,8},
        {10,8},{11,8},{12,8},{13,8},{14,8},{14,7},{14,6},
        {13,6},{12,6},{11,6},{10,6},{9,6},{8,5},
        {8,4},{8,3},{8,2},{8,1},{8,0},{7,0},{6,0}
    };
    private static final int[][][] HOME_LANES = {
        {{7,1},{7,2},{7,3},{7,4},{7,5}},
        {{1,7},{2,7},{3,7},{4,7},{5,7}},
        {{7,13},{7,12},{7,11},{7,10},{7,9}},
        {{13,7},{12,7},{11,7},{10,7},{9,7}}
    };
    private static final float[][] OFFSETS = {{-.17f,-.17f},{.17f,-.17f},{-.17f,.17f},{.17f,.17f}};
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private LudoEngine engine;
    private TokenTapListener listener;
    private float left, top, cell;
    private int animatedPlayer = -1, animatedToken = -1;
    private float animatedProgress;
    private ValueAnimator moveAnimator, captureAnimator;
    private float captureX, captureY, capturePulse = -1f;
    private int captureColor;

    public LudoBoardView(Context context, LudoEngine engine, TokenTapListener listener) {
        super(context); this.engine = engine; this.listener = listener;
        setContentDescription("Ludo board. Tap one of the highlighted legal tokens after rolling.");
        if (TRACK.length != LudoEngine.TRACK_LENGTH) throw new IllegalStateException("Board track must have 52 squares");
    }

    public void setEngine(LudoEngine value) {
        cancelAnimations();
        engine = value;
        invalidate();
    }

    /** Animate the move already accepted by the rules engine; visuals never decide legality. */
    public void animateMove(LudoEngine.MoveResult result, Runnable finished) {
        if (result == null) { if (finished != null) finished.run(); return; }
        cancelMoveOnly();
        animatedPlayer = result.player;
        animatedToken = result.token;
        animatedProgress = result.fromProgress;
        float steps = Math.max(1, result.toProgress - result.fromProgress);
        moveAnimator = ValueAnimator.ofFloat(result.fromProgress, result.toProgress);
        moveAnimator.setDuration(Math.min(900L, 170L + Math.round(steps * 105L)));
        moveAnimator.setInterpolator(new DecelerateInterpolator(1.1f));
        moveAnimator.addUpdateListener(a -> { animatedProgress = (float) a.getAnimatedValue(); postInvalidateOnAnimation(); });
        moveAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(android.animation.Animator animation) { cancelled = true; }
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                animatedPlayer = animatedToken = -1;
                moveAnimator = null;
                invalidate();
                if (!cancelled && finished != null) finished.run();
            }
        });
        if (result.captured && result.capturedPlayer >= 0 && result.capturedToken >= 0) startCapturePulse(result);
        moveAnimator.start();
    }

    private void startCapturePulse(LudoEngine.MoveResult result) {
        int targetIndex = Math.floorMod(LudoEngine.startIndex(result.player) + result.toProgress, LudoEngine.TRACK_LENGTH);
        int oldProgress = Math.floorMod(targetIndex - LudoEngine.startIndex(result.capturedPlayer), LudoEngine.TRACK_LENGTH);
        float[] pos = tokenPosition(result.capturedPlayer, result.capturedToken, oldProgress);
        captureX = pos[0]; captureY = pos[1]; captureColor = COLORS[result.capturedPlayer]; capturePulse = 0f;
        if (captureAnimator != null) captureAnimator.cancel();
        captureAnimator = ValueAnimator.ofFloat(0f, 1f);
        captureAnimator.setDuration(500L);
        captureAnimator.addUpdateListener(a -> { capturePulse = (float) a.getAnimatedValue(); postInvalidateOnAnimation(); });
        captureAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(android.animation.Animator animation) { cancelled = true; }
            @Override public void onAnimationEnd(android.animation.Animator animation) { if (!cancelled) { capturePulse = -1f; captureAnimator = null; invalidate(); } }
        });
        captureAnimator.start();
    }

    private void cancelMoveOnly() {
        if (moveAnimator != null) { moveAnimator.cancel(); moveAnimator = null; }
        animatedPlayer = animatedToken = -1;
    }

    private void cancelAnimations() {
        cancelMoveOnly();
        if (captureAnimator != null) { captureAnimator.cancel(); captureAnimator = null; }
        capturePulse = -1f;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float size = Math.min(getWidth(), getHeight());
        left = (getWidth() - size) / 2f; top = (getHeight() - size) / 2f; cell = size / 15f;
        canvas.save(); canvas.translate(left, top);
        paint.setColor(0xFFF7F7F3); paint.setStyle(Paint.Style.FILL); canvas.drawRect(0,0,size,size,paint);
        drawBases(canvas);
        drawTrack(canvas);
        drawHomeLanes(canvas);
        drawCenter(canvas);
        drawTokens(canvas);
        drawCapturePulse(canvas);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(1f, cell * .025f)); paint.setColor(0xFFCCD2CC);
        canvas.drawRect(0,0,size,size,paint); paint.setStyle(Paint.Style.FILL);
        canvas.restore();
    }

    private void drawBases(Canvas c) {
        drawBase(c, 0, 0, 0); drawBase(c, 9, 0, 3); drawBase(c, 9, 9, 2); drawBase(c, 0, 9, 1);
    }
    private void drawBase(Canvas c, int x, int y, int player) {
        paint.setColor(PALE[player]); paint.setStyle(Paint.Style.FILL);
        RectF r = new RectF(x*cell+.04f*cell,y*cell+.04f*cell,(x+6)*cell-.04f*cell,(y+6)*cell-.04f*cell);
        c.drawRoundRect(r, cell*.38f, cell*.38f, paint);
        paint.setColor(COLORS[player]); c.drawRoundRect(new RectF(r.left+cell*.28f,r.top+cell*.28f,r.right-cell*.28f,r.bottom-cell*.28f),cell*.25f,cell*.25f,paint);
        paint.setColor(0xFFF8F8F5); c.drawRoundRect(new RectF(r.left+cell*.55f,r.top+cell*.55f,r.right-cell*.55f,r.bottom-cell*.55f),cell*.2f,cell*.2f,paint);
    }
    private void drawTrack(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        for (int i=0;i<TRACK.length;i++) {
            int player = playerForStartIndex(i);
            drawCell(c, TRACK[i][0], TRACK[i][1], 0xFFFFFFFF);
            if (i == 0 || i == 13 || i == 26 || i == 39) drawCell(c, TRACK[i][0], TRACK[i][1], PALE[player]);
            else if (i == 8 || i == 21 || i == 34 || i == 47) {
                float x=(TRACK[i][1]+.5f)*cell, y=(TRACK[i][0]+.5f)*cell;
                paint.setColor(0xFFAFB8B1); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(cell*.58f); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                c.drawText("✦",x,y+cell*.2f,paint);
            }
        }
    }
    private void drawHomeLanes(Canvas c) {
        for (int p=0;p<4;p++) for (int[] rc:HOME_LANES[p]) drawCell(c,rc[0],rc[1],PALE[p]);
    }
    private void drawCenter(Canvas c) {
        float x=7.5f*cell,y=7.5f*cell;
        paint.setColor(0xFFE9ECE7); c.drawCircle(x,y,cell*.95f,paint);
        paint.setColor(COLORS[0]); triangle(c,x,y, -1,-1, 1,-1);
        paint.setColor(COLORS[3]); triangle(c,x,y, 1,-1, 1,1);
        paint.setColor(COLORS[2]); triangle(c,x,y, 1,1, -1,1);
        paint.setColor(COLORS[1]); triangle(c,x,y, -1,1, -1,-1);
        paint.setColor(0xFFF7F7F3); c.drawCircle(x,y,cell*.18f,paint);
    }
    private void triangle(Canvas c,float cx,float cy,int ax,int ay,int bx,int by) {
        Path p=new Path(); p.moveTo(cx,cy); p.lineTo(cx+ax*cell*.9f,cy+ay*cell*.9f); p.lineTo(cx+bx*cell*.9f,cy+by*cell*.9f); p.close(); c.drawPath(p,paint);
    }
    private void drawCell(Canvas c,int row,int col,int color) {
        paint.setColor(color); paint.setStyle(Paint.Style.FILL);
        RectF r = new RectF(col*cell+.03f*cell,row*cell+.03f*cell,(col+1)*cell-.03f*cell,(row+1)*cell-.03f*cell);
        c.drawRoundRect(r,cell*.08f,cell*.08f,paint);
        paint.setColor(0x1A34413A); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(1f,cell*.018f)); c.drawRoundRect(r,cell*.08f,cell*.08f,paint); paint.setStyle(Paint.Style.FILL);
    }
    private void drawTokens(Canvas c) {
        List<Integer> legal=engine.legalTokens();
        for (int p=0;p<4;p++) for (int t=0;t<4;t++) {
            float progress = p==animatedPlayer && t==animatedToken ? animatedProgress : engine.progressOf(p,t);
            float[] pos=tokenPosition(p,t,progress);
            float x=pos[0],y=pos[1],radius=cell*.31f;
            boolean selectable=moveAnimator==null && p==engine.currentPlayer() && legal.contains(t);
            if (selectable) { paint.setColor(0x554E9F8B); c.drawCircle(x,y,radius*1.42f,paint); }
            paint.setColor(COLORS[p]); paint.setStyle(Paint.Style.FILL); c.drawCircle(x,y,radius,paint);
            paint.setColor(0xFFF8F8F5); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(2f,cell*.07f)); c.drawCircle(x,y,radius,paint); paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFFFFFFF); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(cell*.24f); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            c.drawText(Integer.toString(t+1),x,y+cell*.08f,paint);
        }
    }
    private void drawCapturePulse(Canvas c) {
        if (capturePulse < 0f) return;
        float radius = cell * (.36f + capturePulse * .72f);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(2f, cell * .09f));
        paint.setColor((Math.max(0, 255 - (int)(capturePulse * 255)) << 24) | (captureColor & 0x00ffffff));
        c.drawCircle(captureX, captureY, radius, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private float[] tokenPosition(int player,int token,float progress) {
        if (progress < 0f) {
            int baseX=(player==3)?9:0, baseY=(player==1||player==2)?9:0;
            int[][] corners={{1,1},{4,1},{1,4},{4,4}};
            float yardX=(baseX+corners[token][0]+.5f+OFFSETS[token][0])*cell;
            float yardY=(baseY+corners[token][1]+.5f+OFFSETS[token][1])*cell;
            if (progress > -1f) {
                float[] start={ (TRACK[LudoEngine.startIndex(player)][1]+.5f+OFFSETS[token][0])*cell,
                        (TRACK[LudoEngine.startIndex(player)][0]+.5f+OFFSETS[token][1])*cell };
                float f=progress+1f;
                return new float[]{yardX+(start[0]-yardX)*f,yardY+(start[1]-yardY)*f};
            }
            return new float[]{yardX,yardY};
        }
        if (progress >= LudoEngine.FINISH_PROGRESS) {
            float[][] finish={{7.5f,6.35f},{6.35f,7.5f},{7.5f,8.65f},{8.65f,7.5f}};
            return new float[]{finish[player][0]*cell,finish[player][1]*cell};
        }
        float ax,ay,bx,by,fraction;
        if (progress < 52f) {
            int step=Math.min(51,(int)Math.floor(progress)); fraction=progress-step;
            ax=(TRACK[step][1]+.5f+OFFSETS[token][0])*cell; ay=(TRACK[step][0]+.5f+OFFSETS[token][1])*cell;
            if (step < 51) { bx=(TRACK[step+1][1]+.5f+OFFSETS[token][0])*cell; by=(TRACK[step+1][0]+.5f+OFFSETS[token][1])*cell; }
            else { bx=(HOME_LANES[player][0][1]+.5f+OFFSETS[token][0])*cell; by=(HOME_LANES[player][0][0]+.5f+OFFSETS[token][1])*cell; }
        } else {
            float laneProgress=progress-52f;
            int step=Math.min(4,(int)Math.floor(laneProgress)); fraction=laneProgress-step;
            ax=(HOME_LANES[player][step][1]+.5f+OFFSETS[token][0])*cell; ay=(HOME_LANES[player][step][0]+.5f+OFFSETS[token][1])*cell;
            if (step < 4) { bx=(HOME_LANES[player][step+1][1]+.5f+OFFSETS[token][0])*cell; by=(HOME_LANES[player][step+1][0]+.5f+OFFSETS[token][1])*cell; }
            else { float[][] finish={{7.5f,6.35f},{6.35f,7.5f},{7.5f,8.65f},{8.65f,7.5f}}; bx=finish[player][0]*cell; by=finish[player][1]*cell; }
        }
        return new float[]{ax+(bx-ax)*fraction, ay+(by-ay)*fraction};
    }

    private int playerForStartIndex(int index) { return switch(index) { case 0 -> 0; case 13 -> 1; case 26 -> 2; case 39 -> 3; default -> -1; }; }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP || cell <= 0 || listener == null || moveAnimator != null) return true;
        float x=event.getX()-left,y=event.getY()-top;
        List<Integer> legal=engine.legalTokens(); float best=cell*1.25f; int found=-1;
        for (int token:legal) {
            float[] p=tokenPosition(engine.currentPlayer(),token,engine.progressOf(engine.currentPlayer(),token));
            float d=(float)Math.hypot(x-p[0],y-p[1]); if (d<best) { best=d; found=token; }
        }
        if (found>=0) listener.onTokenTap(found);
        performClick(); return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
    @Override protected void onDetachedFromWindow() { cancelAnimations(); super.onDetachedFromWindow(); }
    public static int trackLengthForCheck() { return TRACK.length; }
}

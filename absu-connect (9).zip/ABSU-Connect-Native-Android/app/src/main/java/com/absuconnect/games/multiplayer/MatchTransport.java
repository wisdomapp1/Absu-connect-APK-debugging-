package com.absuconnect.games.multiplayer;

import com.absuconnect.games.multiplayer.MatchProtocol.ActionReceipt;
import com.absuconnect.games.multiplayer.MatchProtocol.Listener;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchAction;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchException;
import com.absuconnect.games.multiplayer.MatchProtocol.MatchSnapshot;
import com.absuconnect.games.multiplayer.MatchProtocol.Subscription;

/**
 * Future authenticated transport boundary (for example a WebSocket to an authoritative match service).
 * This project deliberately ships no production implementation. Do not broadcast client-authored winners
 * or trust client-supplied identity, seat, sequence, version, positions, hits or currency.
 */
public interface MatchTransport {
    /** Subscribe after a known version; reconnect implementations should replay or request a full snapshot. */
    Subscription subscribe(String matchId, String authenticatedUserId, long afterVersion,
                           Listener listener) throws MatchException;
    /** Obtain a complete state image after joining or reconnecting. */
    MatchSnapshot fetchSnapshot(String matchId, String authenticatedUserId) throws MatchException;
    /** Server validates ownership, game rules, action ID, sequence and expected state version. */
    ActionReceipt submitAction(MatchAction action) throws MatchException;
}

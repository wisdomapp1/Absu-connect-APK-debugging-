package com.absuconnect.games;

import android.content.Context;
import android.content.SharedPreferences;

/** Shared network setting. Low-data mode is the default to keep student mobile-data use down. */
public final class NetworkMode {
    private static final String PREFS = "absu_network_mode";
    private static final String LOW_DATA = "low_data_enabled";
    private NetworkMode() { }
    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    public static boolean isLowData(Context context) { return prefs(context).getBoolean(LOW_DATA, true); }
    public static void setLowData(Context context, boolean enabled) { prefs(context).edit().putBoolean(LOW_DATA, enabled).apply(); }
}

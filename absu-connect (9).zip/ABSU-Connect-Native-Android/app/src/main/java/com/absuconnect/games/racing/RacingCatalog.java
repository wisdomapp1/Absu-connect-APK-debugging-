package com.absuconnect.games.racing;

/** Original arcade racing roster with progressive driver, car/bike, and livery tiers. */
public final class RacingCatalog {
    private RacingCatalog(){}
    public static final class DriverSpec {
        public final String name,style;
        public final float handling,launch;
        public final int unlockRank;
        public DriverSpec(String name,String style,float handling,float launch){this(name,style,handling,launch,1);}
        public DriverSpec(String name,String style,float handling,float launch,int unlockRank){this.name=name;this.style=style;this.handling=handling;this.launch=launch;this.unlockRank=unlockRank;}
        @Override public String toString(){return name+" · "+style;}
    }
    public static final DriverSpec[] DRIVERS={
        new DriverSpec("Nia / Beacon","Balanced",1.00f,1.00f),new DriverSpec("Tari / Vector","Quick hands",1.16f,.96f),
        new DriverSpec("Kene / Anchor","Steady launch",.92f,1.13f),new DriverSpec("Lami / Pulse","Smooth line",1.08f,1.00f),
        new DriverSpec("Ayo / Drift","Corner specialist",1.12f,.98f),new DriverSpec("Ife / Sable","Endurance",.98f,1.07f),
        new DriverSpec("Dara / Echo","Clean racing line",1.18f,1.02f,2),new DriverSpec("Mosi / Flint","Strong launch",.98f,1.17f,2),
        new DriverSpec("Kali / Skydrift","High-speed control",1.20f,1.04f,3),new DriverSpec("Tobe / Lockstep","Stable hands",1.10f,1.13f,3),
        new DriverSpec("Eno / Quasar","Precision cornering",1.24f,1.08f,4),new DriverSpec("Bisi / Northstar","Endurance racer",1.12f,1.20f,5),
        new DriverSpec("Seyi / Tempest","Aggressive launch",1.18f,1.23f,6),new DriverSpec("Nkem / Glasswing","Featherweight",1.32f,1.12f,8),
        new DriverSpec("Faru / Ironwood","Heavy grip",1.26f,1.22f,10),new DriverSpec("Amara / Solstice","Elite all-rounder",1.34f,1.28f,12)
    };
    public static final class VehicleSpec {
        public final String name,profile;
        public final int style,unlockRank;
        public final float topSpeed,acceleration,handling;
        public VehicleSpec(String name,String profile,int style,float topSpeed,float acceleration,float handling){this(name,profile,style,topSpeed,acceleration,handling,1);}
        public VehicleSpec(String name,String profile,int style,float topSpeed,float acceleration,float handling,int unlockRank){
            this.name=name;this.profile=profile;this.style=style;this.topSpeed=topSpeed;this.acceleration=acceleration;this.handling=handling;this.unlockRank=unlockRank;
        }
        @Override public String toString(){return name+" · "+profile;}
    }
    public static final VehicleSpec[] CARS={
        new VehicleSpec("Zipline R","Compact sprint",0,430,1.04f,1.06f),new VehicleSpec("Claymore GT","Grand tourer",1,490,1.08f,.91f),
        new VehicleSpec("Canopy EV","Electric",2,455,1.18f,1.02f),new VehicleSpec("Rook Rally","Rally hatch",3,445,1.03f,1.14f),
        new VehicleSpec("Mosaic Coupe","Track coupe",4,475,1.10f,1.00f),new VehicleSpec("Harbourline S","Touring hybrid",5,488,1.20f,1.04f,2),
        new VehicleSpec("Copper Comet GT","Sprint coupe",6,505,1.13f,1.00f,2),new VehicleSpec("Rainline Rally-X","All-weather rally",7,472,1.17f,1.21f,3),
        new VehicleSpec("Northstar V12","Grand circuit",8,525,1.21f,.99f,4),new VehicleSpec("Echo Circuit E","Electric race",9,510,1.33f,1.12f,5),
        new VehicleSpec("Monolith RS","Heavy endurance",10,542,1.26f,.95f,8),new VehicleSpec("Zenith Apex","Elite prototype",11,565,1.38f,1.15f,12)
    };
    public static final VehicleSpec[] BIKES={
        new VehicleSpec("Kestrel 250","Light street",0,395,1.13f,1.12f),new VehicleSpec("Rainline R","Sport",1,475,1.18f,.93f),
        new VehicleSpec("Tandem Trail","Scrambler",2,420,1.00f,1.16f),new VehicleSpec("Copper Comet","Roadster",3,455,1.08f,1.04f),
        new VehicleSpec("Pace 600","Touring",4,465,1.04f,.98f),new VehicleSpec("Harbourline 700","Sport tourer",5,490,1.20f,1.03f,2),
        new VehicleSpec("Canopy Sprint-E","Electric sprint",6,480,1.31f,1.12f,2),new VehicleSpec("Kitewind GP","Circuit sport",7,512,1.24f,1.01f,3),
        new VehicleSpec("Stonepath Scrambler","Trail sport",8,470,1.16f,1.24f,4),new VehicleSpec("Violet Current","Race hybrid",9,530,1.35f,1.10f,6),
        new VehicleSpec("Thunderwood 900","Endurance tourer",10,550,1.31f,1.06f,9),new VehicleSpec("Zenith Kestrel","Elite prototype",11,578,1.42f,1.17f,13)
    };
    public static final class SkinSpec {
        public final String name;
        public final int primary,trim,unlockRank;
        public SkinSpec(String name,int primary,int trim){this(name,primary,trim,1);}
        public SkinSpec(String name,int primary,int trim,int unlockRank){this.name=name;this.primary=primary;this.trim=trim;this.unlockRank=unlockRank;}
        @Override public String toString(){return name;}
    }
    public static final SkinSpec[] SKINS={
        new SkinSpec("Morning Mint",0xff39ba97,0xffe7cb73),new SkinSpec("Blue Current",0xff5289df,0xffc8e6ff),
        new SkinSpec("Copper Trail",0xffd47849,0xfff0d0a0),new SkinSpec("Orchid Lane",0xffb372cf,0xfff3b6e0),
        new SkinSpec("Night Circuit",0xff384c5a,0xff76ded1),new SkinSpec("Citrus Line",0xff9dbd4a,0xfff0e48d),
        new SkinSpec("Rain Glass",0xff4c9ca8,0xffc6f1e7,2),new SkinSpec("Ember Thread",0xffc75642,0xffffd18c,2),
        new SkinSpec("Violet Arc",0xff6e5ac2,0xffc8b9ff,3),new SkinSpec("Garden Shade",0xff496b4c,0xffc2db91,4),
        new SkinSpec("Bright Alloy",0xff929eaa,0xfff1f4ed,5),new SkinSpec("Tideglass",0xff397e9d,0xffa3e5eb,6),
        new SkinSpec("Star Bloom",0xffd46f9e,0xffffd8ee,8),new SkinSpec("Golden Hour",0xffc79830,0xffffe2a1,10),
        new SkinSpec("Midnight Crown",0xff29304d,0xff9faaff,12),new SkinSpec("Apex Aurora",0xff36a58e,0xfff0e7a1,15)
    };
    public static int wrap(int index,int count){return Math.floorMod(index,Math.max(1,count));}
    public static VehicleSpec vehicle(boolean motorcycle,int index){VehicleSpec[] list=motorcycle?BIKES:CARS;return list[wrap(index,list.length)];}
    public static int requiredRank(Object item){if(item instanceof DriverSpec)return ((DriverSpec)item).unlockRank;if(item instanceof VehicleSpec)return ((VehicleSpec)item).unlockRank;if(item instanceof SkinSpec)return ((SkinSpec)item).unlockRank;return 1;}
    public static int eligibleCount(Object[] items,int rank){int n=0;for(Object item:items){if(requiredRank(item)>rank)break;n++;}return n;}
    public static String[] names(Object[] items){String[] out=new String[items.length];for(int i=0;i<items.length;i++)out[i]=items[i].toString();return out;}
    public static String[] namesAtRank(Object[] items,int rank){int n=eligibleCount(items,rank);String[] out=new String[n];for(int i=0;i<n;i++)out[i]=items[i].toString();return out;}
}

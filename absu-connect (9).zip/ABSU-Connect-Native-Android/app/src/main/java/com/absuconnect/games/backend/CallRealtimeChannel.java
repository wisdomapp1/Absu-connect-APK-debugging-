package com.absuconnect.games.backend;

import android.os.Handler;
import android.os.Looper;
import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import java.util.concurrent.TimeUnit;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONArray;
import org.json.JSONObject;

/** Private Supabase Realtime channel used for WebRTC signaling and call-row updates. */
public final class CallRealtimeChannel {
    public interface Listener {
        void onSignal(JSONObject signal);
        void onCallRow(JSONObject row);
        void onReady();
        void onDisconnected(String reason);
    }

    private final OkHttpClient client = new OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String callId;
    private final AuthSession session;
    private final Listener listener;
    private volatile boolean closed;
    private volatile boolean ready;
    private WebSocket socket;
    private int ref = 1;
    private String joinRef = "1";
    private int retryAttempt = 0;
    private Runnable heartbeat;
    private Runnable reconnect;

    public CallRealtimeChannel(String callId, AuthSession session, Listener listener) {
        this.callId = callId;
        this.session = session;
        this.listener = listener;
    }

    public void connect() {
        if (closed) return;
        ready = false;
        HttpUrl base = HttpUrl.parse(BuildConfig.SUPABASE_URL);
        if (base == null) { notifyDisconnected("The Supabase URL is invalid."); return; }
        HttpUrl url = base.newBuilder().scheme("wss").addPathSegments("realtime/v1/websocket")
                .addQueryParameter("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .addQueryParameter("vsn", "1.0.0").build();
        socket = client.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                try {
                    JSONArray changes = new JSONArray().put(new JSONObject()
                            .put("event", "UPDATE").put("schema", "public")
                            .put("table", "call_sessions").put("filter", "id=eq." + callId));
                    JSONObject config = new JSONObject()
                            .put("broadcast", new JSONObject().put("ack", true).put("self", false))
                            .put("presence", new JSONObject().put("key", ""))
                            .put("postgres_changes", changes)
                            .put("private", true);
                    JSONObject payload = new JSONObject().put("config", config).put("access_token", session.accessToken);
                    joinRef = String.valueOf(ref++);
                    JSONObject join = new JSONObject().put("topic", "realtime:absu-call:" + callId)
                            .put("event", "phx_join").put("payload", payload)
                            .put("ref", joinRef).put("join_ref", joinRef);
                    webSocket.send(join.toString());
                    startHeartbeat(webSocket);
                } catch (Exception error) { notifyDisconnected("Could not join the secure call channel."); }
            }

            @Override public void onMessage(WebSocket webSocket, String raw) {
                if (closed) return;
                try {
                    JSONObject root = new JSONObject(raw);
                    String event = root.optString("event", "");
                    JSONObject payload = root.optJSONObject("payload");
                    if ("phx_reply".equals(event) && payload != null) {
                        if (!joinRef.equals(root.optString("ref"))) return;
                        JSONObject response = payload.optJSONObject("response");
                        if ("ok".equals(payload.optString("status"))) {
                            ready = true;
                            retryAttempt = 0;
                            if (reconnect != null) { handler.removeCallbacks(reconnect); reconnect = null; }
                            handler.post(() -> { if (!closed) listener.onReady(); });
                        } else if (response != null) {
                            scheduleReconnect("Call channel authorization failed: " + response.optString("reason", "access denied"));
                        }
                        return;
                    }
                    if ("phx_error".equals(event) || "phx_close".equals(event)) {
                        scheduleReconnect("The call signaling connection closed."); return;
                    }
                    if ("broadcast".equals(event) && payload != null) {
                        String eventName = payload.optString("event", "");
                        JSONObject inner = payload.optJSONObject("payload");
                        if ("call_signal".equals(eventName) && inner != null) {
                            handler.post(() -> { if (!closed) listener.onSignal(inner); });
                        }
                    }
                    if ("postgres_changes".equals(event) && payload != null) {
                        JSONObject data = payload.optJSONObject("data");
                        JSONObject record = data == null ? null : data.optJSONObject("record");
                        if (record != null) handler.post(() -> { if (!closed) listener.onCallRow(record); });
                    }
                } catch (Exception ignored) { }
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (!closed && socket == webSocket) {
                    socket = null;
                    scheduleReconnect("Call signaling connection failed: " + (t == null ? "network error" : t.getMessage()));
                }
            }

            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                if (!closed && socket == webSocket) {
                    socket = null;
                    scheduleReconnect("Call signaling disconnected.");
                }
            }
        });
    }

    public boolean isReady() { return ready && !closed; }

    public void sendSignal(JSONObject signal) {
        WebSocket ws = socket;
        if (ws == null || !ready || closed) return;
        try {
            JSONObject payload = new JSONObject().put("type", "broadcast")
                    .put("event", "call_signal").put("payload", signal);
            JSONObject packet = new JSONObject().put("topic", "realtime:absu-call:" + callId)
                    .put("event", "broadcast").put("payload", payload)
                    .put("ref", String.valueOf(ref++)).put("join_ref", joinRef);
            if (!ws.send(packet.toString())) notifyDisconnected("Could not send call signaling data.");
        } catch (Exception e) { notifyDisconnected("Could not encode call signaling data."); }
    }

    private void startHeartbeat(WebSocket ws) {
        heartbeat = new Runnable() {
            @Override public void run() {
                if (closed || socket != ws) return;
                try {
                    ws.send(new JSONObject().put("topic", "phoenix").put("event", "heartbeat")
                            .put("payload", new JSONObject()).put("ref", String.valueOf(ref++)).toString());
                } catch (Exception ignored) { }
                handler.postDelayed(this, 25000L);
            }
        };
        handler.postDelayed(heartbeat, 25000L);
    }

    private void scheduleReconnect(String message) {
        ready = false;
        notifyDisconnected(message);
        if (closed || reconnect != null) return;
        final long[] delays = {1000L, 2000L, 5000L, 8000L, 10000L};
        long delay = delays[Math.min(retryAttempt, delays.length - 1)];
        retryAttempt++;
        reconnect = () -> {
            reconnect = null;
            if (!closed && !ready) connect();
        };
        handler.postDelayed(reconnect, delay);
    }

    private void notifyDisconnected(String message) {
        ready = false;
        handler.post(() -> { if (!closed && listener != null) listener.onDisconnected(message); });
    }

    public void close() {
        closed = true; ready = false;
        if (heartbeat != null) handler.removeCallbacks(heartbeat);
        if (reconnect != null) handler.removeCallbacks(reconnect);
        if (socket != null) { socket.close(1000, "call finished"); socket = null; }
        client.dispatcher().executorService().shutdown();
    }
}

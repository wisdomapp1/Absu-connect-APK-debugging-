package com.absuconnect.games.action;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Persists offline-only career data on one device. Never use these values to authorize online competition or payments. */
public final class LocalGameProgressStore {
    private static final String PREFS="absu_offline_game_career_v1";
    private LocalGameProgressStore(){}
    private static SharedPreferences prefs(Context context){return context.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private static String safe(String text){return (text==null?"unknown":text.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_.-]","_"));}

    public static synchronized LocalGameProgression load(Context context){
        SharedPreferences p=prefs(context);Map<String,Integer> upgrades=new HashMap<>(),plays=new HashMap<>(),streaks=new HashMap<>();
        for(Map.Entry<String,?> e:p.getAll().entrySet()){
            Object value=e.getValue();if(!(value instanceof Integer))continue;
            String key=e.getKey();
            if(key.startsWith("upgrade."))upgrades.put(key.substring(8),(Integer)value);
            else if(key.startsWith("plays."))plays.put(key.substring(6),(Integer)value);
            else if(key.startsWith("streak."))streaks.put(key.substring(7),(Integer)value);
        }
        return new LocalGameProgression(p.getInt("experience",0),p.getInt("practice_credits",0),upgrades,plays,streaks);
    }
    private static void save(Context context,LocalGameProgression state){
        SharedPreferences p=prefs(context);SharedPreferences.Editor edit=p.edit().clear();
        edit.putInt("experience",state.experience()).putInt("practice_credits",state.practiceCredits());
        for(Map.Entry<String,Integer> e:state.upgrades().entrySet())edit.putInt("upgrade."+safe(e.getKey()),e.getValue());
        for(Map.Entry<String,Integer> e:state.playsByGame().entrySet())edit.putInt("plays."+safe(e.getKey()),e.getValue());
        for(Map.Entry<String,Integer> e:state.streaksByGame().entrySet())edit.putInt("streak."+safe(e.getKey()),e.getValue());
        for(Map.Entry<String,?> e:p.getAll().entrySet())if(e.getKey().startsWith("day.")&&e.getValue() instanceof String)edit.putString(e.getKey(),(String)e.getValue());
        edit.commit();
    }
    public static int upgradeLevel(Context context,String key){return load(context).upgradeLevel(key);}
    private static String localDay(Calendar day){return new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(day.getTime());}
    private static String today(){return localDay(Calendar.getInstance());}
    private static String yesterday(){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_MONTH,-1);return localDay(c);}
    public static boolean playedToday(Context context,String gameId){return today().equals(prefs(context).getString("day."+safe(gameId),null));}
    public static synchronized boolean upgrade(Context context,String key,int maxLevel){
        LocalGameProgression state=load(context);if(!state.upgrade(key,maxLevel))return false;save(context,state);return true;
    }
    public static final class MatchReward {
        public final int xp,credits,rank,streak;public final boolean dailyBonus,rankUp;
        MatchReward(int xp,int credits,int rank,int streak,boolean bonus,boolean rankUp){this.xp=xp;this.credits=credits;this.rank=rank;this.streak=streak;dailyBonus=bonus;this.rankUp=rankUp;}
    }
    /** Call once when a local match completes. Daily streak and bonus are calculated on this device's calendar day. */
    public static synchronized MatchReward recordMatch(Context context,String gameId,int baseXp,int baseCredits){
        String id=safe(gameId),today=today();SharedPreferences p=prefs(context);
        String lastDay=p.getString("day."+id,null);boolean firstToday=!today.equals(lastDay);
        LocalGameProgression state=load(context);int beforeXp=state.experience(),beforeCredits=state.practiceCredits(),beforeRank=state.rank();
        if(firstToday&&lastDay!=null&&!yesterday().equals(lastDay))state.resetStreak(id);
        state.recordMatch(id,baseXp,baseCredits,firstToday);save(context,state);
        p.edit().putString("day."+id,today).commit();
        return new MatchReward(state.experience()-beforeXp,state.practiceCredits()-beforeCredits,state.rank(),state.streak(id),firstToday,state.rank()>beforeRank);
    }
}

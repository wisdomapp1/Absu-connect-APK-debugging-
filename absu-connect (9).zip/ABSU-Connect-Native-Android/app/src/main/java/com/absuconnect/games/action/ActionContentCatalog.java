package com.absuconnect.games.action;

/** Original content inventories for local action-game play. Higher ranks are previewable unlock targets. */
public final class ActionContentCatalog {
    private ActionContentCatalog() {}

    public static final class CharacterSpec {
        public final String name,role,description;
        public final int health,stamina,primary,trim,unlockRank;
        public final float moveScale;
        public CharacterSpec(String name,String role,String description,int health,int stamina,float moveScale,int primary,int trim){
            this(name,role,description,health,stamina,moveScale,primary,trim,1);
        }
        public CharacterSpec(String name,String role,String description,int health,int stamina,float moveScale,int primary,int trim,int unlockRank){
            this.name=name;this.role=role;this.description=description;this.health=health;this.stamina=stamina;
            this.moveScale=moveScale;this.primary=primary;this.trim=trim;this.unlockRank=unlockRank;
        }
        @Override public String toString(){return name+" — "+role;}
    }
    public static final CharacterSpec[] FIGHTERS={
        new CharacterSpec("Nia / Beacon","All-rounder","Balanced pace and endurance.",100,100,1.00f,0xff42bca4,0xff173c38),
        new CharacterSpec("Tari / Vector","Quickstep","Fast movement; lighter frame.",92,110,1.16f,0xff69a8e8,0xff19375b),
        new CharacterSpec("Kene / Anchor","Vanguard","More durable; deliberate movement.",112,94,.91f,0xffe39a55,0xff52321c),
        new CharacterSpec("Lami / Pulse","Tactician","Even pace and steady stamina.",100,108,1.02f,0xffc77be5,0xff482558),
        new CharacterSpec("Ayo / Drift","Mobile","Quick repositioning and recovery.",96,104,1.10f,0xffe26d78,0xff59222c),
        new CharacterSpec("Ife / Sable","Sentinel","Resilient and controlled.",108,98,.96f,0xffd1c565,0xff494522),
        new CharacterSpec("Sola / Ember","Pressure","A forceful pace with measured stamina.",111,96,.97f,0xffe66c42,0xff542318,2),
        new CharacterSpec("Efe / Quill","Counter","A nimble counter-fighter.",95,112,1.12f,0xff6dbbb5,0xff173c42,2),
        new CharacterSpec("Ugo / Vale","Guardian","Heavy defence and controlled steps.",120,92,.88f,0xff9b805c,0xff3e3124,3),
        new CharacterSpec("Zuri / Lumen","Flow","High stamina for longer exchanges.",99,120,1.02f,0xffd97bb0,0xff532641,3),
        new CharacterSpec("Femi / Tidal","Reach","Long-range discipline and balance.",106,105,1.01f,0xff4d9cb1,0xff163a4d,4),
        new CharacterSpec("Mira / Forge","Impact","Strong stance; slower repositioning.",126,90,.84f,0xffc97942,0xff57301a,5),
        new CharacterSpec("Chisom / Rift","Feint","Fast recoveries and tricky tempo.",100,116,1.08f,0xff8677df,0xff32275f,6),
        new CharacterSpec("Timi / Vanta","Focus","A resilient specialist.",118,103,.94f,0xff354b60,0xff132431,8),
        new CharacterSpec("Oluchi / Nova","Surge","Quick movement with high stamina.",101,124,1.13f,0xffce6481,0xff501d31,10),
        new CharacterSpec("Obinna / Zenith","Champion","Premium all-round stat profile.",132,118,1.07f,0xffe0b74b,0xff4b3211,12),
        new CharacterSpec("Ajoke / Monolith","Bulwark","The most durable unlock; slower pace.",146,108,.82f,0xff80928d,0xff263532,14),
        new CharacterSpec("Enitan / Crown","Apex","Top-rank specialist with elite balance.",138,132,1.10f,0xffd2f0dd,0xff294d43,16)
    };
    public static final CharacterSpec[] OPERATORS={
        new CharacterSpec("Nia / Beacon","Field lead","Balanced health and movement.",100,100,1.00f,0xff42bca4,0xff173c38),
        new CharacterSpec("Tari / Vector","Runner","Quick lane changes; lighter armour.",92,110,1.16f,0xff69a8e8,0xff19375b),
        new CharacterSpec("Kene / Anchor","Vanguard","More health with slower movement.",112,94,.91f,0xffe39a55,0xff52321c),
        new CharacterSpec("Lami / Pulse","Scout","Steady pace and good recovery.",100,108,1.02f,0xffc77be5,0xff482558),
        new CharacterSpec("Ayo / Drift","Skirmisher","Fast repositioning.",96,104,1.10f,0xffe26d78,0xff59222c),
        new CharacterSpec("Ife / Sable","Sentinel","Durable all-rounder.",108,98,.96f,0xffd1c565,0xff494522),
        new CharacterSpec("Dara / Echo","Tracker","Improved speed and stamina.",98,118,1.13f,0xff4db3c0,0xff17363e,2),
        new CharacterSpec("Mosi / Flint","Support","Higher health and steady pace.",118,100,.95f,0xffc87a52,0xff4d291b,2),
        new CharacterSpec("Kali / Skydrift","Runner","High speed, lower health.",90,120,1.20f,0xff79a3dd,0xff1e3650,3),
        new CharacterSpec("Tobe / Lockstep","Defender","Strong health and measured movement.",124,94,.89f,0xff937b68,0xff3f3229,3),
        new CharacterSpec("Eno / Quasar","Scout","Fast, balanced operator.",102,116,1.10f,0xffa479d8,0xff38284c,4),
        new CharacterSpec("Bisi / Northstar","Medic","Resilient field specialist.",120,112,.96f,0xff6cbd8c,0xff214537,5),
        new CharacterSpec("Seyi / Tempest","Striker","Aggressive movement profile.",110,108,1.11f,0xffdb8554,0xff512a1d,6),
        new CharacterSpec("Nkem / Glasswing","Infiltrator","Very quick, compact health pool.",94,126,1.22f,0xffd47fb1,0xff52233e,8),
        new CharacterSpec("Faru / Ironwood","Guardian","Heavy protection and slow turns.",136,100,.84f,0xff627566,0xff28362d,10),
        new CharacterSpec("Amara / Solstice","Captain","Elite balance for high-rank players.",130,124,1.08f,0xffdfc15d,0xff584719,12),
        new CharacterSpec("Chidi / Overclock","Ace","Fastest top-tier movement profile.",118,138,1.18f,0xff5b89be,0xff1c314a,14),
        new CharacterSpec("Zola / Radiant","Champion","Premium high-rank all-rounder.",148,130,1.10f,0xffe8df9c,0xff514627,16)
    };
    /** Backward-compatible name retained for existing domain checks; new code should choose FIGHTERS or OPERATORS. */
    public static final CharacterSpec[] CHARACTERS=FIGHTERS;

    public static final class WeaponSpec {
        public final String name,type,handling;
        public final int magazine,damage,cooldownMs,reloadMs,range,reserveMagazines,unlockRank;
        public final float movementScale;
        public WeaponSpec(String name,String type,String handling,int magazine,int damage,int cooldownMs,int reloadMs,int range,int reserveMagazines,float movementScale){
            this(name,type,handling,magazine,damage,cooldownMs,reloadMs,range,reserveMagazines,movementScale,1);
        }
        public WeaponSpec(String name,String type,String handling,int magazine,int damage,int cooldownMs,int reloadMs,int range,int reserveMagazines,float movementScale,int unlockRank){
            this.name=name;this.type=type;this.handling=handling;this.magazine=magazine;this.damage=damage;this.cooldownMs=cooldownMs;
            this.reloadMs=reloadMs;this.range=range;this.reserveMagazines=reserveMagazines;this.movementScale=movementScale;this.unlockRank=unlockRank;
        }
        @Override public String toString(){return name+" · "+type;}
    }
    /** Fictional, non-real-world gun profiles; not replicas or real-firearm instructions. */
    public static final WeaponSpec[] GUNS={
        new WeaponSpec("Mako-9","Sidearm","Precise, compact",12,24,330,1100,38,3,1.00f),
        new WeaponSpec("Breeze-18","SMG","Quick fire, close range",24,13,135,1450,27,3,.94f),
        new WeaponSpec("Kite-AR","Rifle","Balanced all-rounder",30,19,220,1550,42,3,.86f),
        new WeaponSpec("Spear-3","Burst rifle","Three-round arcade burst",27,17,285,1650,43,3,.82f),
        new WeaponSpec("Drum-8","Shotgun","Heavy close-range spread",8,47,760,1750,17,4,.74f),
        new WeaponSpec("Farline","Marksman","Slow, accurate long range",10,58,880,1850,58,3,.70f),
        new WeaponSpec("Morrow-5","Carbine","Steady medium-range control",20,22,300,1400,36,3,.90f,2),
        new WeaponSpec("Cinder-12","Scatter","Fast close-range pellets",12,31,480,1450,23,3,.88f,2),
        new WeaponSpec("Tidebreak-44","Support LMG","Large arcade magazine; slow handling",44,18,160,2200,40,3,.62f,2),
        new WeaponSpec("Needle-12","Precision rifle","Long reach and careful timing",12,68,940,1900,64,3,.68f,2),
        new WeaponSpec("Morrow-X","Carbine","Stable medium-range option",24,27,270,1550,42,3,.89f,3),
        new WeaponSpec("Thicket-6","Arcade shotgun","High close-range impact",6,60,820,2000,19,4,.69f,4),
        new WeaponSpec("Cobalt-3","Burst rifle","Controlled three-shot volley",30,24,250,1700,50,3,.78f,5),
        new WeaponSpec("Lantern-7","Scout rifle","Quick aim and long reach",16,54,680,1750,61,3,.73f,7),
        new WeaponSpec("Drumline-52","Support LMG","High reserve and sustained fire",52,23,175,2450,45,3,.58f,10),
        new WeaponSpec("Northstar-DMR","Elite marksman","Top-tier precision profile",14,86,1120,2150,70,3,.64f,14)
    };
    public static final WeaponSpec[] FIGHTING_WEAPONS={
        new WeaponSpec("Practice Staff","Reach","Long, measured arcs",0,12,460,0,0,0,1f),
        new WeaponSpec("Twin Batons","Rapid","Fast combinations",0,8,320,0,0,0,1.04f),
        new WeaponSpec("Guard Gauntlets","Impact","Short, sturdy strikes",0,14,560,0,0,0,.92f),
        new WeaponSpec("Crescent Pair","Flow","Quick angled attacks",0,10,390,0,0,0,.98f),
        new WeaponSpec("Training Blades","Precision","Focused, balanced reach",0,11,430,0,0,0,.95f),
        new WeaponSpec("Rope-Dart Trainer","Technique","Long setup, controlled range",0,13,610,0,0,0,.88f),
        new WeaponSpec("Westwind Spear","Reach","Extended reach and deliberate tempo",0,15,560,0,0,0,.92f,2),
        new WeaponSpec("Stoneguard Shield","Defence","Low impact, stronger guard profile",0,10,520,0,0,0,.86f,2),
        new WeaponSpec("Lantern Bracers","Rapid","Quick linked strikes",0,13,350,0,0,0,1.03f,3),
        new WeaponSpec("Ridge Hammer","Impact","Slow, heavy practice blows",0,18,670,0,0,0,.80f,4),
        new WeaponSpec("Tidal Glaive","Reach","Balanced long-range style",0,17,570,0,0,0,.89f,5),
        new WeaponSpec("Loop Chain Trainer","Flow","Unpredictable wide arcs",0,16,610,0,0,0,.84f,6),
        new WeaponSpec("Dawn Pair","Precision","Fast high-skill profile",0,18,380,0,0,0,.98f,8),
        new WeaponSpec("Cloudstep Staff","Tempo","High control and recovery",0,19,420,0,0,0,1.02f,10),
        new WeaponSpec("Aegis Longguard","Defence","Heavy guard and counter profile",0,21,610,0,0,0,.78f,12),
        new WeaponSpec("Crown of Echoes","Mastery","Top-rank practice weapon profile",0,24,500,0,0,0,.94f,15)
    };

    public static final class SkillSpec {
        public final String name,description,effect;
        public final int value,durationMs,cooldownMs,staminaCost,unlockRank;
        public SkillSpec(String name,String description,String effect,int value,int durationMs,int cooldownMs,int staminaCost){
            this(name,description,effect,value,durationMs,cooldownMs,staminaCost,1);
        }
        public SkillSpec(String name,String description,String effect,int value,int durationMs,int cooldownMs,int staminaCost,int unlockRank){
            this.name=name;this.description=description;this.effect=effect;this.value=value;this.durationMs=durationMs;
            this.cooldownMs=cooldownMs;this.staminaCost=staminaCost;this.unlockRank=unlockRank;
        }
        @Override public String toString(){return name;}
    }
    public static final SkillSpec[] FIGHTING_SKILLS={
        new SkillSpec("Slipstream","A quick evasive burst.","DODGE",20,450,3000,12),
        new SkillSpec("Aegis Brace","Reduce an incoming hit.","GUARD",16,850,4200,18),
        new SkillSpec("Focus Break","A committed counter technique.","STRIKE",27,500,5200,35),
        new SkillSpec("Second Wind","Recover stamina between exchanges.","RECOVER",28,0,6500,0),
        new SkillSpec("Open-Hand Feint","A fast, low-cost opening move.","FEINT",16,300,3600,14),
        new SkillSpec("Rising Current","A measured stamina strike.","STRIKE",31,570,6200,34,2),
        new SkillSpec("Mirror Step","Evasive footwork with a longer cooldown.","DODGE",25,600,6800,13,2),
        new SkillSpec("Stone Rhythm","A defensive guard technique.","GUARD",20,1050,7200,17,3),
        new SkillSpec("Quick Study","Recover stamina after an exchange.","RECOVER",38,0,8200,0,4),
        new SkillSpec("Night Feint","A low-cost counter opening.","FEINT",24,350,7400,12,6),
        new SkillSpec("Zenith Arc","A powerful high-cost finisher.","STRIKE",44,650,9800,43,10),
        new SkillSpec("Crownfall","Elite technique with the longest recovery.","STRIKE",52,750,11500,48,15)
    };
    public static final SkillSpec[] SHOOTER_SKILLS={
        new SkillSpec("Burst Step","Move quickly for a short escape or reposition.","BURST",65,1250,7200,0),
        new SkillSpec("Aegis Field","Reduce incoming CPU fire while active.","SHIELD",55,2600,10500,0),
        new SkillSpec("Field Patch","Restore part of the operator's health.","HEAL",28,0,13000,0),
        new SkillSpec("Focus Window","Increase arcade shot damage briefly.","FOCUS",10,4200,9500,0),
        new SkillSpec("Pulse Net","Slow nearby CPU opponents for a short time.","SLOW",50,3000,10000,0,2),
        new SkillSpec("Recon Flash","Temporarily mark the CPU opponents.","RECON",30,4200,9800,0,2),
        new SkillSpec("Quick Patch+","Restore more operator health.","HEAL",42,0,15000,0,2),
        new SkillSpec("Slipstream Field","Longer movement burst.","BURST",75,1700,10500,0,3),
        new SkillSpec("Aegis Dome","Stronger temporary CPU-hit protection.","SHIELD",70,3600,14500,0,4),
        new SkillSpec("Pulse Net II","Slow bots for a longer window.","SLOW",62,4200,13800,0,6),
        new SkillSpec("Focus Window II","High damage bonus for a short burst.","FOCUS",18,5000,13200,0,10),
        new SkillSpec("Recon Crown","Longest high-rank scan window.","RECON",42,6000,16000,0,15)
    };

    public static final class Cover {
        public final float left,top,right,bottom;
        public Cover(float left,float top,float right,float bottom){this.left=left;this.top=top;this.right=right;this.bottom=bottom;}
    }
    public static final class ArenaSpec {
        public final String name,location,description;
        public final int ground,cover,accent,unlockRank;
        public final Cover[] coverPieces;
        public ArenaSpec(String name,String location,String description,int ground,int cover,int accent,Cover[] pieces){this(name,location,description,ground,cover,accent,pieces,1);}
        public ArenaSpec(String name,String location,String description,int ground,int cover,int accent,Cover[] pieces,int unlockRank){
            this.name=name;this.location=location;this.description=description;this.ground=ground;this.cover=cover;
            this.accent=accent;this.coverPieces=pieces;this.unlockRank=unlockRank;
        }
        @Override public String toString(){return name+" · "+location;}
    }
    public static final ArenaSpec[] ARENAS={
        new ArenaSpec("Glasscourt Walkways","Central campus court","Open sight lines with low planter cover.",0xff263c36,0xff607566,0xfff1c46b,new Cover[]{new Cover(18,24,29,29),new Cover(72,22,83,28),new Cover(38,48,46,53),new Cover(59,68,67,73)}),
        new ArenaSpec("Rainline Courtyard","Covered student commons","Sheltered lanes, paired cover blocks.",0xff293b49,0xff5c7184,0xff73d2d0,new Cover[]{new Cover(16,20,25,30),new Cover(75,19,84,29),new Cover(16,68,26,78),new Cover(74,68,84,78)}),
        new ArenaSpec("Old Stone Steps","East quad amphitheatre","Tiered open ground and central cover.",0xff494035,0xff7c6c54,0xffe3a45f,new Cover[]{new Cover(33,23,41,29),new Cover(58,23,66,29),new Cover(30,66,42,72),new Cover(58,66,70,72)}),
        new ArenaSpec("Lantern Commons","South garden plaza","Green lanes with offset cover.",0xff344437,0xff596f4e,0xffdeca7a,new Cover[]{new Cover(22,30,31,36),new Cover(65,20,75,26),new Cover(43,56,54,63),new Cover(68,72,77,79)},2),
        new ArenaSpec("Canopy Bridge","North garden terrace","Narrow crossing with offset planters.",0xff29423d,0xff597968,0xff9ed8bd,new Cover[]{new Cover(30,16,39,23),new Cover(62,35,72,42),new Cover(25,66,35,73)},2),
        new ArenaSpec("Observatory Court","Upper science quad","Open centre with a pair of low barricades.",0xff35404b,0xff737e84,0xffe5c97c,new Cover[]{new Cover(22,28,33,35),new Cover(67,63,79,70)},4),
        new ArenaSpec("Echo Gardens","West courtyard garden","Garden lanes divided by low stone cover.",0xff314637,0xff65784f,0xffc8d98e,new Cover[]{new Cover(17,44,29,50),new Cover(40,20,50,27),new Cover(70,43,83,50)},7),
        new ArenaSpec("Studio Steps","Arts-block forecourt","Broad steps and staggered cover.",0xff473d49,0xff736278,0xffe1a8cc,new Cover[]{new Cover(25,24,36,30),new Cover(63,25,74,31),new Cover(43,67,55,73)},12)
    };
    public static final class SkinSpec {
        public final String name;public final int primary,trim,unlockRank;
        public SkinSpec(String name,int primary,int trim){this(name,primary,trim,1);}
        public SkinSpec(String name,int primary,int trim,int unlockRank){this.name=name;this.primary=primary;this.trim=trim;this.unlockRank=unlockRank;}
        @Override public String toString(){return name;}
    }
    public static final SkinSpec[] SKINS={
        new SkinSpec("Daybreak",0xff43b9a1,0xfff1cc73),new SkinSpec("Blue Circuit",0xff558de0,0xffa8d9ff),new SkinSpec("Copper Leaf",0xffcd7748,0xffefd098),
        new SkinSpec("Orchid Drift",0xffad70cf,0xffedb3df),new SkinSpec("Night Signal",0xff404d5d,0xff66d6ce),new SkinSpec("Citrus Pop",0xff9dbf4b,0xfff2e492),
        new SkinSpec("Rain Glass",0xff4c9ca8,0xffc6f1e7,2),new SkinSpec("Ember Thread",0xffc75642,0xffffd18c,2),new SkinSpec("Violet Arc",0xff6e5ac2,0xffc8b9ff,3),new SkinSpec("Garden Shade",0xff496b4c,0xffc2db91,4),
        new SkinSpec("Bright Alloy",0xff929eaa,0xfff1f4ed,5),new SkinSpec("Tideglass",0xff397e9d,0xffa3e5eb,6),new SkinSpec("Star Bloom",0xffd46f9e,0xffffd8ee,8),new SkinSpec("Golden Hour",0xffc79830,0xffffe2a1,10),
        new SkinSpec("Midnight Crown",0xff29304d,0xff9faaff,12),new SkinSpec("Apex Aurora",0xff36a58e,0xfff0e7a1,15)
    };
    public static int wrap(int index,int length){return Math.floorMod(index,Math.max(1,length));}
    public static int requiredRank(Object item){
        if(item instanceof CharacterSpec)return ((CharacterSpec)item).unlockRank;
        if(item instanceof WeaponSpec)return ((WeaponSpec)item).unlockRank;
        if(item instanceof SkillSpec)return ((SkillSpec)item).unlockRank;
        if(item instanceof ArenaSpec)return ((ArenaSpec)item).unlockRank;
        if(item instanceof SkinSpec)return ((SkinSpec)item).unlockRank;
        return 1;
    }
    /** Catalogues are kept in increasing rank order, so their first N entries are selectable at a rank. */
    public static int eligibleCount(Object[] items,int rank){int n=0;for(Object item:items){if(requiredRank(item)>rank)break;n++;}return n;}
    public static String[] names(Object[] items){String[] out=new String[items.length];for(int i=0;i<items.length;i++)out[i]=items[i].toString();return out;}
    public static String[] namesAtRank(Object[] items,int rank){int n=eligibleCount(items,rank);String[] out=new String[n];for(int i=0;i<n;i++)out[i]=items[i].toString();return out;}
}

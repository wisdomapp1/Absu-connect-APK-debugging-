package com.absuconnect.games.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.action.LocalGameProgressStore;
import com.absuconnect.games.whot.WhotEngine;
import com.absuconnect.games.whot.WhotEngine.Card;

/** Native WHOT play screen. Online play remains an invite/lobby feature, not live synced gameplay. */
public final class WhotActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WhotEngine game;
    private GameSound sound;
    private boolean vsCpu = true, handoffVisible, matchRewarded, resultDialogShown;
    private boolean dealAnimating, animationBusy;
    private LinearLayout page, opponents, handRow;
    private TextView pile, suitLabel, status, turnLabel, modeLabel;
    private android.widget.Button drawButton, soundButton;
    private static final int[] COLORS = {0xff167a66, 0xffa67928, 0xff315c89, 0xff8a4550, 0xff6a538a};
    private static final String[] ICONS = {"●", "▲", "✚", "■", "★"};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sound = new GameSound(this);
        game = new WhotEngine(2);
        setContentView(buildView());
        chooseMode();
    }

    private View buildView() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UiKit.BG);
        page = UiKit.vertical(this);
        page.setPadding(UiKit.dp(this, 18), UiKit.dp(this, 18), UiKit.dp(this, 18), UiKit.dp(this, 22));
        scroll.addView(page);

        LinearLayout header = UiKit.row(this);
        page.addView(header);
        TextView title = UiKit.text(this, "NAIJA WHOT!", 21, UiKit.INK, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        soundButton = UiKit.button(this, soundLabel(), false);
        header.addView(soundButton);
        soundButton.setOnClickListener(v -> toggleSound());
        android.widget.Button restart = UiKit.button(this, "New game", false);
        header.addView(restart);
        restart.setOnClickListener(v -> chooseMode());
        UiKit.marginTop(this, UiKit.text(this, "The classic shape-matching card game — built from documented Nigerian rules.", 13, UiKit.MUTED, false), page, -2, 5);

        LinearLayout meta = UiKit.row(this);
        UiKit.marginTop(this, meta, page, -2, 18);
        modeLabel = UiKit.text(this, "", 12, UiKit.GREEN, true);
        meta.addView(modeLabel, new LinearLayout.LayoutParams(0, -2, 1));
        turnLabel = UiKit.text(this, "", 14, UiKit.INK, true);
        turnLabel.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        meta.addView(turnLabel);

        LinearLayout opponentsBox = UiKit.card(this);
        opponentsBox.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 10), UiKit.dp(this, 14), UiKit.dp(this, 10));
        UiKit.marginTop(this, opponentsBox, page, -2, 14);
        opponents = UiKit.vertical(this);
        opponentsBox.addView(opponents);

        LinearLayout center = UiKit.row(this);
        center.setGravity(Gravity.CENTER);
        UiKit.marginTop(this, center, page, -2, 16);
        pile = new TextView(this);
        pile.setGravity(Gravity.CENTER);
        pile.setTextColor(0xff263832);
        pile.setTextSize(19);
        pile.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        pile.setBackground(UiKit.rounded(0xffffffff, this));
        pile.setElevation(UiKit.dp(this, 3));
        center.addView(pile, new LinearLayout.LayoutParams(UiKit.dp(this, 116), UiKit.dp(this, 145)));
        LinearLayout suitInfo = UiKit.vertical(this);
        suitInfo.setPadding(UiKit.dp(this, 20), 0, 0, 0);
        center.addView(suitInfo);
        suitInfo.addView(UiKit.text(this, "SHAPE TO MATCH", 10, UiKit.MUTED, true));
        suitLabel = UiKit.text(this, "", 20, UiKit.GREEN, true);
        UiKit.marginTop(this, suitLabel, suitInfo, -2, 5);
        status = UiKit.text(this, "", 14, UiKit.INK, false);
        UiKit.marginTop(this, status, page, -2, 16);

        LinearLayout actions = UiKit.row(this);
        UiKit.marginTop(this, actions, page, -2, 11);
        drawButton = UiKit.button(this, "Draw a card", true);
        actions.addView(drawButton, new LinearLayout.LayoutParams(0, UiKit.dp(this, 48), 1));
        drawButton.setOnClickListener(v -> drawCard());

        TextView cardsHeader = UiKit.text(this, "YOUR HAND  ·  tap a playable card", 12, UiKit.MUTED, true);
        UiKit.marginTop(this, cardsHeader, page, -2, 17);
        HorizontalScrollView handScroll = new HorizontalScrollView(this);
        handScroll.setHorizontalScrollBarEnabled(false);
        UiKit.marginTop(this, handScroll, page, -2, 8);
        handRow = UiKit.row(this);
        handRow.setGravity(Gravity.CENTER_VERTICAL);
        handScroll.addView(handRow);
        page.addView(handScroll, new LinearLayout.LayoutParams(-1, UiKit.dp(this, 142)));
        UiKit.marginTop(this, UiKit.text(this, "Power cards: 1 = play again · 2 = draw two (stackable) · 5 = draw three (stackable) · 8 = skip · 14 = everyone else draws one · WHOT = call a shape.", 12, UiKit.MUTED, false), page, -2, 11);
        render();
        return scroll;
    }

    private String soundLabel() { return sound != null && sound.isMuted() ? "Sound off" : "Sound on"; }
    private void toggleSound() {
        boolean muted = sound.toggleMuted();
        soundButton.setText(muted ? "Sound off" : "Sound on");
        if (!muted) sound.play(ToneGenerator.TONE_PROP_ACK, 90);
    }

    private void chooseMode() {
        String[] modes = {"Solo vs CPU (2 players)", "Pass & play (2 players)", "Pass & play (3 players)", "Pass & play (4 players)"};
        new AlertDialog.Builder(this).setTitle("Start Naija WHOT!").setItems(modes, (d, which) -> {
            handler.removeCallbacksAndMessages(null);
            vsCpu = which == 0;
            game = new WhotEngine(which == 0 ? 2 : which + 1);
            handoffVisible = false; matchRewarded = false; resultDialogShown = false; animationBusy = false;
            dealAnimating = true;
            render();
            startDealAnimation();
        }).setCancelable(false).show();
    }

    private void startDealAnimation() {
        status.setText("Shuffling the pack · dealing 6 cards to each player…");
        sound.play(ToneGenerator.TONE_PROP_ACK, 120);
        pile.setText("SHUFFLING\n•••");
        AnimatorSet shuffle = new AnimatorSet();
        ObjectAnimator rotation = ObjectAnimator.ofFloat(pile, View.ROTATION, -9f, 9f, -6f, 6f, 0f);
        rotation.setDuration(680);
        ObjectAnimator scale = ObjectAnimator.ofFloat(pile, View.SCALE_X, 0.92f, 1.06f, 0.96f, 1f);
        scale.setDuration(680);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(pile, View.SCALE_Y, 0.92f, 1.06f, 0.96f, 1f);
        scaleY.setDuration(680);
        shuffle.playTogether(rotation, scale, scaleY);
        shuffle.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (isFinishing() || isDestroyed()) return;
                render();
                int count = handRow.getChildCount();
                for (int i = 0; i < count; i++) {
                    View card = handRow.getChildAt(i);
                    card.setAlpha(0f); card.setTranslationY(UiKit.dp(WhotActivity.this, 25)); card.setRotationY(88f);
                    card.animate().alpha(1f).translationY(0f).rotationY(0f).setDuration(230).setStartDelay(i * 75L)
                            .withStartAction(() -> sound.play(ToneGenerator.TONE_PROP_ACK, 45)).start();
                }
                long lastDealDelay = Math.max(0, count - 1) * 75L;
                for (int p = 0; p < opponents.getChildCount(); p++) {
                    View opponentRow = opponents.getChildAt(p);
                    if (!(opponentRow instanceof LinearLayout)) continue;
                    View backsView = ((LinearLayout) opponentRow).getChildAt(2);
                    if (!(backsView instanceof LinearLayout)) continue;
                    LinearLayout backs = (LinearLayout) backsView;
                    for (int j = 0; j < backs.getChildCount(); j++) {
                        View back = backs.getChildAt(j);
                        back.setAlpha(0f); back.setRotationY(88f);
                        long delay = lastDealDelay + (p * 3L + j) * 75L;
                        back.animate().alpha(1f).rotationY(0f).setDuration(180).setStartDelay(delay).start();
                        lastDealDelay = Math.max(lastDealDelay, delay);
                    }
                }
                long handDealEnd = 230L + Math.max(0, count - 1) * 75L;
                long allDealEnd = Math.max(handDealEnd, lastDealDelay + 180L) + 35L;
                handler.postDelayed(() -> {
                    dealAnimating = false;
                    status.setText(game.message());
                    render();
                    maybeContinue();
                }, allDealEnd);
            }
        });
        shuffle.start();
    }

    private void render() {
        if (page == null || game == null) return;
        boolean cpuTurn = vsCpu && game.currentPlayer() == 1 && !game.isGameOver();
        boolean localTurn = !vsCpu || game.currentPlayer() == 0;
        modeLabel.setText(vsCpu ? "SOLO PRACTICE · CPU" : "LOCAL PASS & PLAY · " + game.playerCount() + " PLAYERS");
        turnLabel.setText(game.isGameOver() ? "FINISHED" : cpuTurn ? "🤖  CPU TURN" : "●  PLAYER " + (game.currentPlayer() + 1) + " TURN");
        turnLabel.setTextColor(cpuTurn ? 0xffa67928 : game.isGameOver() ? UiKit.MUTED : UiKit.GREEN);
        Card top = game.topCard();
        pile.setText(top.isWhot() ? "WHOT\n20" : ICONS[top.suit] + "\n" + top.number + "\n" + WhotEngine.SUITS[top.suit].toUpperCase());
        pile.setTextColor(top.isWhot() ? 0xff914a16 : COLORS[top.suit]);
        suitLabel.setText(ICONS[game.activeSuit()] + "  " + WhotEngine.SUITS[game.activeSuit()].toUpperCase());
        suitLabel.setTextColor(COLORS[game.activeSuit()]);
        status.setText(game.message());

        opponents.removeAllViews();
        for (int p = 0; p < game.playerCount(); p++) {
            if (p == game.currentPlayer()) continue;
            String label = vsCpu && p == 1 ? "CPU" : "Player " + (p + 1);
            LinearLayout row = UiKit.row(this);
            TextView avatar = UiKit.text(this, vsCpu && p == 1 ? "AI" : "P" + (p + 1), 11, Color.WHITE, true);
            avatar.setGravity(Gravity.CENTER);
            GradientDrawable avatarBg = new GradientDrawable();
            avatarBg.setShape(GradientDrawable.OVAL);
            avatarBg.setColor(vsCpu && p == 1 ? 0xffa67928 : COLORS[p % COLORS.length]);
            avatar.setBackground(avatarBg);
            row.addView(avatar, new LinearLayout.LayoutParams(UiKit.dp(this, 34), UiKit.dp(this, 34)));
            TextView name = UiKit.text(this, label + "  ·  " + game.handSize(p) + " cards", 13, UiKit.INK, true);
            LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, -2, 1);
            nameLp.leftMargin = UiKit.dp(this, 10);
            row.addView(name, nameLp);
            int backs = Math.min(3, game.handSize(p));
            LinearLayout backsRow = UiKit.row(this);
            for (int i = 0; i < backs; i++) {
                TextView back = UiKit.text(this, "✦", 12, 0xffe4d7b9, true);
                back.setGravity(Gravity.CENTER);
                GradientDrawable backBg = new GradientDrawable();
                backBg.setColor(0xff24483e); backBg.setCornerRadius(UiKit.dp(this, 5));
                backBg.setStroke(UiKit.dp(this, 1), 0xffd1b778); back.setBackground(backBg);
                if (dealAnimating) back.setAlpha(0f);
                LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(UiKit.dp(this, 20), UiKit.dp(this, 29));
                if (i > 0) backLp.leftMargin = -UiKit.dp(this, 9);
                backsRow.addView(back, backLp);
            }
            row.addView(backsRow);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, UiKit.dp(this, 39));
            if (opponents.getChildCount() > 0) rowLp.topMargin = UiKit.dp(this, 7);
            opponents.addView(row, rowLp);
        }

        handRow.removeAllViews();
        boolean showHand = localTurn && !game.isGameOver();
        if (showHand) {
            for (Card card : game.currentHand()) {
                boolean legal = game.isPlayable(card);
                TextView tile = new TextView(this);
                tile.setText(card.isWhot() ? "WHOT\n20" : ICONS[card.suit] + "\n" + card.number + "\n" + WhotEngine.SUITS[card.suit].toUpperCase());
                tile.setTextSize(card.isWhot() ? 15 : 14);
                tile.setGravity(Gravity.CENTER);
                tile.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                tile.setTextColor(legal ? (card.isWhot() ? 0xff914a16 : COLORS[card.suit]) : 0xffa7ada9);
                tile.setBackground(UiKit.rounded(legal ? 0xffffffff : 0xffecece8, this));
                tile.setAlpha(legal ? 1f : 0.64f);
                tile.setElevation(UiKit.dp(this, legal ? 3 : 0));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UiKit.dp(this, 88), UiKit.dp(this, 126));
                lp.rightMargin = UiKit.dp(this, 8);
                handRow.addView(tile, lp);
                if (legal && !dealAnimating && !animationBusy) tile.setOnClickListener(v -> playCard(card, tile));
            }
        } else {
            TextView hidden = UiKit.text(this, game.isGameOver() ? "" : (cpuTurn ? "Opponent's cards stay face down" : "Pass phone to the next player to continue"), 13, UiKit.MUTED, false);
            handRow.addView(hidden);
        }
        drawButton.setEnabled(!game.isGameOver() && localTurn && !dealAnimating && !animationBusy);
        drawButton.setText(game.hasPenalty() ? "Draw " + game.pendingPenalty() + " cards" : "Draw 1 card");
        if (game.isGameOver()) {
            drawButton.setEnabled(false);
            handRow.removeAllViews();
            if (!matchRewarded) {
                matchRewarded = true;
                LocalGameProgressStore.MatchReward r = LocalGameProgressStore.recordMatch(this, "naija_whot", game.winner() == 0 ? 60 : 35, game.winner() == 0 ? 42 : 22);
                android.widget.Toast.makeText(this, "Career +" + r.xp + " XP · +" + r.credits + " Practice Points" + (r.rankUp ? " · Rank " + r.rank + " unlocked!" : ""), android.widget.Toast.LENGTH_LONG).show();
            }
            showResult();
        } else if (!vsCpu && game.currentPlayer() > 0 && !handoffVisible && !dealAnimating && !animationBusy) {
            handoffVisible = true;
            new AlertDialog.Builder(this).setTitle("Pass the phone").setMessage("Give the phone to Player " + (game.currentPlayer() + 1) + ". Their cards will appear after they continue.")
                    .setPositiveButton("Ready", (d, w) -> { handoffVisible = false; render(); })
                    .setCancelable(false).show();
        }
    }

    private void drawCard() {
        if (game.isGameOver() || dealAnimating || animationBusy) return;
        try {
            game.drawForCurrentPlayer();
            sound.play(ToneGenerator.TONE_PROP_ACK, 130);
            render();
            maybeContinue();
        } catch (Exception e) { status.setText(e.getMessage()); }
    }

    private void playCard(Card card, View tile) {
        if (game.isGameOver() || animationBusy || dealAnimating) return;
        if (card.isWhot()) {
            String[] options = new String[5];
            for (int i = 0; i < 5; i++) options[i] = ICONS[i] + "  " + WhotEngine.SUITS[i];
            new AlertDialog.Builder(this).setTitle("Call the next shape").setItems(options, (d, i) -> animateCardToPile(card, i, tile)).show();
        } else animateCardToPile(card, card.suit, tile);
    }

    private void animateCardToPile(Card card, int suit, View tile) {
        animationBusy = true;
        drawButton.setEnabled(false);
        int[] from = new int[2], to = new int[2];
        tile.getLocationOnScreen(from); pile.getLocationOnScreen(to);
        float dx = to[0] + pile.getWidth() / 2f - from[0] - tile.getWidth() / 2f;
        float dy = to[1] + pile.getHeight() / 2f - from[1] - tile.getHeight() / 2f;
        tile.animate().translationX(dx).translationY(dy).rotationBy(360f).rotationY(78f)
                .scaleX(0.72f).scaleY(0.72f).alpha(0.15f).setDuration(420)
                .withStartAction(() -> sound.play(ToneGenerator.TONE_PROP_ACK, 120))
                .withEndAction(() -> commitPlay(card, suit)).start();
    }

    private void commitPlay(Card card, int suit) {
        try {
            WhotEngine.TurnResult result = game.play(card, suit);
            handoffVisible = false; animationBusy = false;
            boolean special = card.isWhot() || card.number == 1 || card.number == 2 || card.number == 5 || card.number == 8 || card.number == 14;
            sound.play(special ? ToneGenerator.TONE_PROP_BEEP : ToneGenerator.TONE_PROP_ACK, special ? 220 : 100);
            render();
            animateTurnAndPile(special);
            maybeContinue();
        } catch (Exception e) {
            animationBusy = false;
            status.setText(e.getMessage());
            render();
        }
    }

    private void animateTurnAndPile(boolean special) {
        if (turnLabel != null) {
            turnLabel.setScaleX(0.86f); turnLabel.setScaleY(0.86f); turnLabel.setAlpha(0.55f);
            turnLabel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).start();
        }
        if (pile != null) {
            float tilt = special ? 12f : 5f;
            pile.animate().scaleX(special ? 1.13f : 1.06f).scaleY(special ? 1.13f : 1.06f).rotationBy(tilt).setDuration(130)
                    .withEndAction(() -> pile.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(190).start()).start();
        }
    }

    private void maybeContinue() {
        if (game.isGameOver()) return;
        if (vsCpu && game.currentPlayer() == 1) {
            handler.postDelayed(() -> {
                if (game.isGameOver() || game.currentPlayer() != 1 || isFinishing()) return;
                Card card = game.chooseCpuCard();
                try {
                    if (card == null) game.drawForCurrentPlayer();
                    else game.play(card, card.isWhot() ? game.cpuSuitChoice() : card.suit);
                    sound.play(ToneGenerator.TONE_PROP_ACK, 100);
                    render();
                    animateTurnAndPile(card != null && (card.isWhot() || card.number == 2 || card.number == 5 || card.number == 8 || card.number == 14));
                    maybeContinue();
                } catch (Exception e) { status.setText(e.getMessage()); }
            }, 650);
        }
    }

    private void showResult() {
        if (resultDialogShown) return;
        resultDialogShown = true;
        boolean playerWon = game.winner() == 0;
        sound.play(playerWon ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_NACK, 320);
        TextView heading = UiKit.text(this, playerWon ? "✦  VICTORY!  ✦" : "MATCH OVER", 24, playerWon ? UiKit.GREEN : UiKit.GOLD, true);
        heading.setGravity(Gravity.CENTER);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(heading)
                .setMessage(playerWon ? "You emptied your hand first. Your local career progress has been saved." : (vsCpu ? "The CPU emptied its hand first. Your local career progress has been saved." : "Player " + (game.winner() + 1) + " emptied their hand first."))
                .setPositiveButton("New game", (d, w) -> chooseMode())
                .setNegativeButton("Back to Game Center", (d, w) -> finish()).create();
        dialog.setOnShowListener(d -> {
            heading.setScaleX(0.75f); heading.setScaleY(0.75f); heading.setAlpha(0f);
            heading.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(420).start();
        });
        dialog.show();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (sound != null) sound.close();
        super.onDestroy();
    }
}

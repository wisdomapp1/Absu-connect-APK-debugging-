package com.absuconnect.games.shooter;

/** Camera basis for Fireline's original first-person 3D view. Angles are radians. */
public final class Shooter3DCamera {
    public static final class Vector2 {
        public final float x,z;
        Vector2(float x,float z){this.x=x;this.z=z;}
        public float length(){return (float)Math.sqrt(x*x+z*z);}
    }
    public static final class Vector3 {
        public final float x,y,z;
        Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;}
        public float length(){return (float)Math.sqrt(x*x+y*y+z*z);}
    }
    private float yaw,pitch;
    private final float sensitivity;

    public Shooter3DCamera(){this(.0032f);}
    public Shooter3DCamera(float sensitivity){this.sensitivity=Math.max(.0001f,sensitivity);}
    public synchronized void reset(){yaw=0;pitch=0;}
    public synchronized void look(float dragX,float dragY){
        yaw=wrap(yaw+dragX*sensitivity);
        pitch=clamp(pitch-dragY*sensitivity,-.78f,.78f);
    }
    public synchronized void setAngles(float yawRadians,float pitchRadians){
        yaw=wrap(yawRadians);pitch=clamp(pitchRadians,-.78f,.78f);
    }
    /** Returns normalized arena-plane (x,z) movement for strafe and forward joystick axes. */
    public synchronized Vector2 movement(float strafe,float forward){
        float side=clamp(strafe,-1f,1f),advance=clamp(forward,-1f,1f);
        float dx=(float)Math.sin(yaw)*advance+(float)Math.cos(yaw)*side;
        float dz=-(float)Math.cos(yaw)*advance+(float)Math.sin(yaw)*side;
        float length=(float)Math.sqrt(dx*dx+dz*dz);
        if(length>1f){dx/=length;dz/=length;}
        return new Vector2(dx,dz);
    }
    /** Unit direction matching the center-screen reticle in world coordinates. */
    public synchronized Vector3 direction(){
        float cp=(float)Math.cos(pitch);
        return new Vector3((float)Math.sin(yaw)*cp,(float)Math.sin(pitch),-(float)Math.cos(yaw)*cp);
    }
    public synchronized float yaw(){return yaw;}
    public synchronized float pitch(){return pitch;}
    private static float wrap(float a){
        while(a>(float)Math.PI)a-=(float)(Math.PI*2.0);
        while(a<-(float)Math.PI)a+=(float)(Math.PI*2.0);
        return a;
    }
    private static float clamp(float value,float min,float max){return Math.max(min,Math.min(max,value));}
}

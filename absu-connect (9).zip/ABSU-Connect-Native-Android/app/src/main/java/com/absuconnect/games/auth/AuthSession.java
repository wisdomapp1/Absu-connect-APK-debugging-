package com.absuconnect.games.auth;

public final class AuthSession {
    public final String accessToken;
    public final String refreshToken;
    public final String userId;
    public final String email;
    public final long expiresAtEpochSeconds;

    public AuthSession(String accessToken, String refreshToken, String userId, String email, long expiresAtEpochSeconds) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.userId = userId;
        this.email = email;
        this.expiresAtEpochSeconds = expiresAtEpochSeconds;
    }

    public boolean isFresh() { return expiresAtEpochSeconds > (System.currentTimeMillis() / 1000L) + 90L; }
}

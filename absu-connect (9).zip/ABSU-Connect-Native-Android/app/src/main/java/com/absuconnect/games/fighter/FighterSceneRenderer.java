package com.absuconnect.games.fighter;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Original abstract fighter and arena meshes assembled from procedural low-poly geometry. */
public final class FighterSceneRenderer implements GLSurfaceView.Renderer {
    private static final String VERTEX="attribute vec3 aPosition; uniform mat4 uMvp; void main(){ gl_Position=uMvp*vec4(aPosition,1.0); }";
    private static final String FRAGMENT="precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }";
    private final float[] projection=new float[16],view=new float[16],vp=new float[16],model=new float[16],mvp=new float[16];
    private final FloatBuffer cube;
    private int program,positionHandle,matrixHandle,colorHandle;
    private volatile int pose,enemyPose,weaponIndex,arenaIndex;
    private volatile float spacing=3.15f;
    private volatile float[] playerArmor={.34f,.55f,.62f,1f},playerDark={.09f,.15f,.19f,1f},playerAccent={.85f,.76f,.42f,1f};
    private volatile float[] enemyArmor={.70f,.44f,.26f,1f},enemyDark={.20f,.12f,.10f,1f},enemyAccent={.85f,.76f,.42f,1f};
    private volatile float[] floor={.12f,.16f,.16f,1f},ring={.22f,.28f,.27f,1f};

    public FighterSceneRenderer(){
        float[] vertices={
            -1,-1,1,1,-1,1,1,1,1,-1,-1,1,1,1,1,-1,1,1,
            1,-1,-1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,1,-1,1,1,-1,
            -1,-1,-1,-1,-1,1,-1,1,1,-1,-1,-1,-1,1,1,-1,1,-1,
            1,-1,1,1,-1,-1,1,1,-1,1,-1,1,1,1,-1,1,1,1,
            -1,1,1,1,1,1,1,1,-1,-1,1,1,1,1,-1,-1,1,-1,
            -1,-1,-1,1,-1,-1,1,-1,1,-1,-1,-1,1,-1,1,-1,-1,1
        };
        cube=ByteBuffer.allocateDirect(vertices.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();cube.put(vertices).position(0);
    }
    public void setPose(int value){pose=value;}
    public void setEnemyPose(int value){enemyPose=value;}
    public void setSpacing(float value){spacing=Math.max(1.35f,Math.min(4.5f,value));}
    public void setWeapon(int index){weaponIndex=Math.max(0,index);}
    public void setArena(int index){arenaIndex=Math.max(0,index);}
    public void setPalette(int playerPrimary,int playerSecondary,int playerHighlight,int enemyPrimary,int enemySecondary,int enemyHighlight,int arenaGround,int arenaAccent){
        playerArmor=rgba(playerPrimary);playerDark=rgba(playerSecondary);playerAccent=rgba(playerHighlight);
        enemyArmor=rgba(enemyPrimary);enemyDark=rgba(enemySecondary);enemyAccent=rgba(enemyHighlight);
        floor=rgba(arenaGround);ring=rgba(arenaAccent);
    }
    private static float[] rgba(int color){return new float[]{((color>>16)&255)/255f,((color>>8)&255)/255f,(color&255)/255f,1f};}

    @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){
        GLES20.glClearColor(.055f,.075f,.08f,1f);GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        program=makeProgram(VERTEX,FRAGMENT);positionHandle=GLES20.glGetAttribLocation(program,"aPosition");matrixHandle=GLES20.glGetUniformLocation(program,"uMvp");colorHandle=GLES20.glGetUniformLocation(program,"uColor");
    }
    @Override public void onSurfaceChanged(GL10 gl,int width,int height){
        GLES20.glViewport(0,0,width,height);float aspect=(float)width/Math.max(1,height);Matrix.perspectiveM(projection,0,38f,aspect,.1f,100f);
        Matrix.setLookAtM(view,0,0,4.1f,8.4f,0,1.25f,0,0,1,0);Matrix.multiplyMM(vp,0,projection,0,view,0);
    }
    @Override public void onDrawFrame(GL10 gl){
        long now=System.currentTimeMillis();GLES20.glClearColor(floor[0]*.28f,floor[1]*.28f,floor[2]*.28f,1f);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);GLES20.glUseProgram(program);
        cube.position(0);GLES20.glEnableVertexAttribArray(positionHandle);GLES20.glVertexAttribPointer(positionHandle,3,GLES20.GL_FLOAT,false,0,cube);
        drawArena(now);
        float half=spacing*.5f;drawFighter(-half,pose,playerArmor,playerDark,playerAccent,weaponIndex,now*.001f);
        drawFighter(half,enemyPose,enemyArmor,enemyDark,enemyAccent,weaponIndex,now*.001f+1.3f);
        GLES20.glDisableVertexAttribArray(positionHandle);
    }
    private void drawArena(long now){
        drawBox(0,-.14f,0,5.8f,.16f,3.6f,0,floor);
        drawBox(0,-.045f,0,4.9f,.035f,2.55f,0,ring);
        drawBox(0,-.022f,0,4.55f,.025f,2.20f,0,blend(floor,ring,.48f));
        float[] border=blend(ring,new float[]{.92f,.80f,.48f,1f},.36f);
        for(int x=-2;x<=2;x+=4){drawBox(x,-.005f,0,.035f,.012f,2.8f,0,border);}
        for(int z=-1;z<=1;z+=2){drawBox(0,-.004f,z,5.2f,.012f,.035f,0,border);}
        // Original arena landmarks: compact shapes distinguish all eight campus settings.
        switch(arenaIndex){
            case 0: // Glasscourt Walkways
                for(int x=-2;x<=2;x+=2){drawBox(x,1.9f,-2.0f,.11f,3.8f,.11f,0,border);drawBox(x,1.9f,2.0f,.11f,3.8f,.11f,0,border);}
                drawBox(0,3.85f,0,4.2f,.10f,.10f,0,ring);break;
            case 1: // Rainline Courtyard
                drawBox(0,3.4f,-2.0f,4.4f,.16f,1.5f,0,blend(floor,ring,.34f));
                for(int x=-2;x<=2;x+=4)drawBox(x,1.7f,-2.0f,.12f,3.4f,.12f,0,border);break;
            case 2: case 7: // Old Stone / Studio Steps
                for(int i=0;i<4;i++){float z=-2.25f-i*.38f;float h=.36f+i*.28f;drawBox(0,h*.5f,z,4.8f-i*.45f,h,.36f,0,blend(floor,ring,.18f+i*.12f));}break;
            case 3: // Lantern Commons
                for(int x=-2;x<=2;x+=2){drawBox(x,1.5f,-2.25f,.13f,3f,.13f,0,blend(floor,ring,.28f));drawBox(x,3.05f,-2.25f,.52f,.12f,.52f,0,border);}
                drawBox(0,3.2f,-2.25f,4.4f,.11f,.12f,0,ring);break;
            case 4: // Canopy Bridge
                drawBox(0,3.5f,0,4.5f,.18f,3.2f,0,blend(floor,ring,.24f));
                for(int x=-2;x<=2;x+=4)for(int z=-1;z<=1;z+=2)drawBox(x,1.75f,z,.12f,3.5f,.12f,0,border);break;
            case 5: // Observatory Court
                drawBox(0,.25f,-2.25f,1.6f,.35f,.45f,0,blend(floor,ring,.30f));drawBox(0,1.8f,-2.4f,.13f,3.1f,.13f,0,border);drawBox(0,3.4f,-2.4f,.7f,.35f,.7f,0,ring);break;
            case 6: // Echo Gardens
                for(int x=-2;x<=2;x+=4)for(int z=-1;z<=1;z+=2){drawBox(x,.72f,z,.2f,1.45f,.2f,0,blend(floor,ring,.3f));drawBox(x,1.62f,z,.9f,.8f,.9f,now*.018f%360f,border);}break;
            default:drawBox(0,2.8f,-2.2f,3.6f,.14f,.12f,0,border);
        }
    }
    private void drawFighter(float x,int action,float[] armor,float[] dark,float[] highlight,int weapon,float time){
        float front=x<0?1f:-1f;
        float idle=(float)Math.sin(time*3.1f+(x<0?0:1.4f))*.035f;
        float duck=action==3?.17f:0f;
        float lunge=action==1?.23f:action==4?.38f:0f;
        boolean guard=action==2;
        float stride=action==3?(float)Math.sin(time*18f)*.20f:0f;
        float lean=front*(lunge+(action==2?-.035f:0f));
        // Split chest, shoulder, waist, limb and head volumes read more clearly than a single block silhouette.
        drawBox(x,1.52f+idle-duck,0,.52f,.63f,.34f,lean*18f,armor);
        drawBox(x+front*.025f,1.73f+idle-duck,0,.46f,.23f,.37f,lean*14f,blend(armor,highlight,.22f));
        drawBox(x,1.13f-duck,0,.41f,.20f,.29f,0,dark);
        drawBox(x,2.00f+idle-duck,0,.17f,.20f,.18f,0,highlight);
        drawBox(x,2.22f+idle-duck,0,.32f,.31f,.29f,0,dark);
        drawBox(x+front*.055f,2.23f+idle-duck,.15f,.26f,.12f,.045f,0,highlight);
        drawBox(x-front*.23f,1.73f+idle-duck,0,.17f,.18f,.36f,lean*10f,highlight);
        drawBox(x+front*.23f,1.73f+idle-duck,0,.17f,.18f,.36f,lean*10f,highlight);
        float frontLegX=x+front*.17f+stride*.38f,backLegX=x-front*.17f-stride*.38f;
        drawBox(frontLegX,.73f-duck,0,.19f,.57f,.22f,action==3?stride*45f:front*.06f,dark);
        drawBox(backLegX,.73f-duck,0,.19f,.57f,.22f,action==3?-stride*45f:-front*.06f,dark);
        drawBox(frontLegX+front*.04f,.36f-duck,.025f,.23f,.19f,.25f,0,blend(dark,highlight,.18f));
        drawBox(backLegX-front*.04f,.36f-duck,.025f,.23f,.19f,.25f,0,blend(dark,highlight,.18f));
        drawBox(frontLegX+front*.12f,.20f-duck,.10f,.36f,.12f,.42f,0,dark);
        drawBox(backLegX-front*.10f,.20f-duck,.10f,.36f,.12f,.42f,0,dark);
        float frontArmY=guard?1.83f:1.48f-duck;
        float frontArmX=guard?x+front*.37f:x+front*(.42f+lunge*.48f);
        float armAngle=guard?-front*22f:action==1?-front*12f:action==4?-front*35f:front*8f;
        drawBox(frontArmX,frontArmY,0,.18f,guard?.45f:.52f,.20f,armAngle,armor);
        drawBox(x-front*.43f,1.47f+idle-duck,0,.18f,.48f,.20f,guard?front*18f:front*32f,armor);
        drawBox(x+front*(guard?.56f:.49f+lunge*.82f),frontArmY-.24f,.04f,.23f,.21f,.24f,0,dark);
        drawBox(x-front*.56f,1.20f-duck,.04f,.22f,.20f,.22f,0,dark);
        drawWeapon(x,front,frontArmY,guard,action,weapon,highlight);
        // Small shoulder/hip marks give each palette a readable identity while remaining original placeholder art.
        drawBox(x-front*.02f,1.31f-duck,.16f,.17f,.07f,.035f,0,highlight);
    }
    private void drawWeapon(float x,float front,float y,boolean guarding,int action,int weapon,float[] color){
        float reach=.54f+Math.min(weapon,7)*.055f;
        float handX=x+front*(weapon%4==1||weapon%4==3?.58f:weapon%4==2?.55f:.53f);
        float tilt=guarding?front*22f:action==4?-front*32f:action==1?front*18f:0f;
        // Staff, spear, glaive and mastery profiles use a longer abstract practice prop.
        if(weapon==0||weapon==5||weapon==6||weapon==10||weapon==13||weapon==15){
            drawBox(handX+front*.12f,y-.06f,.06f,.055f,reach+.28f,.065f,tilt,color);
            drawBox(handX+front*.12f,y+reach*.37f,.065f,.22f,.055f,.08f,tilt*.35f,color);
        }else if(weapon==7||weapon==14){
            drawBox(handX+front*.12f,y-.05f,.06f,.45f,.53f,.09f,tilt,color);
            drawBox(handX+front*.12f,y-.05f,.12f,.26f,.32f,.04f,tilt,blend(color,new float[]{.14f,.18f,.18f,1f},.55f));
        }else if(weapon==1||weapon==3||weapon==8||weapon==12){
            drawBox(handX+front*.10f,y-.04f,.06f,.055f,.42f,.06f,tilt,color);
            drawBox(x-front*.56f,1.15f,.06f,.055f,.39f,.06f,-tilt,color);
        }else{
            drawBox(handX+front*.10f,y-.05f,.06f,.06f,.50f,.06f,tilt,color);
        }
    }
    private void drawBox(float x,float y,float z,float sx,float sy,float sz,float rotate,float[] color){
        Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);if(rotate!=0)Matrix.rotateM(model,0,rotate,0,0,1);Matrix.scaleM(model,0,sx,sy,sz);
        Matrix.multiplyMM(mvp,0,vp,0,model,0);GLES20.glUniformMatrix4fv(matrixHandle,1,false,mvp,0);GLES20.glUniform4fv(colorHandle,1,color,0);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);
    }
    private static float[] blend(float[] a,float[] b,float amount){float t=Math.max(0,Math.min(1,amount));return new float[]{a[0]*(1-t)+b[0]*t,a[1]*(1-t)+b[1]*t,a[2]*(1-t)+b[2]*t,1f};}
    private static int makeProgram(String vs,String fs){
        int v=compile(GLES20.GL_VERTEX_SHADER,vs),f=compile(GLES20.GL_FRAGMENT_SHADER,fs),p=GLES20.glCreateProgram();
        GLES20.glAttachShader(p,v);GLES20.glAttachShader(p,f);GLES20.glLinkProgram(p);int[] status=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,status,0);
        if(status[0]==0)throw new IllegalStateException("OpenGL program link failed: "+GLES20.glGetProgramInfoLog(p));return p;
    }
    private static int compile(int type,String source){
        int shader=GLES20.glCreateShader(type);GLES20.glShaderSource(shader,source);GLES20.glCompileShader(shader);int[] status=new int[1];GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,status,0);
        if(status[0]==0)throw new IllegalStateException("OpenGL shader compile failed: "+GLES20.glGetShaderInfoLog(shader));return shader;
    }
}

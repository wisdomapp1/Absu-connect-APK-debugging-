package com.absuconnect.games.multiplayer;

import com.absuconnect.games.GameCatalog;
import com.absuconnect.games.multiplayer.MatchProtocol.ActionIntent;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** Client-side input-shape guard only; the server must repeat validation and simulate game rules. */
public abstract class AllowlistGameActionCodec implements GameActionCodec {
    private final String gameId;
    private final Set<String> allowedTypes;

    protected AllowlistGameActionCodec(String gameId,String... allowedTypes) {
        if (GameCatalog.find(gameId)==null) throw new IllegalArgumentException("Unknown game ID: "+gameId);
        this.gameId=gameId;
        this.allowedTypes=Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(allowedTypes)));
    }

    @Override public final String gameId(){return gameId;}

    @Override public final ActionIntent encode(String actionType,Map<String,String> fields) {
        return validate(new ActionIntent(gameId,actionType,fields==null?Collections.emptyMap():fields));
    }

    @Override public final ActionIntent validate(ActionIntent intent) {
        if(intent==null||!gameId.equals(intent.gameId))throw new IllegalArgumentException("Action game ID does not match codec");
        if(!allowedTypes.contains(intent.type))throw new IllegalArgumentException("Unsupported "+gameId+" action: "+intent.type);
        if(intent.fields.size()>16)throw new IllegalArgumentException("Action has too many fields");
        Map<String,String> safe=new LinkedHashMap<>();
        for(Map.Entry<String,String> entry:intent.fields.entrySet()){
            String key=entry.getKey(),value=entry.getValue();
            if(key==null||!key.matches("[A-Za-z][A-Za-z0-9_]{0,31}"))throw new IllegalArgumentException("Invalid action field name");
            if(value==null||value.length()>128)throw new IllegalArgumentException("Invalid action field value");
            safe.put(key,value);
        }
        return new ActionIntent(gameId,intent.type,safe);
    }
}

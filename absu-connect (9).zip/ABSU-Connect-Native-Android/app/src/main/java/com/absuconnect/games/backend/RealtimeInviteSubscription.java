package com.absuconnect.games.backend;

import android.os.Handler;
import android.os.Looper;
import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import java.util.concurrent.TimeUnit;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONArray;
import org.json.JSONObject;

/** Supabase Realtime protocol scaffold for invite inserts; close it with the owning Activity lifecycle. */
public final class RealtimeInviteSubscription {
    public interface Listener { void onChanged(); void onDisconnected(String reason); }
    private final OkHttpClient client = new OkHttpClient.Builder()
            .pingInterval(25, TimeUnit.SECONDS).build();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebSocket socket;
    private Listener listener;

    public void subscribe(AuthSession session, Listener listener) {
        this.listener = listener;
        HttpUrl base = HttpUrl.parse(BuildConfig.SUPABASE_URL);
        if (base == null) { listener.onDisconnected("Invalid backend URL"); return; }
        HttpUrl url = base.newBuilder().scheme("wss").addPathSegments("realtime/v1/websocket")
                .addQueryParameter("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .addQueryParameter("vsn", "1.0.0").build();
        socket = client.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                try {
                    JSONObject postgresChange = new JSONObject().put("event", "INSERT").put("schema", "public")
                            .put("table", "game_invites").put("filter", "recipient_id=eq." + session.userId);
                    JSONArray changes = new JSONArray().put(postgresChange);
                    JSONObject config = new JSONObject().put("broadcast", new JSONObject().put("ack", false).put("self", false))
                            .put("presence", new JSONObject().put("key", ""))
                            .put("postgres_changes", changes).put("private", false);
                    JSONObject payload = new JSONObject().put("config", config).put("access_token", session.accessToken);
                    JSONObject join = new JSONObject().put("topic", "realtime:game-inbox-" + session.userId)
                            .put("event", "phx_join").put("payload", payload).put("ref", "1");
                    webSocket.send(join.toString());
                } catch (Exception e) { handler.post(() -> listener.onDisconnected("Could not subscribe to game invites.")); }
            }
            @Override public void onMessage(WebSocket webSocket, String text) {
                if (text.contains("postgres_changes") || text.contains("game_invites") || text.contains("INSERT")) {
                    handler.post(() -> { if (RealtimeInviteSubscription.this.listener != null) RealtimeInviteSubscription.this.listener.onChanged(); });
                }
            }
            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                handler.post(() -> { if (RealtimeInviteSubscription.this.listener != null) RealtimeInviteSubscription.this.listener.onDisconnected("Live invite updates disconnected."); });
            }
        });
    }

    public void close() {
        listener = null;
        if (socket != null) { socket.close(1000, "screen closed"); socket = null; }
        client.dispatcher().executorService().shutdown();
    }
}

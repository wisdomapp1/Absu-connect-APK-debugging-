package com.absuconnect.games.backend;

import android.os.Handler;
import android.os.Looper;
import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import java.util.concurrent.TimeUnit;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONArray;
import org.json.JSONObject;

/** Foreground-only Realtime watch for inbound call session inserts/updates. */
public final class CallInboxSubscription {
    public interface Listener { void onCall(JSONObject row); void onDisconnected(); }
    private final OkHttpClient client = new OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebSocket socket;
    private Listener listener;
    private volatile boolean closed;
    private int ref = 2;
    private Runnable heartbeat;

    public void subscribe(AuthSession session, Listener listener) {
        this.listener = listener;
        HttpUrl base = HttpUrl.parse(BuildConfig.SUPABASE_URL);
        if (base == null) return;
        HttpUrl url = base.newBuilder().scheme("wss").addPathSegments("realtime/v1/websocket")
                .addQueryParameter("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY).addQueryParameter("vsn", "1.0.0").build();
        socket = client.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response response) {
                try {
                    JSONArray changes = new JSONArray()
                            .put(new JSONObject().put("event", "INSERT").put("schema", "public").put("table", "call_sessions").put("filter", "recipient_id=eq." + session.userId))
                            .put(new JSONObject().put("event", "UPDATE").put("schema", "public").put("table", "call_sessions").put("filter", "recipient_id=eq." + session.userId));
                    JSONObject config = new JSONObject().put("broadcast", new JSONObject().put("ack", false).put("self", false))
                            .put("presence", new JSONObject().put("key", "")).put("postgres_changes", changes).put("private", false);
                    JSONObject payload = new JSONObject().put("config", config).put("access_token", session.accessToken);
                    ws.send(new JSONObject().put("topic", "realtime:absu-call-inbox:" + session.userId).put("event", "phx_join")
                            .put("payload", payload).put("ref", "1").toString());
                    startHeartbeat(ws);
                } catch (Exception ignored) { }
            }
            @Override public void onMessage(WebSocket ws, String raw) {
                if (closed) return;
                try {
                    JSONObject root = new JSONObject(raw); JSONObject payload = root.optJSONObject("payload");
                    if (payload == null) return;
                    JSONObject data = payload.optJSONObject("data");
                    if (data == null) return;
                    JSONObject row = data.optJSONObject("record");
                    if (row != null && listener != null) handler.post(() -> { if (!closed && CallInboxSubscription.this.listener != null) CallInboxSubscription.this.listener.onCall(row); });
                } catch (Exception ignored) { }
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response response) { if (!closed && listener != null) handler.post(() -> { if (CallInboxSubscription.this.listener != null) CallInboxSubscription.this.listener.onDisconnected(); }); }
        });
    }

    private void startHeartbeat(WebSocket ws) {
        heartbeat = new Runnable() { @Override public void run() {
            if (closed || socket != ws) return;
            try {
                ws.send(new JSONObject().put("topic", "phoenix").put("event", "heartbeat").put("payload", new JSONObject()).put("ref", String.valueOf(ref++)).toString());
            } catch (Exception ignored) { }
            handler.postDelayed(this, 25000L);
        }};
        handler.postDelayed(heartbeat, 25000L);
    }

    public void close() {
        closed = true; listener = null; if (heartbeat != null) handler.removeCallbacks(heartbeat);
        if (socket != null) { socket.close(1000, "call inbox stopped"); socket = null; }
        client.dispatcher().executorService().shutdown();
    }
}

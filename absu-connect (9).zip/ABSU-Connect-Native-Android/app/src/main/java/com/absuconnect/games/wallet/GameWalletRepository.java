package com.absuconnect.games.wallet;

/**
 * Proposed server-authoritative contract for an NGN funding balance converted into
 * a distinct coin balance for one selected game. This source package has no implementation.
 */
public interface GameWalletRepository {
    final class FundingWalletSnapshot {
        public final String walletId;
        public final long version;
        /** NGN balance in minor units (kobo). */
        public final long balanceKobo;
        public FundingWalletSnapshot(String walletId,long version,long balanceKobo){this.walletId=walletId;this.version=version;this.balanceKobo=balanceKobo;}
    }
    final class GameCoinWalletSnapshot {
        public final String walletId,gameId;
        public final long version,coinBalance;
        public GameCoinWalletSnapshot(String walletId,String gameId,long version,long coinBalance){this.walletId=walletId;this.gameId=gameId;this.version=version;this.coinBalance=coinBalance;}
    }
    final class TopUpAuthorization {
        public final String reference;
        public final String authorizationUrl;
        public TopUpAuthorization(String reference,String authorizationUrl){this.reference=reference;this.authorizationUrl=authorizationUrl;}
    }
    final class ConversionQuote {
        public final String quoteId,gameId;
        public final long amountKobo,coinAmount,expiresAtEpochMs;
        public ConversionQuote(String quoteId,String gameId,long amountKobo,long coinAmount,long expiresAtEpochMs){this.quoteId=quoteId;this.gameId=gameId;this.amountKobo=amountKobo;this.coinAmount=coinAmount;this.expiresAtEpochMs=expiresAtEpochMs;}
    }
    final class ConversionResult {
        public final boolean applied;
        public final String transactionId;
        public final FundingWalletSnapshot fundingWallet;
        public final GameCoinWalletSnapshot gameWallet;
        public ConversionResult(boolean applied,String transactionId,FundingWalletSnapshot fundingWallet,GameCoinWalletSnapshot gameWallet){this.applied=applied;this.transactionId=transactionId;this.fundingWallet=fundingWallet;this.gameWallet=gameWallet;}
    }
    final class PurchaseResult {
        public final boolean applied;
        public final String transactionId;
        public final GameCoinWalletSnapshot gameWallet;
        public PurchaseResult(boolean applied,String transactionId,GameCoinWalletSnapshot gameWallet){this.applied=applied;this.transactionId=transactionId;this.gameWallet=gameWallet;}
    }
    /** Read the authenticated NGN funding balance from the server, never from client preferences. */
    FundingWalletSnapshot fetchFundingWallet() throws Exception;
    /** Read only the selected game's independent coin ledger. */
    GameCoinWalletSnapshot fetchGameCoinWallet(String gameId) throws Exception;
    /** Ask the server to create a Paystack NGN top-up; amount uses kobo, not virtual coins. */
    TopUpAuthorization initializePaystackTopUp(long amountKobo,String idempotencyKey) throws Exception;
    /** Credit NGN only after server-side verification of the signed Paystack event and transaction. */
    FundingWalletSnapshot creditVerifiedPaystackTopUp(String paystackReference,String idempotencyKey) throws Exception;
    /** Request a short-lived server conversion quote for a single game and NGN amount. */
    ConversionQuote quoteConversion(String gameId,long amountKobo) throws Exception;
    /** Atomically debit NGN and credit only the game wallet named in the verified quote. */
    ConversionResult convertToGameCoins(String quoteId,String idempotencyKey) throws Exception;
    /** Spend coins from only this game's server-side ledger on a game-specific item. */
    PurchaseResult purchaseItem(String gameId,String productId,String idempotencyKey) throws Exception;
}

package com.absuconnect.games.ui;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;

/** Small system-tone effects shared by the native games; mute state is device-local and persistent. */
public final class GameSound implements AutoCloseable {
    private static final String PREFS = "absu_game_settings";
    private static final String MUTED = "game_sound_muted";
    private final Context appContext;
    private ToneGenerator tones;
    private boolean closed;

    public GameSound(Context context) {
        appContext = context.getApplicationContext();
        try { tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 55); }
        catch (RuntimeException ignored) { tones = null; }
    }

    public boolean isMuted() {
        return appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(MUTED, false);
    }

    /** Toggle the persistent mute setting and return the new muted value. */
    public boolean toggleMuted() {
        boolean muted = !isMuted();
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(MUTED, muted).apply();
        return muted;
    }

    /** Play a short Android system tone when the user has not muted game audio. */
    public void play(int tone, int durationMs) {
        if (closed || isMuted() || tones == null) return;
        try { tones.startTone(tone, Math.max(40, Math.min(500, durationMs))); }
        catch (RuntimeException ignored) { }
    }

    @Override public void close() {
        if (closed) return;
        closed = true;
        if (tones != null) {
            try { tones.stopTone(); tones.release(); }
            catch (RuntimeException ignored) { }
            tones = null;
        }
    }
}

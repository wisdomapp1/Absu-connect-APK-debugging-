package com.absuconnect.games.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.action.ActionContentCatalog;
import com.absuconnect.games.action.LocalGameProgressStore;
import com.absuconnect.games.shooter.ShooterMatchModel;

/** Original first-person 3D CPU shooter. Local combat only; the future online scaffold is not connected. */
public final class ShooterActivity extends AppCompatActivity {
    private ShooterMatchModel model;
    private Shooter3DGameView gameView;
    private Shooter3DHudView hudView;
    private GameSound sound;
    private android.widget.Button soundButton;
    private boolean training,shopOpened,roundRewarded;
    private int operator,weapon,skill,map,skin;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);getWindow().getDecorView().setSystemUiVisibility(5894|1024|512|4096);
        model=new ShooterMatchModel();sound=new GameSound(this);
        gameView=new Shooter3DGameView(this,model);
        gameView.setListener(new Shooter3DGameView.Listener(){
            @Override public void onSound(String cue){playCue(cue);}
            @Override public void onRoundOver(ShooterMatchModel.Result result){showRoundResult(result);}
        });
        hudView=new Shooter3DHudView(this,model,gameView);
        hudView.setListener(new Shooter3DHudView.Listener(){
            @Override public void onBack(){finish();}
            @Override public void onSetup(){chooseLoadout();}
            @Override public void onShop(){openCareer();}
        });
        FrameLayout surface=new FrameLayout(this);
        surface.addView(gameView,new FrameLayout.LayoutParams(-1,-1));
        surface.addView(hudView,new FrameLayout.LayoutParams(-1,-1));
        soundButton=UiKit.button(this,sound.isMuted()?"Sound off":"Sound on",false);
        FrameLayout.LayoutParams soundParams=new FrameLayout.LayoutParams(-2,UiKit.dp(this,40),android.view.Gravity.TOP|android.view.Gravity.RIGHT);
        soundParams.topMargin=UiKit.dp(this,8);soundParams.rightMargin=UiKit.dp(this,12);
        surface.addView(soundButton,soundParams);
        soundButton.setOnClickListener(v->{boolean muted=sound.toggleMuted();soundButton.setText(muted?"Sound off":"Sound on");if(!muted)sound.play(ToneGenerator.TONE_PROP_ACK,90);});
        setContentView(surface);
        chooseMode();
    }
    private void chooseMode(){
        String[] options={"Solo campaign — endless waves, level up after five targets","Training range — optional, targets do not fire"};
        new AlertDialog.Builder(this).setTitle("Campus Fireline · 3D local play")
                .setMessage("Solo first-person campaign: clear five targets to advance through endless waves. Enemies grow gradually tougher; the run ends only when you are down. Optional training is available. No online multiplayer.")
                .setItems(options,(dialog,which)->{training=which==1;model.setTrainingMode(training);chooseLoadout();})
                .setNegativeButton("Back to Game Center",(d,w)->finish()).setCancelable(false).show();
    }
    private void chooseLoadout(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose an operator",ActionContentCatalog.namesAtRank(ActionContentCatalog.OPERATORS,rank),operator,value->{operator=value;chooseWeapon();});}
    private void chooseWeapon(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose a fictional firearm",ActionContentCatalog.namesAtRank(ActionContentCatalog.GUNS,rank),weapon,value->{weapon=value;chooseSkill();});}
    private void chooseSkill(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose a field skill",ActionContentCatalog.namesAtRank(ActionContentCatalog.SHOOTER_SKILLS,rank),skill,value->{skill=value;chooseMap();});}
    private void chooseMap(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose a 3D arena and campus location",ActionContentCatalog.namesAtRank(ActionContentCatalog.ARENAS,rank),map,value->{map=value;chooseSkin();});}
    private void chooseSkin(){int rank=LocalGameProgressStore.load(this).rank();choose("Choose an operator skin",ActionContentCatalog.namesAtRank(ActionContentCatalog.SKINS,rank),skin,value->{skin=value;configureLoadout();});}
    private void configureLoadout(){
        int op=LocalGameProgressStore.upgradeLevel(this,"shooter_operator:"+operator),gun=LocalGameProgressStore.upgradeLevel(this,"shooter_gun:"+weapon);
        model.configure(operator,weapon,skill,map,skin,op,gun);model.setTrainingMode(training);roundRewarded=false;
        if(gameView!=null)gameView.resetRoundReported();if(hudView!=null)hudView.invalidate();
    }
    private interface Pick {void accept(int index);}
    private void choose(String title,String[] options,int selected,Pick next){
        new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options,selected,(dialog,which)->{dialog.dismiss();next.accept(which);})
                .setNegativeButton("Cancel",(dialog,which)->hudView.invalidate()).show();
    }
    private void showRoundResult(ShooterMatchModel.Result result){
        if(isFinishing()||isDestroyed())return;
        if(!roundRewarded){roundRewarded=true;int multiplier=result.playerHealth<=0?1:2;LocalGameProgressStore.MatchReward reward=LocalGameProgressStore.recordMatch(this,"campus_fireline",(35+result.kills*12)*multiplier,(24+result.kills*7)*multiplier);android.widget.Toast.makeText(this,"Career +"+reward.xp+" XP · +"+reward.credits+" Practice Points"+(reward.rankUp?" · Rank "+reward.rank+" unlocked!":""),android.widget.Toast.LENGTH_LONG).show();}
        new AlertDialog.Builder(this).setTitle(result.playerHealth<=0?"Run over":"Level "+result.level)
                .setMessage(result.status+"\nLevel reached: "+result.level+" · Targets cleared: "+result.kills+"\n\nLoadout: "+result.operator+" · "+result.weapon+" · "+result.skill+"\n3D map: "+result.map+" · Skin: "+result.skin+"\n\nLocal CPU/training only · no online sync")
                .setPositiveButton("Play again",(dialog,which)->configureLoadout())
                .setNegativeButton("Game Center",(dialog,which)->finish()).show();
    }
    private void openCareer(){Intent i=new Intent(this,ProgressionShopActivity.class);i.putExtra("shop_kind","shooter").putExtra("game_id","campus_fireline").putExtra("active_a",operator).putExtra("active_b",weapon).putExtra("active_c",skill).putExtra("active_d",map).putExtra("active_e",skin);shopOpened=true;startActivity(i);}
    private void playCue(String cue){
        if(sound==null)return;
        int tone="fire".equals(cue)?ToneGenerator.TONE_PROP_BEEP:"reload".equals(cue)?ToneGenerator.TONE_PROP_PROMPT:"jump".equals(cue)?ToneGenerator.TONE_PROP_BEEP2:ToneGenerator.TONE_PROP_ACK;
        sound.play(tone,75);
    }
    @Override protected void onResume(){super.onResume();if(shopOpened){shopOpened=false;/* Resume the same run; new upgrades apply to the next loadout. */}if(gameView!=null)gameView.setLoopEnabled(true);if(hudView!=null)hudView.setLoopEnabled(true);}
    @Override protected void onPause(){if(hudView!=null)hudView.setLoopEnabled(false);if(gameView!=null)gameView.setLoopEnabled(false);super.onPause();}
    @Override protected void onDestroy(){if(sound!=null)sound.close();super.onDestroy();}
}

package com.absuconnect.games.ui;

import android.content.Context;
import android.opengl.GLSurfaceView;
import com.absuconnect.games.shooter.Shooter3DCamera;
import com.absuconnect.games.shooter.ShooterMatchModel;

/** OpenGL ES 2.0 first-person view controller for original local Campus Fireline. */
public final class Shooter3DGameView extends GLSurfaceView {
    public interface Listener {
        void onSound(String cue);
        void onRoundOver(ShooterMatchModel.Result result);
    }
    static final class InputState {
        volatile float strafe,forward;
        volatile boolean fireHeld,sprinting,jumpRequested;
    }

    private final ShooterMatchModel model;
    private final Shooter3DCamera camera=new Shooter3DCamera();
    private final InputState input=new InputState();
    private final Shooter3DWorldRenderer renderer;
    private boolean loopEnabled;
    private Listener listener;

    public Shooter3DGameView(Context context,ShooterMatchModel model){
        super(context);this.model=model;
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8,8,8,8,16,0);
        setPreserveEGLContextOnPause(true);
        renderer=new Shooter3DWorldRenderer(model,camera,input);
        renderer.setHost(new Shooter3DWorldRenderer.Host(){
            @Override public void onSound(String cue){Listener l=listener;if(l!=null)post(()->{if(listener!=null)listener.onSound(cue);});}
            @Override public void onRoundOver(ShooterMatchModel.Result result){Listener l=listener;if(l!=null)post(()->{if(listener!=null)listener.onRoundOver(result);});}
        });
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        setFocusable(true);setKeepScreenOn(true);
    }
    public void setListener(Listener listener){this.listener=listener;}
    public void setLoopEnabled(boolean enabled){
        if(loopEnabled==enabled)return;
        loopEnabled=enabled;
        if(enabled)onResume();else onPause();
    }
    public void resetRoundReported(){camera.reset();renderer.resetRoundReported();input.strafe=0;input.forward=0;input.fireHeld=false;input.sprinting=false;input.jumpRequested=false;}
    public void setMove(float strafe,float forward){input.strafe=clamp(strafe,-1,1);input.forward=clamp(forward,-1,1);}
    public void setFireHeld(boolean held){input.fireHeld=held;}
    public void setSprintHeld(boolean held){input.sprinting=held;}
    public void look(float deltaX,float deltaY){camera.look(deltaX,deltaY);}
    public void jump(){input.jumpRequested=true;}
    public void pressReload(long now){if(model.reload(now))sound("reload");}
    public void cycleWeapon(){model.cycleWeapon();}
    public void activateSkill(long now){if(model.activateSkill(now))sound("skill");}
    private void sound(String cue){Listener l=listener;if(l!=null)l.onSound(cue);}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
}

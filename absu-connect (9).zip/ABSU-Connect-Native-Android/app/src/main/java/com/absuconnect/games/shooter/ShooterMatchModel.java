package com.absuconnect.games.shooter;

import com.absuconnect.games.action.ActionContentCatalog;
import com.absuconnect.games.action.ActionContentCatalog.ArenaSpec;
import com.absuconnect.games.action.ActionContentCatalog.CharacterSpec;
import com.absuconnect.games.action.ActionContentCatalog.Cover;
import com.absuconnect.games.action.ActionContentCatalog.SkillSpec;
import com.absuconnect.games.action.ActionContentCatalog.WeaponSpec;

/** Original offline combat/CPU rules on the arena plane; the Android presentation is first-person 3D. */
public final class ShooterMatchModel {
    public static final float WORLD_WIDTH=100f, WORLD_HEIGHT=60f;
    private static final int BOT_COUNT=5;
    private static final float PLAYER_EYE_HEIGHT=1.66f, TARGET_CENTER_HEIGHT=1.30f;
    private static final long JUMP_DURATION_MS=620L,JUMP_COOLDOWN_MS=1050L;
    private static final class Bot {float x,y;int hp;long nextShot;boolean alive;}
    public static final class Result {
        public final float playerX,playerY,aimX,aimY,aimPitch;
        public final float[] botX,botY;
        public final int[] botHealth;
        public final int playerHealth,maxHealth,ammo,reserveAmmo,kills,aliveBots,level;
        public final long timeLeftMs;
        public final boolean matchOver,reloading,skillReady,shielded,focused,bursting,training,grounded,jumpReady;
        public final float jumpHeight;
        public final String status,operator,weapon,skill,map,skin;
        Result(float px,float py,float ax,float ay,float pitch,float[] bx,float[] by,int[] bh,int health,int max,
               int ammo,int reserve,int kills,int alive,int level,long time,boolean over,boolean reloading,
               boolean ready,boolean shielded,boolean focused,boolean bursting,boolean training,boolean grounded,boolean jumpReady,float jumpHeight,String status,
               String operator,String weapon,String skill,String map,String skin){
            playerX=px;playerY=py;aimX=ax;aimY=ay;aimPitch=pitch;botX=bx;botY=by;botHealth=bh;
            playerHealth=health;maxHealth=max;this.ammo=ammo;reserveAmmo=reserve;this.kills=kills;
            aliveBots=alive;this.level=level;timeLeftMs=time;matchOver=over;this.reloading=reloading;
            this.skillReady=ready;this.shielded=shielded;this.focused=focused;this.bursting=bursting;
            this.training=training;this.status=status;this.operator=operator;this.weapon=weapon;this.grounded=grounded;this.jumpReady=jumpReady;this.jumpHeight=jumpHeight;
            this.skill=skill;this.map=map;this.skin=skin;
        }
    }
    private final Bot[] bots=new Bot[BOT_COUNT];
    private final int[] magazines=new int[ActionContentCatalog.GUNS.length];
    private final int[] reserves=new int[ActionContentCatalog.GUNS.length];
    private int operatorIndex,weaponIndex,skillIndex,mapIndex,skinIndex,operatorUpgrade,weaponUpgrade;
    private float playerX,playerY,aimX=0,aimY=-1,aimPitch;
    private int health,kills,ammo,reserveAmmo,aliveBots,level;
    private long lastTick,reloadCompletes,nextSkillAt,burstUntil,shieldUntil,focusUntil,slowUntil,reconUntil,startedAt,jumpStartedAt,jumpReadyAt;
    private long lastFireAt;
    private boolean reloading,matchOver,training;
    private String status="Move, align the reticle with a target, then fire.";

    public ShooterMatchModel(){for(int i=0;i<bots.length;i++)bots[i]=new Bot();configure(0,0,0,0,0);}

    /** Rebuild the round with the chosen original content. */
    public synchronized void configure(int operator,int weapon,int skill,int map,int skin){configure(operator,weapon,skill,map,skin,0,0);}
    public synchronized void configure(int operator,int weapon,int skill,int map,int skin,int operatorUpgrade,int weaponUpgrade){
        operatorIndex=ActionContentCatalog.wrap(operator,ActionContentCatalog.OPERATORS.length);
        weaponIndex=ActionContentCatalog.wrap(weapon,ActionContentCatalog.GUNS.length);
        skillIndex=ActionContentCatalog.wrap(skill,ActionContentCatalog.SHOOTER_SKILLS.length);
        mapIndex=ActionContentCatalog.wrap(map,ActionContentCatalog.ARENAS.length);
        skinIndex=ActionContentCatalog.wrap(skin,ActionContentCatalog.SKINS.length);
        this.operatorUpgrade=Math.max(0,Math.min(5,operatorUpgrade));this.weaponUpgrade=Math.max(0,Math.min(5,weaponUpgrade));
        training=false;reset();
    }
    public synchronized void setTrainingMode(boolean enabled){training=enabled;reset();}
    public synchronized boolean isTrainingMode(){return training;}
    public synchronized void reset(){
        CharacterSpec hero=hero();WeaponSpec gun=gun();long now=System.currentTimeMillis();
        playerX=50;playerY=51;aimX=0;aimY=-1;aimPitch=0;health=maxHealth();kills=0;aliveBots=BOT_COUNT;level=1;
        for(int i=0;i<magazines.length;i++){magazines[i]=ActionContentCatalog.GUNS[i].magazine;reserves[i]=ActionContentCatalog.GUNS[i].magazine*ActionContentCatalog.GUNS[i].reserveMagazines;}
        ammo=magazines[weaponIndex];reserveAmmo=reserves[weaponIndex];reloading=false;matchOver=false;
        nextSkillAt=burstUntil=shieldUntil=focusUntil=slowUntil=reconUntil=lastFireAt=jumpStartedAt=jumpReadyAt=0;
        lastTick=startedAt=now;
        float[][] starts={{25,13},{75,14},{50,25},{19,38},{81,37}};
        for(int i=0;i<BOT_COUNT;i++){Bot b=bots[i];b.x=starts[i][0];b.y=starts[i][1];b.hp=enemyHealthForLevel(level);b.alive=true;b.nextShot=now+1100L+i*250L;}
        status=training?"Training range · targets move and do not fire.":"Solo campaign · clear five targets to advance. Survive as long as you can.";
        if(gun.magazine==0){ammo=magazines[weaponIndex]=0;}
    }
    public synchronized void move(float x,float y,float seconds){
        if(matchOver||health<=0)return;
        float len=(float)Math.sqrt(x*x+y*y);if(len<0.03f)return;
        x/=len;y/=len;
        float dt=Math.max(0,Math.min(0.08f,seconds));
        CharacterSpec c=hero();WeaponSpec w=gun();float speed=9.0f*c.moveScale*(1f+operatorUpgrade*.025f)*w.movementScale;
        if(System.currentTimeMillis()<burstUntil)speed*=1.8f;
        float nx=clamp(playerX+x*speed*dt,2,WORLD_WIDTH-2),ny=clamp(playerY+y*speed*dt,2,WORLD_HEIGHT-2);
        if(canStand(nx,playerY))playerX=nx;if(canStand(playerX,ny))playerY=ny;
    }
    /** Starts one bounded jump; held/repeated input cannot retrigger before landing and cooldown. */
    public synchronized boolean jump(long now){
        if(matchOver||health<=0||(jumpStartedAt>0&&now-jumpStartedAt<JUMP_DURATION_MS)||now<jumpReadyAt)return false;
        jumpStartedAt=now;jumpReadyAt=now+JUMP_COOLDOWN_MS;status="Jump! CPU aim disrupted briefly · adjust aim while airborne.";return true;
    }
    private float jumpHeightAt(long now){
        if(jumpStartedAt<=0)return 0f;long elapsed=now-jumpStartedAt;
        if(elapsed<0||elapsed>=JUMP_DURATION_MS){if(elapsed>=JUMP_DURATION_MS)jumpStartedAt=0;return 0f;}
        return (float)Math.sin(Math.PI*Math.max(1L,elapsed)/JUMP_DURATION_MS)*.82f;
    }
    public synchronized void aimAt(float worldX,float worldY){aimAt(worldX,worldY,0f);}
    /** Sets the world-plane look point plus camera pitch so vertical look changes which targets can be hit. */
    public synchronized void aimAt(float worldX,float worldY,float pitchRadians){
        float dx=worldX-playerX,dy=worldY-playerY;float len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>0.001f){aimX=dx/len;aimY=dy/len;}
        aimPitch=clamp(pitchRadians,-.78f,.78f);
    }
    public synchronized boolean fire(long now){
        if(matchOver||health<=0)return false;
        if(reloading){status="Reloading — hold position or switch weapons.";return false;}
        WeaponSpec weapon=gun();
        if(weapon.magazine<=0){status="This profile has no ammunition model.";return false;}
        if(!training&&ammo<=0){status=reserveAmmo>0?"Magazine empty — tap RELOAD.":"Magazine empty — no reserve ammunition remains.";return false;}
        if(now-lastFireAt<weapon.cooldownMs)return false;
        lastFireAt=now;if(!training){ammo--;magazines[weaponIndex]=ammo;}
        Bot target=null;float nearest=Float.MAX_VALUE;
        for(Bot bot:bots){
            if(!bot.alive)continue;
            float dx=bot.x-playerX,dy=bot.y-playerY;
            float forward=dx*aimX+dy*aimY;if(forward<=0||forward>weapon.range)continue;
            float lateral=Math.abs(dx*aimY-dy*aimX);
            float verticalError=Math.abs((TARGET_CENTER_HEIGHT-(PLAYER_EYE_HEIGHT+jumpHeightAt(now)))-(float)Math.tan(aimPitch)*forward);
            // A compact torso target makes deliberate reticle alignment matter while remaining touch-friendly.
            if(lateral>.56f+forward*.008f||verticalError>.57f+forward*.006f)continue;
            if(lineBlocked(playerX,playerY,bot.x,bot.y,arena().coverPieces))continue;
            float d2=dx*dx+dy*dy;if(d2<nearest){nearest=d2;target=bot;}
        }
        if(target==null){status=training?"Shot sent — adjust the reticle onto a moving target.":"Shot sent — adjust the reticle, range or line of sight.";return true;}
        int damage=weapon.damage+weaponUpgrade*2;
        if(weapon.type.equals("Shotgun")||weapon.type.equals("Scatter"))damage=nearest<100?damage:Math.max(8,damage/2);
        if(now<focusUntil)damage+=10;
        target.hp=Math.max(0,target.hp-damage);
        if(target.hp==0){target.alive=false;kills++;aliveBots--;status="Target cleared · "+kills+" / "+BOT_COUNT+".";}
        else status="Hit · "+damage+" arcade damage.";
        if(aliveBots==0){advanceWave(now);}
        return true;
    }
    private void advanceWave(long now){
        level++;aliveBots=BOT_COUNT;float[][] starts={{25,13},{75,14},{50,25},{19,38},{81,37}};
        for(int i=0;i<BOT_COUNT;i++){Bot b=bots[i];b.x=starts[i][0];b.y=starts[i][1];b.hp=enemyHealthForLevel(level);b.alive=true;b.nextShot=now+1100L+i*250L;}
        status="Level "+level+" · new wave. Enemy toughness and pressure rise gradually.";
    }
    static int enemyHealthForLevel(int level){return 78+Math.max(0,Math.min(120,level-1)*3);}
    static int enemyDamageForLevel(int level){return 7+Math.min(6,Math.max(0,level-1)/4);}
    static long enemyShotIntervalForLevel(int level){return Math.max(900L,1600L-Math.min(700L,Math.max(0,level-1)*18L));}
    static float enemySpeedForLevel(int level){return 3.2f+Math.min(1.8f,Math.max(0,level-1)*.035f);}
    public synchronized boolean reload(long now){
        WeaponSpec w=gun();if(training){status="Training ammunition is unlimited.";return false;}
        if(matchOver||w.magazine<=0||reloading||ammo>=w.magazine||reserveAmmo<=0){
            if(reserveAmmo<=0)status="No reserve magazine left.";return false;}
        reloading=true;reloadCompletes=now+w.reloadMs;status="Reloading "+w.name+"…";return true;
    }
    public synchronized void cycleWeapon(){
        if(matchOver)return;
        if(reloading){reloading=false;status="Reload canceled · ";}else status="Equipped ";
        weaponIndex=(weaponIndex+1)%ActionContentCatalog.GUNS.length;ammo=magazines[weaponIndex];reserveAmmo=reserves[weaponIndex];
        lastFireAt=0;status+=gun().name+" · "+gun().type+".";
    }
    public synchronized boolean activateSkill(long now){
        if(matchOver||now<nextSkillAt){status="Skill is cooling down.";return false;}
        SkillSpec skill=ActionContentCatalog.SHOOTER_SKILLS[skillIndex];nextSkillAt=now+skill.cooldownMs;
        switch(skill.effect){
            case "BURST":burstUntil=now+skill.durationMs;status="Burst Step active — move fast.";break;
            case "SHIELD":shieldUntil=now+skill.durationMs;status="Aegis Field active — reduced CPU damage.";break;
            case "HEAL":int before=health;health=Math.min(maxHealth(),health+skill.value);status=health==before?"Health is already full.":"Field Patch restored "+(health-before)+" health.";break;
            case "FOCUS":focusUntil=now+skill.durationMs;status="Focus Window active — bonus shot damage.";break;
            case "SLOW":slowUntil=now+skill.durationMs;status="Pulse Net active — CPU movement slowed.";break;
            case "RECON":reconUntil=now+skill.durationMs;status="Recon Flash active — targets highlighted.";break;
            default:status=skill.name+" activated.";
        }
        return true;
    }
    public synchronized void tick(long now){
        if(matchOver)return;
        jumpHeightAt(now);
        if(lastTick==0)lastTick=now;float dt=Math.max(0,Math.min(0.08f,(now-lastTick)/1000f));lastTick=now;
        if(reloading&&now>=reloadCompletes){int need=gun().magazine-ammo;int taken=Math.min(need,reserveAmmo);ammo+=taken;reserveAmmo-=taken;magazines[weaponIndex]=ammo;reserves[weaponIndex]=reserveAmmo;reloading=false;status="Reload complete · "+ammo+" rounds ready.";}
        float slow=now<slowUntil?0.38f:1.0f;
        for(Bot bot:bots){
            if(!bot.alive)continue;
            float dx=playerX-bot.x,dy=playerY-bot.y;float dist=(float)Math.sqrt(dx*dx+dy*dy);
            if(dist>8.5f&&dist>0.01f){float step=Math.min(dist-8.3f,enemySpeedForLevel(level)*slow*dt);float nx=bot.x+dx/dist*step,ny=bot.y+dy/dist*step;
                if(canStand(nx,bot.y))bot.x=nx;if(canStand(bot.x,ny))bot.y=ny;}
            boolean evasionWindow=jumpStartedAt>0&&now-jumpStartedAt>=100&&now-jumpStartedAt<520;
            if(!training&&health>0&&dist<=15&&now>=bot.nextShot&&hasLineOfSight(bot.x,bot.y,playerX,playerY)){
                if(evasionWindow){bot.nextShot=now+1600;status="Timed jump — you evaded incoming CPU fire.";}
                else{
                    int damage=now<shieldUntil?Math.max(2,enemyDamageForLevel(level)/2):enemyDamageForLevel(level);health=Math.max(0,health-damage);bot.nextShot=now+enemyShotIntervalForLevel(level);
                    if(health==0){status="Operator down — reset to play again.";break;}
                    status=now<shieldUntil?"Aegis Field absorbed part of the CPU hit.":"CPU hit · keep moving, use cover or activate a skill.";
                }
            }
        }
        if(health<=0){matchOver=true;status="Operator down · Level "+level+" reached, "+kills+" targets cleared.";}
    }
    public synchronized Result snapshot(){
        float[] bx=new float[BOT_COUNT],by=new float[BOT_COUNT];int[] bh=new int[BOT_COUNT];int alive=0;
        for(int i=0;i<BOT_COUNT;i++){Bot b=bots[i];bx[i]=b.x;by[i]=b.y;bh[i]=b.alive?b.hp:0;if(b.alive)alive++;}
        long now=System.currentTimeMillis();float jumpHeight=jumpHeightAt(now);return new Result(playerX,playerY,aimX,aimY,aimPitch,bx,by,bh,health,maxHealth(),ammo,reserveAmmo,kills,alive,level,
                -1L,matchOver,reloading,now>=nextSkillAt,now<shieldUntil,now<focusUntil,now<burstUntil,training,
                jumpStartedAt<=0||now-jumpStartedAt>=JUMP_DURATION_MS,now>=jumpReadyAt,jumpHeight,
                status,hero().name,gun().name,ActionContentCatalog.SHOOTER_SKILLS[skillIndex].name,
                ActionContentCatalog.ARENAS[mapIndex].name,ActionContentCatalog.SKINS[skinIndex].name);
    }
    public synchronized int getOperatorIndex(){return operatorIndex;}public synchronized int getWeaponIndex(){return weaponIndex;}
    public synchronized int getSkillIndex(){return skillIndex;}public synchronized int getMapIndex(){return mapIndex;}public synchronized int getSkinIndex(){return skinIndex;}
    public synchronized ArenaSpec arena(){return ActionContentCatalog.ARENAS[mapIndex];}
    public synchronized CharacterSpec hero(){return ActionContentCatalog.OPERATORS[operatorIndex];}
    public synchronized WeaponSpec gun(){return ActionContentCatalog.GUNS[weaponIndex];}
    private int maxHealth(){return hero().health+operatorUpgrade*5;}
    private boolean canStand(float x,float y){
        for(Cover c:arena().coverPieces)if(x>=c.left-2&&x<=c.right+2&&y>=c.top-2&&y<=c.bottom+2)return false;
        return true;
    }
    private boolean hasLineOfSight(float x0,float y0,float x1,float y1){return !lineBlocked(x0,y0,x1,y1,arena().coverPieces);}
    static boolean lineBlocked(float x0,float y0,float x1,float y1,Cover[] pieces){
        for(Cover c:pieces)if(segmentIntersectsAabb(x0,y0,x1,y1,c.left,c.top,c.right,c.bottom))return true;
        return false;
    }
    private static boolean segmentIntersectsAabb(float x0,float y0,float x1,float y1,float left,float top,float right,float bottom){
        float tMin=0f,tMax=1f,dx=x1-x0,dy=y1-y0;
        if(Math.abs(dx)<1.0e-6f){if(x0<left||x0>right)return false;}
        else{float a=(left-x0)/dx,b=(right-x0)/dx;if(a>b){float t=a;a=b;b=t;}tMin=Math.max(tMin,a);tMax=Math.min(tMax,b);}
        if(Math.abs(dy)<1.0e-6f){if(y0<top||y0>bottom)return false;}
        else{float a=(top-y0)/dy,b=(bottom-y0)/dy;if(a>b){float t=a;a=b;b=t;}tMin=Math.max(tMin,a);tMax=Math.min(tMax,b);}
        return tMax>=tMin&&tMax>=0f&&tMin<=1f;
    }
    private static float clamp(float v,float low,float high){return Math.max(low,Math.min(high,v));}
}

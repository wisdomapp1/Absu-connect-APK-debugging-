package com.absuconnect.games.multiplayer.examples;

import com.absuconnect.games.multiplayer.AllowlistGameActionCodec;

/** Example car/bike control-intent adapter; server-side physics and finish order remain authoritative. */
public final class RacingMatchAdapter extends AllowlistGameActionCodec {
    public RacingMatchAdapter(String racingGameId){
        super(requireRaceId(racingGameId),"ready","steer","throttle","brake","boost","resign");
    }
    private static String requireRaceId(String id){
        if(!"kart_racing".equals(id)&&!"bike_racing".equals(id))
            throw new IllegalArgumentException("Racing adapter requires kart_racing or bike_racing");
        return id;
    }
}

package com.absuconnect.games.backend;

import android.content.Context;
import com.absuconnect.games.BuildConfig;
import com.absuconnect.games.auth.AuthSession;
import com.absuconnect.games.auth.SupabaseAuthRepository;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small authenticated PostgREST/Auth client used by the fully native ABSU Connect screens. */
public final class NativeSupabaseApi {
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private final Context context;
    private final SupabaseAuthRepository auth;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS).readTimeout(18, TimeUnit.SECONDS)
            .writeTimeout(18, TimeUnit.SECONDS).build();

    public NativeSupabaseApi(Context context) {
        this.context = context.getApplicationContext();
        this.auth = new SupabaseAuthRepository(this.context);
    }

    public SupabaseAuthRepository auth() { return auth; }

    public JSONArray getArray(String tableAndQuery) throws Exception {
        Object value = execute("GET", "/rest/v1/" + tableAndQuery, null, null);
        return value instanceof JSONArray ? (JSONArray) value : new JSONArray();
    }

    public JSONObject getObject(String tableAndQuery) throws Exception {
        Object value = execute("GET", "/rest/v1/" + tableAndQuery, null, null);
        return value instanceof JSONArray && ((JSONArray) value).length() > 0
                ? ((JSONArray) value).optJSONObject(0) : value instanceof JSONObject ? (JSONObject) value : new JSONObject();
    }

    public JSONArray postArray(String tableAndQuery, JSONObject body, String prefer) throws Exception {
        Object value = execute("POST", "/rest/v1/" + tableAndQuery, body, prefer);
        return value instanceof JSONArray ? (JSONArray) value : new JSONArray();
    }

    public JSONArray patchArray(String tableAndQuery, JSONObject body, String prefer) throws Exception {
        Object value = execute("PATCH", "/rest/v1/" + tableAndQuery, body, prefer);
        return value instanceof JSONArray ? (JSONArray) value : new JSONArray();
    }

    public void delete(String tableAndQuery) throws Exception {
        execute("DELETE", "/rest/v1/" + tableAndQuery, null, null);
    }

    public Object rpc(String name, JSONObject body) throws Exception {
        return execute("POST", "/rest/v1/rpc/" + name, body, null);
    }

    /** Invoke a Supabase Edge Function with the current user's access token. */
    public Object invokeFunction(String name, JSONObject body) throws Exception {
        return execute("POST", "/functions/v1/" + name, body, null);
    }

    /**
     * Upload an event flyer directly to the `event-flyers` bucket in Supabase Storage.
     * Returns the public URL.
     */
    public String uploadEventFlyer(String userId, byte[] imageBytes, String filename) throws Exception {
        AuthSession session = auth.freshSession(context);
        String cleanName = filename.replaceAll("[^a-zA-Z0-9_.-]", "_");
        String path = userId + "/flyers/" + System.currentTimeMillis() + "_" + cleanName;
        String url = BuildConfig.SUPABASE_URL + "/storage/v1/object/event-flyers/" + path;

        RequestBody requestBody = RequestBody.create(imageBytes, MediaType.parse("image/jpeg"));
        Request request = new Request.Builder()
                .url(url)
                .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer " + session.accessToken)
                .header("x-upsert", "true")
                .header("Content-Type", "image/jpeg")
                .post(requestBody)
                .build();

        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Storage upload failed (" + response.code() + "): " + (response.body() != null ? response.body().string() : ""));
            }
        }
        return BuildConfig.SUPABASE_URL + "/storage/v1/object/public/event-flyers/" + path;
    }

    /**
     * Upload a community image (profile or cover) directly to the `community-images` bucket in Supabase Storage.
     * Returns the public URL.
     */
    public String uploadCommunityImage(String userId, String kind, byte[] imageBytes, String filename) throws Exception {
        AuthSession session = auth.freshSession(context);
        String cleanName = filename.replaceAll("[^a-zA-Z0-9_.-]", "_");
        String path = userId + "/" + kind + "/" + System.currentTimeMillis() + "_" + cleanName;
        String url = BuildConfig.SUPABASE_URL + "/storage/v1/object/community-images/" + path;

        RequestBody requestBody = RequestBody.create(imageBytes, MediaType.parse("image/jpeg"));
        Request request = new Request.Builder()
                .url(url)
                .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer " + session.accessToken)
                .header("x-upsert", "true")
                .header("Content-Type", "image/jpeg")
                .post(requestBody)
                .build();

        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Storage upload failed (" + response.code() + "): " + (response.body() != null ? response.body().string() : ""));
            }
        }
        return BuildConfig.SUPABASE_URL + "/storage/v1/object/public/community-images/" + path;
    }

    /** Upload arbitrary image/video/audio bytes to any Supabase Storage bucket. Returns object path. */
    public String uploadStorageBytes(String bucket, String objectPath, byte[] bytes, String contentType) throws Exception {
        AuthSession session = auth.freshSession(context);
        String url = BuildConfig.SUPABASE_URL + "/storage/v1/object/" + bucket + "/" + objectPath;
        String mime = (contentType == null || contentType.trim().isEmpty()) ? "application/octet-stream" : contentType;
        RequestBody requestBody = RequestBody.create(bytes, MediaType.parse(mime));
        Request request = new Request.Builder()
                .url(url)
                .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer " + session.accessToken)
                .header("x-upsert", "true")
                .header("Content-Type", mime)
                .post(requestBody)
                .build();
        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Storage upload failed (" + response.code() + "): " + (response.body() != null ? response.body().string() : ""));
            }
        }
        return objectPath;
    }

    public static String publicStorageUrl(String bucket, String objectPath) {
        if (objectPath == null || objectPath.isEmpty()) return "";
        if (objectPath.startsWith("http://") || objectPath.startsWith("https://")) return objectPath;
        String cleanPath = objectPath.startsWith("/") ? objectPath.substring(1) : objectPath;
        return BuildConfig.SUPABASE_URL + "/storage/v1/object/public/" + bucket + "/" + cleanPath;
    }

    /** Generate a signed URL (valid 1 hour) for private buckets like post-media or story-media, falling back to public URL. */
    public String resolveMediaUrl(String bucket, String pathOrUrl) {
        if (pathOrUrl == null || pathOrUrl.trim().isEmpty()) return "";
        String clean = pathOrUrl.trim();
        if (clean.startsWith("http://") || clean.startsWith("https://")) {
            if (clean.contains("/storage/v1/object/public/" + bucket + "/")) {
                clean = clean.substring(clean.indexOf("/storage/v1/object/public/" + bucket + "/") + ("/storage/v1/object/public/" + bucket + "/").length());
            } else {
                return clean;
            }
        }
        if (clean.startsWith(bucket + "/")) {
            clean = clean.substring(bucket.length() + 1);
        }
        if (clean.startsWith("/")) clean = clean.substring(1);
        try {
            AuthSession session = auth.freshSession(context);
            String url = BuildConfig.SUPABASE_URL + "/storage/v1/object/sign/" + bucket + "/" + clean;
            RequestBody body = RequestBody.create("{\"expiresIn\":3600}", JSON);
            Request req = new Request.Builder()
                    .url(url)
                    .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                    .header("Authorization", "Bearer " + session.accessToken)
                    .header("Content-Type", "application/json")
                    .post(body)
                    .build();
            try (Response resp = http.newCall(req).execute()) {
                if (resp.isSuccessful() && resp.body() != null) {
                    JSONObject obj = new JSONObject(resp.body().string());
                    String signed = obj.optString("signedURL", "");
                    if (!signed.isEmpty()) {
                        if (signed.startsWith("http")) return signed;
                        if (signed.startsWith("/storage/v1")) return BuildConfig.SUPABASE_URL + signed;
                        return BuildConfig.SUPABASE_URL + "/storage/v1" + (signed.startsWith("/") ? signed : "/" + signed);
                    }
                }
            }
        } catch (Exception ignored) { }
        return publicStorageUrl(bucket, clean);
    }

    public JSONArray postJsonArray(String tableAndQuery, JSONArray arrayBody, String prefer) throws Exception {
        Object value = executeRaw("POST", "/rest/v1/" + tableAndQuery, arrayBody.toString(), prefer);
        return value instanceof JSONArray ? (JSONArray) value : new JSONArray();
    }

    private Object execute(String method, String path, JSONObject body, String prefer) throws Exception {
        return executeRaw(method, path, body == null ? "{}" : body.toString(), prefer);
    }

    private Object executeRaw(String method, String path, String rawBody, String prefer) throws Exception {
        AuthSession session = auth.freshSession(context);
        String url = BuildConfig.SUPABASE_URL + path;
        Request.Builder builder = new Request.Builder().url(url)
                .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer " + session.accessToken)
                .header("Accept", "application/json");
        if (prefer != null && !prefer.isEmpty()) builder.header("Prefer", prefer);
        if ("GET".equals(method)) builder.get();
        else if ("DELETE".equals(method)) builder.delete();
        else {
            RequestBody requestBody = RequestBody.create(rawBody == null ? "{}" : rawBody, JSON);
            if ("PATCH".equals(method)) builder.patch(requestBody); else builder.post(requestBody);
            builder.header("Content-Type", "application/json");
        }
        try (Response response = http.newCall(builder.build()).execute()) {
            String responseText = response.body() == null ? "" : response.body().string();
            if (!response.isSuccessful()) {
                String message = responseText;
                try {
                    JSONObject err = new JSONObject(responseText);
                    message = err.optString("message", err.optString("msg", err.optString("error_description", responseText)));
                    if (message.isEmpty()) message = responseText;
                } catch (Exception ignored) { }
                throw new IOException("Supabase " + response.code() + ": " + message);
            }
            if (responseText.trim().isEmpty()) return new JSONObject();
            try {
                String first = responseText.trim();
                if (first.startsWith("[")) return new JSONArray(first);
                if (first.startsWith("{")) return new JSONObject(first);
                return first;
            } catch (Exception ignored) { return responseText; }
        }
    }
}

package com.absuconnect.games.auth;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.absuconnect.games.BuildConfig;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;

public final class SupabaseAuthRepository {
    public interface Callback { void onResult(AuthSession session, String error); }
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private final Context appContext;
    private final OkHttpClient client = new OkHttpClient();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public SupabaseAuthRepository(Context context) { appContext = context.getApplicationContext(); }

    public void signUp(String email, String password, Callback callback) {
        executor.execute(() -> {
            AuthSession session = null;
            String error = null;
            try {
                JSONObject body = new JSONObject().put("email", email.trim()).put("password", password);
                Request request = new Request.Builder().url(BuildConfig.SUPABASE_URL + "/auth/v1/signup")
                        .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                        .post(RequestBody.create(body.toString(), JSON)).build();
                try (Response response = client.newCall(request).execute()) {
                    String text = response.body() == null ? "{}" : response.body().string();
                    JSONObject json = new JSONObject(text);
                    if (!response.isSuccessful()) {
                        error = json.optString("msg", json.optString("message", "Account creation failed. Please try again."));
                    } else if (json.has("access_token") && json.has("user")) {
                        JSONObject user = json.getJSONObject("user");
                        long expires = System.currentTimeMillis() / 1000L + json.optLong("expires_in", 3600L);
                        session = new AuthSession(json.getString("access_token"), json.getString("refresh_token"),
                                user.getString("id"), user.optString("email", email), expires);
                        AuthSessionStore.save(appContext, session);
                    } else {
                        error = "Account created. Check your email to confirm it, then sign in.";
                    }
                }
            } catch (Exception ex) {
                error = ex instanceof IOException ? "Network unavailable. Check your connection and try again." : "Could not create the account. Please try again.";
            }
            AuthSession result = session;
            String resultError = error;
            main.post(() -> callback.onResult(result, resultError));
        });
    }

    public void signIn(String email, String password, Callback callback) {
        executor.execute(() -> {
            AuthSession session = null;
            String error = null;
            try {
                JSONObject body = new JSONObject().put("email", email.trim()).put("password", password);
                HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/auth/v1/token")
                        .newBuilder().addQueryParameter("grant_type", "password").build();
                Request request = new Request.Builder().url(url)
                        .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                        .post(RequestBody.create(body.toString(), JSON)).build();
                try (Response response = client.newCall(request).execute()) {
                    String text = response.body() == null ? "{}" : response.body().string();
                    JSONObject json = new JSONObject(text);
                    if (!response.isSuccessful()) {
                        error = json.optString("msg", json.optString("message", "Sign-in failed. Check your details and try again."));
                    } else {
                        JSONObject user = json.getJSONObject("user");
                        long expires = System.currentTimeMillis() / 1000L + json.optLong("expires_in", 3600L);
                        session = new AuthSession(json.getString("access_token"), json.getString("refresh_token"),
                                user.getString("id"), user.optString("email", email), expires);
                        AuthSessionStore.save(appContext, session);
                    }
                }
            } catch (Exception ex) {
                error = ex instanceof IOException ? "Network unavailable. Check your connection and try again." : "Could not sign in. Please try again.";
            }
            AuthSession result = session;
            String resultError = error;
            main.post(() -> callback.onResult(result, resultError));
        });
    }

    /** Call on a worker thread before authenticated REST requests. */
    public AuthSession freshSession(Context context) throws IOException {
        AuthSession current = AuthSessionStore.load(context);
        if (current == null) throw new IOException("Sign in to continue.");
        if (current.isFresh()) return current;
        try {
            JSONObject body = new JSONObject().put("refresh_token", current.refreshToken);
            HttpUrl url = HttpUrl.parse(BuildConfig.SUPABASE_URL + "/auth/v1/token")
                    .newBuilder().addQueryParameter("grant_type", "refresh_token").build();
            Request request = new Request.Builder().url(url)
                    .header("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
                    .post(RequestBody.create(body.toString(), JSON)).build();
            try (Response response = client.newCall(request).execute()) {
                String text = response.body() == null ? "{}" : response.body().string();
                if (!response.isSuccessful()) throw new IOException("Session expired. Sign in again.");
                JSONObject json = new JSONObject(text);
                JSONObject user = json.getJSONObject("user");
                AuthSession refreshed = new AuthSession(json.getString("access_token"),
                        json.optString("refresh_token", current.refreshToken), user.getString("id"),
                        user.optString("email", current.email), System.currentTimeMillis() / 1000L + json.optLong("expires_in", 3600L));
                AuthSessionStore.save(context, refreshed);
                return refreshed;
            }
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Could not refresh session. Sign in again."); }
    }
}

package com.absuconnect.games.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class UiKit {
    static final int BG = Color.rgb(245, 244, 240);
    static final int PAPER = Color.WHITE;
    static final int INK = Color.rgb(26, 39, 36);
    static final int MUTED = Color.rgb(101, 113, 107);
    static final int GREEN = Color.rgb(22, 122, 102);
    static final int GOLD = Color.rgb(174, 125, 49);
    static final int BORDER = Color.rgb(222, 224, 218);
    private UiKit() {}

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static TextView text(Context c, String value, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    static GradientDrawable rounded(int color, Context c) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(c, 18));
        d.setStroke(dp(c, 1), BORDER); return d;
    }
    static LinearLayout vertical(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    static LinearLayout card(Context c) {
        LinearLayout l = vertical(c); l.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16));
        l.setBackground(rounded(PAPER, c)); return l;
    }
    static Button button(Context c, String label, boolean primary) {
        Button b = new Button(c); b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(primary ? Color.WHITE : GREEN);
        GradientDrawable d = new GradientDrawable(); d.setColor(primary ? GREEN : Color.rgb(233, 242, 238));
        d.setCornerRadius(dp(c, 13)); b.setBackground(d); b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        return b;
    }
    static void marginTop(Context c, View view, LinearLayout parent, int height, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height < 0 ? height : dp(c, height));
        p.topMargin = dp(c, top); parent.addView(view, p);
    }
}

package com.absuconnect.games.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.absuconnect.games.action.ActionContentCatalog;
import com.absuconnect.games.action.GameCoinPricing;
import com.absuconnect.games.action.LocalGameProgression;
import com.absuconnect.games.action.LocalGameProgressStore;
import com.absuconnect.games.racing.RacingCatalog;
import java.util.ArrayList;

/** Device-local item preview and earned-point upgrade screen; no paid currency or online authority. */
public final class ProgressionShopActivity extends AppCompatActivity {
    private static final int MAX_UPGRADE=5;
    private LinearLayout page;
    private String kind="fighter",gameId="campus_duel";
    private int activeA,activeB,activeC,activeD,activeE;

    private static final class Item {
        final String section,name,detail,key,artType;
        final int requiredRank,maxUpgrade,coinPrice;
        final boolean current;final int primary,trim;
        Item(String section,String name,String detail,String key,int rank,int max,boolean current,int price){this(section,name,detail,key,rank,max,current,colour(name,false),colour(name,true),price);}
        Item(String section,String name,String detail,String key,int rank,int max,boolean current,int primary,int trim,int price){
            this.section=section;this.name=name;this.detail=detail;this.key=key;requiredRank=rank;maxUpgrade=max;this.current=current;this.primary=primary;this.trim=trim;coinPrice=price;artType=artType(section);
        }
    }
    @Override protected void onCreate(Bundle state){super.onCreate(state);
        kind=getIntent().getStringExtra("shop_kind");if(kind==null)kind="fighter";
        gameId=getIntent().getStringExtra("game_id");if(gameId==null)gameId="campus_duel";
        activeA=getIntent().getIntExtra("active_a",0);activeB=getIntent().getIntExtra("active_b",0);activeC=getIntent().getIntExtra("active_c",0);activeD=getIntent().getIntExtra("active_d",0);activeE=getIntent().getIntExtra("active_e",0);
        render();
    }
    private void render(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(UiKit.BG);
        page=UiKit.vertical(this);page.setPadding(UiKit.dp(this,16),UiKit.dp(this,14),UiKit.dp(this,16),UiKit.dp(this,24));scroll.addView(page);
        LinearLayout header=UiKit.row(this);TextView back=UiKit.text(this,"‹  Back",15,UiKit.GREEN,true);header.addView(back);back.setOnClickListener(v->finish());
        TextView title=UiKit.text(this,title(),18,UiKit.INK,true);title.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));page.addView(header);
        LocalGameProgression state=LocalGameProgressStore.load(this);
        LinearLayout career=UiKit.card(this);career.setPadding(UiKit.dp(this,14),UiKit.dp(this,13),UiKit.dp(this,14),UiKit.dp(this,13));UiKit.marginTop(this,career,page,-2,12);
        career.addView(UiKit.text(this,"RANK "+state.rank()+"    ·    "+state.experience()+" XP    ·    "+state.practiceCredits()+" Practice Points",14,UiKit.GREEN,true));
        TextView next=UiKit.text(this,state.rank()>=LocalGameProgression.MAX_RANK?"Maximum rank reached.":state.xpToNextRank()+" XP to the next rank · next gear unlocks appear below.",12,UiKit.MUTED,false);UiKit.marginTop(this,next,career,-2,5);career.addView(next);
        String gameTitle=gameTitle();boolean completedToday=LocalGameProgressStore.playedToday(this,gameId);
        TextView daily=UiKit.text(this,completedToday?"Daily replay goal complete · keep playing to earn match XP.":"Today's replay goal: finish a local "+gameTitle+" match to earn a one-time daily bonus.",12,UiKit.INK,true);UiKit.marginTop(this,daily,career,-2,7);career.addView(daily);
        int streak=state.streak(gameId);TextView streakLine=UiKit.text(this,"Local-device streak: "+streak+" day"+(streak==1?"":"s")+" · offline only, not synced to an account.",11,UiKit.MUTED,false);UiKit.marginTop(this,streakLine,career,-2,4);career.addView(streakLine);
        TextView explainer=UiKit.text(this,"Preview the locked tiers here. Finish local matches to earn XP and rank-up unlocks. Upgrade the currently selected fighter, operator, driver or vehicle with non-purchasable Practice Points. Progress is saved only on this device; it is separate from the proposed NGN funding wallet and per-game coin wallets, and cannot affect online matches.",12,UiKit.MUTED,false);UiKit.marginTop(this,explainer,page,-2,10);
        String section="";
        for(Item item:items()){
            if(!item.section.equals(section)){section=item.section;TextView heading=UiKit.text(this,section.toUpperCase(),11,UiKit.GREEN,true);UiKit.marginTop(this,heading,page,-2,14);}
            addItem(item,state);
        }
        setContentView(scroll);
    }
    private String title(){return kind.equals("fighter")?"Fighter Hall":kind.equals("shooter")?"Fireline Armory":kind.equals("bike")?"Bike Garage":"Car Garage";}
    private String gameTitle(){return kind.equals("fighter")?"Campus Duel":kind.equals("shooter")?"Campus Fireline":kind.equals("bike")?"Campus Bike Racing":"Campus Car Racing";}
    private void addItem(Item item,LocalGameProgression state){
        boolean unlocked=state.unlockedAtRank(item.requiredRank);LinearLayout card=UiKit.card(this);card.setPadding(UiKit.dp(this,12),UiKit.dp(this,10),UiKit.dp(this,12),UiKit.dp(this,10));UiKit.marginTop(this,card,page,-2,7);
        LinearLayout row=UiKit.row(this);TextView name=UiKit.text(this,item.name,14,UiKit.INK,true);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=UiKit.text(this,unlocked?(item.current?"EQUIPPED":"RANK "+item.requiredRank):"LOCKED · R"+item.requiredRank,10,unlocked?UiKit.GREEN:0xffa5682b,true);row.addView(badge);card.addView(row);
        TextView desc=UiKit.text(this,item.detail,11,UiKit.MUTED,false);UiKit.marginTop(this,desc,card,-2,5);card.addView(desc);
        TextView estimate=UiKit.text(this,"Illustrative value: "+coinNumber(item.coinPrice)+" "+gameCoinName()+" · not a live price",10,UiKit.MUTED,false);UiKit.marginTop(this,estimate,card,-2,4);card.addView(estimate);
        LinearLayout actions=UiKit.row(this);UiKit.marginTop(this,actions,card,-2,7);
        android.widget.Button preview=UiKit.button(this,unlocked?"Preview":"Preview locked",false);actions.addView(preview,new LinearLayout.LayoutParams(0,UiKit.dp(this,38),1));preview.setOnClickListener(v->preview(item,state));
        if(item.current&&item.maxUpgrade>0&&unlocked){
            int level=state.upgradeLevel(item.key);String label=level>=item.maxUpgrade?"Max L"+level:"Upgrade L"+level+" → "+(level+1)+" · "+state.nextUpgradeCost(item.key)+" pts";
            android.widget.Button upgrade=UiKit.button(this,label,true);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,UiKit.dp(this,38),1);lp.leftMargin=UiKit.dp(this,7);actions.addView(upgrade,lp);
            upgrade.setEnabled(level<item.maxUpgrade&&state.practiceCredits()>=state.nextUpgradeCost(item.key));
            upgrade.setOnClickListener(v->{if(LocalGameProgressStore.upgrade(this,item.key,item.maxUpgrade)){new AlertDialog.Builder(this).setTitle("Upgrade ready").setMessage(item.name+" is now level "+LocalGameProgressStore.load(this).upgradeLevel(item.key)+". The stat increase applies the next time you start a round or race.").setPositiveButton("Continue",(d,w)->render()).show();}else render();});
        }else if(!unlocked){TextView hint=UiKit.text(this,"Earn XP to reach rank "+item.requiredRank+"",10,0xffa5682b,true);actions.addView(hint,new LinearLayout.LayoutParams(0,UiKit.dp(this,38),1));}
        else{TextView hint=UiKit.text(this,item.current?"Selected loadout":"Choose in game loadout",10,UiKit.MUTED,true);actions.addView(hint,new LinearLayout.LayoutParams(0,UiKit.dp(this,38),1));}
        card.addView(actions);
    }
    private void preview(Item item,LocalGameProgression state){
        String lock=state.unlockedAtRank(item.requiredRank)?"Available at your rank.":"Locked until Rank "+item.requiredRank+". Earn XP in local matches to unlock it.";
        String current=item.current?"\n\nThis is in your current loadout.":"";
        String pricing="\n\nIllustrative value: "+coinNumber(item.coinPrice)+" "+gameCoinName()+" (not a live price or offer).";
        int level=item.current?state.upgradeLevel(item.key):0;
        if(item.maxUpgrade>0&&level<item.maxUpgrade)pricing+="\nExample next upgrade, Level "+(level+1)+": "+coinNumber(GameCoinPricing.upgrade(item.coinPrice,level))+" "+gameCoinName()+".";
        LinearLayout body=UiKit.vertical(this);body.setPadding(UiKit.dp(this,12),UiKit.dp(this,8),UiKit.dp(this,12),0);
        body.addView(new ItemPreviewView(this,item),new LinearLayout.LayoutParams(-1,UiKit.dp(this,132)));
        TextView detail=UiKit.text(this,item.detail+"\n\n"+lock+current+pricing+"\n\nExample coin values scale with rank and item value/stats such as health, stamina, damage, magazine size, speed, acceleration, handling and cosmetic rarity. The current prototype unlocks by XP and upgrades with free device-local Practice Points. No coin wallet or purchase is active; these example values are not approved prices.",12,UiKit.MUTED,false);UiKit.marginTop(this,detail,body,-1,8);body.addView(detail);
        new AlertDialog.Builder(this).setTitle(item.name+(state.unlockedAtRank(item.requiredRank)?"":" · LOCKED")).setView(body).setPositiveButton("Close",null).show();
    }
    private ArrayList<Item> items(){ArrayList<Item> list=new ArrayList<>();
        if(kind.equals("fighter")){
            for(int i=0;i<ActionContentCatalog.FIGHTERS.length;i++){ActionContentCatalog.CharacterSpec x=ActionContentCatalog.FIGHTERS[i];list.add(new Item("Fighters",x.name,x.role+" · "+x.description+" Health "+x.health+", stamina "+x.stamina+", pace "+x.moveScale,xKey("fighter",i),x.unlockRank,5,i==activeA,x.primary,x.trim,GameCoinPricing.fighter(x)));}
            for(int i=0;i<ActionContentCatalog.FIGHTING_WEAPONS.length;i++){ActionContentCatalog.WeaponSpec x=ActionContentCatalog.FIGHTING_WEAPONS[i];list.add(new Item("Training weapons",x.name,x.type+" · "+x.handling+" · practice impact "+x.damage,xKey("fighter_weapon",i),x.unlockRank,5,i==activeB,GameCoinPricing.meleeWeapon(x)));}
            for(int i=0;i<ActionContentCatalog.FIGHTING_SKILLS.length;i++){ActionContentCatalog.SkillSpec x=ActionContentCatalog.FIGHTING_SKILLS[i];list.add(new Item("Combat skills",x.name,x.description+" Cooldown "+(x.cooldownMs/1000)+"s.","skill_"+safeKey(x.name),x.unlockRank,0,i==activeC,GameCoinPricing.skill(x)));}
            for(int i=0;i<ActionContentCatalog.ARENAS.length;i++){ActionContentCatalog.ArenaSpec x=ActionContentCatalog.ARENAS[i];list.add(new Item("Arenas and locations",x.name,x.location+" · "+x.description,"",x.unlockRank,0,i==activeD,x.ground,x.accent,GameCoinPricing.arena(x)));}
            for(int i=0;i<ActionContentCatalog.SKINS.length;i++){ActionContentCatalog.SkinSpec x=ActionContentCatalog.SKINS[i];list.add(new Item("Fighter skins",x.name,"Original color palette · visual-only selection.","",x.unlockRank,0,i==activeE,x.primary,x.trim,GameCoinPricing.skin(x)));}
        }else if(kind.equals("shooter")){
            for(int i=0;i<ActionContentCatalog.OPERATORS.length;i++){ActionContentCatalog.CharacterSpec x=ActionContentCatalog.OPERATORS[i];list.add(new Item("Operators",x.name,x.role+" · "+x.description+" Health "+x.health+", movement "+x.moveScale,xKey("shooter_operator",i),x.unlockRank,5,i==activeA,x.primary,x.trim,GameCoinPricing.operator(x)));}
            for(int i=0;i<ActionContentCatalog.GUNS.length;i++){ActionContentCatalog.WeaponSpec x=ActionContentCatalog.GUNS[i];list.add(new Item("Fictional gun profiles",x.name,x.type+" · "+x.handling+" Damage "+x.damage+", magazine "+x.magazine+", range "+x.range,xKey("shooter_gun",i),x.unlockRank,5,i==activeB,GameCoinPricing.firearm(x)));}
            for(int i=0;i<ActionContentCatalog.SHOOTER_SKILLS.length;i++){ActionContentCatalog.SkillSpec x=ActionContentCatalog.SHOOTER_SKILLS[i];list.add(new Item("Action skills",x.name,x.description+" Cooldown "+(x.cooldownMs/1000)+"s.","skill_"+safeKey(x.name),x.unlockRank,0,i==activeC,GameCoinPricing.skill(x)));}
            for(int i=0;i<ActionContentCatalog.ARENAS.length;i++){ActionContentCatalog.ArenaSpec x=ActionContentCatalog.ARENAS[i];list.add(new Item("Maps and locations",x.name,x.location+" · "+x.description,"",x.unlockRank,0,i==activeD,x.ground,x.accent,GameCoinPricing.arena(x)));}
            for(int i=0;i<ActionContentCatalog.SKINS.length;i++){ActionContentCatalog.SkinSpec x=ActionContentCatalog.SKINS[i];list.add(new Item("Operator skins",x.name,"Original color palette · visual-only selection.","",x.unlockRank,0,i==activeE,x.primary,x.trim,GameCoinPricing.skin(x)));}
        }else{
            boolean bike=kind.equals("bike");Object[] vehicles=bike?RacingCatalog.BIKES:RacingCatalog.CARS;String vehicleSection=bike?"Motorcycles":"Cars";
            for(int i=0;i<RacingCatalog.DRIVERS.length;i++){RacingCatalog.DriverSpec x=RacingCatalog.DRIVERS[i];list.add(new Item("Drivers",x.name,x.style+" · handling "+x.handling+", launch "+x.launch,xKey("racing_driver",i),x.unlockRank,5,i==activeA,GameCoinPricing.driver(x)));}
            for(int i=0;i<vehicles.length;i++){RacingCatalog.VehicleSpec x=(RacingCatalog.VehicleSpec)vehicles[i];list.add(new Item(vehicleSection,x.name,x.profile+" · top speed "+x.topSpeed+", acceleration "+x.acceleration+", handling "+x.handling,xKey(bike?"bike":"car",i),x.unlockRank,5,i==activeB,GameCoinPricing.vehicle(x)));}
            for(int i=0;i<RacingCatalog.SKINS.length;i++){RacingCatalog.SkinSpec x=RacingCatalog.SKINS[i];list.add(new Item("Paint and liveries",x.name,"Original livery palette · visual-only selection.","",x.unlockRank,0,i==activeC,x.primary,x.trim,GameCoinPricing.livery(x)));}
        }
        return list;
    }
    private String gameCoinName(){return gameTitle()+" Coins";}
    private static String coinNumber(int coins){return java.text.NumberFormat.getIntegerInstance(java.util.Locale.US).format(coins);}
    private static int colour(String name,boolean alternate){int h=name==null?0:name.hashCode();int r=66+Math.floorMod((h>>>16)+(alternate?83:0),155),g=70+Math.floorMod((h>>>8)+(alternate?47:0),150),b=75+Math.floorMod(h+(alternate?119:0),145);return 0xff000000|(r<<16)|(g<<8)|b;}
    private static String artType(String section){String s=section.toLowerCase(java.util.Locale.ROOT);if(s.contains("fighter")||s.contains("operator")||s.contains("driver"))return "character";if(s.contains("weapon")||s.contains("firearm")||s.contains("gun"))return "weapon";if(s.contains("motorcycle"))return "bike";if(s.equals("cars"))return "car";if(s.contains("skill"))return "skill";if(s.contains("arena")||s.contains("map"))return "map";return "skin";}
    private static String xKey(String type,int index){return type+":"+index;}
    private static String safeKey(String value){return value.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+","_");}

    /** Abstract original visual preview; real production character/vehicle art has not been commissioned. */
    private static final class ItemPreviewView extends View {
        private final Item item;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        ItemPreviewView(Context context,Item item){super(context);this.item=item;}
        private float dp(float v){return v*getResources().getDisplayMetrics().density;}
        private void fill(Canvas c,int color){paint.setStyle(Paint.Style.FILL);paint.setColor(color);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w*.5f,cy=h*.56f,d=dp(1);
            fill(c,0xff1c2c29);c.drawRoundRect(new RectF(0,0,w,h),dp(12),dp(12),paint);
            paint.setTextSize(dp(8));paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);paint.setColor(0xffb3c8bb);paint.setTextAlign(Paint.Align.LEFT);c.drawText("ORIGINAL CONCEPT PREVIEW",dp(12),dp(17),paint);
            switch(item.artType){
                case "character":
                    fill(c,0x553dd3b1);c.drawCircle(cx,cy,dp(42),paint);fill(c,item.primary);c.drawRoundRect(new RectF(cx-dp(17),cy-dp(8),cx+dp(17),cy+dp(28)),dp(8),dp(8),paint);c.drawCircle(cx,cy-dp(24),dp(12),paint);fill(c,item.trim);c.drawRoundRect(new RectF(cx-dp(22),cy-dp(11),cx-dp(14),cy+dp(9)),dp(3),dp(3),paint);c.drawRoundRect(new RectF(cx+dp(14),cy-dp(11),cx+dp(22),cy+dp(9)),dp(3),dp(3),paint);c.drawRoundRect(new RectF(cx-dp(14),cy+dp(24),cx-dp(5),cy+dp(44)),dp(3),dp(3),paint);c.drawRoundRect(new RectF(cx+dp(5),cy+dp(24),cx+dp(14),cy+dp(44)),dp(3),dp(3),paint);break;
                case "weapon":
                    fill(c,item.primary);c.drawRoundRect(new RectF(cx-dp(57),cy-dp(9),cx+dp(40),cy+dp(8)),dp(5),dp(5),paint);c.drawRect(cx+dp(39),cy-dp(5),cx+dp(60),cy+dp(4),paint);fill(c,item.trim);c.drawRoundRect(new RectF(cx-dp(41),cy-dp(14),cx-dp(3),cy-dp(8)),dp(2),dp(2),paint);c.drawRoundRect(new RectF(cx-dp(18),cy+dp(6),cx-dp(7),cy+dp(24)),dp(2),dp(2),paint);c.drawRect(cx-dp(59),cy-dp(7),cx-dp(45),cy+dp(6),paint);break;
                case "car":
                    fill(c,0xff253936);c.drawCircle(cx-dp(36),cy+dp(22),dp(13),paint);c.drawCircle(cx+dp(36),cy+dp(22),dp(13),paint);fill(c,0xffdae2d9);c.drawCircle(cx-dp(36),cy+dp(22),dp(5),paint);c.drawCircle(cx+dp(36),cy+dp(22),dp(5),paint);fill(c,item.primary);c.drawRoundRect(new RectF(cx-dp(62),cy-dp(9),cx+dp(62),cy+dp(23)),dp(9),dp(9),paint);fill(c,item.trim);c.drawRoundRect(new RectF(cx-dp(25),cy-dp(23),cx+dp(24),cy+dp(1)),dp(9),dp(9),paint);fill(c,0xffb9d8d1);c.drawRoundRect(new RectF(cx-dp(18),cy-dp(19),cx-dp(2),cy-dp(3)),dp(4),dp(4),paint);c.drawRoundRect(new RectF(cx+dp(2),cy-dp(19),cx+dp(18),cy-dp(3)),dp(4),dp(4),paint);break;
                case "bike":
                    fill(c,0xff293935);c.drawCircle(cx-dp(39),cy+dp(22),dp(18),paint);c.drawCircle(cx+dp(39),cy+dp(22),dp(18),paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(3));paint.setColor(item.trim);c.drawCircle(cx-dp(39),cy+dp(22),dp(12),paint);c.drawCircle(cx+dp(39),cy+dp(22),dp(12),paint);fill(c,item.primary);c.drawRoundRect(new RectF(cx-dp(20),cy-dp(3),cx+dp(21),cy+dp(10)),dp(6),dp(6),paint);c.drawLine(cx-dp(39),cy+dp(22),cx-dp(13),cy-dp(1),paint);c.drawLine(cx-dp(13),cy-dp(1),cx+dp(9),cy+dp(22),paint);c.drawLine(cx+dp(9),cy+dp(22),cx+dp(39),cy+dp(22),paint);fill(c,item.trim);c.drawRoundRect(new RectF(cx-dp(15),cy-dp(16),cx+dp(11),cy-dp(3)),dp(5),dp(5),paint);break;
                case "map":
                    fill(c,item.primary);c.drawRoundRect(new RectF(cx-dp(75),cy-dp(39),cx+dp(75),cy+dp(43)),dp(8),dp(8),paint);paint.setColor(0x44d4e4d4);paint.setStrokeWidth(dp(1));for(int i=-2;i<=2;i++){c.drawLine(cx+dp(i*24),cy-dp(34),cx+dp(i*24),cy+dp(38),paint);c.drawLine(cx-dp(69),cy+dp(i*16),cx+dp(69),cy+dp(i*16),paint);}fill(c,item.trim);c.drawRoundRect(new RectF(cx-dp(47),cy-dp(21),cx-dp(20),cy-dp(9)),dp(3),dp(3),paint);c.drawRoundRect(new RectF(cx+dp(20),cy+dp(7),cx+dp(48),cy+dp(20)),dp(3),dp(3),paint);break;
                case "skill":
                    paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(3));paint.setColor(item.primary);for(int i=0;i<4;i++)c.drawCircle(cx,cy,dp(11+i*11),paint);paint.setStyle(Paint.Style.FILL);fill(c,item.trim);c.drawCircle(cx,cy,dp(8),paint);fill(c,0xfff0db9b);c.drawCircle(cx,cy,dp(3),paint);break;
                default:
                    fill(c,item.primary);for(int i=0;i<4;i++)c.drawRoundRect(new RectF(cx-dp(74)+i*dp(38),cy-dp(25),cx-dp(42)+i*dp(38),cy+dp(25)),dp(6),dp(6),paint);fill(c,item.trim);c.drawRoundRect(new RectF(cx-dp(57),cy-dp(10),cx-dp(25),cy+dp(10)),dp(5),dp(5),paint);c.drawRoundRect(new RectF(cx-dp(19),cy-dp(10),cx+dp(13),cy+dp(10)),dp(5),dp(5),paint);break;
            }
        }
    }
}

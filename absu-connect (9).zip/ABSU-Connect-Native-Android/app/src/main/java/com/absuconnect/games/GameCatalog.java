package com.absuconnect.games;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Stable identifiers shared by Android routes, invitation RPCs, analytics, and future game packages. */
public final class GameCatalog {
    public static final class Module {
        public final String id, title, genre, status;
        public final int minPlayers, maxPlayers;
        public Module(String id, String title, String genre, int minPlayers, int maxPlayers, String status) {
            this.id=id; this.title=title; this.genre=genre; this.minPlayers=minPlayers; this.maxPlayers=maxPlayers; this.status=status;
        }
    }
    public static final List<Module> ALL = Collections.unmodifiableList(Arrays.asList(
        new Module("campus_ludo", "Campus Ludo", "Board", 2, 4, "local-prototype"),
        new Module("campus_duel", "Campus Duel", "Fighting", 2, 2, "configurable-local-prototype"),
        new Module("campus_fireline", "Campus Fireline", "Action shooter", 1, 1, "solo-endless-level-campaign"),
        new Module("naija_whot", "Naija WHOT!", "Card", 2, 4, "local-playable"),
        new Module("billiards", "Campus 8-Ball", "Sports", 2, 2, "local-playable"),
        new Module("kart_racing", "Campus Car Racing", "Racing", 2, 2, "configurable-local-playable"),
        new Module("bike_racing", "Campus Bike Racing", "Racing", 2, 2, "configurable-local-playable")
    ));
    private GameCatalog() {}

    public static Module find(String id) {
        for (Module module:ALL) if (module.id.equals(id)) return module;
        return null;
    }
}

package com.absuconnect.app.model

enum class AppTab(val route: String, val label: String) {
    HOME("home", "Home"),
    FRIENDS("friends", "Friends"),
    MESSAGES("messages", "Messages"),
    ALERTS("alerts", "Alerts"),
    MORE("more", "More")
}

enum class FriendTab(val key: String, val label: String) {
    DISCOVER("discover", "Discover"),
    REQUESTS("requests", "Requests"),
    SENT("sent", "Sent"),
    FRIENDS("friends", "Friends")
}

enum class SubScreen {
    NONE,
    CREATE_POST,
    CHAT,
    SAVED,
    PROFILE,
    USER_PROFILE
}

data class Profile(
    val id: String,
    val displayName: String,
    val username: String = "",
    val department: String = "",
    val faculty: String = "",
    val level: String = "",
    val campus: String = "Uturu Main Campus",
    val bio: String = "",
    val avatarUrl: String = "",
    val interests: List<String> = emptyList(),
    val isOnline: Boolean = false
)

data class PostMediaItem(
    val id: String = "",
    val url: String,
    val storagePath: String = "",
    val mediaType: String = "image",
    val mimeType: String = "image/jpeg"
)

data class PostComment(
    val id: String,
    val postId: String,
    val authorId: String,
    val authorName: String,
    val authorAvatar: String = "",
    val body: String,
    val createdAt: String,
    val parentCommentId: String? = null
)

data class FeedPost(
    val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatar: String = "",
    val authorDepartment: String = "",
    val body: String,
    val createdAt: String,
    val communityId: String? = null,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val media: List<PostMediaItem> = emptyList()
)

data class FriendshipItem(
    val id: String,
    val requesterId: String,
    val addresseeId: String,
    val status: String,
    val peer: Profile
)

data class DiscoverMatchResult(
    val profile: Profile,
    val score: Int,
    val matchReasons: List<String>
)

data class ConversationItem(
    val id: String,
    val title: String,
    val isGroup: Boolean,
    val lastMessageAt: String,
    val peerId: String = "",
    val peerAvatar: String = "",
    val lastMessagePreview: String = ""
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val body: String,
    val createdAt: String,
    val mediaUrl: String = "",
    val mediaType: String = ""
)

data class AlertItem(
    val id: String,
    val type: String,
    val entityType: String = "",
    val entityId: String = "",
    val title: String,
    val body: String,
    val createdAt: String,
    val isRead: Boolean
)

data class SelectedMediaDraft(
    val localId: String,
    val displayName: String,
    val mimeType: String,
    val mediaType: String, // "image" or "video"
    val bytes: ByteArray,
    val uriString: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is SelectedMediaDraft) return false
        return localId == other.localId
    }

    override fun hashCode(): Int = localId.hashCode()
}

data class MediaBatchValidationResult(
    val accepted: List<SelectedMediaDraft>,
    val rejectedReasons: List<String>
) {
    val hasFailures: Boolean get() = rejectedReasons.isNotEmpty()
}

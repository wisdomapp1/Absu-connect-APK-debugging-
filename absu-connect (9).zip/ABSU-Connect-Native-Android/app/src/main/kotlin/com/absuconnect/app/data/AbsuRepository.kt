package com.absuconnect.app.data

import android.content.Context
import com.absuconnect.app.model.*
import com.absuconnect.games.NetworkMode
import com.absuconnect.games.auth.AuthSession
import com.absuconnect.games.auth.AuthSessionStore
import com.absuconnect.games.backend.NativeSupabaseApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Instant

class AbsuRepository(context: Context) {
    private val appContext = context.applicationContext
    val api = NativeSupabaseApi(appContext)

    fun currentSession(): AuthSession? = AuthSessionStore.load(appContext)

    suspend fun signOut() = withContext(Dispatchers.IO) {
        val session = currentSession()
        val prefs = appContext.getSharedPreferences("absu_native_push", Context.MODE_PRIVATE)
        val token = prefs.getString("registered_fcm_token", null)
        try {
            if (session != null && !token.isNullOrBlank()) {
                api.delete("device_push_tokens?user_id=eq.${session.userId}&token=eq.${URLEncoder.encode(token, "UTF-8")}")
            }
        } catch (_: Exception) { }
        AuthSessionStore.clear(appContext)
        prefs.edit().remove("registered_fcm_token").apply()
    }

    suspend fun updatePresence(userId: String) = withContext(Dispatchers.IO) {
        try {
            val now = Instant.now().toString()
            api.postArray(
                "user_presence?on_conflict=user_id",
                JSONObject().put("user_id", userId).put("last_seen_at", now).put("updated_at", now),
                "resolution=merge-duplicates,return=minimal"
            )
        } catch (_: Exception) { }
    }

    suspend fun fetchOnlineUserIds(): Set<String> = withContext(Dispatchers.IO) {
        val result = mutableSetOf<String>()
        try {
            val cutoff = Instant.now().minusSeconds(120)
            val rows = api.getArray("user_presence?select=user_id,last_seen_at&limit=200")
            for (i in 0 until rows.length()) {
                val r = rows.optJSONObject(i) ?: continue
                val uid = r.optString("user_id", "")
                val seen = r.optString("last_seen_at", "")
                if (uid.isNotBlank() && seen.isNotBlank()) {
                    try {
                        if (!Instant.parse(seen).isBefore(cutoff)) result.add(uid)
                    } catch (_: Exception) { }
                }
            }
        } catch (_: Exception) { }
        result
    }

    suspend fun fetchProfile(userId: String): Profile = withContext(Dispatchers.IO) {
        val p = api.getObject("profiles?select=*&id=eq.$userId")
        val onlineIds = fetchOnlineUserIds()
        parseProfile(p, onlineIds)
    }

    suspend fun updateProfile(profile: Profile) = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("id", profile.id)
            .put("display_name", profile.displayName.trim())
            .put("username", profile.username.trim().removePrefix("@"))
            .put("department", profile.department.trim())
            .put("faculty", profile.faculty.trim())
            .put("level", profile.level.trim())
            .put("campus", profile.campus.trim())
            .put("bio", profile.bio.trim())
            .put("interests", JSONArray(profile.interests))
        api.postArray("profiles?on_conflict=id", payload, "resolution=merge-duplicates,return=minimal")
    }

    suspend fun fetchFeedPosts(currentUserId: String): List<FeedPost> = withContext(Dispatchers.IO) {
        val limit = if (NetworkMode.isLowData(appContext)) 12 else 30
        val posts = api.getArray(
            "posts?select=id,author_id,body,created_at,community_id,profiles:profiles!posts_author_id_fkey(display_name,username,avatar_url,department),post_media(*),post_reactions(user_id),comments(id)&order=created_at.desc&limit=$limit"
        )
        val savedIds = fetchSavedPostIds(currentUserId)
        val result = mutableListOf<FeedPost>()
        for (i in 0 until posts.length()) {
            val row = posts.optJSONObject(i) ?: continue
            result.add(parsePost(row, currentUserId, savedIds))
        }
        result
    }

    suspend fun fetchSavedPostIds(userId: String): Set<String> = withContext(Dispatchers.IO) {
        val ids = mutableSetOf<String>()
        try {
            val arr = api.getArray("saved_posts?select=post_id&user_id=eq.$userId&limit=200")
            for (i in 0 until arr.length()) {
                val id = arr.optJSONObject(i)?.optString("post_id", "") ?: ""
                if (id.isNotBlank()) ids.add(id)
            }
        } catch (_: Exception) { }
        ids
    }

    suspend fun fetchSavedPosts(userId: String): List<FeedPost> = withContext(Dispatchers.IO) {
        val ids = fetchSavedPostIds(userId)
        if (ids.isEmpty()) return@withContext emptyList()
        val idList = ids.joinToString(",")
        val arr = api.getArray(
            "posts?select=id,author_id,body,created_at,community_id,profiles:profiles!posts_author_id_fkey(display_name,username,avatar_url,department),post_media(*),post_reactions(user_id),comments(id)&id=in.($idList)&order=created_at.desc&limit=100"
        )
        val out = mutableListOf<FeedPost>()
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            out.add(parsePost(row, userId, ids))
        }
        out
    }

    suspend fun toggleLike(postId: String, userId: String, currentlyLiked: Boolean) = withContext(Dispatchers.IO) {
        if (currentlyLiked) {
            api.delete("post_reactions?post_id=eq.$postId&user_id=eq.$userId")
        } else {
            api.postArray(
                "post_reactions?on_conflict=post_id,user_id",
                JSONObject().put("post_id", postId).put("user_id", userId).put("reaction", "like"),
                "resolution=merge-duplicates,return=minimal"
            )
        }
    }

    suspend fun toggleSavePost(postId: String, userId: String, currentlySaved: Boolean) = withContext(Dispatchers.IO) {
        if (currentlySaved) {
            api.delete("saved_posts?post_id=eq.$postId&user_id=eq.$userId")
        } else {
            api.postArray(
                "saved_posts?on_conflict=user_id,post_id",
                JSONObject().put("post_id", postId).put("user_id", userId).put("created_at", Instant.now().toString()),
                "resolution=merge-duplicates,return=minimal"
            )
        }
    }

    suspend fun fetchComments(postId: String): List<PostComment> = withContext(Dispatchers.IO) {
        val arr = api.getArray(
            "comments?select=id,post_id,author_id,body,created_at,parent_comment_id,author:profiles!comments_author_id_fkey(display_name,avatar_url)&post_id=eq.$postId&order=created_at.asc&limit=150"
        )
        val out = mutableListOf<PostComment>()
        for (i in 0 until arr.length()) {
            val r = arr.optJSONObject(i) ?: continue
            val author = r.optJSONObject("author")
            out.add(
                PostComment(
                    id = r.optString("id"),
                    postId = r.optString("post_id"),
                    authorId = r.optString("author_id"),
                    authorName = author?.optString("display_name", "ABSU Student")?.ifBlank { "ABSU Student" } ?: "ABSU Student",
                    authorAvatar = author?.optString("avatar_url", "") ?: "",
                    body = r.optString("body"),
                    createdAt = r.optString("created_at"),
                    parentCommentId = r.optString("parent_comment_id", "").ifBlank { null }
                )
            )
        }
        out
    }

    suspend fun addComment(postId: String, authorId: String, body: String, parentId: String? = null) = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("post_id", postId)
            .put("author_id", authorId)
            .put("body", body.trim())
        if (!parentId.isNullOrBlank()) payload.put("parent_comment_id", parentId)
        api.postArray("comments", payload, "return=representation")
    }

    suspend fun createPostWithMedia(
        authorId: String,
        body: String,
        communityId: String?,
        mediaDrafts: List<SelectedMediaDraft>
    ): String = withContext(Dispatchers.IO) {
        val postPayload = JSONObject()
            .put("author_id", authorId)
            .put("body", body.trim())
            .put("visibility", if (communityId.isNullOrBlank()) "public" else "community")
        if (!communityId.isNullOrBlank()) postPayload.put("community_id", communityId)

        val createdPosts = api.postArray("posts", postPayload, "return=representation")
        if (createdPosts.length() == 0) error("Post creation did not return a record.")
        val postId = createdPosts.optJSONObject(0).optString("id")

        if (mediaDrafts.isNotEmpty()) {
            val mediaRows = JSONArray()
            try {
                val nowIso = Instant.now().toString()
                mediaDrafts.forEachIndexed { idx, draft ->
                    require(draft.mediaType == "image") { "Only photo uploads are enabled for posts." }
                    val ext = draft.displayName.substringAfterLast('.', "jpg")
                        .lowercase()
                        .replace(Regex("[^a-z0-9]"), "")
                        .ifBlank { "jpg" }
                    val cleanName = draft.displayName.replace(Regex("[^a-zA-Z0-9_.-]"), "_")
                    val storagePath = "$authorId/${System.currentTimeMillis()}_${idx}_$cleanName"
                    api.uploadStorageBytes("post-media", storagePath, draft.bytes, draft.mimeType)

                    mediaRows.put(
                        JSONObject()
                            .put("post_id", postId)
                            .put("uploader_id", authorId)
                            .put("kind", "image")
                            .put("provider", "supabase")
                            .put("secure_url", storagePath)
                            .put("asset_id", storagePath)
                            .put("format", ext)
                            .put("bytes", draft.bytes.size)
                            .put("position", idx)
                            .put("created_at", nowIso)
                    )
                }
                api.postJsonArray("post_media", mediaRows, "return=minimal")
            } catch (ex: Exception) {
                try { api.delete("posts?id=eq.$postId") } catch (_: Exception) { }
                throw ex
            }
        }
        postId
    }

    suspend fun fetchFriendshipsAndDiscover(currentUserId: String): Triple<List<FriendshipItem>, List<Profile>, Profile> =
        withContext(Dispatchers.IO) {
            val onlineIds = fetchOnlineUserIds()
            val me = parseProfile(api.getObject("profiles?select=*&id=eq.$currentUserId"), onlineIds)
            val links = api.getArray(
                "friendships?select=id,requester_id,addressee_id,status,requester:profiles!friendships_requester_id_fkey(*),addressee:profiles!friendships_addressee_id_fkey(*)&or=(requester_id.eq.$currentUserId,addressee_id.eq.$currentUserId)&order=created_at.desc&limit=150"
            )
            val friendships = mutableListOf<FriendshipItem>()
            for (i in 0 until links.length()) {
                val f = links.optJSONObject(i) ?: continue
                val req = f.optString("requester_id")
                val addr = f.optString("addressee_id")
                val peerObj = f.optJSONObject(if (req == currentUserId) "addressee" else "requester") ?: JSONObject()
                friendships.add(
                    FriendshipItem(
                        id = f.optString("id"),
                        requesterId = req,
                        addresseeId = addr,
                        status = f.optString("status"),
                        peer = parseProfile(peerObj, onlineIds)
                    )
                )
            }
            val peopleArr = api.getArray("profiles?select=*&id=neq.$currentUserId&order=created_at.desc&limit=80")
            val candidates = mutableListOf<Profile>()
            for (i in 0 until peopleArr.length()) {
                val p = peopleArr.optJSONObject(i) ?: continue
                candidates.add(parseProfile(p, onlineIds))
            }
            Triple(friendships, candidates, me)
        }

    suspend fun sendFriendRequest(currentUserId: String, targetUserId: String) = withContext(Dispatchers.IO) {
        val created = api.postArray(
            "friendships",
            JSONObject().put("requester_id", currentUserId).put("addressee_id", targetUserId).put("status", "pending"),
            "return=representation"
        )
        if (created.length() > 0) {
            val id = created.optJSONObject(0).optString("id")
            try {
                api.invokeFunction(
                    "send-android-push",
                    JSONObject().put("recipient_id", targetUserId).put("type", "friend_request").put("entity_id", id)
                )
            } catch (_: Exception) { }
        }
    }

    suspend fun respondFriendRequest(friendshipId: String, requesterId: String, accept: Boolean) = withContext(Dispatchers.IO) {
        api.patchArray(
            "friendships?id=eq.$friendshipId",
            JSONObject().put("status", if (accept) "accepted" else "declined"),
            "return=minimal"
        )
        if (accept) {
            try {
                api.invokeFunction(
                    "send-android-push",
                    JSONObject().put("recipient_id", requesterId).put("type", "friend_accepted").put("entity_id", friendshipId)
                )
            } catch (_: Exception) { }
        }
    }

    suspend fun cancelFriendRequest(friendshipId: String) = withContext(Dispatchers.IO) {
        api.delete("friendships?id=eq.$friendshipId")
    }

    suspend fun startOrGetDirectConversation(currentUserId: String, peerId: String, peerName: String): String =
        withContext(Dispatchers.IO) {
            try {
                val res = api.rpc("create_or_get_direct_conversation", JSONObject().put("p_target_user_id", peerId))
                val raw = res?.toString()?.trim()?.trim('"').orEmpty()
                if (raw.isNotBlank() && raw != "null" && !raw.startsWith("{")) return@withContext raw
            } catch (_: Exception) { }

            val created = api.postArray(
                "conversations",
                JSONObject()
                    .put("title", peerName)
                    .put("is_group", false)
                    .put("created_by", currentUserId)
                    .put("last_message_at", Instant.now().toString()),
                "return=representation"
            )
            val cid = created.optJSONObject(0).optString("id")
            api.postArray(
                "conversation_members",
                JSONObject().put("conversation_id", cid).put("user_id", currentUserId).put("last_read_at", Instant.now().toString()),
                "return=minimal"
            )
            api.postArray(
                "conversation_members",
                JSONObject().put("conversation_id", cid).put("user_id", peerId),
                "return=minimal"
            )
            cid
        }

    suspend fun fetchConversations(currentUserId: String): List<ConversationItem> = withContext(Dispatchers.IO) {
        val members = api.getArray("conversation_members?select=conversation_id&user_id=eq.$currentUserId&limit=100")
        val ids = (0 until members.length()).mapNotNull { members.optJSONObject(it)?.optString("conversation_id")?.ifBlank { null } }
        if (ids.isEmpty()) return@withContext emptyList()
        val arr = api.getArray(
            "conversations?select=id,title,is_group,last_message_at&id=in.(${ids.joinToString(",")})&order=last_message_at.desc&limit=40"
        )
        val out = mutableListOf<ConversationItem>()
        for (i in 0 until arr.length()) {
            val c = arr.optJSONObject(i) ?: continue
            val cid = c.optString("id")
            val isGroup = c.optBoolean("is_group", false)
            var title = c.optString("title", if (isGroup) "Group Conversation" else "Direct Chat")
            var peerId = ""
            var peerAvatar = ""
            if (!isGroup) {
                try {
                    val peers = api.getArray(
                        "conversation_members?select=user_id,profiles:profiles(display_name,avatar_url)&conversation_id=eq.$cid&user_id=neq.$currentUserId&limit=1"
                    )
                    if (peers.length() > 0) {
                        val pr = peers.optJSONObject(0)
                        peerId = pr.optString("user_id", "")
                        val profileObj = pr.optJSONObject("profiles")
                        val dn = profileObj?.optString("display_name", "") ?: ""
                        if (dn.isNotBlank()) title = dn
                        peerAvatar = profileObj?.optString("avatar_url", "") ?: ""
                    }
                } catch (_: Exception) { }
            }
            out.add(
                ConversationItem(
                    id = cid,
                    title = title,
                    isGroup = isGroup,
                    lastMessageAt = c.optString("last_message_at"),
                    peerId = peerId,
                    peerAvatar = peerAvatar
                )
            )
        }
        out
    }

    suspend fun fetchChatMessages(conversationId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        val arr = api.getArray(
            "messages?select=id,conversation_id,sender_id,body,created_at,media_url,media_type&conversation_id=eq.$conversationId&order=created_at.asc&limit=120"
        )
        val out = mutableListOf<ChatMessage>()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            out.add(
                ChatMessage(
                    id = m.optString("id"),
                    conversationId = m.optString("conversation_id"),
                    senderId = m.optString("sender_id"),
                    body = m.optString("body"),
                    createdAt = m.optString("created_at"),
                    mediaUrl = m.optString("media_url", ""),
                    mediaType = m.optString("media_type", "")
                )
            )
        }
        out
    }

    suspend fun sendChatMessage(conversationId: String, senderId: String, body: String) = withContext(Dispatchers.IO) {
        val sent = api.postArray(
            "messages",
            JSONObject().put("conversation_id", conversationId).put("sender_id", senderId).put("body", body.trim()),
            "return=representation"
        )
        try {
            api.patchArray(
                "conversations?id=eq.$conversationId",
                JSONObject().put("last_message_at", Instant.now().toString()),
                "return=minimal"
            )
        } catch (_: Exception) { }
        if (sent.length() > 0) {
            val msgId = sent.optJSONObject(0).optString("id")
            try {
                val recipients = api.getArray(
                    "conversation_members?select=user_id&conversation_id=eq.$conversationId&user_id=neq.$senderId&limit=50"
                )
                for (i in 0 until recipients.length()) {
                    val rid = recipients.optJSONObject(i)?.optString("user_id") ?: continue
                    api.invokeFunction(
                        "send-android-push",
                        JSONObject().put("recipient_id", rid).put("type", "message").put("entity_id", msgId)
                    )
                }
            } catch (_: Exception) { }
        }
    }

    suspend fun fetchAlerts(userId: String): List<AlertItem> = withContext(Dispatchers.IO) {
        val arr = api.getArray(
            "notifications?select=id,type,title,body,read_at,created_at,entity_type,entity_id&recipient_id=eq.$userId&order=created_at.desc&limit=80"
        )
        val out = mutableListOf<AlertItem>()
        for (i in 0 until arr.length()) {
            val n = arr.optJSONObject(i) ?: continue
            out.add(
                AlertItem(
                    id = n.optString("id"),
                    type = n.optString("type", "system"),
                    entityType = n.optString("entity_type", ""),
                    entityId = n.optString("entity_id", ""),
                    title = n.optString("title", "ABSU Connect"),
                    body = n.optString("body", ""),
                    createdAt = n.optString("created_at"),
                    isRead = !n.isNull("read_at")
                )
            )
        }
        out
    }

    suspend fun markAlertRead(notificationId: String) = withContext(Dispatchers.IO) {
        api.patchArray(
            "notifications?id=eq.$notificationId",
            JSONObject().put("read_at", Instant.now().toString()),
            "return=minimal"
        )
    }

    suspend fun markAllAlertsRead(userId: String) = withContext(Dispatchers.IO) {
        api.patchArray(
            "notifications?recipient_id=eq.$userId&read_at=is.null",
            JSONObject().put("read_at", Instant.now().toString()),
            "return=minimal"
        )
    }

    /**
     * Idempotent smart welcome notification + real online peer count. Never invents fake counts.
     */
    suspend fun ensureWelcomeDiscoveryNotification(userId: String) = withContext(Dispatchers.IO) {
        try {
            val existing = api.getArray(
                "notifications?select=id&recipient_id=eq.$userId&entity_type=eq.discovery_welcome&limit=1"
            )
            if (existing.length() > 0) return@withContext

            val onlineCount = fetchOnlineUserIds().count { it != userId }
            val body = if (onlineCount > 0) {
                "Find coursemates and campus friends! $onlineCount verified student${if (onlineCount == 1) " is" else "s are"} online right now — tap to open Discover."
            } else {
                "Welcome to ABSU Connect! Tap to explore students from your department and faculty in Friend Navigator."
            }
            api.postArray(
                "notifications",
                JSONObject()
                    .put("recipient_id", userId)
                    .put("type", "system")
                    .put("entity_type", "discovery_welcome")
                    .put("title", "Discover your ABSU circle")
                    .put("body", body)
                    .put("created_at", Instant.now().toString()),
                "return=minimal"
            )
        } catch (_: Exception) { }
    }

    private fun parseProfile(p: JSONObject, onlineIds: Set<String>): Profile {
        val id = p.optString("id", "")
        val rawInterests = p.optJSONArray("interests")
        val interests = mutableListOf<String>()
        if (rawInterests != null) {
            for (i in 0 until rawInterests.length()) {
                val item = rawInterests.optString(i, "")
                if (item.isNotBlank()) interests.add(item)
            }
        }
        return Profile(
            id = id,
            displayName = p.optString("display_name", p.optString("username", "ABSU Student")).ifBlank { "ABSU Student" },
            username = p.optString("username", ""),
            department = p.optString("department", ""),
            faculty = p.optString("faculty", ""),
            level = p.optString("level", ""),
            campus = p.optString("campus", "Uturu Main Campus"),
            bio = p.optString("bio", ""),
            avatarUrl = p.optString("avatar_url", ""),
            interests = interests,
            isOnline = id in onlineIds
        )
    }

    private fun parsePost(row: JSONObject, currentUserId: String, savedIds: Set<String>): FeedPost {
        val id = row.optString("id")
        val author = row.optJSONObject("profiles")
        val reactions = row.optJSONArray("post_reactions") ?: JSONArray()
        var isLiked = false
        for (i in 0 until reactions.length()) {
            if (reactions.optJSONObject(i)?.optString("user_id") == currentUserId) {
                isLiked = true
                break
            }
        }
        val commentsArr = row.optJSONArray("comments") ?: JSONArray()
        val mediaArr = row.optJSONArray("post_media") ?: JSONArray()
        val mediaList = mutableListOf<Pair<Int, PostMediaItem>>()
        for (i in 0 until mediaArr.length()) {
            val m = mediaArr.optJSONObject(i) ?: continue
            val rawUrl = m.optString("secure_url", m.optString("asset_id", ""))
            val kind = m.optString("kind", "image")
            val pos = m.optInt("position", i)
            val resolved = if (rawUrl.isNotBlank()) api.resolveMediaUrl("post-media", rawUrl) else ""
            if (resolved.isNotBlank()) {
                mediaList.add(
                    pos to PostMediaItem(
                        id = m.optString("id"),
                        url = resolved,
                        storagePath = m.optString("asset_id", rawUrl),
                        mediaType = kind,
                        mimeType = if (kind == "video") "video/mp4" else "image/jpeg"
                    )
                )
            }
        }
        return FeedPost(
            id = id,
            authorId = row.optString("author_id"),
            authorName = author?.optString("display_name", "ABSU Student")?.ifBlank { "ABSU Student" } ?: "ABSU Student",
            authorAvatar = author?.optString("avatar_url", "") ?: "",
            authorDepartment = author?.optString("department", "") ?: "",
            body = row.optString("body", ""),
            createdAt = row.optString("created_at", ""),
            communityId = row.optString("community_id", "").ifBlank { null },
            likesCount = reactions.length(),
            commentsCount = commentsArr.length(),
            isLiked = isLiked,
            isSaved = id in savedIds,
            media = mediaList.sortedBy { it.first }.map { it.second }
        )
    }
}

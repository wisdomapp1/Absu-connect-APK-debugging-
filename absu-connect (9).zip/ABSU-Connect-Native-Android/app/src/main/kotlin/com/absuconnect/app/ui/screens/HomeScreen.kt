package com.absuconnect.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absuconnect.app.model.FeedPost
import com.absuconnect.app.model.PostComment
import com.absuconnect.app.model.Profile
import com.absuconnect.app.ui.components.LinkifiedText
import com.absuconnect.app.ui.components.PostMediaGallery
import com.absuconnect.app.ui.components.UserAvatar
import com.absuconnect.app.ui.theme.AbsuPurple

@Composable
fun HomeScreen(
    currentUser: Profile?,
    posts: List<FeedPost>,
    loading: Boolean,
    listState: LazyListState,
    onRefresh: () -> Unit,
    onOpenCreatePost: () -> Unit,
    onToggleLike: (FeedPost) -> Unit,
    onToggleSave: (FeedPost) -> Unit,
    onOpenComments: (FeedPost) -> Unit,
    onOpenAuthorProfile: (String) -> Unit
) {
    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Composer Card
        item(key = "composer_card") {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenCreatePost() }
                        .padding(14.dp)
                ) {
                    UserAvatar(
                        name = currentUser?.displayName ?: "ABSU Student",
                        avatarUrl = currentUser?.avatarUrl ?: "",
                        size = 42.dp
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Share a campus update or photo...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                    FilledTonalIconButton(onClick = onOpenCreatePost) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Create post")
                    }
                }
            }
        }

        if (loading && posts.isEmpty()) {
            item(key = "loading") {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else if (posts.isEmpty()) {
            item(key = "empty") {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Your campus feed is ready", fontWeight = FontWeight.Bold)
                        Text(
                            "Publish the first campus post or connect with classmates in Friend Navigator.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(onClick = onRefresh) { Text("Refresh Feed") }
                    }
                }
            }
        } else {
            items(posts, key = { it.id }) { post ->
                FeedPostCard(
                    post = post,
                    onToggleLike = { onToggleLike(post) },
                    onToggleSave = { onToggleSave(post) },
                    onOpenComments = { onOpenComments(post) },
                    onOpenAuthor = { onOpenAuthorProfile(post.authorId) }
                )
            }
        }
    }
}

@Composable
fun FeedPostCard(
    post: FeedPost,
    onToggleLike: () -> Unit,
    onToggleSave: () -> Unit,
    onOpenComments: () -> Unit,
    onOpenAuthor: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.clickable { onOpenAuthor() }
            ) {
                UserAvatar(name = post.authorName, avatarUrl = post.authorAvatar, size = 40.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(post.authorName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    val sub = buildString {
                        if (post.authorDepartment.isNotBlank()) append("${post.authorDepartment} · ")
                        append(post.createdAt.take(16).replace('T', ' '))
                    }
                    Text(sub, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onToggleSave) {
                    Icon(
                        imageVector = if (post.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Save post",
                        tint = if (post.isSaved) AbsuPurple else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (post.body.isNotBlank()) {
                LinkifiedText(text = post.body)
            }

            if (post.media.isNotEmpty()) {
                PostMediaGallery(media = post.media)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                TextButton(onClick = onToggleLike) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (post.isLiked) Color(0xFFE11D48) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("${post.likesCount} Likes")
                }
                TextButton(onClick = onOpenComments) {
                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Comments", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("${post.commentsCount} Comments")
                }
            }
        }
    }
}

@Composable
fun CommentsDialog(
    post: FeedPost,
    comments: List<PostComment>,
    loading: Boolean,
    onDismiss: () -> Unit,
    onSendComment: (String) -> Unit
) {
    var draft by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Comments on ${post.authorName}'s post", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 380.dp)) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                } else if (comments.isEmpty()) {
                    Text("No comments yet. Start the discussion!", style = MaterialTheme.typography.bodySmall)
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        items(comments, key = { it.id }) { c ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(c.authorName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    LinkifiedText(text = c.body, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    placeholder = { Text("Write a comment (links supported)...") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = draft.trim()
                    if (trimmed.isNotEmpty()) {
                        onSendComment(trimmed)
                        draft = ""
                    }
                },
                enabled = draft.isNotBlank()
            ) {
                Text("Post")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

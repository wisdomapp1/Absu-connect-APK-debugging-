package com.absuconnect.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absuconnect.app.model.*
import com.absuconnect.app.ui.components.LinkifiedText
import com.absuconnect.app.ui.components.UserAvatar
import com.absuconnect.app.ui.theme.AbsuEmerald
import com.absuconnect.app.util.DiscoveryScorer

@Composable
fun FriendsScreen(
    currentUser: Profile?,
    currentUserId: String,
    activeSubTab: FriendTab,
    onSelectSubTab: (FriendTab) -> Unit,
    friendships: List<FriendshipItem>,
    candidates: List<Profile>,
    discoverListState: LazyListState,
    requestsListState: LazyListState,
    sentListState: LazyListState,
    friendsListState: LazyListState,
    onSendFriendRequest: (String) -> Unit,
    onRespondRequest: (friendshipId: String, requesterId: String, accept: Boolean) -> Unit,
    onCancelRequest: (friendshipId: String) -> Unit,
    onMessagePeer: (Profile) -> Unit,
    onCallPeer: (peerId: String, peerName: String, callType: String) -> Unit,
    onOpenUserProfile: (String) -> Unit
) {
    var search by remember { mutableStateOf("") }

    val accepted = remember(friendships) { friendships.filter { it.status == "accepted" } }
    val incoming = remember(friendships, currentUserId) {
        friendships.filter { it.status == "pending" && it.addresseeId == currentUserId }
    }
    val sent = remember(friendships, currentUserId) {
        friendships.filter { it.status == "pending" && it.requesterId == currentUserId }
    }
    val excludedIds = remember(friendships, currentUserId) {
        buildSet {
            add(currentUserId)
            friendships.forEach {
                add(it.requesterId)
                add(it.addresseeId)
            }
        }
    }
    val discovered = remember(currentUser, candidates, excludedIds, search) {
        DiscoveryScorer.scoreCandidates(currentUser, candidates, excludedIds).filter { match ->
            search.isBlank() ||
                match.profile.displayName.contains(search, ignoreCase = true) ||
                match.profile.department.contains(search, ignoreCase = true) ||
                match.profile.faculty.contains(search, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = activeSubTab.ordinal) {
            FriendTab.entries.forEach { tab ->
                val count = when (tab) {
                    FriendTab.DISCOVER -> discovered.size
                    FriendTab.REQUESTS -> incoming.size
                    FriendTab.SENT -> sent.size
                    FriendTab.FRIENDS -> accepted.size
                }
                Tab(
                    selected = activeSubTab == tab,
                    onClick = { onSelectSubTab(tab) },
                    text = { Text("${tab.label} ($count)", fontSize = 12.sp, maxLines = 1) }
                )
            }
        }

        // Each tab uses its own independent LazyListState so scrolling never leaks across tabs or screens
        when (activeSubTab) {
            FriendTab.DISCOVER -> {
                LazyColumn(
                    state = discoverListState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item(key = "discover_search") {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            placeholder = { Text("Search ABSU students by name, dept, faculty...") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (discovered.isEmpty()) {
                        item(key = "empty_discover") {
                            EmptyStateCard("No new campus suggestions match your filter right now.")
                        }
                    } else {
                        items(discovered, key = { it.profile.id }) { match ->
                            DiscoverStudentCard(
                                match = match,
                                onAddFriend = { onSendFriendRequest(match.profile.id) },
                                onOpenProfile = { onOpenUserProfile(match.profile.id) }
                            )
                        }
                    }
                }
            }

            FriendTab.REQUESTS -> {
                LazyColumn(
                    state = requestsListState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (incoming.isEmpty()) {
                        item { EmptyStateCard("No pending incoming friend requests.") }
                    } else {
                        items(incoming, key = { it.id }) { item ->
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.clickable { onOpenUserProfile(item.peer.id) }
                                    ) {
                                        UserAvatar(name = item.peer.displayName, avatarUrl = item.peer.avatarUrl, showOnline = item.peer.isOnline)
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(item.peer.displayName, fontWeight = FontWeight.Bold)
                                            Text(item.peer.department.ifBlank { item.peer.campus }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { onRespondRequest(item.id, item.requesterId, true) },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Accept") }
                                        OutlinedButton(
                                            onClick = { onRespondRequest(item.id, item.requesterId, false) },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Decline") }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            FriendTab.SENT -> {
                LazyColumn(
                    state = sentListState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (sent.isEmpty()) {
                        item { EmptyStateCard("No outgoing friend requests pending.") }
                    } else {
                        items(sent, key = { it.id }) { item ->
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.padding(14.dp)
                                ) {
                                    UserAvatar(name = item.peer.displayName, avatarUrl = item.peer.avatarUrl, showOnline = item.peer.isOnline)
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.peer.displayName, fontWeight = FontWeight.Bold)
                                        Text(item.peer.department.ifBlank { item.peer.campus }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    OutlinedButton(onClick = { onCancelRequest(item.id) }) { Text("Cancel") }
                                }
                            }
                        }
                    }
                }
            }

            FriendTab.FRIENDS -> {
                LazyColumn(
                    state = friendsListState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (accepted.isEmpty()) {
                        item { EmptyStateCard("Connect with peers from the Discover tab to start chatting and calling.") }
                    } else {
                        items(accepted, key = { it.id }) { item ->
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.clickable { onOpenUserProfile(item.peer.id) }
                                    ) {
                                        UserAvatar(name = item.peer.displayName, avatarUrl = item.peer.avatarUrl, showOnline = item.peer.isOnline)
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(item.peer.displayName, fontWeight = FontWeight.Bold)
                                            Text(
                                                text = if (item.peer.isOnline) "Online now · ${item.peer.department}" else item.peer.department.ifBlank { item.peer.campus },
                                                fontSize = 12.sp,
                                                color = if (item.peer.isOnline) AbsuEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { onMessagePeer(item.peer) }, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Chat", fontSize = 12.sp)
                                        }
                                        Button(onClick = { onCallPeer(item.peer.id, item.peer.displayName, "audio") }, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Voice", fontSize = 12.sp)
                                        }
                                        Button(onClick = { onCallPeer(item.peer.id, item.peer.displayName, "video") }, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Video", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiscoverStudentCard(
    match: DiscoverMatchResult,
    onAddFriend: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val p = match.profile
    Card(shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.clickable { onOpenProfile() }
            ) {
                UserAvatar(name = p.displayName, avatarUrl = p.avatarUrl, size = 46.dp, showOnline = p.isOnline)
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(p.displayName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (p.isOnline) {
                            Surface(color = AbsuEmerald.copy(alpha = 0.14f), shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    text = "Online now",
                                    color = AbsuEmerald,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    val academic = listOf(p.department, p.level).filter { it.isNotBlank() }.joinToString(" · ")
                    if (academic.isNotBlank()) {
                        Text(academic, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Button(onClick = onAddFriend, shape = RoundedCornerShape(12.dp)) {
                    Text("Connect", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (match.matchReasons.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    match.matchReasons.take(3).forEach { reason ->
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = reason,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            if (p.bio.isNotBlank()) {
                LinkifiedText(
                    text = p.bio,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }
    }
}

@Composable
fun EmptyStateCard(message: String) {
    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(20.dp)
        )
    }
}

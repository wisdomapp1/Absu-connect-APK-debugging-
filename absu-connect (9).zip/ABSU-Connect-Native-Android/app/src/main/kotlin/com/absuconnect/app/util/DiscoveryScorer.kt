package com.absuconnect.app.util

import com.absuconnect.app.model.DiscoverMatchResult
import com.absuconnect.app.model.Profile

object DiscoveryScorer {
    fun scoreCandidates(
        currentUser: Profile?,
        candidates: List<Profile>,
        excludedIds: Set<String>
    ): List<DiscoverMatchResult> {
        val currentDept = currentUser?.department?.trim()?.lowercase().orEmpty()
        val currentFaculty = currentUser?.faculty?.trim()?.lowercase().orEmpty()
        val currentLevel = currentUser?.level?.trim()?.lowercase().orEmpty()
        val currentInterests = currentUser?.interests
            ?.map { it.trim().lowercase() }
            ?.filter { it.isNotEmpty() }
            ?.toSet()
            .orEmpty()

        return candidates
            .asSequence()
            .filter { it.id.isNotBlank() && it.id !in excludedIds }
            .map { candidate ->
                var score = 0
                val reasons = mutableListOf<String>()

                val cDept = candidate.department.trim().lowercase()
                val cFaculty = candidate.faculty.trim().lowercase()
                val cLevel = candidate.level.trim().lowercase()

                if (currentDept.isNotEmpty() && cDept == currentDept) {
                    score += 40
                    reasons.add("Same Department")
                }
                if (currentFaculty.isNotEmpty() && cFaculty == currentFaculty) {
                    score += 25
                    reasons.add("Same Faculty")
                }
                if (currentLevel.isNotEmpty() && cLevel == currentLevel) {
                    score += 20
                    reasons.add("Same Level")
                }

                val sharedInterests = candidate.interests.filter { interest ->
                    interest.trim().lowercase() in currentInterests
                }
                if (sharedInterests.isNotEmpty()) {
                    score += sharedInterests.size.coerceAtMost(3) * 15
                    reasons.add("Shared: ${sharedInterests.first()}")
                }

                if (candidate.isOnline) {
                    score += 18
                    reasons.add("Online now")
                }

                if (reasons.isEmpty() && candidate.campus.isNotBlank()) {
                    reasons.add(candidate.campus)
                }

                DiscoverMatchResult(
                    profile = candidate,
                    score = score,
                    matchReasons = reasons
                )
            }
            .sortedWith(
                compareByDescending<DiscoverMatchResult> { it.score }
                    .thenByDescending { it.profile.isOnline }
                    .thenBy { it.profile.displayName.lowercase() }
            )
            .toList()
    }
}

package com.absuconnect.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absuconnect.app.ui.components.AbsuMonogramBadge
import com.absuconnect.games.auth.AuthSession
import com.absuconnect.games.auth.SupabaseAuthRepository

@Composable
fun AuthScreen(
    authRepo: SupabaseAuthRepository,
    onAuthenticated: (AuthSession, Boolean) -> Unit
) {
    var signUpMode by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.Start
    ) {
        AbsuMonogramBadge(size = 64.dp)
        Spacer(Modifier.height(18.dp))
        Text(
            text = "ABSU Connect",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Meet your people. Find your campus circle. Stay connected.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))
        Text(
            text = if (signUpMode) "Create your student account" else "Welcome back",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email address") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (6+ characters)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )

        errorMsg?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                val trimmed = email.trim()
                if (trimmed.isEmpty() || password.length < 6) {
                    errorMsg = "Enter a valid email and a password with at least 6 characters."
                    return@Button
                }
                busy = true
                errorMsg = null
                val wasSignUp = signUpMode
                val callback = SupabaseAuthRepository.Callback { session, err ->
                    busy = false
                    if (session != null) onAuthenticated(session, wasSignUp)
                    else errorMsg = err ?: "Authentication did not complete."
                }
                if (signUpMode) authRepo.signUp(trimmed, password, callback)
                else authRepo.signIn(trimmed, password, callback)
            },
            enabled = !busy,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                text = if (busy) "Please wait..." else if (signUpMode) "Create account" else "Sign in",
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = {
                signUpMode = !signUpMode
                errorMsg = null
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(if (signUpMode) "I already have an account · Sign in" else "New student? Create an account")
        }

        Spacer(Modifier.height(20.dp))
        Text(
            text = "Your ABSU Connect account is synced seamlessly across the web and native Android app.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

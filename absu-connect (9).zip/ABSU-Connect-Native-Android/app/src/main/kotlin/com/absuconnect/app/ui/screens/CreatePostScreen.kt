package com.absuconnect.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.absuconnect.app.model.SelectedMediaDraft
import com.absuconnect.app.util.MediaValidator
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    isSubmitting: Boolean,
    onBack: () -> Unit,
    onPublish: (body: String, media: List<SelectedMediaDraft>) -> Unit
) {
    val context = LocalContext.current
    var body by remember { mutableStateOf("") }
    var selectedMedia by remember { mutableStateOf<List<SelectedMediaDraft>>(emptyList()) }
    var warningBanner by remember { mutableStateOf<String?>(null) }
    var pendingAutoReopen by remember { mutableStateOf(false) }

    val safeImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        val batch = MediaValidator.readAndValidateUris(context, uris)
        if (batch.accepted.isNotEmpty()) {
            selectedMedia = selectedMedia + batch.accepted
        }
        if (batch.hasFailures) {
            warningBanner = batch.rejectedReasons.joinToString(" ") +
                if (batch.accepted.isNotEmpty()) " Valid photos were kept." else ""
            pendingAutoReopen = true
        } else {
            warningBanner = null
        }
    }

    LaunchedEffect(pendingAutoReopen) {
        if (pendingAutoReopen) {
            pendingAutoReopen = false
            delay(200L)
            safeImagePicker.launch(arrayOf("image/*"))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Create Campus Post", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    Button(
                        onClick = { onPublish(body, selectedMedia) },
                        enabled = !isSubmitting && (body.isNotBlank() || selectedMedia.isNotEmpty()),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(if (isSubmitting) "Posting..." else "Publish", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = body,
                onValueChange = { body = it },
                placeholder = { Text("What's happening on ABSU campus? Links starting with http://, https://, or www. become clickable automatically.") },
                minLines = 5,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            warningBanner?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Text(
                            text = msg,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { safeImagePicker.launch(arrayOf("image/*")) },
                    enabled = !isSubmitting,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (selectedMedia.isEmpty()) "Add Photos" else "Add More")
                }
            }

            if (selectedMedia.isNotEmpty()) {
                Text(
                    text = "Attached Photos (${selectedMedia.size}) — use arrows to reorder",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    itemsIndexed(selectedMedia, key = { _, item -> item.localId }) { idx, item ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.width(156.dp)
                        ) {
                            Box(modifier = Modifier.height(150.dp).fillMaxWidth()) {
                                AsyncImage(
                                    model = item.uriString,
                                    contentDescription = item.displayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )

                                IconButton(
                                    onClick = {
                                        selectedMedia = selectedMedia.filterNot { it.localId == item.localId }
                                    },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.65f))
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (idx > 0) {
                                            val copy = selectedMedia.toMutableList()
                                            val moved = copy.removeAt(idx)
                                            copy.add(idx - 1, moved)
                                            selectedMedia = copy
                                        }
                                    },
                                    enabled = idx > 0,
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Move left", modifier = Modifier.size(16.dp))
                                }
                                Text("#${idx + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                IconButton(
                                    onClick = {
                                        if (idx < selectedMedia.lastIndex) {
                                            val copy = selectedMedia.toMutableList()
                                            val moved = copy.removeAt(idx)
                                            copy.add(idx + 1, moved)
                                            selectedMedia = copy
                                        }
                                    },
                                    enabled = idx < selectedMedia.lastIndex,
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Move right", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

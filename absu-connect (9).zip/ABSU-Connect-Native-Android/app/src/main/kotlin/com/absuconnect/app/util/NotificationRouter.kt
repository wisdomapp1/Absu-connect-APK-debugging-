package com.absuconnect.app.util

import com.absuconnect.app.model.AppTab
import com.absuconnect.app.model.FriendTab

data class NotificationDestination(
    val tab: AppTab,
    val friendTab: FriendTab? = null
)

object NotificationRouter {
    private val DISCOVERY_TYPES = setOf(
        "welcome_discovery",
        "discovery_suggestion",
        "discovery_reminder",
        "discovery_welcome",
        "discovery"
    )

    fun isDiscoveryNotification(type: String?, entityType: String?): Boolean {
        val t = type?.trim()?.lowercase().orEmpty()
        val e = entityType?.trim()?.lowercase().orEmpty()
        return t in DISCOVERY_TYPES || e in DISCOVERY_TYPES
    }

    fun resolveDestination(type: String?, entityType: String?): NotificationDestination {
        if (isDiscoveryNotification(type, entityType)) {
            return NotificationDestination(tab = AppTab.FRIENDS, friendTab = FriendTab.DISCOVER)
        }
        return when (type?.trim()?.lowercase()) {
            "message" -> NotificationDestination(tab = AppTab.MESSAGES)
            "friend_request" -> NotificationDestination(tab = AppTab.FRIENDS, friendTab = FriendTab.REQUESTS)
            "friend_accepted" -> NotificationDestination(tab = AppTab.FRIENDS, friendTab = FriendTab.FRIENDS)
            else -> NotificationDestination(tab = AppTab.ALERTS)
        }
    }
}

package com.absuconnect.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.absuconnect.app.model.FeedPost
import com.absuconnect.app.model.Profile
import com.absuconnect.app.ui.components.LinkifiedText
import com.absuconnect.app.ui.components.UserAvatar
import com.absuconnect.app.ui.theme.AbsuEmerald

@Composable
fun MoreScreen(
    currentUser: Profile?,
    lowDataMode: Boolean,
    listState: LazyListState,
    onOpenProfile: () -> Unit,
    onOpenSaved: () -> Unit,
    onToggleLowData: () -> Unit,
    onSignOut: () -> Unit
) {
    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(key = "profile_card") {
            Card(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenProfile() }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    UserAvatar(
                        name = currentUser?.displayName ?: "ABSU Student",
                        avatarUrl = currentUser?.avatarUrl ?: "",
                        size = 54.dp,
                        showOnline = true
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(currentUser?.displayName ?: "ABSU Student", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            text = listOfNotNull(
                                currentUser?.department?.ifBlank { null },
                                currentUser?.level?.ifBlank { null }
                            ).joinToString(" · ").ifBlank { currentUser?.campus ?: "Uturu Main Campus" },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text("Edit profile", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }

        item(key = "shortcuts") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MoreActionTile(Icons.Default.Bookmark, "Saved Posts", "Bookmarked campus updates & announcements", onOpenSaved)
                MoreActionTile(Icons.Default.Person, "My Student Profile", "Department, faculty, level & clickable bio", onOpenProfile)
            }
        }

        item(key = "settings") {
            Card(shape = RoundedCornerShape(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleLowData() }
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Low Data Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Reduces feed page size & uses 240p call video", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = lowDataMode, onCheckedChange = { onToggleLowData() })
                }
            }
        }

        item(key = "signout") {
            OutlinedButton(
                onClick = onSignOut,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Sign Out", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MoreActionTile(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(14.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedPostsScreen(
    posts: List<FeedPost>,
    listState: LazyListState,
    onBack: () -> Unit,
    onToggleLike: (FeedPost) -> Unit,
    onToggleSave: (FeedPost) -> Unit,
    onOpenComments: (FeedPost) -> Unit,
    onOpenAuthor: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Saved Posts", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            if (posts.isEmpty()) {
                item { EmptyStateCard("No saved posts yet. Tap the bookmark icon on any post to save it here.") }
            } else {
                items(posts, key = { it.id }) { post ->
                    FeedPostCard(
                        post = post,
                        onToggleLike = { onToggleLike(post) },
                        onToggleSave = { onToggleSave(post) },
                        onOpenComments = { onOpenComments(post) },
                        onOpenAuthor = { onOpenAuthor(post.authorId) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    profile: Profile,
    onBack: () -> Unit,
    onSave: (Profile) -> Unit
) {
    var name by remember(profile.id) { mutableStateOf(profile.displayName) }
    var username by remember(profile.id) { mutableStateOf(profile.username) }
    var department by remember(profile.id) { mutableStateOf(profile.department) }
    var faculty by remember(profile.id) { mutableStateOf(profile.faculty) }
    var level by remember(profile.id) { mutableStateOf(profile.level) }
    var campus by remember(profile.id) { mutableStateOf(profile.campus) }
    var bio by remember(profile.id) { mutableStateOf(profile.bio) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Display Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = department, onValueChange = { department = it }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = faculty, onValueChange = { faculty = it }, label = { Text("Faculty") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = level, onValueChange = { level = it }, label = { Text("Level") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = campus, onValueChange = { campus = it }, label = { Text("Campus") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text("Bio (URLs become clickable links)") }, minLines = 3, modifier = Modifier.fillMaxWidth())

            Button(
                onClick = {
                    onSave(
                        profile.copy(
                            displayName = name,
                            username = username,
                            department = department,
                            faculty = faculty,
                            level = level,
                            campus = campus,
                            bio = bio
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Save Profile", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    user: Profile,
    onBack: () -> Unit,
    onMessage: (Profile) -> Unit,
    onCall: (peerId: String, peerName: String, callType: String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(user.displayName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        UserAvatar(name = user.displayName, avatarUrl = user.avatarUrl, size = 64.dp, showOnline = user.isOnline)
                        Column {
                            Text(user.displayName, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            if (user.isOnline) {
                                Text("Online on campus", fontSize = 12.sp, color = AbsuEmerald, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = listOf(user.department, user.faculty, user.level).filter { it.isNotBlank() }.joinToString(" · "),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (user.bio.isNotBlank()) {
                        LinkifiedText(text = user.bio)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onMessage(user) }, modifier = Modifier.weight(1f)) { Text("Message") }
                        Button(onClick = { onCall(user.id, user.displayName, "audio") }, modifier = Modifier.weight(1f)) { Text("Voice") }
                        Button(onClick = { onCall(user.id, user.displayName, "video") }, modifier = Modifier.weight(1f)) { Text("Video") }
                    }
                }
            }
        }
    }
}

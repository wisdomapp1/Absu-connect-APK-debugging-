package com.absuconnect.app.ui.components

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.absuconnect.app.model.PostMediaItem
import com.absuconnect.app.ui.theme.AbsuEmerald
import com.absuconnect.app.ui.theme.AbsuPurple
import com.absuconnect.app.ui.theme.AbsuPurpleDark
import com.absuconnect.app.ui.theme.AbsuPurpleLight
import com.absuconnect.app.util.UrlUtils

@Composable
fun AbsuMonogramBadge(size: Dp = 44.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val rx = w * (112f / 512f)
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(AbsuPurpleLight, AbsuPurple, AbsuPurpleDark),
                start = Offset.Zero,
                end = Offset(w, h)
            ),
            cornerRadius = CornerRadius(rx, rx)
        )
        val sx = w / 512f
        val sy = h / 512f
        val arch = Path().apply {
            moveTo(120f * sx, 400f * sy)
            lineTo(242f * sx, 108f * sy)
            cubicTo(250f * sx, 88f * sy, 262f * sx, 88f * sy, 270f * sx, 108f * sy)
            lineTo(392f * sx, 400f * sy)
        }
        drawPath(
            path = arch,
            color = Color.White,
            style = Stroke(width = 44f * sx, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawLine(
            color = Color.White,
            start = Offset(172f * sx, 290f * sy),
            end = Offset(340f * sx, 290f * sy),
            strokeWidth = 38f * sx,
            cap = StrokeCap.Round
        )
        drawCircle(
            color = AbsuPurple,
            radius = 32f * sx,
            center = Offset(256f * sx, 290f * sy)
        )
        drawCircle(
            color = Color.White,
            radius = 32f * sx,
            center = Offset(256f * sx, 290f * sy),
            style = Stroke(width = 12f * sx)
        )
    }
}

@Composable
fun UserAvatar(
    name: String,
    avatarUrl: String,
    size: Dp = 42.dp,
    showOnline: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val initials = name.trim().split(Regex("\\s+")).take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("")
        .ifBlank { "A" }
    Box(
        modifier = Modifier
            .size(size)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        if (avatarUrl.isNotBlank()) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer)
            )
        } else {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .matchParentSize()
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AbsuPurpleLight, AbsuPurpleDark)))
            ) {
                Text(
                    text = initials,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.36f).sp
                )
            }
        }
        if (showOnline) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(size * 0.28f)
                    .clip(CircleShape)
                    .background(AbsuEmerald)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun LinkifiedText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.bodyMedium.copy(
        color = MaterialTheme.colorScheme.onSurface
    )
) {
    val context = LocalContext.current
    val linkColor = MaterialTheme.colorScheme.primary
    val segments = remember(text) { UrlUtils.segmentTextWithUrls(text) }

    val annotated = remember(segments, linkColor) {
        buildAnnotatedString {
            for (seg in segments) {
                val targetUrl = seg.url
                if (targetUrl != null) {
                    withLink(
                        LinkAnnotation.Url(
                            url = targetUrl,
                            styles = TextLinkStyles(
                                style = SpanStyle(
                                    color = linkColor,
                                    fontWeight = FontWeight.SemiBold,
                                    textDecoration = TextDecoration.Underline
                                )
                            ),
                            linkInteractionListener = {
                                runCatching {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(intent)
                                }
                            }
                        )
                    ) {
                        append(seg.text)
                    }
                } else {
                    append(seg.text)
                }
            }
        }
    }

    Text(
        text = annotated,
        style = style,
        modifier = modifier
    )
}

@Composable
fun NativeVideoPlayer(
    videoUrl: String,
    modifier: Modifier = Modifier,
    autoPlay: Boolean = false
) {
    val context = LocalContext.current
    var muted by remember { mutableStateOf(!autoPlay) }
    var isPlaying by remember { mutableStateOf(autoPlay) }

    val exoPlayer = remember(videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUrl))
            repeatMode = Player.REPEAT_MODE_ONE
            volume = if (muted) 0f else 1f
            playWhenReady = autoPlay
            prepare()
        }
    }

    LaunchedEffect(muted) {
        exoPlayer.volume = if (muted) 0f else 1f
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (!isPlaying) {
                FilledTonalIconButton(
                    onClick = {
                        exoPlayer.play()
                        isPlaying = true
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play video", modifier = Modifier.size(18.dp))
                }
            }
            FilledTonalIconButton(
                onClick = { muted = !muted },
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = if (muted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = if (muted) "Unmute" else "Mute",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun PostMediaGallery(media: List<PostMediaItem>, modifier: Modifier = Modifier) {
    if (media.isEmpty()) return
    if (media.size == 1) {
        val item = media.first()
        if (item.mediaType == "video") {
            NativeVideoPlayer(
                videoUrl = item.url,
                modifier = modifier
                    .fillMaxWidth()
                    .height(240.dp)
            )
        } else {
            AsyncImage(
                model = item.url,
                contentDescription = "Post image",
                contentScale = ContentScale.Crop,
                modifier = modifier
                    .fillMaxWidth()
                    .heightIn(min = 180.dp, max = 320.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
        }
        return
    }

    val pagerState = rememberPagerState(pageCount = { media.size })
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(14.dp))
            ) { page ->
                val item = media[page]
                if (item.mediaType == "video") {
                    NativeVideoPlayer(videoUrl = item.url, modifier = Modifier.fillMaxSize())
                } else {
                    AsyncImage(
                        model = item.url,
                        contentDescription = "Attachment ${page + 1}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
            ) {
                Text(
                    text = "${pagerState.currentPage + 1} / ${media.size}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            repeat(media.size) { index ->
                val selected = pagerState.currentPage == index
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (selected) 8.dp else 6.dp)
                        .clip(CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        )
                )
            }
        }
    }
}

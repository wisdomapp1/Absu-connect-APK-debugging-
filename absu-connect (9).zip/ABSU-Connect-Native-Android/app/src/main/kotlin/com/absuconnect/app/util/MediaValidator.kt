package com.absuconnect.app.util

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.absuconnect.app.model.MediaBatchValidationResult
import com.absuconnect.app.model.SelectedMediaDraft
import java.util.UUID

object MediaValidator {
    const val MAX_IMAGE_BYTES = 15L * 1024L * 1024L // 15 MB

    fun isValidImageBytes(
        bytes: ByteArray,
        decodeImage: (ByteArray) -> Boolean = ::defaultBitmapDecoder
    ): Boolean {
        if (bytes.isEmpty() || bytes.size.toLong() > MAX_IMAGE_BYTES) return false
        return try {
            decodeImage(bytes)
        } catch (_: Exception) {
            false
        }
    }

    fun isSupportedPostMimeType(mimeType: String): Boolean {
        return mimeType.lowercase().startsWith("image/")
    }

    private fun defaultBitmapDecoder(bytes: ByteArray): Boolean {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        return opts.outWidth > 0 && opts.outHeight > 0
    }

    fun readAndValidateUris(
        context: Context,
        uris: List<Uri>,
        decodeImage: (ByteArray) -> Boolean = ::defaultBitmapDecoder
    ): MediaBatchValidationResult {
        val accepted = mutableListOf<SelectedMediaDraft>()
        val rejected = mutableListOf<String>()

        for (uri in uris) {
            val mime = (context.contentResolver.getType(uri) ?: "image/jpeg").lowercase()
            val name = queryDisplayName(context, uri) ?: "upload_${System.currentTimeMillis()}"

            if (!isSupportedPostMimeType(mime)) {
                rejected.add("$name is not a supported image (only photo uploads are enabled).")
                continue
            }

            val bytes = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } catch (_: Exception) {
                null
            }

            if (bytes == null || bytes.isEmpty()) {
                rejected.add("$name could not be read.")
                continue
            }

            if (bytes.size.toLong() > MAX_IMAGE_BYTES) {
                rejected.add("$name exceeds the 15 MB image upload limit.")
            } else if (!isValidImageBytes(bytes, decodeImage)) {
                rejected.add("$name appears corrupted or unreadable.")
            } else {
                accepted.add(
                    SelectedMediaDraft(
                        localId = UUID.randomUUID().toString(),
                        displayName = name,
                        mimeType = mime,
                        mediaType = "image",
                        bytes = bytes,
                        uriString = uri.toString()
                    )
                )
            }
        }

        return MediaBatchValidationResult(accepted = accepted, rejectedReasons = rejected)
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
        } catch (_: Exception) {
            null
        }
    }
}

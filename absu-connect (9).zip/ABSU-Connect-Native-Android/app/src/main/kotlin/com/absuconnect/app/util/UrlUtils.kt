package com.absuconnect.app.util

data class UrlSegment(
    val text: String,
    val url: String? // null = plain text, non-null = normalized external https/http URL
)

object UrlUtils {
    private val URL_REGEX = Regex(
        """((?:https?://|www\.)[^\s<>()]+(?:\([^\s<>()]*\)|[^\s<>().,;:!?"'\]\)])*)""",
        RegexOption.IGNORE_CASE
    )

    fun normalizeExternalUrl(raw: String): String {
        val trimmed = raw.trim()
        return if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            trimmed
        } else {
            "https://$trimmed"
        }
    }

    fun segmentTextWithUrls(input: String): List<UrlSegment> {
        if (input.isEmpty()) return emptyList()
        val segments = mutableListOf<UrlSegment>()
        var cursor = 0
        for (match in URL_REGEX.findAll(input)) {
            val start = match.range.first
            val endExclusive = match.range.last + 1
            if (start > cursor) {
                segments.add(UrlSegment(input.substring(cursor, start), null))
            }
            var rawUrl = match.value
            var trailing = ""
            while (rawUrl.isNotEmpty() && rawUrl.last() in charArrayOf('.', ',', ';', ':', '!', '?', ')', ']')) {
                trailing = rawUrl.last() + trailing
                rawUrl = rawUrl.dropLast(1)
            }
            if (rawUrl.isNotEmpty()) {
                segments.add(UrlSegment(rawUrl, normalizeExternalUrl(rawUrl)))
            }
            if (trailing.isNotEmpty()) {
                segments.add(UrlSegment(trailing, null))
            }
            cursor = endExclusive
        }
        if (cursor < input.length) {
            segments.add(UrlSegment(input.substring(cursor), null))
        }
        return segments
    }
}

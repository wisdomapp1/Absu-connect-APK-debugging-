package com.absuconnect.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AbsuPurple = Color(0xFF7C3AED)
val AbsuPurpleLight = Color(0xFF8B5CF6)
val AbsuPurpleDark = Color(0xFF5B21B6)
val AbsuPurpleSubtle = Color(0xFFF1EDFA)
val AbsuEmerald = Color(0xFF10B981)
val AbsuBgLight = Color(0xFFF8F7FA)
val AbsuCardLight = Color(0xFFFFFFFF)
val AbsuBorderLight = Color(0xFFE8E2EE)
val AbsuInkLight = Color(0xFF1F1938)
val AbsuMutedLight = Color(0xFF6B657C)

private val LightColors = lightColorScheme(
    primary = AbsuPurple,
    onPrimary = Color.White,
    primaryContainer = AbsuPurpleSubtle,
    onPrimaryContainer = AbsuPurpleDark,
    secondary = AbsuPurpleLight,
    background = AbsuBgLight,
    onBackground = AbsuInkLight,
    surface = AbsuCardLight,
    onSurface = AbsuInkLight,
    surfaceVariant = Color(0xFFF3EFFA),
    onSurfaceVariant = AbsuMutedLight,
    outlineVariant = AbsuBorderLight
)

private val DarkColors = darkColorScheme(
    primary = AbsuPurpleLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2D2250),
    onPrimaryContainer = Color(0xFFE9E0FF),
    secondary = AbsuPurple,
    background = Color(0xFF0F0D15),
    onBackground = Color(0xFFF4F1FA),
    surface = Color(0xFF191624),
    onSurface = Color(0xFFF4F1FA),
    surfaceVariant = Color(0xFF231E33),
    onSurfaceVariant = Color(0xFFA89FC2),
    outlineVariant = Color(0xFF2E2742)
)

@Composable
fun AbsuConnectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}

package com.absuconnect.games.ui

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.absuconnect.app.data.AbsuRepository
import com.absuconnect.app.model.*
import com.absuconnect.app.ui.components.AbsuMonogramBadge
import com.absuconnect.app.ui.screens.*
import com.absuconnect.app.ui.theme.AbsuConnectTheme
import com.absuconnect.app.util.NotificationRouter
import com.absuconnect.games.NetworkMode
import com.absuconnect.games.R
import com.absuconnect.games.auth.AuthSession
import com.absuconnect.games.auth.AuthSessionStore
import com.absuconnect.games.backend.RealtimeNotificationSubscription
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.Instant

/**
 * 100% Native Kotlin + Jetpack Compose entry point for ABSU Connect MVP 1.
 * Zero WebView or hosted web shell is rendered anywhere in this activity.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val CHANNEL_GENERAL = "absu_notifications"
        private const val CHANNEL_CALLS = "absu_calls"
        private const val REQ_NOTIFICATIONS = 7001

        @JvmField
        @Volatile
        var isForeground: Boolean = false
    }

    private lateinit var repository: AbsuRepository
    private var liveAlerts: RealtimeNotificationSubscription? = null

    private val externalNavPage = mutableStateOf<String?>(null)
    private val externalFriendTab = mutableStateOf<String?>(null)
    private val liveAlertSignal = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = AbsuRepository(this)
        createNotificationChannels()
        applyLaunchIntent(intent)

        setContent {
            AbsuConnectTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AbsuNativeRoot()
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AbsuNativeRoot() {
        val scope = rememberCoroutineScope()
        var session by remember { mutableStateOf<AuthSession?>(AuthSessionStore.load(this@MainActivity)) }

        var activeTab by remember { mutableStateOf(AppTab.HOME) }
        var friendSubTab by remember { mutableStateOf(FriendTab.DISCOVER) }
        var subScreen by remember { mutableStateOf(SubScreen.NONE) }

        // Independent LazyListStates per screen so scrolling Friend Navigator never affects Home or vice versa
        val homeScrollState = rememberLazyListState()
        val discoverScrollState = rememberLazyListState()
        val requestsScrollState = rememberLazyListState()
        val sentScrollState = rememberLazyListState()
        val friendsScrollState = rememberLazyListState()
        val messagesScrollState = rememberLazyListState()
        val chatScrollState = rememberLazyListState()
        val alertsScrollState = rememberLazyListState()
        val moreScrollState = rememberLazyListState()
        val savedScrollState = rememberLazyListState()

        // Domain state
        var currentUser by remember { mutableStateOf<Profile?>(null) }
        var posts by remember { mutableStateOf<List<FeedPost>>(emptyList()) }
        var savedPosts by remember { mutableStateOf<List<FeedPost>>(emptyList()) }
        var friendships by remember { mutableStateOf<List<FriendshipItem>>(emptyList()) }
        var candidates by remember { mutableStateOf<List<Profile>>(emptyList()) }
        var conversations by remember { mutableStateOf<List<ConversationItem>>(emptyList()) }
        var activeConversation by remember { mutableStateOf<ConversationItem?>(null) }
        var chatMessages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
        var alerts by remember { mutableStateOf<List<AlertItem>>(emptyList()) }
        var inspectedUser by remember { mutableStateOf<Profile?>(null) }

        var feedLoading by remember { mutableStateOf(false) }
        var postSubmitting by remember { mutableStateOf(false) }
        var commentsPost by remember { mutableStateOf<FeedPost?>(null) }
        var commentsList by remember { mutableStateOf<List<PostComment>>(emptyList()) }
        var commentsLoading by remember { mutableStateOf(false) }
        var lowDataMode by remember { mutableStateOf(NetworkMode.isLowData(this@MainActivity)) }

        fun refreshAll(uid: String) {
            scope.launch {
                feedLoading = true
                runCatching { repository.fetchProfile(uid) }.onSuccess { currentUser = it }
                runCatching { repository.fetchFeedPosts(uid) }.onSuccess { posts = it }
                runCatching { repository.fetchFriendshipsAndDiscover(uid) }.onSuccess { (links, cand, me) ->
                    friendships = links
                    candidates = cand
                    currentUser = me
                }
                runCatching { repository.fetchConversations(uid) }.onSuccess { conversations = it }
                runCatching { repository.fetchAlerts(uid) }.onSuccess { alerts = it }
                feedLoading = false
            }
        }

        LaunchedEffect(externalNavPage.value, externalFriendTab.value, session?.userId) {
            val page = externalNavPage.value
            val fTab = externalFriendTab.value
            if (session != null && page != null) {
                when (page) {
                    "friends" -> {
                        activeTab = AppTab.FRIENDS
                        subScreen = SubScreen.NONE
                        if (fTab == "discover") friendSubTab = FriendTab.DISCOVER
                        else if (fTab == "requests") friendSubTab = FriendTab.REQUESTS
                        else if (fTab == "friends") friendSubTab = FriendTab.FRIENDS
                    }
                    "messages" -> { activeTab = AppTab.MESSAGES; subScreen = SubScreen.NONE }
                    "alerts" -> { activeTab = AppTab.ALERTS; subScreen = SubScreen.NONE }
                    else -> { activeTab = AppTab.HOME; subScreen = SubScreen.NONE }
                }
                externalNavPage.value = null
                externalFriendTab.value = null
            }
        }

        LaunchedEffect(session?.userId) {
            val uid = session?.userId ?: return@LaunchedEffect
            ensureNotificationPermission()
            registerFirebasePushToken(uid)
            startLiveAlerts(session!!)
            repository.updatePresence(uid)
            repository.ensureWelcomeDiscoveryNotification(uid)
            refreshAll(uid)
            while (true) {
                delay(30_000L)
                repository.updatePresence(uid)
            }
        }

        LaunchedEffect(liveAlertSignal.intValue) {
            val uid = session?.userId ?: return@LaunchedEffect
            if (liveAlertSignal.intValue > 0) {
                runCatching { repository.fetchAlerts(uid) }.onSuccess { alerts = it }
            }
        }

        if (session == null) {
            AuthScreen(
                authRepo = repository.api.auth(),
                onAuthenticated = { newSession, _ ->
                    session = newSession
                    activeTab = AppTab.HOME
                    subScreen = SubScreen.NONE
                }
            )
            return
        }

        val currentUid = session!!.userId

        LaunchedEffect(subScreen, currentUid) {
            if (subScreen == SubScreen.SAVED) {
                runCatching { repository.fetchSavedPosts(currentUid) }.onSuccess { savedPosts = it }
            }
        }

        BackHandler(enabled = commentsPost != null || subScreen != SubScreen.NONE || activeTab != AppTab.HOME) {
            when {
                commentsPost != null -> commentsPost = null
                subScreen != SubScreen.NONE -> subScreen = SubScreen.NONE
                activeTab != AppTab.HOME -> activeTab = AppTab.HOME
            }
        }

        when (subScreen) {
            SubScreen.CREATE_POST -> {
                CreatePostScreen(
                    isSubmitting = postSubmitting,
                    onBack = { subScreen = SubScreen.NONE },
                    onPublish = { body, media ->
                        scope.launch {
                            postSubmitting = true
                            val res = runCatching {
                                repository.createPostWithMedia(currentUid, body, null, media)
                            }
                            postSubmitting = false
                            res.onSuccess {
                                toast("Post published.")
                                subScreen = SubScreen.NONE
                                refreshAll(currentUid)
                            }.onFailure { err ->
                                toast(err.message ?: "Could not publish post.")
                            }
                        }
                    }
                )
                return
            }

            SubScreen.CHAT -> {
                val conv = activeConversation
                if (conv != null) {
                    ChatScreen(
                        conversation = conv,
                        currentUserId = currentUid,
                        messages = chatMessages,
                        listState = chatScrollState,
                        onBack = { subScreen = SubScreen.NONE },
                        onSendMessage = { text ->
                            scope.launch {
                                runCatching { repository.sendChatMessage(conv.id, currentUid, text) }
                                    .onSuccess {
                                        runCatching { repository.fetchChatMessages(conv.id) }
                                            .onSuccess { chatMessages = it }
                                    }
                                    .onFailure { toast(it.message ?: "Failed to send message.") }
                            }
                        },
                        onCallPeer = { pid, pName, cType -> launchCall(pid, pName, cType) }
                    )
                    return
                }
            }

            SubScreen.SAVED -> {
                SavedPostsScreen(
                    posts = savedPosts,
                    listState = savedScrollState,
                    onBack = { subScreen = SubScreen.NONE },
                    onToggleLike = { post ->
                        scope.launch {
                            runCatching { repository.toggleLike(post.id, currentUid, post.isLiked) }
                            runCatching { repository.fetchSavedPosts(currentUid) }.onSuccess { savedPosts = it }
                            runCatching { repository.fetchFeedPosts(currentUid) }.onSuccess { posts = it }
                        }
                    },
                    onToggleSave = { post ->
                        scope.launch {
                            runCatching { repository.toggleSavePost(post.id, currentUid, post.isSaved) }
                            runCatching { repository.fetchSavedPosts(currentUid) }.onSuccess { savedPosts = it }
                            runCatching { repository.fetchFeedPosts(currentUid) }.onSuccess { posts = it }
                        }
                    },
                    onOpenComments = { post ->
                        commentsPost = post
                        commentsLoading = true
                        scope.launch {
                            runCatching { repository.fetchComments(post.id) }.onSuccess { commentsList = it }
                            commentsLoading = false
                        }
                    },
                    onOpenAuthor = { authorId ->
                        scope.launch {
                            runCatching { repository.fetchProfile(authorId) }.onSuccess {
                                inspectedUser = it
                                subScreen = SubScreen.USER_PROFILE
                            }
                        }
                    }
                )
                return
            }

            SubScreen.PROFILE -> {
                val me = currentUser ?: Profile(id = currentUid, displayName = "ABSU Student")
                EditProfileScreen(
                    profile = me,
                    onBack = { subScreen = SubScreen.NONE },
                    onSave = { updated ->
                        scope.launch {
                            runCatching { repository.updateProfile(updated) }
                                .onSuccess {
                                    currentUser = updated
                                    toast("Profile saved.")
                                    subScreen = SubScreen.NONE
                                }
                                .onFailure { toast(it.message ?: "Could not update profile.") }
                        }
                    }
                )
                return
            }

            SubScreen.USER_PROFILE -> {
                val target = inspectedUser
                if (target != null) {
                    UserProfileScreen(
                        user = target,
                        onBack = { subScreen = SubScreen.NONE },
                        onMessage = { peer ->
                            scope.launch {
                                runCatching {
                                    repository.startOrGetDirectConversation(currentUid, peer.id, peer.displayName)
                                }.onSuccess { cid ->
                                    activeConversation = ConversationItem(
                                        id = cid,
                                        title = peer.displayName,
                                        isGroup = false,
                                        lastMessageAt = Instant.now().toString(),
                                        peerId = peer.id,
                                        peerAvatar = peer.avatarUrl
                                    )
                                    runCatching { repository.fetchChatMessages(cid) }.onSuccess { chatMessages = it }
                                    subScreen = SubScreen.CHAT
                                }
                            }
                        },
                        onCall = { pid, pName, cType -> launchCall(pid, pName, cType) }
                    )
                    return
                }
            }

            else -> Unit
        }

        val unreadAlertCount = alerts.count { !it.isRead }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AbsuMonogramBadge(size = 30.dp)
                            Text("ABSU Connect", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { refreshAll(currentUid) }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    AppTab.entries.forEach { tab ->
                        val icon = when (tab) {
                            AppTab.HOME -> Icons.Default.Home
                            AppTab.FRIENDS -> Icons.Default.People
                            AppTab.MESSAGES -> Icons.Default.ChatBubbleOutline
                            AppTab.ALERTS -> Icons.Default.Notifications
                            AppTab.MORE -> Icons.Default.Menu
                        }
                        NavigationBarItem(
                            selected = activeTab == tab,
                            onClick = {
                                activeTab = tab
                                subScreen = SubScreen.NONE
                            },
                            icon = {
                                if (tab == AppTab.ALERTS && unreadAlertCount > 0) {
                                    BadgedBox(badge = { Badge { Text("$unreadAlertCount") } }) {
                                        Icon(icon, contentDescription = tab.label)
                                    }
                                } else {
                                    Icon(icon, contentDescription = tab.label)
                                }
                            },
                            label = { Text(tab.label, fontSize = 11.sp, maxLines = 1) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (activeTab) {
                    AppTab.HOME -> {
                        HomeScreen(
                            currentUser = currentUser,
                            posts = posts,
                            loading = feedLoading,
                            listState = homeScrollState,
                            onRefresh = { refreshAll(currentUid) },
                            onOpenCreatePost = { subScreen = SubScreen.CREATE_POST },
                            onToggleLike = { post ->
                                scope.launch {
                                    runCatching { repository.toggleLike(post.id, currentUid, post.isLiked) }
                                    runCatching { repository.fetchFeedPosts(currentUid) }.onSuccess { posts = it }
                                }
                            },
                            onToggleSave = { post ->
                                scope.launch {
                                    runCatching { repository.toggleSavePost(post.id, currentUid, post.isSaved) }
                                        .onSuccess { toast(if (post.isSaved) "Removed from Saved." else "Saved post.") }
                                    runCatching { repository.fetchFeedPosts(currentUid) }.onSuccess { posts = it }
                                }
                            },
                            onOpenComments = { post ->
                                commentsPost = post
                                commentsLoading = true
                                scope.launch {
                                    runCatching { repository.fetchComments(post.id) }.onSuccess { commentsList = it }
                                    commentsLoading = false
                                }
                            },
                            onOpenAuthorProfile = { uid ->
                                scope.launch {
                                    runCatching { repository.fetchProfile(uid) }.onSuccess {
                                        inspectedUser = it
                                        subScreen = SubScreen.USER_PROFILE
                                    }
                                }
                            }
                        )
                    }

                    AppTab.FRIENDS -> {
                        FriendsScreen(
                            currentUser = currentUser,
                            currentUserId = currentUid,
                            activeSubTab = friendSubTab,
                            onSelectSubTab = { friendSubTab = it },
                            friendships = friendships,
                            candidates = candidates,
                            discoverListState = discoverScrollState,
                            requestsListState = requestsScrollState,
                            sentListState = sentScrollState,
                            friendsListState = friendsScrollState,
                            onSendFriendRequest = { targetId ->
                                scope.launch {
                                    runCatching { repository.sendFriendRequest(currentUid, targetId) }
                                        .onSuccess { toast("Friend request sent."); refreshAll(currentUid) }
                                        .onFailure { toast(it.message ?: "Request failed.") }
                                }
                            },
                            onRespondRequest = { fid, requesterId, accept ->
                                scope.launch {
                                    runCatching { repository.respondFriendRequest(fid, requesterId, accept) }
                                        .onSuccess {
                                            toast(if (accept) "Friend request accepted." else "Request declined.")
                                            refreshAll(currentUid)
                                        }
                                }
                            },
                            onCancelRequest = { fid ->
                                scope.launch {
                                    runCatching { repository.cancelFriendRequest(fid) }
                                        .onSuccess { toast("Request cancelled."); refreshAll(currentUid) }
                                }
                            },
                            onMessagePeer = { peer ->
                                scope.launch {
                                    runCatching {
                                        repository.startOrGetDirectConversation(currentUid, peer.id, peer.displayName)
                                    }.onSuccess { cid ->
                                        activeConversation = ConversationItem(
                                            id = cid,
                                            title = peer.displayName,
                                            isGroup = false,
                                            lastMessageAt = Instant.now().toString(),
                                            peerId = peer.id,
                                            peerAvatar = peer.avatarUrl
                                        )
                                        runCatching { repository.fetchChatMessages(cid) }.onSuccess { chatMessages = it }
                                        subScreen = SubScreen.CHAT
                                    }
                                }
                            },
                            onCallPeer = { pid, pName, cType -> launchCall(pid, pName, cType) },
                            onOpenUserProfile = { uid ->
                                scope.launch {
                                    runCatching { repository.fetchProfile(uid) }.onSuccess {
                                        inspectedUser = it
                                        subScreen = SubScreen.USER_PROFILE
                                    }
                                }
                            }
                        )
                    }

                    AppTab.MESSAGES -> {
                        MessagesScreen(
                            conversations = conversations,
                            listState = messagesScrollState,
                            onOpenConversation = { conv ->
                                activeConversation = conv
                                scope.launch {
                                    runCatching { repository.fetchChatMessages(conv.id) }.onSuccess { chatMessages = it }
                                    subScreen = SubScreen.CHAT
                                }
                            }
                        )
                    }

                    AppTab.ALERTS -> {
                        AlertsScreen(
                            alerts = alerts,
                            listState = alertsScrollState,
                            onAlertClick = { alert ->
                                scope.launch {
                                    if (!alert.isRead) {
                                        runCatching { repository.markAlertRead(alert.id) }
                                        runCatching { repository.fetchAlerts(currentUid) }.onSuccess { alerts = it }
                                    }
                                }
                                val dest = NotificationRouter.resolveDestination(alert.type, alert.entityType)
                                activeTab = dest.tab
                                dest.friendTab?.let { friendSubTab = it }
                            },
                            onMarkAllRead = {
                                scope.launch {
                                    runCatching { repository.markAllAlertsRead(currentUid) }
                                    runCatching { repository.fetchAlerts(currentUid) }.onSuccess { alerts = it }
                                }
                            }
                        )
                    }

                    AppTab.MORE -> {
                        MoreScreen(
                            currentUser = currentUser,
                            lowDataMode = lowDataMode,
                            listState = moreScrollState,
                            onOpenProfile = { subScreen = SubScreen.PROFILE },
                            onOpenSaved = { subScreen = SubScreen.SAVED },
                            onToggleLowData = {
                                val next = !lowDataMode
                                NetworkMode.setLowData(this@MainActivity, next)
                                lowDataMode = next
                                toast(if (next) "Low data mode enabled." else "Low data mode disabled.")
                            },
                            onSignOut = {
                                scope.launch {
                                    liveAlerts?.close()
                                    liveAlerts = null
                                    repository.signOut()
                                    session = null
                                }
                            }
                        )
                    }
                }
            }
        }

        commentsPost?.let { post ->
            CommentsDialog(
                post = post,
                comments = commentsList,
                loading = commentsLoading,
                onDismiss = { commentsPost = null },
                onSendComment = { text ->
                    scope.launch {
                        runCatching { repository.addComment(post.id, currentUid, text) }
                            .onSuccess {
                                runCatching { repository.fetchComments(post.id) }.onSuccess { commentsList = it }
                                runCatching { repository.fetchFeedPosts(currentUid) }.onSuccess { posts = it }
                            }
                            .onFailure { toast(it.message ?: "Could not post comment.") }
                    }
                }
            )
        }
    }

    private fun launchCall(peerId: String, peerName: String, type: String) {
        startActivity(
            Intent(this, CallActivity::class.java)
                .putExtra("peer_id", peerId)
                .putExtra("peer_name", peerName)
                .putExtra("call_type", type)
                .putExtra("outgoing", true)
                .putExtra("incoming", false)
        )
    }

    private fun startLiveAlerts(session: AuthSession) {
        liveAlerts?.close()
        liveAlerts = RealtimeNotificationSubscription().apply {
            subscribe(session, object : RealtimeNotificationSubscription.Listener {
                override fun onNotification(row: JSONObject) {
                    runOnUiThread {
                        val title = row.optString("title", "ABSU Connect Alert")
                        val body = row.optString("body", "You have a new update.")
                        showLocalNotification(title, body, kotlin.math.abs(row.optString("id", System.nanoTime().toString()).hashCode()))
                        liveAlertSignal.intValue++
                    }
                }

                override fun onDisconnected(reason: String) {}
            })
        }
    }

    private fun registerFirebasePushToken(userId: String) {
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (!task.isSuccessful || task.result == null) return@addOnCompleteListener
                val token = task.result
                getSharedPreferences("absu_native_push", MODE_PRIVATE).edit()
                    .putString("registered_fcm_token", token)
                    .apply()
                Thread {
                    try {
                        repository.api.postArray(
                            "device_push_tokens?on_conflict=user_id,token",
                            JSONObject()
                                .put("user_id", userId)
                                .put("token", token)
                                .put("platform", "android")
                                .put("updated_at", Instant.now().toString()),
                            "resolution=merge-duplicates,return=minimal"
                        )
                    } catch (_: Exception) { }
                }.start()
            }
        } catch (_: Exception) { }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            val general = NotificationChannel(CHANNEL_GENERAL, "ABSU Connect Notifications", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Messages, friend activity and campus alerts"
                enableVibration(true)
            }
            val calls = NotificationChannel(CHANNEL_CALLS, "ABSU Connect Calls", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Incoming voice and video call alerts"
                enableVibration(true)
            }
            manager.createNotificationChannel(general)
            manager.createNotificationChannel(calls)
        }
    }

    private fun showLocalNotification(title: String, message: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(this, CHANNEL_GENERAL)
            .setSmallIcon(R.drawable.ic_absu_logo)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(this).notify(id, n)
    }

    private fun toast(msg: String) {
        runOnUiThread {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun applyLaunchIntent(intent: Intent?) {
        val target = intent?.getStringExtra("absu_open_page") ?: return
        externalNavPage.value = target
        externalFriendTab.value = intent.getStringExtra("absu_friend_tab")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyLaunchIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        isForeground = true
    }

    override fun onStop() {
        isForeground = false
        liveAlerts?.close()
        liveAlerts = null
        super.onStop()
    }

    override fun onDestroy() {
        liveAlerts?.close()
        super.onDestroy()
    }
}
